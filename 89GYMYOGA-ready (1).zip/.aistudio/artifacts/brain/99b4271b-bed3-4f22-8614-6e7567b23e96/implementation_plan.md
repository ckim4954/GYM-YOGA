# 89 FITNESS & YOGA — Version 2.0 (Cyber Fitness Management)

Bản nâng cấp toàn diện giao diện và trải nghiệm người dùng theo phong cách **Premium Cyber Fitness Dashboard**, khắc phục triệt để các lỗi vỡ bố cục trên màn hình nhỏ (đặc biệt tại trang **Cài đặt** và chế độ **Light Mode**), chuẩn hóa tự động thời hạn **Bảng giá Yoga (1, 2, 3 tháng)**, đồng bộ hệ thống biểu tượng Material Icons và thiết kế mới biểu tượng ứng dụng **Cyber 89** — đồng thời bảo toàn tuyệt đối 100% cơ sở dữ liệu Room, công thức tài chính và lịch sử hợp đồng hiện có.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> Các quyết định thiết kế và nghiệp vụ dưới đây đã được xác nhận và tuân thủ nghiêm ngặt nguyên tắc **Bảo toàn dữ liệu & Không thay đổi công thức doanh thu**:

- **Confirmed Decision 1 — Bố cục trang Cài đặt**: Tổ chức lại thành **Danh sách cuộn dọc chia theo từng nhóm chức năng riêng biệt** (Giao diện & Hiển thị, Bảng giá GYM & YOGA, Sao lưu & Khôi phục Đám mây / Cục bộ, Thùng rác khôi phục, Kiểm thử công thức) kết hợp thanh nhảy nhanh gọn gàng, chấm dứt hoàn toàn tình trạng tiêu đề bị ép hẹp xuống dòng từng chữ hoặc tràn nút ngang.
- **Confirmed Decision 2 — Biểu tượng ứng dụng (Launcher Icon Cyber 89)**: Thiết kế Android Adaptive Icon mới với **Số 89 kim loại 3D viền sáng Electric Blue và Cyber Purple trên nền Deep Navy (`#0A111F`)**, hiển thị sắc nét trên mọi màn hình chính Android.
- **Confirmed Decision 3 — Chuẩn hóa Bảng giá & Hợp đồng Yoga**: Cấu hình chính xác 3 gói mặc định (`Yoga 1 tháng` = `500.000đ` / `1 tháng`, `Yoga 2 tháng` = `1.000.000đ` / `2 tháng`, `Yoga 3 tháng` = `1.500.000đ` / `3 tháng`), tự động nâng cấp dữ liệu bảng giá Yoga chưa có thời hạn trong DB hiện hữu và xóa bỏ hoàn toàn các thông báo nhắc cấu hình thủ công.
- **Confirmed Decision 4 — Bảo toàn Package ID & Cơ sở dữ liệu**: Giữ nguyên `applicationId = "com.aistudio.gymyogamanager.vnhq"` và toàn bộ 9 bảng dữ liệu Room để bản cài đặt mới có thể cập nhật trực tiếp lên APK hiện tại mà không mất dữ liệu.

---

## 1. Overview & Core Concept

- **What It Does**: Hệ thống quản lý hội viên GYM, hội viên YOGA, hợp đồng PT, vé tập lẻ theo ngày/tuần, theo dõi hạn tập trực quan bằng mắt và báo cáo tài chính kép (Doanh thu dòng tiền thực thu & Doanh thu phân bổ theo ngày/buổi thực tế) kèm xuất báo cáo PDF A4, Excel và sao lưu Google Drive.
- **Target Audience / Persona**: Chủ phòng tập và quản lý vận hành tại **89 FITNESS & YOGA** sử dụng điện thoại Android bằng một tay để tra cứu nhanh, đăng ký/gia hạn hợp đồng và đối soát tài chính hàng ngày.
- **Key Value**: Giao diện **Modern Cyber Fitness** sắc nét, tương phản chuẩn xác ở cả Light Mode lẫn Dark Mode, bố cục thích ứng linh hoạt (`BoxWithConstraints` & `FlowRow`) không bao giờ bị tràn chữ hay che khuất bởi nút nổi (FAB), và tự động tính hạn hợp đồng Yoga chính xác tuyệt đối.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Quản lý GYM & YOGA**:
   - Thẻ tổng quan hiển thị 3 chỉ số (`Tổng hội viên`, `Đang còn hạn`, `Đã hết hạn`) cân đối theo chiều rộng màn hình cùng huy hiệu gợi ý STT tiếp theo.
   - Tại màn hình **YOGA**, khi bấm **Thêm HV Yoga** hoặc **Gia hạn**, chọn gói `Yoga 1 tháng (500.000đ)`, `Yoga 2 tháng (1.000.000đ)` hoặc `Yoga 3 tháng (1.500.000đ)` sẽ lập tức tự động tính **Ngày bắt đầu** và **Ngày hết hạn (ngày tập cuối cùng)** theo đúng số tháng của gói (ví dụ: đăng ký gói 2 tháng ngày `07/11/2026` tự động tính hạn tập cuối đến `06/01/2027`, kết thúc độc quyền nội bộ `07/01/2027`).
   - Vùng đệm đáy danh sách (`bottom = 112.dp`) đảm bảo nút nổi **Floating Action Button** không bao giờ che khuất nút **Gia hạn** hoặc thông tin của hội viên cuối danh sách.
2. **Màn hình Cài đặt (Responsive Vertical Sections)**:
   - Thanh tiêu đề cố định (Sticky Header) gọn gàng gồm nút **Quay lại**, tiêu đề **Cài đặt** hiển thị trên một dòng rõ ràng và nút chuyển nhanh chế độ Sáng/Tối dạng biểu tượng tinh gọn.
   - Nội dung bên dưới cuộn dọc mượt mà qua các thẻ chức năng độc lập:
     1. **Giao diện & Chế độ hiển thị** (Light Mode / Dark Mode / Theo hệ thống Android — bố trí bằng lưới thích ứng không tràn ngang).
     2. **Bảng giá & Gói tập GYM / YOGA** (Hiển thị rõ Tên gói, Thời hạn và Giá tiền với các nút Sửa/Xóa căn chỉnh chuẩn xác).
     3. **Sao lưu & Khôi phục dữ liệu** (Google Drive API thực tế + Xuất/Nhập file JSON cục bộ).
     4. **Thùng rác & Khôi phục dữ liệu đã xóa**.
     5. **Chẩn đoán & Kiểm thử công thức tài chính**.
3. **Doanh thu & Theo dõi**:
   - Màn hình **DOANH THU** hiển thị bộ chọn tháng/năm, bộ lọc bộ môn dạng `FlowRow` tự co giãn, biểu đồ so sánh trực quan giữa **Doanh thu dòng tiền** và **Doanh thu phân bổ**, cùng cụm nút xuất **PDF A4** và **Excel** có icon rõ ràng.
   - Màn hình **THEO DÕI** hiển thị 5 thẻ đếm trạng thái có icon đồng bộ và danh sách hội viên ưu tiên người sắp hết hạn lên đầu.

### Visual Identity & Theme (Modern Cyber Fitness)
- **Aesthetic Direction**: **Premium Cyber Fitness Dashboard — Modern SaaS**. Tinh tế, có chiều sâu công nghệ, phân cấp thị giác rõ ràng cho từng phân hệ mà không lạm dụng màu sắc lòe loẹt.
- **Color Palette & Mood**:
  - **Dark Mode (Cyber Navy Charcoal)**:
    - `--background`: `#0A0F18` (Dark Navy) | YOGA: `#0E0B16`
    - `--surface`: `#111927` (Navy Blue) | YOGA: `#171224`
    - `--card`: `#182334` (Layered Slate Navy) | YOGA: `#201931`
    - `--primary`: `#2997FF` (Electric Blue cho GYM) / `#B366FF` (Cyber Purple cho YOGA)
    - `--secondary`: `#00D2FF` (Metallic Cyan) / `#D4A5FF` (Soft Lavender)
    - `--text-primary`: `#F1F5F9` | `--text-secondary`: `#94A3B8` | `--border`: `#26354D`
  - **Light Mode (High-Contrast Daylight SaaS)**:
    - `--background`: `#F4F6F9` (Cool Light Gray) | YOGA: `#F7F4FA`
    - `--surface`: `#FFFFFF` (Pure Crisp White)
    - `--card`: `#FFFFFF` với vùng phụ `#F8FAFC`
    - `--primary`: `#0F4C81` (Deep Electric Navy cho GYM) / `#6B2FB5` (Cyber Violet đậm cho YOGA)
    - `--secondary`: `#0284C7` (Metallic Blue) / `#8B5CF6` (Violet)
    - `--text-primary`: `#0F172A` (Deep Slate Ink — tương phản tuyệt đối trên nền trắng)
    - `--text-secondary`: `#475569` (Muted Slate)
    - `--border`: `#CBD5E1`
  - **Semantic Status Colors (Đồng bộ DOANH THU & THEO DÕI)**:
    - *Success (Còn hạn / Thực thu)*: Emerald Green (`#059669` Light / `#34D399` Dark)
    - *Warning (Sắp hết hạn)*: Amber (`#D97706` Light / `#FBBF24` Dark) & Deep Orange (`#EA580C` Light / `#FB923C` Dark)
    - *Error (Đã hết hạn / Nợ)*: Crimson Red (`#DC2626` Light / `#F87171` Dark)
- **Typography & Synchronized Icon System**:
  - Sử dụng bộ font **Inter** với `tabular-nums` cho toàn bộ con số tài chính và ngày tháng.
  - Thay thế các nhãn thuần chữ bằng hệ thống **Material Icons** đồng bộ theo từng phân hệ:
    - **GYM**: `FitnessCenter`, `Person`, `Groups`, `PersonAdd`, `Search`, `Edit`, `DeleteOutline`, `CalendarMonth`, `EventAvailable`, `Payments`, `Description`.
    - **YOGA**: `SelfImprovement`, `Spa`, `AccessibilityNew`, `Event`, `Person`, `Groups`, `CalendarMonth`.
    - **DOANH THU**: `AccountBalanceWallet`, `Payments`, `TrendingUp`, `BarChart`, `Analytics`, `ReceiptLong`, `PictureAsPdf`, `TableChart`.
    - **THEO DÕI**: `Visibility`, `NotificationsActive`, `Schedule`, `EventBusy`, `WarningAmber`, `CheckCircle`.
    - **SETTINGS**: `Settings`, `Palette`, `Backup`, `Restore`, `PriceChange`, `Science`, `Storage`.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Tự động chuẩn hóa dữ liệu Bảng giá Yoga hiện có mà không cần xóa App**
  - *Chosen Approach*: Khi khởi chạy ứng dụng, hàm `ensureDefaultPricingSeeded()` không chỉ tạo bảng giá khi DB trống mà còn kiểm tra các gói Yoga mặc định (`PKG_YOGA_1`, `PKG_YOGA_2`, `PKG_YOGA_3`). Nếu các gói này đang có `soThang == null` hoặc tên cũ `"Gói 1"`, `"Gói 2"`, `"Gói 3"`, hệ thống tự động cập nhật thành `Yoga 1 tháng` (`1 tháng`, `500.000đ`), `Yoga 2 tháng` (`2 tháng`, `1.000.000đ`), `Yoga 3 tháng` (`3 tháng`, `1.500.000đ`).
  - *Why*: Đảm bảo người dùng nâng cấp từ phiên bản APK cũ nhận ngay bảng giá Yoga có đầy đủ thời hạn mà không làm ảnh hưởng đến bất kỳ hợp đồng hay hội viên nào đã lưu trước đó.
- **Decision 2: Bố cục Responsive đa tầng với `BoxWithConstraints` và `FlowRow`**
  - *Chosen Approach*: Loại bỏ các thanh chip ngang cố định gây tràn màn hình và loại bỏ nút chuyển giao diện dài trên thanh tiêu đề Cài đặt. Sử dụng `BoxWithConstraints` cho các lưới chỉ số thống kê và `FlowRow` cho các nhóm nút chọn gói tập, bộ lọc, chế độ giao diện.
  - *Why*: Đảm bảo ứng dụng hiển thị cân đối trên cả màn hình điện thoại nhỏ (320dp–360dp), màn hình tiêu chuẩn và khi người dùng bật cỡ chữ lớn trên Android.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram
```
┌─────────────────────────────────────────────────────────────────────────────┐
│                   89 FITNESS & YOGA (MVVM + Clean Architecture)             │
├─────────────────────────────────────────────────────────────────────────────┤
│  UI Layer (Jetpack Compose + Cyber Fitness Design System)                   │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │ Sticky Top Header Bar (Brand Emblem "89" + Module Title + Settings)   │  │
│  └───────────────┬───────────────────┬───────────────────┬───────────────┘  │
│                  ▼                   ▼                   ▼                  │
│  ┌───────────────────────┐ ┌───────────────────┐ ┌───────────────────────┐  │
│  │  GYM / YOGA Screens   │ │  DOANH THU Screen │ │   THEO DÕI Screen     │  │
│  │ • Responsive 3-Stat   │ │ • Month/Year Nav  │ │ • 5 Status Counters   │  │
│  │   Overview Header     │ │ • Cash vs Alloc   │ │   with Material Icons │  │
│  │ • Quick Walk-in Bar   │ │   Comparison Bar  │ │ • 1-Tap Filter & Sort │  │
│  │ • Member/PT/Walk-in   │ │ • Traceable Drill │ │ • Expiry-First Cards  │  │
│  │   Cards + Safe FAB    │ │   Down + PDF/XLS  │ │   + Quick Renew       │  │
│  └───────────┬───────────┘ └─────────┬─────────┘ └───────────┬───────────┘  │
│              └───────────────────────┼───────────────────────┘              │
│                                      ▼                                      │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │       SETTINGS Screen (Vertical Scrollable Section Cards)             │  │
│  │  [1. Giao diện (Light/Dark/System)]  [2. Bảng giá GYM & YOGA (1/2/3T)]│  │
│  │  [3. Sao lưu Google Drive & JSON]    [4. Thùng rác & Kiểm thử]        │  │
│  └───────────────────────────────────┬───────────────────────────────────┘  │
├──────────────────────────────────────┼──────────────────────────────────────┤
│  Domain & ViewModel Layer            ▼                                      │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │ GymYogaViewModel + FinancialEngine (7/7 Golden Tests Verified)        │  │
│  │ • Yoga Package Auto-Duration Calculation (1M / 2M / 3M)               │  │
│  │ • Renewal Rules (Early / Exact / Post-Gap) + Daily & Session Prorata  │  │
│  └───────────────────────────────────┬───────────────────────────────────┘  │
├──────────────────────────────────────┼──────────────────────────────────────┤
│  Persistence & External Services     ▼                                      │
│  ┌─────────────────────────────────┐ ┌───────────────────────────────────┐  │
│  │ Room Database (9 Tables Intact) │ │ ReportExporter & Drive Backup     │  │
│  │ • Auto-Upgrade Yoga Seed Logic  │ │ • Print-Friendly A4 PDF & CSV/XLS │  │
│  │ • Zero Destructive Migration    │ │ • Google Drive REST v3 + Safety   │  │
│  └─────────────────────────────────┘ └───────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State
- **Room Database Preservation**: Giữ nguyên phiên bản và cấu trúc 9 bảng dữ liệu (`members`, `member_contracts`, `payment_transactions`, `pricing_packages`, `pt_contracts`, `pt_sessions`, `walk_in_tickets`, `app_config`, `audit_logs`).
- **Yoga Package Auto-Upgrade**: Trong `GymYogaRepository.ensureDefaultPricingSeeded()`, ngoài việc khởi tạo khi bảng trống, bổ sung bước đồng bộ an toàn cho 3 gói Yoga mặc định (`PKG_YOGA_1` -> `Yoga 1 tháng`, `soThang = 1`, `500.000đ`; `PKG_YOGA_2` -> `Yoga 2 tháng`, `soThang = 2`, `1.000.000đ`; `PKG_YOGA_3` -> `Yoga 3 tháng`, `soThang = 3`, `1.500.000đ`) nếu bản ghi hiện tại chưa có `soThang`.

### Interactive Component & State Mapping
- **Theme Switching (`LIGHT`, `DARK`, `SYSTEM`)**: Chọn bất kỳ chế độ nào trong mục **Giao diện hiển thị** sẽ lưu ngay vào `app_config` (`THEME_MODE`) và cập nhật tức thì toàn bộ `MaterialTheme.colorScheme` lẫn `LocalAppDesignTokens` (bao gồm cả `OutlinedTextField`, `FilterChip`, `Dialog`, `NavigationBar` và `Surface`), đảm bảo không bao giờ xảy ra hiện tượng chữ trắng trên nền trắng hoặc chữ tối trên nền tối.
- **Yoga Contract Creation & Renewal**: Khi chọn gói trong `MemberRegistrationOrRenewalDialog`, `LaunchedEffect` tự động đọc `pkg.soThang` (1, 2 hoặc 3 tháng) và tính ngay `ngayKetThucDocQuyen` cùng ngày tập cuối cùng hiển thị (`lastTrainingDateDisplay`) theo quy tắc lịch thực tế.
- **Cyber 89 Adaptive Icon**: Tạo tài nguyên hình ảnh biểu tượng **Cyber 89** kim loại 3D phát sáng Electric Blue & Cyber Purple trên nền `#0A111F`, cấu hình chuẩn `ic_launcher_foreground.xml`, `ic_launcher_background.xml` và bộ ảnh PNG vuông/tròn cho toàn bộ 5 mật độ màn hình `mipmap-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}`.
