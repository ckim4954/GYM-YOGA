package com.example

import com.example.domain.DateUtils
import com.example.domain.FinancialEngine
import com.example.domain.LocalDateSpec
import com.example.domain.MemberTrackingStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `verify all 7 mandatory Golden Test Cases pass`() {
        val results = FinancialEngine.runAllGoldenTestCases()
        assertEquals(7, results.size)
        results.forEach { result ->
            assertTrue(
                "Golden Test ${result.id} (${result.title}) failed: expected [${result.expectedDisplay}] but got [${result.actualDisplay}]",
                result.passed
            )
        }
    }

    @Test
    fun `verify renewal rules Case 1, Case 2, and Case 3`() {
        // Old contract: 15/07/2026 to last training day 14/08/2026 -> exclusive end = 15/08/2026
        val oldEndExclusive = LocalDateSpec(2026, 8, 15)

        // Case 1: Early renewal on 10/08/2026 -> new start date must be 15/08/2026
        val case1Start = FinancialEngine.calculateRenewalStartDate(
            previousEndExclusive = oldEndExclusive,
            renewalDate = LocalDateSpec(2026, 8, 10)
        )
        assertEquals(LocalDateSpec(2026, 8, 15), case1Start)

        // Case 2: Exact next-cycle renewal on 15/08/2026 -> new start date must be 15/08/2026
        val case2Start = FinancialEngine.calculateRenewalStartDate(
            previousEndExclusive = oldEndExclusive,
            renewalDate = LocalDateSpec(2026, 8, 15)
        )
        assertEquals(LocalDateSpec(2026, 8, 15), case2Start)

        // Case 3: Renew after gap on 25/08/2026 -> new start date must be 25/08/2026
        val case3Start = FinancialEngine.calculateRenewalStartDate(
            previousEndExclusive = oldEndExclusive,
            renewalDate = LocalDateSpec(2026, 8, 25)
        )
        assertEquals(LocalDateSpec(2026, 8, 25), case3Start)
    }

    @Test
    fun `verify full contract schedule sum equals contract amount`() {
        val start = LocalDateSpec(2026, 10, 6)
        val endEx = LocalDateSpec(2026, 11, 6)
        val schedule = FinancialEngine.generateFullContractSchedule(start, endEx, 250_000L)
        assertEquals(2, schedule.size)
        assertEquals(209_677L, schedule[0].allocatedAmount)
        assertEquals(40_323L, schedule[1].allocatedAmount)
        assertEquals(250_000L, schedule.sumOf { it.allocatedAmount })
    }

    @Test
    fun `verify tracking status 5 tiers`() {
        val today = LocalDateSpec(2026, 8, 10)

        // Expired yesterday (last training day 09/08 -> endExclusive 10/08)
        val (statusExpired, remExpired) = FinancialEngine.evaluateTrackingStatus(today, LocalDateSpec(2026, 8, 10))
        assertEquals(MemberTrackingStatus.EXPIRED, statusExpired)
        assertEquals(-1, remExpired)

        // Expiring today (last training day 10/08 -> endExclusive 11/08)
        val (statusToday, remToday) = FinancialEngine.evaluateTrackingStatus(today, LocalDateSpec(2026, 8, 11))
        assertEquals(MemberTrackingStatus.EXPIRING_TODAY, statusToday)
        assertEquals(0, remToday)

        // Expiring in 5 days (1..7)
        val (status7, rem7) = FinancialEngine.evaluateTrackingStatus(today, DateUtils.toExclusiveEndDate(today.plusDays(5)))
        assertEquals(MemberTrackingStatus.EXPIRING_1_TO_7, status7)
        assertEquals(5, rem7)

        // Expiring in 10 days (8..15)
        val (status15, rem15) = FinancialEngine.evaluateTrackingStatus(today, DateUtils.toExclusiveEndDate(today.plusDays(10)))
        assertEquals(MemberTrackingStatus.EXPIRING_8_TO_15, status15)
        assertEquals(10, rem15)

        // Active > 15 days (20 days)
        val (statusActive, remActive) = FinancialEngine.evaluateTrackingStatus(today, DateUtils.toExclusiveEndDate(today.plusDays(20)))
        assertEquals(MemberTrackingStatus.ACTIVE_OVER_15, statusActive)
        assertEquals(20, remActive)
    }
}
