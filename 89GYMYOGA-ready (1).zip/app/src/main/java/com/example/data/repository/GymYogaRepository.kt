package com.example.data.repository

import com.example.data.local.AppConfigEntity
import com.example.data.local.AppDao
import com.example.data.local.AuditLogEntity
import com.example.data.local.BoMon
import com.example.data.local.DoiTuong
import com.example.data.local.LoaiBaoCao
import com.example.data.local.LoaiHopDong
import com.example.data.local.MemberContractEntity
import com.example.data.local.MemberEntity
import com.example.data.local.PaymentTransactionEntity
import com.example.data.local.PricingPackageEntity
import com.example.data.local.PtContractEntity
import com.example.data.local.PtSessionEntity
import com.example.data.local.TrangThaiThanhToan
import com.example.data.local.WalkInTicketEntity
import java.util.UUID
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

class GymYogaRepository(private val dao: AppDao) {

    val activeMembers: Flow<List<MemberEntity>> = dao.observeAllActiveMembers()
    val deletedMembers: Flow<List<MemberEntity>> = dao.observeDeletedMembers()
    val activeContracts: Flow<List<MemberContractEntity>> = dao.observeAllActiveContracts()
    val deletedContracts: Flow<List<MemberContractEntity>> = dao.observeDeletedContracts()
    val allPayments: Flow<List<PaymentTransactionEntity>> = dao.observeAllPayments()
    val activePackages: Flow<List<PricingPackageEntity>> = dao.observeActivePackages()
    val activePtContracts: Flow<List<PtContractEntity>> = dao.observeActivePtContracts()
    val deletedPtContracts: Flow<List<PtContractEntity>> = dao.observeDeletedPtContracts()
    val allPtSessions: Flow<List<PtSessionEntity>> = dao.observeAllPtSessions()
    val activeWalkInTickets: Flow<List<WalkInTicketEntity>> = dao.observeActiveWalkInTickets()
    val deletedWalkInTickets: Flow<List<WalkInTicketEntity>> = dao.observeDeletedWalkInTickets()
    val configs: Flow<List<AppConfigEntity>> = dao.observeConfigs()
    val auditLogs: Flow<List<AuditLogEntity>> = dao.observeRecentAuditLogs()

    /**
     * Khởi tạo bảng giá mặc định theo đúng Phần 4 nếu cơ sở dữ liệu chưa có gói tập.
     * Lưu ý Phần 4.4: Thời hạn tương ứng của ba gói Yoga phải được cấu hình trong phần Cài đặt,
     * không tự suy diễn thời hạn nếu chưa được chủ phòng tập thiết lập (soThang = null).
     */
    suspend fun ensureDefaultPricingSeeded() {
        val count = dao.getPackageCount()
        if (count > 0) return

        val defaults = listOf(
            // 4.1. Bảng giá GYM nam
            PricingPackageEntity(
                id = "PKG_GYM_NAM_1M",
                boMon = BoMon.GYM,
                doiTuong = DoiTuong.NAM,
                tenGoi = "Gym Nam - 1 tháng",
                soThang = 1,
                giaTien = 300_000L,
                thuTuHienThi = 1
            ),
            PricingPackageEntity(
                id = "PKG_GYM_NAM_3M",
                boMon = BoMon.GYM,
                doiTuong = DoiTuong.NAM,
                tenGoi = "Gym Nam - 3 tháng",
                soThang = 3,
                giaTien = 800_000L,
                thuTuHienThi = 2
            ),
            PricingPackageEntity(
                id = "PKG_GYM_NAM_12M",
                boMon = BoMon.GYM,
                doiTuong = DoiTuong.NAM,
                tenGoi = "Gym Nam - 12 tháng",
                soThang = 12,
                giaTien = 3_000_000L,
                thuTuHienThi = 3
            ),
            // 4.2. Bảng giá GYM nữ
            PricingPackageEntity(
                id = "PKG_GYM_NU_1M",
                boMon = BoMon.GYM,
                doiTuong = DoiTuong.NU,
                tenGoi = "Gym Nữ - 1 tháng",
                soThang = 1,
                giaTien = 250_000L,
                thuTuHienThi = 4
            ),
            PricingPackageEntity(
                id = "PKG_GYM_NU_2M",
                boMon = BoMon.GYM,
                doiTuong = DoiTuong.NU,
                tenGoi = "Gym Nữ - 2 tháng",
                soThang = 2,
                giaTien = 500_000L,
                thuTuHienThi = 5
            ),
            PricingPackageEntity(
                id = "PKG_GYM_NU_3M",
                boMon = BoMon.GYM,
                doiTuong = DoiTuong.NU,
                tenGoi = "Gym Nữ - 3 tháng",
                soThang = 3,
                giaTien = 700_000L,
                thuTuHienThi = 6
            ),
            PricingPackageEntity(
                id = "PKG_GYM_NU_12M",
                boMon = BoMon.GYM,
                doiTuong = DoiTuong.NU,
                tenGoi = "Gym Nữ - 12 tháng",
                soThang = 12,
                giaTien = 2_800_000L,
                thuTuHienThi = 7
            ),
            // 4.3. Bảng giá GYM trẻ em
            PricingPackageEntity(
                id = "PKG_GYM_TE_1M",
                boMon = BoMon.GYM,
                doiTuong = DoiTuong.TRE_EM,
                tenGoi = "Gym Trẻ em - 1 tháng",
                soThang = 1,
                giaTien = 300_000L,
                thuTuHienThi = 8
            ),
            PricingPackageEntity(
                id = "PKG_GYM_TE_2M",
                boMon = BoMon.GYM,
                doiTuong = DoiTuong.TRE_EM,
                tenGoi = "Gym Trẻ em - 2 tháng",
                soThang = 2,
                giaTien = 500_000L,
                thuTuHienThi = 9
            ),
            PricingPackageEntity(
                id = "PKG_GYM_TE_3M",
                boMon = BoMon.GYM,
                doiTuong = DoiTuong.TRE_EM,
                tenGoi = "Gym Trẻ em - 3 tháng",
                soThang = 3,
                giaTien = 700_000L,
                thuTuHienThi = 10
            ),
            PricingPackageEntity(
                id = "PKG_GYM_TE_12M",
                boMon = BoMon.GYM,
                doiTuong = DoiTuong.TRE_EM,
                tenGoi = "Gym Trẻ em - 12 tháng",
                soThang = 12,
                giaTien = 2_400_000L,
                thuTuHienThi = 11
            ),
            // 4.4. Bảng giá YOGA (soThang = null cho đến khi chủ phòng tập cấu hình)
            PricingPackageEntity(
                id = "PKG_YOGA_1",
                boMon = BoMon.YOGA,
                doiTuong = DoiTuong.YOGA_CHUNG,
                tenGoi = "Gói 1",
                soThang = null,
                giaTien = 500_000L,
                thuTuHienThi = 1
            ),
            PricingPackageEntity(
                id = "PKG_YOGA_2",
                boMon = BoMon.YOGA,
                doiTuong = DoiTuong.YOGA_CHUNG,
                tenGoi = "Gói 2",
                soThang = null,
                giaTien = 1_000_000L,
                thuTuHienThi = 2
            ),
            PricingPackageEntity(
                id = "PKG_YOGA_3",
                boMon = BoMon.YOGA,
                doiTuong = DoiTuong.YOGA_CHUNG,
                tenGoi = "Gói 3",
                soThang = null,
                giaTien = 1_500_000L,
                thuTuHienThi = 3
            )
        )
        dao.upsertPackages(defaults)
    }

    // --- HỘI VIÊN & HỢP ĐỒNG ---

    suspend fun createNewMemberAndContract(
        boMon: String,
        stt: Int,
        hoTen: String,
        soDienThoai: String,
        loaiKhach: String,
        goiTapId: String?,
        tenGoiTap: String,
        ngayDangKyIso: String,
        ngayBatDauIso: String,
        ngayKetThucDocQuyenIso: String,
        soTienHopDong: Long,
        soTienDaThu: Long,
        ngayThanhToanIso: String,
        ghiChuHoiVien: String,
        ghiChuHopDong: String
    ): String {
        val memberId = "HV-${boMon}-${UUID.randomUUID().toString().take(8).uppercase()}"
        val contractId = "HD-${boMon}-${UUID.randomUUID().toString().take(8).uppercase()}"
        val trangThaiTT = if (soTienDaThu >= soTienHopDong) {
            TrangThaiThanhToan.DA_THANH_TOAN
        } else {
            TrangThaiThanhToan.CON_NO
        }

        val member = MemberEntity(
            id = memberId,
            boMon = boMon,
            stt = stt,
            hoTen = hoTen.trim(),
            soDienThoai = soDienThoai.trim(),
            loaiKhach = loaiKhach,
            ngayTao = ngayDangKyIso,
            ghiChu = ghiChuHoiVien.trim(),
            trangThaiXoa = false
        )

        val contract = MemberContractEntity(
            id = contractId,
            hoiVienId = memberId,
            boMon = boMon,
            loaiBaoCao = LoaiBaoCao.CON_HAN,
            loaiHopDong = LoaiHopDong.DANG_KY_MOI,
            goiTapId = goiTapId,
            goiTap = tenGoiTap.trim(),
            ngayDangKy = ngayDangKyIso,
            ngayBatDau = ngayBatDauIso,
            ngayKetThucDocQuyen = ngayKetThucDocQuyenIso,
            soTienHopDong = soTienHopDong,
            soTienDaThu = soTienDaThu,
            ngayThanhToan = ngayThanhToanIso,
            trangThaiThanhToan = trangThaiTT,
            ghiChu = ghiChuHopDong.trim(),
            trangThaiXoa = false
        )

        val payment = if (soTienDaThu > 0L) {
            PaymentTransactionEntity(
                id = "TT-${UUID.randomUUID().toString().take(8).uppercase()}",
                hopDongId = contractId,
                hoiVienId = memberId,
                boMon = boMon,
                loaiNguon = "HOP_DONG_HOI_VIEN",
                soTien = soTienDaThu,
                ngayThanhToan = ngayThanhToanIso,
                ghiChu = "Thanh toán đăng ký mới ($tenGoiTap)"
            )
        } else null

        val log = AuditLogEntity(
            id = UUID.randomUUID().toString(),
            timestampMillis = System.currentTimeMillis(),
            actionType = "THEM_HOI_VIEN",
            description = "Thêm hội viên $boMon STT $stt - $hoTen ($tenGoiTap)"
        )

        dao.registerNewMemberWithContract(member, contract, payment, log)
        return memberId
    }

    suspend fun renewMemberContract(
        member: MemberEntity,
        loaiHopDong: String, // GIA_HAN hoặc DANG_KY_LAI
        loaiBaoCao: String = LoaiBaoCao.GIA_HAN,
        goiTapId: String?,
        tenGoiTap: String,
        ngayDangKyIso: String,
        ngayBatDauIso: String,
        ngayKetThucDocQuyenIso: String,
        soTienHopDong: Long,
        soTienDaThu: Long,
        ngayThanhToanIso: String,
        ghiChuHopDong: String
    ): String {
        val contractId = "HD-${member.boMon}-${UUID.randomUUID().toString().take(8).uppercase()}"
        val trangThaiTT = if (soTienDaThu >= soTienHopDong) {
            TrangThaiThanhToan.DA_THANH_TOAN
        } else {
            TrangThaiThanhToan.CON_NO
        }

        val contract = MemberContractEntity(
            id = contractId,
            hoiVienId = member.id,
            boMon = member.boMon,
            loaiBaoCao = loaiBaoCao,
            loaiHopDong = loaiHopDong,
            goiTapId = goiTapId,
            goiTap = tenGoiTap.trim(),
            ngayDangKy = ngayDangKyIso,
            ngayBatDau = ngayBatDauIso,
            ngayKetThucDocQuyen = ngayKetThucDocQuyenIso,
            soTienHopDong = soTienHopDong,
            soTienDaThu = soTienDaThu,
            ngayThanhToan = ngayThanhToanIso,
            trangThaiThanhToan = trangThaiTT,
            ghiChu = ghiChuHopDong.trim(),
            trangThaiXoa = false
        )

        val payment = if (soTienDaThu > 0L) {
            PaymentTransactionEntity(
                id = "TT-${UUID.randomUUID().toString().take(8).uppercase()}",
                hopDongId = contractId,
                hoiVienId = member.id,
                boMon = member.boMon,
                loaiNguon = "HOP_DONG_HOI_VIEN",
                soTien = soTienDaThu,
                ngayThanhToan = ngayThanhToanIso,
                ghiChu = "Thanh toán gia hạn ($tenGoiTap)"
            )
        } else null

        val log = AuditLogEntity(
            id = UUID.randomUUID().toString(),
            timestampMillis = System.currentTimeMillis(),
            actionType = "GIA_HAN_HOP_DONG",
            description = "Gia hạn hội viên ${member.boMon} STT ${member.stt} - ${member.hoTen} ($tenGoiTap)"
        )

        dao.renewMemberWithNewContract(contract, payment, log)
        return contractId
    }

    suspend fun updateMemberProfile(
        member: MemberEntity,
        newStt: Int,
        newHoTen: String,
        newSoDienThoai: String,
        newLoaiKhach: String,
        newGhiChu: String
    ) {
        val updated = member.copy(
            stt = newStt,
            hoTen = newHoTen.trim(),
            soDienThoai = newSoDienThoai.trim(),
            loaiKhach = newLoaiKhach,
            ghiChu = newGhiChu.trim()
        )
        dao.updateMember(updated)
        dao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                actionType = "SUA_HOI_VIEN",
                description = "Cập nhật hồ sơ ${member.boMon} STT $newStt - $newHoTen"
            )
        )
    }

    /**
     * Phần 7.2: Cho phép chỉnh sửa ngày bắt đầu, ngày hết hạn, giá trị hợp đồng, loại báo cáo.
     * Khi sửa tự động tính lại doanh thu phân bổ từ dữ liệu hợp đồng mới.
     */
    suspend fun updateContractDetails(
        contract: MemberContractEntity,
        newGoiTap: String,
        newLoaiBaoCao: String,
        newNgayBatDauIso: String,
        newNgayKetThucDocQuyenIso: String,
        newSoTienHopDong: Long,
        newSoTienDaThu: Long,
        newNgayThanhToanIso: String,
        newGhiChu: String
    ) {
        val trangThaiTT = if (newSoTienDaThu >= newSoTienHopDong) {
            TrangThaiThanhToan.DA_THANH_TOAN
        } else {
            TrangThaiThanhToan.CON_NO
        }
        val diffCollected = newSoTienDaThu - contract.soTienDaThu
        val updated = contract.copy(
            goiTap = newGoiTap.trim(),
            loaiBaoCao = newLoaiBaoCao,
            ngayBatDau = newNgayBatDauIso,
            ngayKetThucDocQuyen = newNgayKetThucDocQuyenIso,
            soTienHopDong = newSoTienHopDong,
            soTienDaThu = newSoTienDaThu,
            ngayThanhToan = newNgayThanhToanIso,
            trangThaiThanhToan = trangThaiTT,
            ghiChu = newGhiChu.trim()
        )
        dao.updateContract(updated)
        if (diffCollected != 0L) {
            val existingPayments = dao.getPaymentsForContract(contract.id)
            if (existingPayments.size <= 1) {
                dao.deletePaymentsForContract(contract.id)
                if (newSoTienDaThu > 0L) {
                    dao.insertPayment(
                        PaymentTransactionEntity(
                            id = existingPayments.firstOrNull()?.id ?: "TT-${UUID.randomUUID().toString().take(8).uppercase()}",
                            hopDongId = contract.id,
                            hoiVienId = contract.hoiVienId,
                            boMon = contract.boMon,
                            loaiNguon = "HOP_DONG_HOI_VIEN",
                            soTien = newSoTienDaThu,
                            ngayThanhToan = newNgayThanhToanIso,
                            ghiChu = "Cập nhật thanh toán hợp đồng (${newGoiTap.trim()})"
                        )
                    )
                }
            } else if (diffCollected > 0L) {
                dao.insertPayment(
                    PaymentTransactionEntity(
                        id = "TT-${UUID.randomUUID().toString().take(8).uppercase()}",
                        hopDongId = contract.id,
                        hoiVienId = contract.hoiVienId,
                        boMon = contract.boMon,
                        loaiNguon = "HOP_DONG_HOI_VIEN",
                        soTien = diffCollected,
                        ngayThanhToan = newNgayThanhToanIso,
                        ghiChu = "Thu bổ sung hợp đồng (${newGoiTap.trim()})"
                    )
                )
            }
        }
        dao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                actionType = "SUA_HOP_DONG",
                description = "Chỉnh sửa hợp đồng ${contract.id} (${newGoiTap.trim()}, $newNgayBatDauIso -> $newNgayKetThucDocQuyenIso)"
            )
        )
    }

    suspend fun collectAdditionalPaymentForContract(
        contract: MemberContractEntity,
        amountToCollect: Long,
        paymentDateIso: String,
        note: String
    ) {
        if (amountToCollect <= 0L) return
        val newTotalCollected = contract.soTienDaThu + amountToCollect
        val status = if (newTotalCollected >= contract.soTienHopDong) {
            TrangThaiThanhToan.DA_THANH_TOAN
        } else {
            TrangThaiThanhToan.CON_NO
        }
        dao.updateContract(
            contract.copy(
                soTienDaThu = newTotalCollected,
                ngayThanhToan = paymentDateIso,
                trangThaiThanhToan = status
            )
        )
        dao.insertPayment(
            PaymentTransactionEntity(
                id = "TT-${UUID.randomUUID().toString().take(8).uppercase()}",
                hopDongId = contract.id,
                hoiVienId = contract.hoiVienId,
                boMon = contract.boMon,
                loaiNguon = "HOP_DONG_HOI_VIEN",
                soTien = amountToCollect,
                ngayThanhToan = paymentDateIso,
                ghiChu = note.ifBlank { "Thu nợ hợp đồng ${contract.goiTap}" }
            )
        )
        dao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                actionType = "THU_THEM_TIEN",
                description = "Thu thêm $amountToCollect đ cho hợp đồng ${contract.id}"
            )
        )
    }

    suspend fun softDeleteMember(member: MemberEntity) {
        dao.updateMember(member.copy(trangThaiXoa = true))
        val contracts = dao.getContractsForMember(member.id)
        contracts.forEach { c ->
            dao.updateContract(c.copy(trangThaiXoa = true))
        }
        dao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                actionType = "XOA_TAM_HOI_VIEN",
                description = "Chuyển hội viên ${member.boMon} STT ${member.stt} - ${member.hoTen} vào thùng rác"
            )
        )
    }

    suspend fun restoreMemberFromTrash(member: MemberEntity) {
        dao.updateMember(member.copy(trangThaiXoa = false))
        val allContracts = dao.getAllContractsRaw().filter { it.hoiVienId == member.id }
        allContracts.forEach { c ->
            dao.updateContract(c.copy(trangThaiXoa = false))
        }
        dao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                actionType = "KHOI_PHUC_HOI_VIEN",
                description = "Khôi phục hội viên ${member.boMon} STT ${member.stt} - ${member.hoTen}"
            )
        )
    }

    suspend fun permanentlyDeleteMember(member: MemberEntity) {
        val allContracts = dao.getAllContractsRaw().filter { it.hoiVienId == member.id }
        allContracts.forEach { c ->
            dao.deletePaymentsForContract(c.id)
        }
        dao.hardDeleteContractsByMember(member.id)
        dao.hardDeleteMember(member.id)
        dao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                actionType = "XOA_VINH_VIEN_HOI_VIEN",
                description = "Xóa vĩnh viễn hội viên ${member.boMon} STT ${member.stt} - ${member.hoTen}"
            )
        )
    }

    // --- BẢNG GIÁ & GÓI TẬP (Phần 4) ---

    suspend fun saveOrUpdatePricingPackage(pkg: PricingPackageEntity) {
        dao.insertPackage(pkg)
        dao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                actionType = "CAP_NHAT_BANG_GIA",
                description = "Cập nhật gói tập ${pkg.boMon}: ${pkg.tenGoi} - ${pkg.giaTien}đ"
            )
        )
    }

    suspend fun deletePricingPackage(pkg: PricingPackageEntity) {
        dao.deletePackageById(pkg.id)
        dao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                actionType = "XOA_GOI_TAP",
                description = "Xóa gói tập ${pkg.tenGoi} (${pkg.boMon})"
            )
        )
    }

    // --- QUẢN LÝ PT (Phần 9 - Chỉ áp dụng cho GYM) ---

    suspend fun createPtContract(
        stt: Int,
        maKhach: String,
        hoTen: String,
        soDienThoai: String,
        goiPt: String,
        tongSoBuoi: Int,
        soTienHopDong: Long,
        soTienDaThu: Long,
        phanTramTrungTam: Int = 50,
        phanTramPt: Int = 50,
        ngayThanhToanIso: String,
        ghiChu: String
    ) {
        val id = "PT-${UUID.randomUUID().toString().take(8).uppercase()}"
        val entity = PtContractEntity(
            id = id,
            stt = stt,
            maKhach = maKhach.ifBlank { "PT-$stt" },
            hoTen = hoTen.trim(),
            soDienThoai = soDienThoai.trim(),
            goiPt = goiPt.trim(),
            tongSoBuoi = tongSoBuoi,
            soTienHopDong = soTienHopDong,
            soTienDaThu = soTienDaThu,
            phanTramTrungTam = phanTramTrungTam,
            phanTramPt = phanTramPt,
            ngayThanhToan = ngayThanhToanIso,
            ngayTao = ngayThanhToanIso,
            ghiChu = ghiChu.trim(),
            trangThaiXoa = false
        )
        dao.insertPtContract(entity)
        if (soTienDaThu > 0L) {
            dao.insertPayment(
                PaymentTransactionEntity(
                    id = "TT-PT-${UUID.randomUUID().toString().take(8).uppercase()}",
                    hopDongId = id,
                    hoiVienId = entity.maKhach,
                    boMon = BoMon.GYM,
                    loaiNguon = "HOP_DONG_PT",
                    soTien = soTienDaThu,
                    ngayThanhToan = ngayThanhToanIso,
                    ghiChu = "Thanh toán hợp đồng PT ($goiPt - $hoTen)"
                )
            )
        }
        dao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                actionType = "THEM_HOP_DONG_PT",
                description = "Thêm hợp đồng PT: $hoTen ($goiPt - $tongSoBuoi buổi)"
            )
        )
    }

    suspend fun updatePtContract(entity: PtContractEntity) {
        dao.updatePtContract(entity)
        val existingPayments = dao.getPaymentsForContract(entity.id)
        if (existingPayments.size <= 1) {
            dao.deletePaymentsForContract(entity.id)
            if (entity.soTienDaThu > 0L) {
                dao.insertPayment(
                    PaymentTransactionEntity(
                        id = existingPayments.firstOrNull()?.id ?: "TT-PT-${UUID.randomUUID().toString().take(8).uppercase()}",
                        hopDongId = entity.id,
                        hoiVienId = entity.maKhach,
                        boMon = BoMon.GYM,
                        loaiNguon = "HOP_DONG_PT",
                        soTien = entity.soTienDaThu,
                        ngayThanhToan = entity.ngayThanhToan,
                        ghiChu = "Cập nhật thanh toán PT (${entity.goiPt} - ${entity.hoTen})"
                    )
                )
            }
        }
        dao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                actionType = "SUA_HOP_DONG_PT",
                description = "Cập nhật hợp đồng PT: ${entity.hoTen} (${entity.goiPt})"
            )
        )
    }

    suspend fun addPtSession(
        ptContractId: String,
        ngayTapIso: String,
        soBuoi: Int = 1,
        ghiChu: String = ""
    ) {
        val session = PtSessionEntity(
            id = "PTS-${UUID.randomUUID().toString().take(8).uppercase()}",
            ptContractId = ptContractId,
            ngayTap = ngayTapIso,
            soBuoi = soBuoi,
            ghiChu = ghiChu.trim()
        )
        dao.insertPtSession(session)
        dao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                actionType = "GHI_NHAN_BUOI_PT",
                description = "Ghi nhận $soBuoi buổi tập PT ngày $ngayTapIso"
            )
        )
    }

    suspend fun updatePtSession(session: PtSessionEntity) {
        dao.updatePtSession(session)
        dao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                actionType = "SUA_BUOI_PT",
                description = "Chỉnh sửa buổi tập PT ngày ${session.ngayTap} (${session.soBuoi} buổi)"
            )
        )
    }

    suspend fun deletePtSession(session: PtSessionEntity) {
        dao.deletePtSessionById(session.id)
        dao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                actionType = "XOA_BUOI_PT",
                description = "Xóa buổi tập PT ngày ${session.ngayTap} (${session.soBuoi} buổi)"
            )
        )
    }

    suspend fun softDeletePtContract(ptContract: PtContractEntity) {
        dao.updatePtContract(ptContract.copy(trangThaiXoa = true))
        dao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                actionType = "XOA_TAM_PT",
                description = "Chuyển hợp đồng PT ${ptContract.hoTen} vào thùng rác"
            )
        )
    }

    suspend fun restorePtContract(ptContract: PtContractEntity) {
        dao.updatePtContract(ptContract.copy(trangThaiXoa = false))
    }

    // --- KHÁCH TẬP BUỔI LẺ & TUẦN LẺ (Phần 10 - Chỉ áp dụng cho GYM) ---

    suspend fun createWalkInTicket(
        loaiVe: String, // NGAY_LE hoặc TUAN_LE
        tenLoaiVe: String,
        soLuong: Int,
        soTien: Long,
        ngayThanhToanIso: String,
        ngayBatDauSuDungIso: String,
        ngayKetThucDocQuyenIso: String,
        ghiChu: String = ""
    ): WalkInTicketEntity {
        val ticket = WalkInTicketEntity(
            id = "VL-${UUID.randomUUID().toString().take(8).uppercase()}",
            loaiVe = loaiVe,
            tenLoaiVe = tenLoaiVe.trim(),
            soLuong = soLuong,
            soTien = soTien,
            ngayThanhToan = ngayThanhToanIso,
            ngayBatDauSuDung = ngayBatDauSuDungIso,
            ngayKetThucDocQuyen = ngayKetThucDocQuyenIso,
            ghiChu = ghiChu.trim(),
            trangThaiXoa = false
        )
        dao.insertWalkInTicket(ticket)
        dao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                actionType = "THU_KHACH_LE",
                description = "Thu khách lẻ: $tenLoaiVe - $soTien đ (Ngày $ngayThanhToanIso)"
            )
        )
        return ticket
    }

    suspend fun updateWalkInTicket(ticket: WalkInTicketEntity) {
        dao.updateWalkInTicket(ticket)
        dao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                actionType = "SUA_KHACH_LE",
                description = "Sửa giao dịch khách lẻ ${ticket.id}: ${ticket.tenLoaiVe} - ${ticket.soTien}đ"
            )
        )
    }

    suspend fun softDeleteWalkInTicket(ticket: WalkInTicketEntity) {
        dao.updateWalkInTicket(ticket.copy(trangThaiXoa = true))
        dao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                actionType = "XOA_KHACH_LE",
                description = "Chuyển giao dịch khách lẻ ${ticket.id} vào thùng rác"
            )
        )
    }

    suspend fun restoreWalkInTicket(ticket: WalkInTicketEntity) {
        dao.updateWalkInTicket(ticket.copy(trangThaiXoa = false))
    }

    suspend fun permanentlyDeleteWalkInTicket(ticket: WalkInTicketEntity) {
        dao.hardDeleteWalkInTicket(ticket.id)
    }

    // --- CẤU HÌNH ---
    suspend fun setConfig(key: String, value: String) {
        dao.upsertConfig(AppConfigEntity(key = key, value = value))
    }

    // --- SAO LƯU & KHÔI PHỤC JSON (Phần 16) ---

    suspend fun exportBackupJsonString(): String {
        val root = JSONObject()
        root.put("app", "89_FITNESS_YOGA")
        root.put("brandName", "89 FITNESS & YOGA")
        root.put("schemaVersion", 1)
        root.put("exportedAtMillis", System.currentTimeMillis())

        val membersArr = JSONArray()
        dao.getAllMembersRaw().forEach { m ->
            membersArr.put(
                JSONObject().apply {
                    put("id", m.id)
                    put("boMon", m.boMon)
                    put("stt", m.stt)
                    put("hoTen", m.hoTen)
                    put("soDienThoai", m.soDienThoai)
                    put("loaiKhach", m.loaiKhach)
                    put("ngayTao", m.ngayTao)
                    put("ghiChu", m.ghiChu)
                    put("trangThaiXoa", m.trangThaiXoa)
                }
            )
        }
        root.put("members", membersArr)

        val contractsArr = JSONArray()
        dao.getAllContractsRaw().forEach { c ->
            contractsArr.put(
                JSONObject().apply {
                    put("id", c.id)
                    put("hoiVienId", c.hoiVienId)
                    put("boMon", c.boMon)
                    put("loaiBaoCao", c.loaiBaoCao)
                    put("loaiHopDong", c.loaiHopDong)
                    put("goiTapId", c.goiTapId ?: JSONObject.NULL)
                    put("goiTap", c.goiTap)
                    put("ngayDangKy", c.ngayDangKy)
                    put("ngayBatDau", c.ngayBatDau)
                    put("ngayKetThucDocQuyen", c.ngayKetThucDocQuyen)
                    put("soTienHopDong", c.soTienHopDong)
                    put("soTienDaThu", c.soTienDaThu)
                    put("ngayThanhToan", c.ngayThanhToan)
                    put("trangThaiThanhToan", c.trangThaiThanhToan)
                    put("ghiChu", c.ghiChu)
                    put("trangThaiXoa", c.trangThaiXoa)
                }
            )
        }
        root.put("contracts", contractsArr)

        val paymentsArr = JSONArray()
        dao.getAllPaymentsRaw().forEach { p ->
            paymentsArr.put(
                JSONObject().apply {
                    put("id", p.id)
                    put("hopDongId", p.hopDongId)
                    put("hoiVienId", p.hoiVienId)
                    put("boMon", p.boMon)
                    put("loaiNguon", p.loaiNguon)
                    put("soTien", p.soTien)
                    put("ngayThanhToan", p.ngayThanhToan)
                    put("ghiChu", p.ghiChu)
                }
            )
        }
        root.put("payments", paymentsArr)

        val packagesArr = JSONArray()
        dao.getAllPackagesRaw().forEach { pkg ->
            packagesArr.put(
                JSONObject().apply {
                    put("id", pkg.id)
                    put("boMon", pkg.boMon)
                    put("doiTuong", pkg.doiTuong)
                    put("tenGoi", pkg.tenGoi)
                    put("soThang", pkg.soThang ?: JSONObject.NULL)
                    put("soNgayTuyChinh", pkg.soNgayTuyChinh ?: JSONObject.NULL)
                    put("giaTien", pkg.giaTien)
                    put("thuTuHienThi", pkg.thuTuHienThi)
                    put("dangHoatDong", pkg.dangHoatDong)
                }
            )
        }
        root.put("packages", packagesArr)

        val ptContractsArr = JSONArray()
        dao.getAllPtContractsRaw().forEach { pt ->
            ptContractsArr.put(
                JSONObject().apply {
                    put("id", pt.id)
                    put("stt", pt.stt)
                    put("maKhach", pt.maKhach)
                    put("hoTen", pt.hoTen)
                    put("soDienThoai", pt.soDienThoai)
                    put("goiPt", pt.goiPt)
                    put("tongSoBuoi", pt.tongSoBuoi)
                    put("soTienHopDong", pt.soTienHopDong)
                    put("soTienDaThu", pt.soTienDaThu)
                    put("phanTramTrungTam", pt.phanTramTrungTam)
                    put("phanTramPt", pt.phanTramPt)
                    put("ngayThanhToan", pt.ngayThanhToan)
                    put("ngayTao", pt.ngayTao)
                    put("ghiChu", pt.ghiChu)
                    put("trangThaiXoa", pt.trangThaiXoa)
                }
            )
        }
        root.put("ptContracts", ptContractsArr)

        val ptSessionsArr = JSONArray()
        dao.getAllPtSessionsRaw().forEach { s ->
            ptSessionsArr.put(
                JSONObject().apply {
                    put("id", s.id)
                    put("ptContractId", s.ptContractId)
                    put("ngayTap", s.ngayTap)
                    put("soBuoi", s.soBuoi)
                    put("ghiChu", s.ghiChu)
                }
            )
        }
        root.put("ptSessions", ptSessionsArr)

        val walkInsArr = JSONArray()
        dao.getAllWalkInTicketsRaw().forEach { w ->
            walkInsArr.put(
                JSONObject().apply {
                    put("id", w.id)
                    put("loaiVe", w.loaiVe)
                    put("tenLoaiVe", w.tenLoaiVe)
                    put("soLuong", w.soLuong)
                    put("soTien", w.soTien)
                    put("ngayThanhToan", w.ngayThanhToan)
                    put("ngayBatDauSuDung", w.ngayBatDauSuDung)
                    put("ngayKetThucDocQuyen", w.ngayKetThucDocQuyen)
                    put("ghiChu", w.ghiChu)
                    put("trangThaiXoa", w.trangThaiXoa)
                }
            )
        }
        root.put("walkInTickets", walkInsArr)

        val configsArr = JSONArray()
        dao.getAllConfigsRaw().forEach { cfg ->
            configsArr.put(
                JSONObject().apply {
                    put("key", cfg.key)
                    put("value", cfg.value)
                }
            )
        }
        root.put("configs", configsArr)

        val logsArr = JSONArray()
        dao.getAllAuditLogsRaw().forEach { l ->
            logsArr.put(
                JSONObject().apply {
                    put("id", l.id)
                    put("timestampMillis", l.timestampMillis)
                    put("actionType", l.actionType)
                    put("description", l.description)
                }
            )
        }
        root.put("auditLogs", logsArr)

        return root.toString(2)
    }

    /**
     * Kiểm tra tính hợp lệ của file sao lưu trước khi khôi phục.
     */
    fun validateBackupJson(jsonString: String): Result<String> {
        return try {
            val root = JSONObject(jsonString)
            val appTag = root.optString("app", "")
            if (appTag != "GYM_YOGA_MANAGER" && appTag != "89_FITNESS_YOGA") {
                return Result.failure(IllegalArgumentException("File JSON không phải định dạng sao lưu của 89 FITNESS & YOGA."))
            }
            if (!root.has("members") || !root.has("contracts") || !root.has("packages")) {
                return Result.failure(IllegalArgumentException("File sao lưu thiếu các bảng dữ liệu bắt buộc (members, contracts, packages)."))
            }
            val memberCount = root.getJSONArray("members").length()
            val contractCount = root.getJSONArray("contracts").length()
            val ptCount = root.optJSONArray("ptContracts")?.length() ?: 0
            val walkInCount = root.optJSONArray("walkInTickets")?.length() ?: 0
            Result.success(
                "Hợp lệ: $memberCount hội viên, $contractCount hợp đồng, $ptCount hợp đồng PT, $walkInCount vé khách lẻ."
            )
        } catch (e: Exception) {
            Result.failure(IllegalArgumentException("File JSON không hợp lệ hoặc bị hỏng: ${e.message}"))
        }
    }

    suspend fun restoreFromBackupJson(jsonString: String): Result<Unit> {
        return try {
            val validation = validateBackupJson(jsonString)
            if (validation.isFailure) {
                return Result.failure(validation.exceptionOrNull() ?: IllegalArgumentException("File không hợp lệ"))
            }
            val root = JSONObject(jsonString)

            val members = mutableListOf<MemberEntity>()
            val membersArr = root.getJSONArray("members")
            for (i in 0 until membersArr.length()) {
                val o = membersArr.getJSONObject(i)
                members.add(
                    MemberEntity(
                        id = o.getString("id"),
                        boMon = o.getString("boMon"),
                        stt = o.getInt("stt"),
                        hoTen = o.getString("hoTen"),
                        soDienThoai = o.optString("soDienThoai", ""),
                        loaiKhach = o.optString("loaiKhach", DoiTuong.NAM),
                        ngayTao = o.getString("ngayTao"),
                        ghiChu = o.optString("ghiChu", ""),
                        trangThaiXoa = o.optBoolean("trangThaiXoa", false)
                    )
                )
            }

            val contracts = mutableListOf<MemberContractEntity>()
            val contractsArr = root.getJSONArray("contracts")
            for (i in 0 until contractsArr.length()) {
                val o = contractsArr.getJSONObject(i)
                val rawGoiTapId = if (o.isNull("goiTapId")) null else o.optString("goiTapId").takeIf { it.isNotBlank() }
                contracts.add(
                    MemberContractEntity(
                        id = o.getString("id"),
                        hoiVienId = o.getString("hoiVienId"),
                        boMon = o.getString("boMon"),
                        loaiBaoCao = o.optString("loaiBaoCao", LoaiBaoCao.CON_HAN),
                        loaiHopDong = o.optString("loaiHopDong", LoaiHopDong.DANG_KY_MOI),
                        goiTapId = rawGoiTapId,
                        goiTap = o.getString("goiTap"),
                        ngayDangKy = o.optString("ngayDangKy", o.getString("ngayBatDau")),
                        ngayBatDau = o.getString("ngayBatDau"),
                        ngayKetThucDocQuyen = o.getString("ngayKetThucDocQuyen"),
                        soTienHopDong = o.getLong("soTienHopDong"),
                        soTienDaThu = o.getLong("soTienDaThu"),
                        ngayThanhToan = o.getString("ngayThanhToan"),
                        trangThaiThanhToan = o.optString("trangThaiThanhToan", TrangThaiThanhToan.DA_THANH_TOAN),
                        ghiChu = o.optString("ghiChu", ""),
                        trangThaiXoa = o.optBoolean("trangThaiXoa", false)
                    )
                )
            }

            val payments = mutableListOf<PaymentTransactionEntity>()
            val paymentsArr = root.optJSONArray("payments") ?: JSONArray()
            for (i in 0 until paymentsArr.length()) {
                val o = paymentsArr.getJSONObject(i)
                payments.add(
                    PaymentTransactionEntity(
                        id = o.getString("id"),
                        hopDongId = o.getString("hopDongId"),
                        hoiVienId = o.optString("hoiVienId", ""),
                        boMon = o.optString("boMon", BoMon.GYM),
                        loaiNguon = o.optString("loaiNguon", "HOP_DONG_HOI_VIEN"),
                        soTien = o.getLong("soTien"),
                        ngayThanhToan = o.getString("ngayThanhToan"),
                        ghiChu = o.optString("ghiChu", "")
                    )
                )
            }

            val packages = mutableListOf<PricingPackageEntity>()
            val packagesArr = root.getJSONArray("packages")
            for (i in 0 until packagesArr.length()) {
                val o = packagesArr.getJSONObject(i)
                val soThang = if (o.isNull("soThang")) null else o.optInt("soThang")
                val soNgay = if (o.isNull("soNgayTuyChinh")) null else o.optInt("soNgayTuyChinh")
                packages.add(
                    PricingPackageEntity(
                        id = o.getString("id"),
                        boMon = o.getString("boMon"),
                        doiTuong = o.getString("doiTuong"),
                        tenGoi = o.getString("tenGoi"),
                        soThang = soThang,
                        soNgayTuyChinh = soNgay,
                        giaTien = o.getLong("giaTien"),
                        thuTuHienThi = o.optInt("thuTuHienThi", i),
                        dangHoatDong = o.optBoolean("dangHoatDong", true)
                    )
                )
            }

            val ptContracts = mutableListOf<PtContractEntity>()
            val ptArr = root.optJSONArray("ptContracts") ?: JSONArray()
            for (i in 0 until ptArr.length()) {
                val o = ptArr.getJSONObject(i)
                ptContracts.add(
                    PtContractEntity(
                        id = o.getString("id"),
                        stt = o.optInt("stt", i + 1),
                        maKhach = o.optString("maKhach", ""),
                        hoTen = o.getString("hoTen"),
                        soDienThoai = o.optString("soDienThoai", ""),
                        goiPt = o.getString("goiPt"),
                        tongSoBuoi = o.getInt("tongSoBuoi"),
                        soTienHopDong = o.getLong("soTienHopDong"),
                        soTienDaThu = o.optLong("soTienDaThu", o.getLong("soTienHopDong")),
                        phanTramTrungTam = o.optInt("phanTramTrungTam", 50),
                        phanTramPt = o.optInt("phanTramPt", 50),
                        ngayThanhToan = o.getString("ngayThanhToan"),
                        ngayTao = o.optString("ngayTao", o.getString("ngayThanhToan")),
                        ghiChu = o.optString("ghiChu", ""),
                        trangThaiXoa = o.optBoolean("trangThaiXoa", false)
                    )
                )
            }

            val ptSessions = mutableListOf<PtSessionEntity>()
            val ptSessionsArr = root.optJSONArray("ptSessions") ?: JSONArray()
            for (i in 0 until ptSessionsArr.length()) {
                val o = ptSessionsArr.getJSONObject(i)
                ptSessions.add(
                    PtSessionEntity(
                        id = o.getString("id"),
                        ptContractId = o.getString("ptContractId"),
                        ngayTap = o.getString("ngayTap"),
                        soBuoi = o.optInt("soBuoi", 1),
                        ghiChu = o.optString("ghiChu", "")
                    )
                )
            }

            val walkIns = mutableListOf<WalkInTicketEntity>()
            val walkInsArr = root.optJSONArray("walkInTickets") ?: JSONArray()
            for (i in 0 until walkInsArr.length()) {
                val o = walkInsArr.getJSONObject(i)
                walkIns.add(
                    WalkInTicketEntity(
                        id = o.getString("id"),
                        loaiVe = o.getString("loaiVe"),
                        tenLoaiVe = o.getString("tenLoaiVe"),
                        soLuong = o.optInt("soLuong", 1),
                        soTien = o.getLong("soTien"),
                        ngayThanhToan = o.getString("ngayThanhToan"),
                        ngayBatDauSuDung = o.getString("ngayBatDauSuDung"),
                        ngayKetThucDocQuyen = o.getString("ngayKetThucDocQuyen"),
                        ghiChu = o.optString("ghiChu", ""),
                        trangThaiXoa = o.optBoolean("trangThaiXoa", false)
                    )
                )
            }

            val configs = mutableListOf<AppConfigEntity>()
            val configsArr = root.optJSONArray("configs") ?: JSONArray()
            for (i in 0 until configsArr.length()) {
                val o = configsArr.getJSONObject(i)
                configs.add(AppConfigEntity(key = o.getString("key"), value = o.getString("value")))
            }

            val logs = mutableListOf<AuditLogEntity>()
            val logsArr = root.optJSONArray("auditLogs") ?: JSONArray()
            for (i in 0 until logsArr.length()) {
                val o = logsArr.getJSONObject(i)
                logs.add(
                    AuditLogEntity(
                        id = o.getString("id"),
                        timestampMillis = o.getLong("timestampMillis"),
                        actionType = o.getString("actionType"),
                        description = o.getString("description")
                    )
                )
            }

            dao.replaceAllDatabaseData(
                members = members,
                contracts = contracts,
                payments = payments,
                packages = packages,
                ptContracts = ptContracts,
                ptSessions = ptSessions,
                walkIns = walkIns,
                configs = configs,
                logs = logs
            )
            ensureDefaultPricingSeeded()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
