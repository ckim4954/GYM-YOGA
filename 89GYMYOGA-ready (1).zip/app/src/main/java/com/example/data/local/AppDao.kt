package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {

    // --- 1. HỘI VIÊN ---
    @Query("SELECT * FROM hoi_vien WHERE trangThaiXoa = 0 ORDER BY stt ASC")
    fun observeAllActiveMembers(): Flow<List<MemberEntity>>

    @Query("SELECT * FROM hoi_vien WHERE trangThaiXoa = 1 ORDER BY ngayTao DESC")
    fun observeDeletedMembers(): Flow<List<MemberEntity>>

    @Query("SELECT * FROM hoi_vien")
    suspend fun getAllMembersRaw(): List<MemberEntity>

    @Query("SELECT * FROM hoi_vien WHERE id = :id LIMIT 1")
    suspend fun getMemberById(id: String): MemberEntity?

    @Query("SELECT MAX(stt) FROM hoi_vien WHERE boMon = :boMon AND trangThaiXoa = 0")
    suspend fun getMaxSttForDepartment(boMon: String): Int?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertMember(member: MemberEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMembers(members: List<MemberEntity>)

    @Update
    suspend fun updateMember(member: MemberEntity)

    @Query("DELETE FROM hoi_vien")
    suspend fun clearAllMembers()

    @Query("DELETE FROM hoi_vien WHERE id = :id")
    suspend fun hardDeleteMember(id: String)

    // --- 2. HỢP ĐỒNG HỘI VIÊN ---
    @Query("SELECT * FROM hop_dong WHERE trangThaiXoa = 0 ORDER BY ngayBatDau DESC")
    fun observeAllActiveContracts(): Flow<List<MemberContractEntity>>

    @Query("SELECT * FROM hop_dong WHERE trangThaiXoa = 1 ORDER BY ngayBatDau DESC")
    fun observeDeletedContracts(): Flow<List<MemberContractEntity>>

    @Query("SELECT * FROM hop_dong")
    suspend fun getAllContractsRaw(): List<MemberContractEntity>

    @Query("SELECT * FROM hop_dong WHERE id = :id LIMIT 1")
    suspend fun getContractById(id: String): MemberContractEntity?

    @Query("SELECT * FROM hop_dong WHERE hoiVienId = :hoiVienId AND trangThaiXoa = 0 ORDER BY ngayKetThucDocQuyen DESC")
    suspend fun getContractsForMember(hoiVienId: String): List<MemberContractEntity>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertContract(contract: MemberContractEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertContracts(contracts: List<MemberContractEntity>)

    @Update
    suspend fun updateContract(contract: MemberContractEntity)

    @Query("DELETE FROM hop_dong")
    suspend fun clearAllContracts()

    @Query("DELETE FROM hop_dong WHERE hoiVienId = :hoiVienId")
    suspend fun hardDeleteContractsByMember(hoiVienId: String)

    // --- 3. GIAO DỊCH THANH TOÁN ---
    @Query("SELECT * FROM giao_dich_thanh_toan ORDER BY ngayThanhToan DESC")
    fun observeAllPayments(): Flow<List<PaymentTransactionEntity>>

    @Query("SELECT * FROM giao_dich_thanh_toan")
    suspend fun getAllPaymentsRaw(): List<PaymentTransactionEntity>

    @Query("SELECT * FROM giao_dich_thanh_toan WHERE hopDongId = :hopDongId ORDER BY ngayThanhToan ASC")
    suspend fun getPaymentsForContract(hopDongId: String): List<PaymentTransactionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: PaymentTransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPayments(payments: List<PaymentTransactionEntity>)

    @Query("DELETE FROM giao_dich_thanh_toan WHERE hopDongId = :hopDongId")
    suspend fun deletePaymentsForContract(hopDongId: String)

    @Query("DELETE FROM giao_dich_thanh_toan")
    suspend fun clearAllPayments()

    // --- 4. GÓI TẬP & BẢNG GIÁ ---
    @Query("SELECT * FROM goi_tap WHERE dangHoatDong = 1 ORDER BY boMon ASC, doiTuong ASC, thuTuHienThi ASC")
    fun observeActivePackages(): Flow<List<PricingPackageEntity>>

    @Query("SELECT * FROM goi_tap")
    suspend fun getAllPackagesRaw(): List<PricingPackageEntity>

    @Query("SELECT COUNT(*) FROM goi_tap")
    suspend fun getPackageCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackage(pkg: PricingPackageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPackages(packages: List<PricingPackageEntity>)

    @Update
    suspend fun updatePackage(pkg: PricingPackageEntity)

    @Query("DELETE FROM goi_tap WHERE id = :id")
    suspend fun deletePackageById(id: String)

    @Query("DELETE FROM goi_tap")
    suspend fun clearAllPackages()

    // --- 5. HỢP ĐỒNG PT ---
    @Query("SELECT * FROM hop_dong_pt WHERE trangThaiXoa = 0 ORDER BY stt ASC")
    fun observeActivePtContracts(): Flow<List<PtContractEntity>>

    @Query("SELECT * FROM hop_dong_pt WHERE trangThaiXoa = 1 ORDER BY stt ASC")
    fun observeDeletedPtContracts(): Flow<List<PtContractEntity>>

    @Query("SELECT * FROM hop_dong_pt")
    suspend fun getAllPtContractsRaw(): List<PtContractEntity>

    @Query("SELECT * FROM hop_dong_pt WHERE id = :id LIMIT 1")
    suspend fun getPtContractById(id: String): PtContractEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPtContract(ptContract: PtContractEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPtContracts(ptContracts: List<PtContractEntity>)

    @Update
    suspend fun updatePtContract(ptContract: PtContractEntity)

    @Query("DELETE FROM hop_dong_pt")
    suspend fun clearAllPtContracts()

    // --- 6. BUỔI TẬP PT ---
    @Query("SELECT * FROM buoi_tap_pt ORDER BY ngayTap DESC")
    fun observeAllPtSessions(): Flow<List<PtSessionEntity>>

    @Query("SELECT * FROM buoi_tap_pt")
    suspend fun getAllPtSessionsRaw(): List<PtSessionEntity>

    @Query("SELECT * FROM buoi_tap_pt WHERE ptContractId = :ptContractId ORDER BY ngayTap DESC")
    suspend fun getSessionsForPtContract(ptContractId: String): List<PtSessionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPtSession(session: PtSessionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPtSessions(sessions: List<PtSessionEntity>)

    @Update
    suspend fun updatePtSession(session: PtSessionEntity)

    @Query("DELETE FROM buoi_tap_pt WHERE id = :sessionId")
    suspend fun deletePtSessionById(sessionId: String)

    @Query("DELETE FROM buoi_tap_pt WHERE ptContractId = :ptContractId")
    suspend fun deletePtSessionsByContract(ptContractId: String)

    @Query("DELETE FROM buoi_tap_pt")
    suspend fun clearAllPtSessions()

    // --- 7. KHÁCH TẬP LẺ ---
    @Query("SELECT * FROM khach_tap_le WHERE trangThaiXoa = 0 ORDER BY ngayThanhToan DESC, id DESC")
    fun observeActiveWalkInTickets(): Flow<List<WalkInTicketEntity>>

    @Query("SELECT * FROM khach_tap_le WHERE trangThaiXoa = 1 ORDER BY ngayThanhToan DESC")
    fun observeDeletedWalkInTickets(): Flow<List<WalkInTicketEntity>>

    @Query("SELECT * FROM khach_tap_le")
    suspend fun getAllWalkInTicketsRaw(): List<WalkInTicketEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWalkInTicket(ticket: WalkInTicketEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWalkInTickets(tickets: List<WalkInTicketEntity>)

    @Update
    suspend fun updateWalkInTicket(ticket: WalkInTicketEntity)

    @Query("DELETE FROM khach_tap_le WHERE id = :id")
    suspend fun hardDeleteWalkInTicket(id: String)

    @Query("DELETE FROM khach_tap_le")
    suspend fun clearAllWalkInTickets()

    // --- 8. CẤU HÌNH ---
    @Query("SELECT * FROM cau_hinh")
    fun observeConfigs(): Flow<List<AppConfigEntity>>

    @Query("SELECT * FROM cau_hinh")
    suspend fun getAllConfigsRaw(): List<AppConfigEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertConfig(config: AppConfigEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertConfigs(configs: List<AppConfigEntity>)

    @Query("DELETE FROM cau_hinh")
    suspend fun clearAllConfigs()

    // --- 9. LỊCH SỬ THAY ĐỔI ---
    @Query("SELECT * FROM lich_su_thay_doi ORDER BY timestampMillis DESC LIMIT 200")
    fun observeRecentAuditLogs(): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM lich_su_thay_doi ORDER BY timestampMillis DESC")
    suspend fun getAllAuditLogsRaw(): List<AuditLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAuditLogs(logs: List<AuditLogEntity>)

    @Query("DELETE FROM lich_su_thay_doi")
    suspend fun clearAllAuditLogs()

    // --- ATOMIC TRANSACTIONS ---
    @Transaction
    suspend fun registerNewMemberWithContract(
        member: MemberEntity,
        contract: MemberContractEntity,
        payment: PaymentTransactionEntity?,
        auditLog: AuditLogEntity
    ) {
        insertMember(member)
        insertContract(contract)
        if (payment != null && payment.soTien > 0L) {
            insertPayment(payment)
        }
        insertAuditLog(auditLog)
    }

    @Transaction
    suspend fun renewMemberWithNewContract(
        contract: MemberContractEntity,
        payment: PaymentTransactionEntity?,
        auditLog: AuditLogEntity
    ) {
        insertContract(contract)
        if (payment != null && payment.soTien > 0L) {
            insertPayment(payment)
        }
        insertAuditLog(auditLog)
    }

    @Transaction
    suspend fun replaceAllDatabaseData(
        members: List<MemberEntity>,
        contracts: List<MemberContractEntity>,
        payments: List<PaymentTransactionEntity>,
        packages: List<PricingPackageEntity>,
        ptContracts: List<PtContractEntity>,
        ptSessions: List<PtSessionEntity>,
        walkIns: List<WalkInTicketEntity>,
        configs: List<AppConfigEntity>,
        logs: List<AuditLogEntity>
    ) {
        clearAllMembers()
        clearAllContracts()
        clearAllPayments()
        clearAllPackages()
        clearAllPtContracts()
        clearAllPtSessions()
        clearAllWalkInTickets()
        clearAllConfigs()
        clearAllAuditLogs()

        upsertMembers(members)
        upsertContracts(contracts)
        upsertPayments(payments)
        upsertPackages(packages)
        upsertPtContracts(ptContracts)
        upsertPtSessions(ptSessions)
        upsertWalkInTickets(walkIns)
        upsertConfigs(configs)
        upsertAuditLogs(logs)
    }
}
