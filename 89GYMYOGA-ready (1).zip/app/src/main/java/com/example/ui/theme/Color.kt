package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// --- GYM Light Theme Tokens (Section III.1) ---
val GymPrimary = Color(0xFF174A7E)
val GymPrimaryDark = Color(0xFF103657)
val GymSecondary = Color(0xFF477DA8)
val GymPrimaryLight = Color(0xFFE6EEF6)
val GymBackground = Color(0xFFF3F6FA)
val GymSurface = Color(0xFFFFFFFF)
val GymTextPrimary = Color(0xFF172536)
val GymTextSecondary = Color(0xFF657487)
val GymBorder = Color(0xFFE2E9F0)

// --- YOGA Light Theme Tokens (Section III.2) ---
val YogaPrimary = Color(0xFF674779)
val YogaPrimaryDark = Color(0xFF493052)
val YogaSecondary = Color(0xFF9175A1)
val YogaPrimaryLight = Color(0xFFF1EBF4)
val YogaBackground = Color(0xFFF7F4F8)
val YogaSurface = Color(0xFFFFFFFF)
val YogaTextPrimary = Color(0xFF29232E)
val YogaTextSecondary = Color(0xFF776D7D)
val YogaBorder = Color(0xFFEAE2ED)

// --- Dark Mode Charcoal Layered Tokens (Section VII) ---
val DarkGymPrimary = Color(0xFF5B9BD5)
val DarkGymPrimaryContainer = Color(0xFF183452)
val DarkGymSecondary = Color(0xFF7DB3E3)
val DarkGymBackground = Color(0xFF0E131B)
val DarkGymSurface = Color(0xFF151D28)
val DarkGymCardSurface = Color(0xFF1C2635)
val DarkGymTextPrimary = Color(0xFFECF2F8)
val DarkGymTextSecondary = Color(0xFF94A3B8)
val DarkGymBorder = Color(0xFF283548)

val DarkYogaPrimary = Color(0xFFB896CB)
val DarkYogaPrimaryContainer = Color(0xFF3E2947)
val DarkYogaSecondary = Color(0xFFCBB0DC)
val DarkYogaBackground = Color(0xFF131018)
val DarkYogaSurface = Color(0xFF1B1723)
val DarkYogaCardSurface = Color(0xFF241E2F)
val DarkYogaTextPrimary = Color(0xFFF2ECF6)
val DarkYogaTextSecondary = Color(0xFFA599B0)
val DarkYogaBorder = Color(0xFF352C42)

// --- Status Colors (Light Mode) ---
val StatusActiveGreen = Color(0xFF15803D)
val StatusActiveGreenBg = Color(0xFFDCFCE7)

val StatusExpiring15Amber = Color(0xFFB45309)
val StatusExpiring15AmberBg = Color(0xFFFEF3C7)

val StatusExpiring7Orange = Color(0xFFC2410C)
val StatusExpiring7OrangeBg = Color(0xFFFFEDD5)

val StatusExpiringTodayOrange = Color(0xFFEA580C)
val StatusExpiringTodayOrangeBg = Color(0xFFFFEDD5)

val StatusExpiredRed = Color(0xFFB91C1C)
val StatusExpiredRedBg = Color(0xFFFEE2E2)

val StatusInfoBlue = Color(0xFF0369A1)
val StatusInfoBlueBg = Color(0xFFE0F2FE)

// --- Status Colors (Dark Mode - High Contrast on Charcoal) ---
val DarkStatusActiveGreen = Color(0xFF4ADE80)
val DarkStatusActiveGreenBg = Color(0xFF132E21)

val DarkStatusExpiringAmber = Color(0xFFFBBF24)
val DarkStatusExpiringAmberBg = Color(0xFF332611)

val DarkStatusExpiringOrange = Color(0xFFFB923C)
val DarkStatusExpiringOrangeBg = Color(0xFF361F12)

val DarkStatusExpiredRed = Color(0xFFF87171)
val DarkStatusExpiredRedBg = Color(0xFF38181B)

val DarkStatusInfoBlue = Color(0xFF38BDF8)
val DarkStatusInfoBlueBg = Color(0xFF112A3D)

val RevenuePrimary = Color(0xFF174A7E)
val RevenuePrimaryDark = Color(0xFF103657)
