package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

enum class AppAccentMode {
    GYM,
    YOGA,
    REVENUE,
    TRACKING
}

/**
 * Chế độ giao diện 3 lựa chọn (Phần VII):
 * - LIGHT: Sáng (Mặc định khi mở lần đầu)
 * - DARK: Tối (Dark Charcoal chuyên nghiệp)
 * - SYSTEM: Theo hệ thống Android
 */
enum class ThemeModePreference(val code: String, val labelVi: String) {
    LIGHT("LIGHT", "Giao diện Sáng (Light Mode)"),
    DARK("DARK", "Giao diện Tối (Dark Mode)"),
    SYSTEM("SYSTEM", "Theo hệ thống Android");

    val configValue: String
        get() = code

    companion object {
        fun fromCode(code: String?): ThemeModePreference {
            return entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: LIGHT
        }

        fun fromConfigString(value: String?): ThemeModePreference = fromCode(value)
    }
}

@Immutable
data class AppDesignTokens(
    val isDark: Boolean,
    val primaryAccent: Color,
    val primaryAccentDark: Color,
    val primaryAccentSoftBg: Color,
    val secondaryAccent: Color,
    val gymAccent: Color,
    val gymSoftBg: Color,
    val yogaAccent: Color,
    val yogaSoftBg: Color,
    val appBackground: Color,
    val cardSurface: Color,
    val elevatedSurface: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val borderSubtle: Color,
    val successText: Color,
    val successBg: Color,
    val warningAmberText: Color,
    val warningAmberBg: Color,
    val warningOrangeText: Color,
    val warningOrangeBg: Color,
    val dangerText: Color,
    val dangerBg: Color,
    val infoText: Color,
    val infoBg: Color
) {
    // Unified token aliases used across all screens & components
    val background: Color get() = appBackground
    val surface: Color get() = cardSurface
    val borderColor: Color get() = borderSubtle
    val dividerColor: Color get() = borderSubtle
    val statusActiveBg: Color get() = successBg
    val statusActiveText: Color get() = successText
    val statusWarningBg: Color get() = warningAmberBg
    val statusWarningText: Color get() = warningAmberText
    val statusUrgentBg: Color get() = warningOrangeBg
    val statusUrgentText: Color get() = warningOrangeText
    val statusTodayBg: Color get() = dangerBg
    val statusTodayText: Color get() = dangerText
    val statusExpiredBg: Color get() = dangerBg
    val statusExpiredText: Color get() = dangerText
}

val LocalAppDesignTokens = staticCompositionLocalOf {
    AppDesignTokens(
        isDark = false,
        primaryAccent = GymPrimary,
        primaryAccentDark = GymPrimaryDark,
        primaryAccentSoftBg = GymPrimaryLight,
        secondaryAccent = GymSecondary,
        gymAccent = GymPrimary,
        gymSoftBg = GymPrimaryLight,
        yogaAccent = YogaPrimary,
        yogaSoftBg = YogaPrimaryLight,
        appBackground = GymBackground,
        cardSurface = GymSurface,
        elevatedSurface = Color(0xFFF8FAFC),
        textPrimary = GymTextPrimary,
        textSecondary = GymTextSecondary,
        borderSubtle = GymBorder,
        successText = StatusActiveGreen,
        successBg = StatusActiveGreenBg,
        warningAmberText = StatusExpiring15Amber,
        warningAmberBg = StatusExpiring15AmberBg,
        warningOrangeText = StatusExpiring7Orange,
        warningOrangeBg = StatusExpiring7OrangeBg,
        dangerText = StatusExpiredRed,
        dangerBg = StatusExpiredRedBg,
        infoText = StatusInfoBlue,
        infoBg = StatusInfoBlueBg
    )
}

private val GymLightScheme = lightColorScheme(
    primary = GymPrimary,
    onPrimary = Color.White,
    primaryContainer = GymPrimaryLight,
    onPrimaryContainer = GymPrimaryDark,
    secondary = GymSecondary,
    onSecondary = Color.White,
    background = GymBackground,
    onBackground = GymTextPrimary,
    surface = GymSurface,
    onSurface = GymTextPrimary,
    surfaceVariant = Color(0xFFEDF2F7),
    onSurfaceVariant = GymTextSecondary,
    outline = GymBorder,
    error = StatusExpiredRed,
    onError = Color.White
)

private val YogaLightScheme = lightColorScheme(
    primary = YogaPrimary,
    onPrimary = Color.White,
    primaryContainer = YogaPrimaryLight,
    onPrimaryContainer = YogaPrimaryDark,
    secondary = YogaSecondary,
    onSecondary = Color.White,
    background = YogaBackground,
    onBackground = YogaTextPrimary,
    surface = YogaSurface,
    onSurface = YogaTextPrimary,
    surfaceVariant = Color(0xFFF2EDF5),
    onSurfaceVariant = YogaTextSecondary,
    outline = YogaBorder,
    error = StatusExpiredRed,
    onError = Color.White
)

private val DarkGymScheme = darkColorScheme(
    primary = DarkGymPrimary,
    onPrimary = Color(0xFF071B2F),
    primaryContainer = DarkGymPrimaryContainer,
    onPrimaryContainer = Color(0xFFD6E8FA),
    secondary = DarkGymSecondary,
    onSecondary = Color(0xFF081F36),
    background = DarkGymBackground,
    onBackground = DarkGymTextPrimary,
    surface = DarkGymSurface,
    onSurface = DarkGymTextPrimary,
    surfaceVariant = DarkGymCardSurface,
    onSurfaceVariant = DarkGymTextSecondary,
    outline = DarkGymBorder,
    error = DarkStatusExpiredRed,
    onError = Color(0xFF2D0A0C)
)

private val DarkYogaScheme = darkColorScheme(
    primary = DarkYogaPrimary,
    onPrimary = Color(0xFF261430),
    primaryContainer = DarkYogaPrimaryContainer,
    onPrimaryContainer = Color(0xFFF2E6F7),
    secondary = DarkYogaSecondary,
    onSecondary = Color(0xFF2A1836),
    background = DarkYogaBackground,
    onBackground = DarkYogaTextPrimary,
    surface = DarkYogaSurface,
    onSurface = DarkYogaTextPrimary,
    surfaceVariant = DarkYogaCardSurface,
    onSurfaceVariant = DarkYogaTextSecondary,
    outline = DarkYogaBorder,
    error = DarkStatusExpiredRed,
    onError = Color(0xFF2D0A0C)
)

@Composable
fun GymYogaManagerTheme(
    themeMode: ThemeModePreference = ThemeModePreference.LIGHT,
    accentMode: AppAccentMode = AppAccentMode.GYM,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val useDark = when (themeMode) {
        ThemeModePreference.LIGHT -> false
        ThemeModePreference.DARK -> true
        ThemeModePreference.SYSTEM -> systemDark
    }

    val isYogaMode = accentMode == AppAccentMode.YOGA

    val colorScheme = if (useDark) {
        if (isYogaMode) DarkYogaScheme else DarkGymScheme
    } else {
        if (isYogaMode) YogaLightScheme else GymLightScheme
    }

    val tokens = if (useDark) {
        AppDesignTokens(
            isDark = true,
            primaryAccent = if (isYogaMode) DarkYogaPrimary else DarkGymPrimary,
            primaryAccentDark = if (isYogaMode) DarkYogaPrimaryContainer else DarkGymPrimaryContainer,
            primaryAccentSoftBg = if (isYogaMode) DarkYogaPrimaryContainer else DarkGymPrimaryContainer,
            secondaryAccent = if (isYogaMode) DarkYogaSecondary else DarkGymSecondary,
            gymAccent = DarkGymPrimary,
            gymSoftBg = DarkGymPrimaryContainer,
            yogaAccent = DarkYogaPrimary,
            yogaSoftBg = DarkYogaPrimaryContainer,
            appBackground = if (isYogaMode) DarkYogaBackground else DarkGymBackground,
            cardSurface = if (isYogaMode) DarkYogaSurface else DarkGymSurface,
            elevatedSurface = if (isYogaMode) DarkYogaCardSurface else DarkGymCardSurface,
            textPrimary = if (isYogaMode) DarkYogaTextPrimary else DarkGymTextPrimary,
            textSecondary = if (isYogaMode) DarkYogaTextSecondary else DarkGymTextSecondary,
            borderSubtle = if (isYogaMode) DarkYogaBorder else DarkGymBorder,
            successText = DarkStatusActiveGreen,
            successBg = DarkStatusActiveGreenBg,
            warningAmberText = DarkStatusExpiringAmber,
            warningAmberBg = DarkStatusExpiringAmberBg,
            warningOrangeText = DarkStatusExpiringOrange,
            warningOrangeBg = DarkStatusExpiringOrangeBg,
            dangerText = DarkStatusExpiredRed,
            dangerBg = DarkStatusExpiredRedBg,
            infoText = DarkStatusInfoBlue,
            infoBg = DarkStatusInfoBlueBg
        )
    } else {
        AppDesignTokens(
            isDark = false,
            primaryAccent = if (isYogaMode) YogaPrimary else GymPrimary,
            primaryAccentDark = if (isYogaMode) YogaPrimaryDark else GymPrimaryDark,
            primaryAccentSoftBg = if (isYogaMode) YogaPrimaryLight else GymPrimaryLight,
            secondaryAccent = if (isYogaMode) YogaSecondary else GymSecondary,
            gymAccent = GymPrimary,
            gymSoftBg = GymPrimaryLight,
            yogaAccent = YogaPrimary,
            yogaSoftBg = YogaPrimaryLight,
            appBackground = if (isYogaMode) YogaBackground else GymBackground,
            cardSurface = Color.White,
            elevatedSurface = if (isYogaMode) Color(0xFFFBF9FC) else Color(0xFFF8FAFC),
            textPrimary = if (isYogaMode) YogaTextPrimary else GymTextPrimary,
            textSecondary = if (isYogaMode) YogaTextSecondary else GymTextSecondary,
            borderSubtle = if (isYogaMode) YogaBorder else GymBorder,
            successText = StatusActiveGreen,
            successBg = StatusActiveGreenBg,
            warningAmberText = StatusExpiring15Amber,
            warningAmberBg = StatusExpiring15AmberBg,
            warningOrangeText = StatusExpiring7Orange,
            warningOrangeBg = StatusExpiring7OrangeBg,
            dangerText = StatusExpiredRed,
            dangerBg = StatusExpiredRedBg,
            infoText = StatusInfoBlue,
            infoBg = StatusInfoBlueBg
        )
    }

    CompositionLocalProvider(LocalAppDesignTokens provides tokens) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
