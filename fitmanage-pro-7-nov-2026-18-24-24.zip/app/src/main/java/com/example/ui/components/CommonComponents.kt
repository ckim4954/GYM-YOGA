package com.example.ui.components

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.BoMon
import com.example.data.local.DoiTuong
import com.example.data.local.LoaiBaoCao
import com.example.data.local.LoaiHopDong
import com.example.data.local.MemberContractEntity
import com.example.data.local.PricingPackageEntity
import com.example.domain.DateUtils
import com.example.domain.FinancialEngine
import com.example.domain.LocalDateSpec
import com.example.domain.MemberTrackingStatus
import com.example.ui.theme.GymPrimary
import com.example.ui.theme.LocalAppDesignTokens
import com.example.ui.theme.StatusActiveGreen
import com.example.ui.theme.StatusExpiredRed
import com.example.ui.theme.YogaPrimary
import com.example.ui.viewmodel.MemberWithContractsUi

@Composable
fun TrackingStatusBadge(
    status: MemberTrackingStatus,
    remainingDays: Int,
    modifier: Modifier = Modifier
) {
    val tokens = LocalAppDesignTokens.current
    val (bgColor, textColor, textLabel) = when (status) {
        MemberTrackingStatus.ACTIVE_OVER_15 -> Triple(
            tokens.statusActiveBg,
            tokens.statusActiveText,
            "Còn $remainingDays ngày"
        )
        MemberTrackingStatus.EXPIRING_8_TO_15 -> Triple(
            tokens.statusWarningBg,
            tokens.statusWarningText,
            "Còn $remainingDays ngày"
        )
        MemberTrackingStatus.EXPIRING_1_TO_7 -> Triple(
            tokens.statusUrgentBg,
            tokens.statusUrgentText,
            "Sắp hết ($remainingDays ngày)"
        )
        MemberTrackingStatus.EXPIRING_TODAY -> Triple(
            tokens.statusTodayBg,
            tokens.statusTodayText,
            "Hôm nay hết hạn"
        )
        MemberTrackingStatus.EXPIRED -> Triple(
            tokens.statusExpiredBg,
            tokens.statusExpiredText,
            if (remainingDays < 0) "Quá hạn ${-remainingDays} ngày" else "Đã hết hạn"
        )
    }

    val statusIcon = when (status) {
        MemberTrackingStatus.ACTIVE_OVER_15 -> Icons.Default.CheckCircle
        MemberTrackingStatus.EXPIRING_8_TO_15 -> Icons.Default.Schedule
        MemberTrackingStatus.EXPIRING_1_TO_7 -> Icons.Default.WarningAmber
        MemberTrackingStatus.EXPIRING_TODAY -> Icons.Default.NotificationsActive
        MemberTrackingStatus.EXPIRED -> Icons.Default.EventBusy
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .padding(horizontal = 9.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(
            imageVector = statusIcon,
            contentDescription = null,
            tint = textColor,
            modifier = Modifier.size(13.dp)
        )
        Text(
            text = textLabel,
            style = MaterialTheme.typography.labelMedium,
            color = textColor,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

@Composable
fun DepartmentBadge(boMon: String, modifier: Modifier = Modifier) {
    val tokens = LocalAppDesignTokens.current
    val isYoga = boMon == BoMon.YOGA
    val color = if (isYoga) tokens.yogaAccent else tokens.gymAccent
    val bg = if (isYoga) tokens.yogaSoftBg else tokens.gymSoftBg
    val icon = if (isYoga) Icons.Default.SelfImprovement else Icons.Default.FitnessCenter

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(12.dp)
        )
        Text(
            text = boMon,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}

@Composable
fun DatePickerField(
    label: String,
    dateDisplay: String, // dd/MM/yyyy
    onDateChanged: (String) -> Unit,
    modifier: Modifier = Modifier,
    supportingText: String? = null,
    testTag: String = "date_field"
) {
    val context = LocalContext.current
    val parsed = LocalDateSpec.parseDisplay(dateDisplay) ?: LocalDateSpec.today()

    OutlinedTextField(
        value = dateDisplay,
        onValueChange = { onDateChanged(it) },
        label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        placeholder = { Text("dd/MM/yyyy") },
        singleLine = true,
        supportingText = supportingText?.let { { Text(it) } },
        trailingIcon = {
            IconButton(
                onClick = {
                    DatePickerDialog(
                        context,
                        { _, y, m, d ->
                            val selected = LocalDateSpec(y, m + 1, d)
                            onDateChanged(selected.toDisplayString())
                        },
                        parsed.year,
                        parsed.month - 1,
                        parsed.day
                    ).show()
                }
            ) {
                Icon(
                    imageVector = Icons.Default.CalendarMonth,
                    contentDescription = "Chọn ngày $label"
                )
            }
        },
        modifier = modifier.fillMaxWidth().testTag(testTag)
    )
}

/**
 * Hàng hiển thị hội viên chuẩn Cyber Fitness: có chiều sâu, rõ STT, Họ tên, Gói, Hạn tập, Số tiền, SĐT và Icon đồng bộ.
 */
@Composable
fun MemberRowItem(
    item: MemberWithContractsUi,
    accentColor: Color,
    onClick: () -> Unit,
    onQuickRenew: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalAppDesignTokens.current
    val latest = item.latestContract
    val solidBtnColor = if (item.member.boMon == BoMon.YOGA) YogaPrimary else GymPrimary

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .border(1.dp, tokens.borderColor, RoundedCornerShape(14.dp)),
        color = tokens.cardSurface,
        tonalElevation = 0.dp
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(accentColor.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "#${item.member.stt}",
                            style = MaterialTheme.typography.labelLarge,
                            color = accentColor,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.member.hoTen,
                            style = MaterialTheme.typography.titleMedium,
                            color = tokens.textPrimary,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val subInfo = buildString {
                            if (item.member.soDienThoai.isNotBlank()) {
                                append(item.member.soDienThoai)
                            } else {
                                append("Chưa có SĐT")
                            }
                            if (item.member.boMon == BoMon.GYM) {
                                append(" • ")
                                append(DoiTuong.labelVi(item.member.loaiKhach))
                            }
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = null,
                                tint = tokens.textSecondary,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = subInfo,
                                style = MaterialTheme.typography.bodySmall,
                                color = tokens.textSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                TrackingStatusBadge(
                    status = item.trackingStatus,
                    remainingDays = item.remainingDays
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = tokens.dividerColor)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Description,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = latest?.goiTap ?: "Chưa có hợp đồng",
                            style = MaterialTheme.typography.labelLarge,
                            color = accentColor,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.EventAvailable,
                            contentDescription = null,
                            tint = tokens.textSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "${item.startDateDisplay} → ${item.lastTrainingDateDisplay}",
                            style = MaterialTheme.typography.bodySmall,
                            color = tokens.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Column(
                    horizontalAlignment = Alignment.End,
                    modifier = Modifier.padding(horizontal = 8.dp)
                ) {
                    Text(
                        text = DateUtils.formatVnd(latest?.soTienDaThu ?: 0L),
                        style = MaterialTheme.typography.titleSmall,
                        color = tokens.textPrimary,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    if (item.totalDebt > 0L) {
                        Text(
                            text = "Nợ ${DateUtils.formatVnd(item.totalDebt)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.statusExpiredText,
                            maxLines = 1
                        )
                    } else {
                        Text(
                            text = "Đã thu đủ",
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.statusActiveText,
                            maxLines = 1
                        )
                    }
                }

                OutlinedButton(
                    onClick = onQuickRenew,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("renew_member_${item.member.stt}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Gia hạn",
                        tint = if (tokens.isDark) accentColor else solidBtnColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        "Gia hạn",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (tokens.isDark) accentColor else solidBtnColor,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

/**
 * Hộp thoại Đăng ký Hội viên mới hoặc Gia hạn hợp đồng mới (Phần 5, 6, 7 & Phần VII Bảng giá Yoga).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MemberRegistrationOrRenewalDialog(
    boMon: String,
    isRenewal: Boolean,
    existingMember: MemberWithContractsUi? = null,
    allDepartmentMembers: List<MemberWithContractsUi>,
    maxStt: Int,
    suggestedStt: Int,
    availablePackages: List<PricingPackageEntity>,
    onDismiss: () -> Unit,
    onOpenPricingSettings: () -> Unit,
    onConfirmNewMember: (
        stt: Int,
        hoTen: String,
        soDienThoai: String,
        loaiKhach: String,
        goiTapId: String?,
        tenGoiTap: String,
        ngayDangKyIso: String,
        ngayBatDauIso: String,
        ngayKetThucDocQuyenIso: String,
        soTienHopDong: Long,
        soTienDaThu: Long,
        ngayThanhToanIso: String,
        ghiChuHoiVien: String,
        ghiChuHopDong: String
    ) -> Unit,
    onConfirmRenewal: (
        loaiHopDong: String,
        loaiBaoCao: String,
        goiTapId: String?,
        tenGoiTap: String,
        ngayDangKyIso: String,
        ngayBatDauIso: String,
        ngayKetThucDocQuyenIso: String,
        soTienHopDong: Long,
        soTienDaThu: Long,
        ngayThanhToanIso: String,
        ghiChuHopDong: String
    ) -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    val isYoga = boMon == BoMon.YOGA
    val accentColor = if (isYoga) tokens.yogaAccent else tokens.gymAccent
    val solidBrandColor = if (isYoga) YogaPrimary else GymPrimary
    val todaySpec = remember { LocalDateSpec.today() }

    var sttText by remember {
        mutableStateOf(
            if (isRenewal && existingMember != null) existingMember.member.stt.toString()
            else suggestedStt.toString()
        )
    }
    var hoTen by remember { mutableStateOf(existingMember?.member?.hoTen ?: "") }
    var soDienThoai by remember { mutableStateOf(existingMember?.member?.soDienThoai ?: "") }
    var selectedDoiTuong by remember {
        mutableStateOf(
            existingMember?.member?.loaiKhach
                ?: if (boMon == BoMon.GYM) DoiTuong.NAM else DoiTuong.YOGA_CHUNG
        )
    }

    val filteredPackages = remember(boMon, selectedDoiTuong, availablePackages) {
        availablePackages.filter { pkg ->
            pkg.boMon == boMon && (boMon == BoMon.YOGA || pkg.doiTuong == selectedDoiTuong)
        }
    }

    var selectedPackage by remember(filteredPackages) {
        mutableStateOf(filteredPackages.firstOrNull())
    }
    var customPackageName by remember(selectedPackage) {
        mutableStateOf(selectedPackage?.tenGoi ?: if (boMon == BoMon.GYM) "Gym 1 tháng" else "Yoga 1 tháng")
    }
    var contractPriceText by remember(selectedPackage) {
        mutableStateOf((selectedPackage?.giaTien ?: if (isYoga) 500_000L else 300_000L).toString())
    }
    var collectedPriceText by remember(selectedPackage) {
        mutableStateOf((selectedPackage?.giaTien ?: if (isYoga) 500_000L else 300_000L).toString())
    }

    var registrationDateDisplay by remember { mutableStateOf(todaySpec.toDisplayString()) }
    var paymentDateDisplay by remember { mutableStateOf(todaySpec.toDisplayString()) }

    // Calculate default start date per Phần 7.1
    val previousEndExclusiveSpec = remember(existingMember) {
        existingMember?.latestContract?.ngayKetThucDocQuyen?.let { LocalDateSpec.parseIso(it) }
    }

    var startDateDisplay by remember {
        val regSpec = LocalDateSpec.parseDisplay(registrationDateDisplay) ?: todaySpec
        val autoStart = if (isRenewal) {
            FinancialEngine.calculateRenewalStartDate(previousEndExclusiveSpec, regSpec)
        } else {
            regSpec
        }
        mutableStateOf(autoStart.toDisplayString())
    }

    // Calculate default displayed last training day = exclusiveEnd - 1 day
    var lastTrainingDateDisplay by remember {
        val startSpec = LocalDateSpec.parseDisplay(startDateDisplay) ?: todaySpec
        val effectiveMonths = selectedPackage?.soThang ?: when (selectedPackage?.giaTien) {
            1_000_000L -> 2
            1_500_000L -> 3
            else -> 1
        }
        val endEx = FinancialEngine.calculateExclusiveEndDate(
            startDate = startSpec,
            months = effectiveMonths,
            customDays = selectedPackage?.soNgayTuyChinh
        )
        mutableStateOf(DateUtils.toDisplayedLastTrainingDate(endEx).toDisplayString())
    }

    // Update start date & expiry date automatically when registrationDate or selectedPackage changes
    LaunchedEffect(registrationDateDisplay, selectedPackage) {
        val regSpec = LocalDateSpec.parseDisplay(registrationDateDisplay) ?: return@LaunchedEffect
        val computedStart = if (isRenewal) {
            FinancialEngine.calculateRenewalStartDate(previousEndExclusiveSpec, regSpec)
        } else {
            regSpec
        }
        startDateDisplay = computedStart.toDisplayString()
        val pkg = selectedPackage
        if (pkg != null) {
            customPackageName = pkg.tenGoi
            contractPriceText = pkg.giaTien.toString()
            collectedPriceText = pkg.giaTien.toString()
            val effectiveMonths = pkg.soThang ?: when (pkg.giaTien) {
                1_000_000L -> 2
                1_500_000L -> 3
                else -> 1
            }
            val endEx = FinancialEngine.calculateExclusiveEndDate(
                startDate = computedStart,
                months = effectiveMonths,
                customDays = pkg.soNgayTuyChinh
            )
            lastTrainingDateDisplay = DateUtils.toDisplayedLastTrainingDate(endEx).toDisplayString()
        }
    }

    var ghiChuHoiVien by remember { mutableStateOf(existingMember?.member?.ghiChu ?: "") }
    var ghiChuHopDong by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Check duplicate STT or duplicate phone (Phần 5.1)
    val parsedStt = sttText.toIntOrNull()
    val duplicateSttMember = remember(parsedStt, allDepartmentMembers, isRenewal) {
        if (isRenewal || parsedStt == null) null
        else allDepartmentMembers.firstOrNull { it.member.stt == parsedStt }
    }
    val duplicatePhoneMember = remember(soDienThoai, allDepartmentMembers, isRenewal) {
        val trimmed = soDienThoai.trim()
        if (isRenewal || trimmed.isEmpty()) null
        else allDepartmentMembers.firstOrNull { it.member.soDienThoai == trimmed }
    }

    val startSpecPreview = LocalDateSpec.parseDisplay(startDateDisplay)
    val lastDaySpecPreview = LocalDateSpec.parseDisplay(lastTrainingDateDisplay)
    val endExPreview = lastDaySpecPreview?.let { DateUtils.toExclusiveEndDate(it) }
    val totalDaysPreview = if (startSpecPreview != null && endExPreview != null) {
        DateUtils.daysBetween(startSpecPreview, endExPreview)
    } else 0

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .heightIn(max = 720.dp)
                .padding(vertical = 12.dp),
            shape = RoundedCornerShape(20.dp),
            color = tokens.surface
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // STICKY TOP HEADER BAR
                Surface(
                    color = tokens.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            DepartmentBadge(boMon = boMon)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (isRenewal) "Gia hạn hợp đồng $boMon" else "Đăng ký hội viên $boMon mới",
                                style = MaterialTheme.typography.titleLarge,
                                color = tokens.textPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "Đóng",
                                tint = tokens.textPrimary
                            )
                        }
                    }
                }
                HorizontalDivider(color = tokens.borderColor)

                // SCROLLABLE FORM BODY
                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                ) {
                    if (!isRenewal) {
                        Surface(
                            color = accentColor.copy(alpha = if (tokens.isDark) 0.16f else 0.08f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "STT lớn nhất hiện tại: $maxStt",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = tokens.textPrimary,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "Gợi ý tiếp theo: #$suggestedStt",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = accentColor,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.clickable { sttText = suggestedStt.toString() }
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = sttText,
                                onValueChange = { sttText = it.filter { ch -> ch.isDigit() } },
                                label = { Text("STT *") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(0.35f).testTag("input_stt")
                            )
                            OutlinedTextField(
                                value = hoTen,
                                onValueChange = { hoTen = it },
                                label = { Text("Họ và tên *") },
                                singleLine = true,
                                modifier = Modifier.weight(0.65f).testTag("input_ho_ten")
                            )
                        }

                        if (duplicateSttMember != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            WarningBanner(
                                text = "Cảnh báo: STT #$parsedStt đang trùng với hội viên \"${duplicateSttMember.member.hoTen}\". Hệ thống sẽ KHÔNG ghi đè hồ sơ cũ nếu bạn tiếp tục lưu."
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = soDienThoai,
                            onValueChange = { soDienThoai = it },
                            label = { Text("Số điện thoại") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("input_sdt")
                        )

                        if (duplicatePhoneMember != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            WarningBanner(
                                text = "Cảnh báo: SĐT ${soDienThoai.trim()} đang trùng với hội viên \"${duplicatePhoneMember.member.hoTen}\" (STT #${duplicatePhoneMember.member.stt})."
                            )
                        }

                        if (boMon == BoMon.GYM) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Đối tượng bảng giá Gym:",
                                style = MaterialTheme.typography.labelMedium,
                                color = tokens.textSecondary
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                listOf(
                                    DoiTuong.NAM to "Nam",
                                    DoiTuong.NU to "Nữ",
                                    DoiTuong.TRE_EM to "Trẻ em"
                                ).forEach { (code, label) ->
                                    FilterChip(
                                        selected = selectedDoiTuong == code,
                                        onClick = { selectedDoiTuong = code },
                                        label = { Text(label) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = accentColor.copy(alpha = if (tokens.isDark) 0.22f else 0.14f),
                                            selectedLabelColor = accentColor
                                        )
                                    )
                                }
                            }
                        }
                    } else if (existingMember != null) {
                        // Thông tin hội viên khi gia hạn
                        Surface(
                            color = accentColor.copy(alpha = if (tokens.isDark) 0.16f else 0.08f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Hội viên: #${existingMember.member.stt} – ${existingMember.member.hoTen}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = tokens.textPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Hợp đồng gần nhất hết hạn tập ngày: ${existingMember.lastTrainingDateDisplay}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = tokens.textSecondary
                                )
                                val regSpec = LocalDateSpec.parseDisplay(registrationDateDisplay)
                                if (regSpec != null && previousEndExclusiveSpec != null) {
                                    val ruleExplanation = when {
                                        regSpec < previousEndExclusiveSpec ->
                                            "Quy tắc TH1 (Gia hạn sớm): Hợp đồng mới tự động nối tiếp ngày ${previousEndExclusiveSpec.toDisplayString()}."
                                        regSpec == previousEndExclusiveSpec ->
                                            "Quy tắc TH2 (Đúng ngày nối tiếp): Hợp đồng mới bắt đầu ngày ${previousEndExclusiveSpec.toDisplayString()}."
                                        else -> {
                                            val restDays = DateUtils.daysBetween(previousEndExclusiveSpec, regSpec)
                                            "Quy tắc TH3 (Đăng ký lại sau nghỉ $restDays ngày): Hợp đồng mới bắt đầu ngày ${regSpec.toDisplayString()}, không tính doanh thu những ngày nghỉ."
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = ruleExplanation,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = accentColor,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Chọn gói tập ($boMon):",
                        style = MaterialTheme.typography.labelMedium,
                        color = tokens.textSecondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        filteredPackages.forEach { pkg ->
                            val isSelected = selectedPackage?.id == pkg.id
                            val effectiveMonths = pkg.soThang ?: when (pkg.giaTien) {
                                1_000_000L -> 2
                                1_500_000L -> 3
                                else -> 1
                            }
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    selectedPackage = pkg
                                    customPackageName = pkg.tenGoi
                                    contractPriceText = pkg.giaTien.toString()
                                    collectedPriceText = pkg.giaTien.toString()
                                    val startSpec = LocalDateSpec.parseDisplay(startDateDisplay) ?: todaySpec
                                    val endEx = FinancialEngine.calculateExclusiveEndDate(
                                        startDate = startSpec,
                                        months = effectiveMonths,
                                        customDays = pkg.soNgayTuyChinh
                                    )
                                    lastTrainingDateDisplay = DateUtils.toDisplayedLastTrainingDate(endEx).toDisplayString()
                                },
                                label = {
                                    val durText = when {
                                        pkg.soThang != null -> "${pkg.soThang} tháng"
                                        pkg.soNgayTuyChinh != null -> "${pkg.soNgayTuyChinh} ngày"
                                        else -> "$effectiveMonths tháng"
                                    }
                                    Text("${pkg.tenGoi} • ${DateUtils.formatVnd(pkg.giaTien)} ($durText)")
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = accentColor.copy(alpha = if (tokens.isDark) 0.22f else 0.14f),
                                    selectedLabelColor = accentColor
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = customPackageName,
                        onValueChange = { customPackageName = it },
                        label = { Text("Tên gói tập lưu trong hợp đồng *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    DatePickerField(
                        label = if (isRenewal) "Ngày đăng ký gia hạn *" else "Ngày đăng ký *",
                        dateDisplay = registrationDateDisplay,
                        onDateChanged = {
                            registrationDateDisplay = it
                            paymentDateDisplay = it
                        },
                        testTag = "input_ngay_dang_ky"
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        DatePickerField(
                            label = "Ngày bắt đầu tập *",
                            dateDisplay = startDateDisplay,
                            onDateChanged = { newStart ->
                                startDateDisplay = newStart
                                val sSpec = LocalDateSpec.parseDisplay(newStart)
                                val pkg = selectedPackage
                                if (sSpec != null && pkg != null) {
                                    val effectiveMonths = pkg.soThang ?: when (pkg.giaTien) {
                                        1_000_000L -> 2
                                        1_500_000L -> 3
                                        else -> 1
                                    }
                                    val endEx = FinancialEngine.calculateExclusiveEndDate(
                                        startDate = sSpec,
                                        months = effectiveMonths,
                                        customDays = pkg.soNgayTuyChinh
                                    )
                                    lastTrainingDateDisplay = DateUtils.toDisplayedLastTrainingDate(endEx).toDisplayString()
                                }
                            },
                            modifier = Modifier.weight(1f),
                            testTag = "input_ngay_bat_dau"
                        )
                        DatePickerField(
                            label = "Ngày hết hạn (cuối) *",
                            dateDisplay = lastTrainingDateDisplay,
                            onDateChanged = { lastTrainingDateDisplay = it },
                            modifier = Modifier.weight(1f),
                            testTag = "input_ngay_het_han"
                        )
                    }

                    if (totalDaysPreview > 0 && endExPreview != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Thời hạn hợp đồng: $totalDaysPreview ngày thực tế (Kết thúc độc quyền nội bộ: ${endExPreview.toDisplayString()})",
                            style = MaterialTheme.typography.labelSmall,
                            color = accentColor,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = contractPriceText,
                            onValueChange = {
                                val clean = it.filter { ch -> ch.isDigit() }
                                contractPriceText = clean
                                collectedPriceText = clean
                            },
                            label = { Text("Giá hợp đồng (VNĐ) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("input_gia_hop_dong")
                        )
                        OutlinedTextField(
                            value = collectedPriceText,
                            onValueChange = { collectedPriceText = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Thực thu (VNĐ) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("input_thuc_thu")
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    DatePickerField(
                        label = "Ngày thanh toán thực tế (Tính dòng tiền)",
                        dateDisplay = paymentDateDisplay,
                        onDateChanged = { paymentDateDisplay = it },
                        testTag = "input_ngay_thanh_toan"
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = ghiChuHopDong,
                        onValueChange = { ghiChuHopDong = it },
                        label = { Text("Ghi chú hợp đồng") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorMessage!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = tokens.statusExpiredText,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                } // End scrollable form body

                // STICKY BOTTOM ACTION BAR
                HorizontalDivider(color = tokens.borderColor)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Hủy", color = tokens.textSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val sttVal = sttText.toIntOrNull()
                            if (!isRenewal && (sttVal == null || sttVal <= 0)) {
                                errorMessage = "Vui lòng nhập STT hợp lệ (> 0)."
                                return@Button
                            }
                            if (!isRenewal && hoTen.isBlank()) {
                                errorMessage = "Vui lòng nhập Họ và tên hội viên."
                                return@Button
                            }
                            val regSpec = LocalDateSpec.parseDisplay(registrationDateDisplay)
                            val startSpec = LocalDateSpec.parseDisplay(startDateDisplay)
                            val lastDaySpec = LocalDateSpec.parseDisplay(lastTrainingDateDisplay)
                            val paySpec = LocalDateSpec.parseDisplay(paymentDateDisplay)

                            if (regSpec == null || startSpec == null || lastDaySpec == null || paySpec == null) {
                                errorMessage = "Định dạng ngày không hợp lệ (Chuẩn dd/MM/yyyy)."
                                return@Button
                            }
                            val exclusiveEndSpec = DateUtils.toExclusiveEndDate(lastDaySpec)
                            if (DateUtils.daysBetween(startSpec, exclusiveEndSpec) <= 0) {
                                errorMessage = "Ngày hết hạn cuối cùng phải lớn hơn hoặc bằng ngày bắt đầu."
                                return@Button
                            }
                            val contractAmount = contractPriceText.toLongOrNull() ?: 0L
                            val collectedAmount = collectedPriceText.toLongOrNull() ?: 0L
                            if (contractAmount <= 0L) {
                                errorMessage = "Giá trị hợp đồng phải lớn hơn 0đ."
                                return@Button
                            }

                            if (!isRenewal) {
                                onConfirmNewMember(
                                    sttVal!!,
                                    hoTen.trim(),
                                    soDienThoai.trim(),
                                    selectedDoiTuong,
                                    selectedPackage?.id,
                                    customPackageName.ifBlank { "Gói tập $boMon" },
                                    regSpec.toIsoString(),
                                    startSpec.toIsoString(),
                                    exclusiveEndSpec.toIsoString(),
                                    contractAmount,
                                    collectedAmount,
                                    paySpec.toIsoString(),
                                    ghiChuHoiVien,
                                    ghiChuHopDong
                                )
                            } else {
                                val loaiHd = if (previousEndExclusiveSpec != null && regSpec > previousEndExclusiveSpec) {
                                    LoaiHopDong.DANG_KY_LAI
                                } else {
                                    LoaiHopDong.GIA_HAN
                                }
                                onConfirmRenewal(
                                    loaiHd,
                                    LoaiBaoCao.GIA_HAN,
                                    selectedPackage?.id,
                                    customPackageName.ifBlank { "Gói gia hạn $boMon" },
                                    regSpec.toIsoString(),
                                    startSpec.toIsoString(),
                                    exclusiveEndSpec.toIsoString(),
                                    contractAmount,
                                    collectedAmount,
                                    paySpec.toIsoString(),
                                    ghiChuHopDong
                                )
                            }
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = solidBrandColor,
                            contentColor = Color.White
                        ),
                        modifier = Modifier.testTag("confirm_save_member_btn")
                    ) {
                        Text(if (isRenewal) "Lưu hợp đồng gia hạn" else "Lưu hội viên & hợp đồng")
                    }
                }
            }
        }
    }
}

@Composable
fun WarningBanner(text: String) {
    val tokens = LocalAppDesignTokens.current
    Surface(
        color = tokens.statusWarningBg,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.WarningAmber,
                contentDescription = null,
                tint = tokens.statusWarningText,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodySmall,
                color = tokens.statusWarningText,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

/**
 * Hồ sơ chi tiết hội viên + Toàn bộ lịch sử hợp đồng + Lịch sử thanh toán + Sửa hợp đồng / Thu nợ (Phần 5.2, 5.3, 7.2).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MemberProfileDetailDialog(
    memberUi: MemberWithContractsUi,
    onDismiss: () -> Unit,
    onRequestRenew: () -> Unit,
    onUpdateMemberInfo: (Int, String, String, String, String) -> Unit,
    onUpdateContract: (MemberContractEntity, String, String, String, String, Long, Long, String, String) -> Unit,
    onCollectDebt: (MemberContractEntity, Long, String, String) -> Unit,
    onDeleteMember: () -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    val boMon = memberUi.member.boMon
    val isYoga = boMon == BoMon.YOGA
    val accentColor = if (isYoga) tokens.yogaAccent else tokens.gymAccent
    val solidBrandColor = if (isYoga) YogaPrimary else GymPrimary

    var showEditMemberForm by remember { mutableStateOf(false) }
    var contractToEdit by remember { mutableStateOf<MemberContractEntity?>(null) }
    var contractForDebtCollection by remember { mutableStateOf<MemberContractEntity?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .heightIn(max = 720.dp)
                .padding(vertical = 12.dp),
            shape = RoundedCornerShape(20.dp),
            color = tokens.surface
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // STICKY TOP HEADER BAR
                Surface(
                    color = tokens.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                DepartmentBadge(boMon = boMon)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Mã: ${memberUi.member.id}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = tokens.textSecondary
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "#${memberUi.member.stt} – ${memberUi.member.hoTen}",
                                style = MaterialTheme.typography.titleLarge,
                                color = tokens.textPrimary,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "Đóng",
                                tint = tokens.textPrimary
                            )
                        }
                    }
                }
                HorizontalDivider(color = tokens.borderColor)

                // SCROLLABLE BODY
                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "SĐT: ${memberUi.member.soDienThoai.ifBlank { "Chưa cập nhật" }} • Ngày tạo: ${DateUtils.isoToDisplay(memberUi.member.ngayTao)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = tokens.textSecondary
                        )
                    }
                    if (memberUi.member.ghiChu.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Ghi chú: ${memberUi.member.ghiChu}",
                            style = MaterialTheme.typography.bodySmall,
                            color = tokens.textSecondary
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = onRequestRenew,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = solidBrandColor,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Gia hạn hợp đồng mới", maxLines = 1)
                        }
                        OutlinedButton(
                            onClick = { showEditMemberForm = !showEditMemberForm },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Sửa hồ sơ", maxLines = 1)
                        }
                        OutlinedButton(
                            onClick = { showDeleteConfirm = true },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                Icons.Default.DeleteOutline,
                                contentDescription = "Xóa hội viên",
                                tint = tokens.statusExpiredText,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Xóa", color = tokens.statusExpiredText, maxLines = 1)
                        }
                    }

                    if (showEditMemberForm) {
                        Spacer(modifier = Modifier.height(12.dp))
                        EditMemberInlineSection(
                            member = memberUi.member,
                            accentColor = solidBrandColor,
                            onSave = { stt, name, phone, loai, note ->
                                onUpdateMemberInfo(stt, name, phone, loai, note)
                                showEditMemberForm = false
                            },
                            onCancel = { showEditMemberForm = false }
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = tokens.borderColor)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Lịch sử toàn bộ hợp đồng (Phần 5.3)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.History, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Lịch sử hợp đồng (${memberUi.contracts.size} hợp đồng)",
                            style = MaterialTheme.typography.titleMedium,
                            color = tokens.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "Mỗi lần đăng ký hoặc gia hạn tạo một hợp đồng độc lập. Chạm 'Sửa ngày/giá' để điều chỉnh thủ công.",
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.textSecondary
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    memberUi.contracts.forEachIndexed { idx, contract ->
                        val startSpec = LocalDateSpec.parseIso(contract.ngayBatDau)
                        val endExSpec = LocalDateSpec.parseIso(contract.ngayKetThucDocQuyen)
                        val lastDayStr = endExSpec?.let { DateUtils.toDisplayedLastTrainingDate(it).toDisplayString() } ?: "-"
                        val totalDays = if (startSpec != null && endExSpec != null) {
                            DateUtils.daysBetween(startSpec, endExSpec)
                        } else 0
                        val debt = (contract.soTienHopDong - contract.soTienDaThu).coerceAtLeast(0L)
                        val schedule = if (startSpec != null && endExSpec != null) {
                            FinancialEngine.generateFullContractSchedule(startSpec, endExSpec, contract.soTienHopDong)
                        } else emptyList()

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = tokens.elevatedSurface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp)
                                .border(1.dp, tokens.borderColor, RoundedCornerShape(12.dp))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${idx + 1}. ${contract.goiTap}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = accentColor
                                    )
                                    Text(
                                        text = LoaiBaoCao.labelVi(contract.loaiBaoCao),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = tokens.textSecondary
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Bắt đầu: ${DateUtils.isoToDisplay(contract.ngayBatDau)} → Hết hạn tập: $lastDayStr ($totalDays ngày)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = tokens.textPrimary,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "Giá HĐ: ${DateUtils.formatVnd(contract.soTienHopDong)} | Đã thu: ${DateUtils.formatVnd(contract.soTienDaThu)} (Ngày TT: ${DateUtils.isoToDisplay(contract.ngayThanhToan)})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = tokens.textSecondary
                                )
                                if (schedule.isNotEmpty()) {
                                    val scheduleText = schedule.joinToString(" • ") {
                                        "T${it.month}/${it.year}: ${DateUtils.formatVnd(it.allocatedAmount)} (${it.daysInMonth}n)"
                                    }
                                    Text(
                                        text = "Phân bổ: $scheduleText",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = accentColor
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = { contractToEdit = contract },
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Sửa ngày / giá", style = MaterialTheme.typography.labelSmall)
                                    }
                                    if (debt > 0L) {
                                        Button(
                                            onClick = { contractForDebtCollection = contract },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = StatusActiveGreen,
                                                contentColor = Color.White
                                            ),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Thu nợ ${DateUtils.formatVnd(debt)}", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Lịch sử thanh toán (Phần 5.2)
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Payments, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Lịch sử thanh toán (${memberUi.payments.size} giao dịch)",
                            style = MaterialTheme.typography.titleMedium,
                            color = tokens.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    if (memberUi.payments.isEmpty()) {
                        Text(
                            text = "Chưa có giao dịch thanh toán.",
                            style = MaterialTheme.typography.bodySmall,
                            color = tokens.textSecondary
                        )
                    } else {
                        memberUi.payments.forEach { p ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = p.ghiChu.ifBlank { "Thanh toán hợp đồng" },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = tokens.textPrimary,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = "Ngày thu: ${DateUtils.isoToDisplay(p.ngayThanhToan)} • Mã: ${p.id}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = tokens.textSecondary
                                    )
                                }
                                Text(
                                    text = DateUtils.formatVnd(p.soTien),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.statusActiveText
                                )
                            }
                        }
                    }
                } // End scrollable body
            }
        }
    }

    if (contractToEdit != null) {
        EditContractDialog(
            contract = contractToEdit!!,
            onDismiss = { contractToEdit = null },
            onSave = { goiTap, loaiBc, startIso, endExIso, price, paid, payDateIso, note ->
                onUpdateContract(
                    contractToEdit!!,
                    goiTap,
                    loaiBc,
                    startIso,
                    endExIso,
                    price,
                    paid,
                    payDateIso,
                    note
                )
                contractToEdit = null
            }
        )
    }

    if (contractForDebtCollection != null) {
        val c = contractForDebtCollection!!
        val remainingDebt = (c.soTienHopDong - c.soTienDaThu).coerceAtLeast(0L)
        var collectText by remember(c) { mutableStateOf(remainingDebt.toString()) }
        var collectDate by remember { mutableStateOf(LocalDateSpec.today().toDisplayString()) }
        var collectNote by remember { mutableStateOf("Thu nợ hợp đồng ${c.goiTap}") }

        AlertDialog(
            onDismissRequest = { contractForDebtCollection = null },
            title = { Text("Thu nợ hợp đồng") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Còn nợ: ${DateUtils.formatVnd(remainingDebt)}")
                    OutlinedTextField(
                        value = collectText,
                        onValueChange = { collectText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số tiền thu thêm (VNĐ)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    DatePickerField(
                        label = "Ngày thu thực tế",
                        dateDisplay = collectDate,
                        onDateChanged = { collectDate = it }
                    )
                    OutlinedTextField(
                        value = collectNote,
                        onValueChange = { collectNote = it },
                        label = { Text("Ghi chú") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = collectText.toLongOrNull() ?: 0L
                        val dIso = DateUtils.displayToIso(collectDate) ?: LocalDateSpec.today().toIsoString()
                        if (amt > 0L) {
                            onCollectDebt(c, amt, dIso, collectNote)
                        }
                        contractForDebtCollection = null
                    }
                ) {
                    Text("Xác nhận thu")
                }
            },
            dismissButton = {
                TextButton(onClick = { contractForDebtCollection = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Chuyển hội viên vào thùng rác?") },
            text = {
                Text("Hồ sơ hội viên \"${memberUi.member.hoTen}\" sẽ được chuyển vào Thùng rác trong phần Cài đặt và có thể khôi phục khi cần.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteMember()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StatusExpiredRed,
                        contentColor = Color.White
                    )
                ) {
                    Text("Chuyển vào thùng rác")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Hủy")
                }
            }
        )
    }
}

@Composable
private fun EditMemberInlineSection(
    member: com.example.data.local.MemberEntity,
    accentColor: Color,
    onSave: (Int, String, String, String, String) -> Unit,
    onCancel: () -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    var sttText by remember { mutableStateOf(member.stt.toString()) }
    var hoTen by remember { mutableStateOf(member.hoTen) }
    var sdt by remember { mutableStateOf(member.soDienThoai) }
    var loaiKhach by remember { mutableStateOf(member.loaiKhach) }
    var ghiChu by remember { mutableStateOf(member.ghiChu) }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = tokens.elevatedSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, tokens.borderColor, RoundedCornerShape(12.dp))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "Chỉnh sửa thông tin hồ sơ",
                style = MaterialTheme.typography.titleSmall,
                color = tokens.textPrimary,
                fontWeight = FontWeight.Bold
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = sttText,
                    onValueChange = { sttText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("STT") },
                    singleLine = true,
                    modifier = Modifier.weight(0.35f)
                )
                OutlinedTextField(
                    value = hoTen,
                    onValueChange = { hoTen = it },
                    label = { Text("Họ và tên") },
                    singleLine = true,
                    modifier = Modifier.weight(0.65f)
                )
            }
            OutlinedTextField(
                value = sdt,
                onValueChange = { sdt = it },
                label = { Text("Số điện thoại") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = ghiChu,
                onValueChange = { ghiChu = it },
                label = { Text("Ghi chú") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                TextButton(onClick = onCancel) { Text("Đóng") }
                Button(
                    onClick = {
                        val stt = sttText.toIntOrNull() ?: member.stt
                        if (hoTen.isNotBlank()) {
                            onSave(stt, hoTen, sdt, loaiKhach, ghiChu)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = accentColor,
                        contentColor = Color.White
                    )
                ) {
                    Text("Lưu thay đổi")
                }
            }
        }
    }
}

/**
 * Hộp thoại chỉnh sửa Ngày bắt đầu, Ngày hết hạn cuối cùng, Giá trị hợp đồng, Loại báo cáo (Phần 7.2 & 13.3).
 */
@Composable
fun EditContractDialog(
    contract: MemberContractEntity,
    onDismiss: () -> Unit,
    onSave: (
        goiTap: String,
        loaiBaoCao: String,
        startIso: String,
        endExclusiveIso: String,
        price: Long,
        paid: Long,
        payDateIso: String,
        note: String
    ) -> Unit
) {
    val initialEndEx = LocalDateSpec.parseIso(contract.ngayKetThucDocQuyen) ?: LocalDateSpec.today().plusMonths(1)
    val initialLastTrainDay = DateUtils.toDisplayedLastTrainingDate(initialEndEx)

    var goiTap by remember { mutableStateOf(contract.goiTap) }
    var loaiBaoCao by remember { mutableStateOf(contract.loaiBaoCao) }
    var startDisplay by remember { mutableStateOf(DateUtils.isoToDisplay(contract.ngayBatDau)) }
    var lastDayDisplay by remember { mutableStateOf(initialLastTrainDay.toDisplayString()) }
    var priceText by remember { mutableStateOf(contract.soTienHopDong.toString()) }
    var paidText by remember { mutableStateOf(contract.soTienDaThu.toString()) }
    var payDateDisplay by remember { mutableStateOf(DateUtils.isoToDisplay(contract.ngayThanhToan)) }
    var ghiChu by remember { mutableStateOf(contract.ghiChu) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Chỉnh sửa hợp đồng & Phân bổ") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = goiTap,
                    onValueChange = { goiTap = it },
                    label = { Text("Gói tập") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = loaiBaoCao == LoaiBaoCao.CON_HAN,
                        onClick = { loaiBaoCao = LoaiBaoCao.CON_HAN },
                        label = { Text("Còn hạn / Mới") }
                    )
                    FilterChip(
                        selected = loaiBaoCao == LoaiBaoCao.GIA_HAN,
                        onClick = { loaiBaoCao = LoaiBaoCao.GIA_HAN },
                        label = { Text("Gia hạn") }
                    )
                }
                DatePickerField(
                    label = "Ngày bắt đầu tập",
                    dateDisplay = startDisplay,
                    onDateChanged = { startDisplay = it }
                )
                DatePickerField(
                    label = "Ngày hết hạn cuối cùng được tập",
                    dateDisplay = lastDayDisplay,
                    onDateChanged = { lastDayDisplay = it }
                )
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Giá trị hợp đồng (VNĐ)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = paidText,
                    onValueChange = { paidText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Số tiền thực tế đã thu (VNĐ)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                DatePickerField(
                    label = "Ngày thanh toán",
                    dateDisplay = payDateDisplay,
                    onDateChanged = { payDateDisplay = it }
                )
                OutlinedTextField(
                    value = ghiChu,
                    onValueChange = { ghiChu = it },
                    label = { Text("Ghi chú") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (errorMsg != null) {
                    Text(errorMsg!!, color = StatusExpiredRed, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val sSpec = LocalDateSpec.parseDisplay(startDisplay)
                    val lSpec = LocalDateSpec.parseDisplay(lastDayDisplay)
                    val pSpec = LocalDateSpec.parseDisplay(payDateDisplay)
                    if (sSpec == null || lSpec == null || pSpec == null) {
                        errorMsg = "Ngày không hợp lệ (dd/MM/yyyy)."
                        return@Button
                    }
                    val endEx = DateUtils.toExclusiveEndDate(lSpec)
                    if (DateUtils.daysBetween(sSpec, endEx) <= 0) {
                        errorMsg = "Ngày hết hạn cuối cùng phải >= ngày bắt đầu."
                        return@Button
                    }
                    val price = priceText.toLongOrNull() ?: 0L
                    val paid = paidText.toLongOrNull() ?: 0L
                    onSave(
                        goiTap.ifBlank { "Gói tập" },
                        loaiBaoCao,
                        sSpec.toIsoString(),
                        endEx.toIsoString(),
                        price,
                        paid,
                        pSpec.toIsoString(),
                        ghiChu
                    )
                }
            ) {
                Text("Lưu chỉnh sửa")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Hủy")
            }
        }
    )
}
