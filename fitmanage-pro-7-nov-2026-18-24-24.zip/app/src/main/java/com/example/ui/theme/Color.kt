package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// --- LIGHT MODE: Modern Cyber Fitness Daylight Palette (Sections IV & V) ---
// GYM / REVENUE / TRACKING Light
val GymPrimary = Color(0xFF0D47A1)        // Deep Electric Blue
val GymPrimaryDark = Color(0xFF082E6B)    // Deep Navy
val GymSecondary = Color(0xFF0284C7)      // Metallic Blue
val GymPrimaryLight = Color(0xFFE0F2FE)   // Soft Electric Blue tint
val GymBackground = Color(0xFFF1F5F9)     // Cool White-Gray background
val GymSurface = Color(0xFFFFFFFF)        // Pure White surface
val GymTextPrimary = Color(0xFF0F172A)    // Deep Navy-Black text (High contrast)
val GymTextSecondary = Color(0xFF475569)  // Slate secondary text
val GymBorder = Color(0xFFCBD5E1)         // Crisp light gray border

// YOGA Light
val YogaPrimary = Color(0xFF6B2FB5)       // Deep Cyber Purple
val YogaPrimaryDark = Color(0xFF4A1D85)   // Deep Violet
val YogaSecondary = Color(0xFF8B5CF6)     // Vivid Violet
val YogaPrimaryLight = Color(0xFFF3E8FF)  // Soft Lavender tint
val YogaBackground = Color(0xFFF5F3F9)    // Cool Lavender-Gray background
val YogaSurface = Color(0xFFFFFFFF)       // Pure White surface
val YogaTextPrimary = Color(0xFF1A1228)   // Deep Plum-Black text (High contrast)
val YogaTextSecondary = Color(0xFF584B6B) // Muted Violet-Slate text
val YogaBorder = Color(0xFFD8CEE6)        // Crisp Lavender-Gray border

// --- DARK MODE: Cyber Fitness Navy & Neon Palette (Sections IV & V) ---
// GYM / REVENUE / TRACKING Dark
val DarkGymPrimary = Color(0xFF2997FF)           // Electric Blue
val DarkGymPrimaryContainer = Color(0xFF132F52)  // Deep Metallic Blue container
val DarkGymSecondary = Color(0xFF38BDF8)         // Cyber Cyan-Blue
val DarkGymBackground = Color(0xFF0A0F18)        // Dark Navy background
val DarkGymSurface = Color(0xFF111927)           // Navy Blue surface
val DarkGymCardSurface = Color(0xFF172235)       // Layered Navy-Black card
val DarkGymTextPrimary = Color(0xFFF1F5F9)       // Crisp Cool White
val DarkGymTextSecondary = Color(0xFF94A3B8)     // Metallic Slate Gray
val DarkGymBorder = Color(0xFF24344D)            // Subtle Cyber Navy border

// YOGA Dark
val DarkYogaPrimary = Color(0xFFB366FF)          // Cyber Purple
val DarkYogaPrimaryContainer = Color(0xFF2E1B4B) // Deep Violet container
val DarkYogaSecondary = Color(0xFFD4A5FF)        // Soft Lavender
val DarkYogaBackground = Color(0xFF0D0A16)       // Deepest Cyber Violet-Navy
val DarkYogaSurface = Color(0xFF161124)          // Dark Violet-Navy surface
val DarkYogaCardSurface = Color(0xFF1F1833)      // Layered Violet-Charcoal card
val DarkYogaTextPrimary = Color(0xFFF5F0FF)      // Crisp Lavender-White
val DarkYogaTextSecondary = Color(0xFFA99BC2)    // Muted Lavender-Gray
val DarkYogaBorder = Color(0xFF32264D)           // Subtle Cyber Purple border

// --- Status Colors (Light Mode — High Contrast on White) ---
val StatusActiveGreen = Color(0xFF059669)        // Emerald Green
val StatusActiveGreenBg = Color(0xFFD1FAE5)

val StatusExpiring15Amber = Color(0xFFD97706)    // Amber
val StatusExpiring15AmberBg = Color(0xFFFEF3C7)

val StatusExpiring7Orange = Color(0xFFEA580C)    // Deep Amber-Orange
val StatusExpiring7OrangeBg = Color(0xFFFFEDD5)

val StatusExpiringTodayOrange = Color(0xFFDC2626)
val StatusExpiringTodayOrangeBg = Color(0xFFFEE2E2)

val StatusExpiredRed = Color(0xFFDC2626)         // Crimson Red
val StatusExpiredRedBg = Color(0xFFFEE2E2)

val StatusInfoBlue = Color(0xFF0284C7)
val StatusInfoBlueBg = Color(0xFFE0F2FE)

// --- Status Colors (Dark Mode — Luminous Emerald, Amber, Red on Dark Navy) ---
val DarkStatusActiveGreen = Color(0xFF34D399)    // Emerald Green
val DarkStatusActiveGreenBg = Color(0xFF0D2E24)

val DarkStatusExpiringAmber = Color(0xFFFBBF24)  // Amber
val DarkStatusExpiringAmberBg = Color(0xFF33250E)

val DarkStatusExpiringOrange = Color(0xFFFB923C) // Urgent Amber-Orange
val DarkStatusExpiringOrangeBg = Color(0xFF381E10)

val DarkStatusExpiredRed = Color(0xFFF87171)     // Luminous Red
val DarkStatusExpiredRedBg = Color(0xFF38151A)

val DarkStatusInfoBlue = Color(0xFF38BDF8)
val DarkStatusInfoBlueBg = Color(0xFF0F2940)

val RevenuePrimary = Color(0xFF0D47A1)
val RevenuePrimaryDark = Color(0xFF082E6B)
