package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.SportsGymnastics
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.BoMon
import com.example.data.local.LoaiVeKhachLe
import com.example.data.local.PtContractEntity
import com.example.data.local.PtSessionEntity
import com.example.data.local.WalkInTicketEntity
import com.example.domain.DateUtils
import com.example.domain.FinancialEngine
import com.example.domain.LocalDateSpec
import com.example.ui.components.DatePickerField
import com.example.ui.components.MemberProfileDetailDialog
import com.example.ui.components.MemberRegistrationOrRenewalDialog
import com.example.ui.components.MemberRowItem
import com.example.ui.theme.GymPrimary
import com.example.ui.theme.LocalAppDesignTokens
import com.example.ui.theme.StatusActiveGreen
import com.example.ui.theme.StatusExpiredRed
import com.example.ui.theme.YogaPrimary
import com.example.ui.viewmodel.AppUiState
import com.example.ui.viewmodel.GymYogaViewModel
import com.example.ui.viewmodel.MemberWithContractsUi
import com.example.ui.viewmodel.PtContractWithSessionsUi

@Composable
fun DepartmentMemberScreen(
    boMon: String, // BoMon.GYM hoặc BoMon.YOGA
    uiState: AppUiState,
    viewModel: GymYogaViewModel,
    onOpenPricingSettings: () -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    val isYoga = boMon == BoMon.YOGA
    val primaryColor = MaterialTheme.colorScheme.primary
    val solidBrandColor = if (isYoga) YogaPrimary else GymPrimary

    val members = if (isYoga) uiState.yogaMembers else uiState.gymMembers
    val maxStt = if (isYoga) uiState.maxSttYoga else uiState.maxSttGym
    val nextStt = if (isYoga) uiState.nextSttYoga else uiState.nextSttGym

    var searchQuery by remember(boMon) { mutableStateOf("") }
    // Sub-tab only for GYM: 0 = Hội viên GYM, 1 = Khách tập PT, 2 = Khách lẻ (Ngày/Tuần)
    var gymSubTab by remember(boMon) { mutableIntStateOf(0) }

    var showAddMemberDialog by remember { mutableStateOf(false) }
    var memberForRenewal by remember { mutableStateOf<MemberWithContractsUi?>(null) }
    var selectedMemberProfile by remember { mutableStateOf<MemberWithContractsUi?>(null) }

    // PT Dialog states (GYM only)
    var showAddPtDialog by remember { mutableStateOf(false) }
    var selectedPtForDetail by remember { mutableStateOf<PtContractWithSessionsUi?>(null) }

    // Walk-in Dialog states (GYM only)
    var showCustomWalkInDialog by remember { mutableStateOf(false) }
    var walkInToEdit by remember { mutableStateOf<WalkInTicketEntity?>(null) }

    val filteredMembers = remember(members, searchQuery) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) {
            members
        } else {
            members.filter { item ->
                item.member.stt.toString().contains(q) ||
                    item.member.hoTen.lowercase().contains(q) ||
                    item.member.soDienThoai.lowercase().contains(q)
            }
        }
    }

    Scaffold(
        containerColor = tokens.background,
        floatingActionButton = {
            val fabLabel = when {
                isYoga -> "Thêm HV Yoga"
                gymSubTab == 0 -> "Thêm HV Gym"
                gymSubTab == 1 -> "Thêm HĐ PT"
                else -> "Thêm Vé Lẻ"
            }
            val fabIcon = when {
                isYoga || gymSubTab == 0 -> Icons.Default.PersonAdd
                else -> Icons.Default.Add
            }
            FloatingActionButton(
                onClick = {
                    when {
                        isYoga || gymSubTab == 0 -> showAddMemberDialog = true
                        gymSubTab == 1 -> showAddPtDialog = true
                        else -> showCustomWalkInDialog = true
                    }
                },
                containerColor = solidBrandColor,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_${boMon.lowercase()}")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(fabIcon, contentDescription = fabLabel)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(fabLabel, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 116.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Minimalist Premium Overview Header (Phần II, III & V.1/V.2 — Không dùng ảnh banner, không dùng từ "PHÂN HỆ")
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = tokens.cardSurface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(primaryColor.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isYoga) Icons.Default.SelfImprovement else Icons.Default.FitnessCenter,
                                        contentDescription = null,
                                        tint = primaryColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = if (isYoga) "YOGA" else "GYM",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = tokens.textPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Surface(
                                color = tokens.elevatedSurface,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.border(1.dp, tokens.borderColor, RoundedCornerShape(8.dp))
                            ) {
                                Text(
                                    text = "STT max: #$maxStt · Gợi ý: #$nextStt",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = primaryColor,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                    maxLines = 1
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val activeCount = members.count { it.remainingDays >= 0 }
                            val expiredCount = members.count { it.remainingDays < 0 }
                            StatMetricTile(
                                label = "Tổng hội viên",
                                value = "${members.size}",
                                valueColor = tokens.textPrimary,
                                icon = Icons.Default.Groups,
                                modifier = Modifier.weight(1f)
                            )
                            StatMetricTile(
                                label = "Đang còn hạn",
                                value = "$activeCount",
                                valueColor = tokens.statusActiveText,
                                icon = Icons.Default.EventAvailable,
                                modifier = Modifier.weight(1f)
                            )
                            StatMetricTile(
                                label = "Đã hết hạn",
                                value = "$expiredCount",
                                valueColor = if (expiredCount > 0) tokens.statusExpiredText else tokens.textSecondary,
                                icon = Icons.Default.EventBusy,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Quick Walk-in Bar only for GYM (Phần V.1 & Phần 10)
            if (!isYoga) {
                item {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = tokens.cardSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, tokens.borderColor, RoundedCornerShape(14.dp))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.quickCollectOneDayWalkIn() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = solidBrandColor,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("quick_walk_in_30k_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Bolt,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Thu 1 ngày lẻ · 30.000đ",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            OutlinedButton(
                                onClick = { showCustomWalkInDialog = true },
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                                modifier = Modifier.testTag("custom_walk_in_btn")
                            ) {
                                Text(
                                    text = "Vé lẻ khác",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = primaryColor,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                // GYM Sub-tabs: Hội viên | Khách PT | Khách lẻ (Scrollable on narrow screens)
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Triple(0, "Hội viên (${members.size})", Icons.Default.Groups),
                            Triple(1, "Khách PT (${uiState.ptContracts.size})", Icons.Default.SportsGymnastics),
                            Triple(2, "Khách lẻ (${uiState.walkInTickets.size})", Icons.Default.ConfirmationNumber)
                        ).forEach { (idx, title, icon) ->
                            val selected = gymSubTab == idx
                            FilterChip(
                                selected = selected,
                                onClick = { gymSubTab = idx },
                                label = {
                                    Text(
                                        text = title,
                                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                                        maxLines = 1
                                    )
                                },
                                leadingIcon = {
                                    Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = primaryColor.copy(alpha = if (tokens.isDark) 0.22f else 0.14f),
                                    selectedLabelColor = primaryColor,
                                    selectedLeadingIconColor = primaryColor
                                ),
                                modifier = Modifier.testTag("gym_subtab_$idx")
                            )
                        }
                    }
                }
            }

            // Content according to active mode
            if (isYoga || gymSubTab == 0) {
                // Search bar for STT, Họ và tên, Số điện thoại (Phần 5 & 6)
                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = {
                            Text(
                                "Tìm theo STT, Họ và tên hoặc Số điện thoại...",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = "Tìm kiếm", tint = primaryColor)
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Xóa tìm kiếm")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = primaryColor,
                            unfocusedBorderColor = tokens.borderColor,
                            unfocusedContainerColor = tokens.cardSurface,
                            focusedContainerColor = tokens.cardSurface
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_member_${boMon.lowercase()}")
                    )
                }

                if (filteredMembers.isEmpty()) {
                    item {
                        EmptyDepartmentState(
                            title = if (searchQuery.isBlank()) "Chưa có hội viên $boMon nào" else "Không tìm thấy hội viên phù hợp",
                            subtitle = if (searchQuery.isBlank()) {
                                "Bấm nút '+ Thêm HV ${if (isYoga) "Yoga" else "Gym"}' ở góc dưới bên phải để tạo hồ sơ và hợp đồng đầu tiên (STT gợi ý: #$nextStt)."
                            } else {
                                "Thử tìm bằng STT, tên khác hoặc số điện thoại."
                            },
                            accentColor = primaryColor
                        )
                    }
                } else {
                    items(filteredMembers, key = { it.member.id }) { memberUi ->
                        MemberRowItem(
                            item = memberUi,
                            accentColor = primaryColor,
                            onClick = { selectedMemberProfile = memberUi },
                            onQuickRenew = { memberForRenewal = memberUi }
                        )
                    }
                }
            } else if (gymSubTab == 1) {
                // PHẦN 9: QUẢN LÝ KHÁCH TẬP PT (Chỉ áp dụng cho GYM)
                item {
                    Surface(
                        color = primaryColor.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Quy tắc PT: Trung tâm hưởng 50% – PT hưởng 50%",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = primaryColor
                            )
                            Text(
                                text = "Doanh thu phân bổ PT chỉ ghi nhận theo số buổi thực tế đã tập trong tháng (Kỳ đang chọn: T${uiState.revenueDashboard.month}/${uiState.revenueDashboard.year}).",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                if (uiState.ptContracts.isEmpty()) {
                    item {
                        EmptyDepartmentState(
                            title = "Chưa có hợp đồng PT nào",
                            subtitle = "Bấm '+ Thêm HĐ PT' ở góc dưới để tạo gói PT theo số buổi (ví dụ: 10 buổi – 1.400.000đ).",
                            accentColor = primaryColor
                        )
                    }
                } else {
                    items(uiState.ptContracts, key = { it.contract.id }) { ptUi ->
                        PtContractCardItem(
                            ptUi = ptUi,
                            selectedMonth = uiState.revenueDashboard.month,
                            selectedYear = uiState.revenueDashboard.year,
                            onRecordOneSessionToday = {
                                viewModel.recordPtSession(
                                    ptContract = ptUi,
                                    ngayTapIso = LocalDateSpec.today().toIsoString(),
                                    soBuoi = 1,
                                    ghiChu = "Tập 1 buổi PT"
                                )
                            },
                            onOpenDetail = { selectedPtForDetail = ptUi }
                        )
                    }
                }
            } else {
                // PHẦN 10: QUẢN LÝ KHÁCH TẬP BUỔI LẺ VÀ TUẦN LẺ (Chỉ áp dụng cho GYM)
                item {
                    Surface(
                        color = primaryColor.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Quản lý vé buổi lẻ & tuần lẻ (Chỉ áp dụng cho GYM)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = primaryColor
                            )
                            Text(
                                text = "Vé ngày ghi nhận theo ngày sử dụng. Vé tuần trải qua nhiều tháng tự động phân bổ theo số ngày dịch vụ thuộc từng tháng.",
                                style = MaterialTheme.typography.bodySmall,
                                color = tokens.textSecondary
                            )
                        }
                    }
                }

                if (uiState.walkInTickets.isEmpty()) {
                    item {
                        EmptyDepartmentState(
                            title = "Chưa có giao dịch khách tập lẻ",
                            subtitle = "Bấm 'Thu 1 ngày lẻ · 30.000đ' ở trên hoặc nút '+ Thêm Vé Lẻ' ở góc dưới.",
                            accentColor = primaryColor
                        )
                    }
                } else {
                    items(uiState.walkInTickets, key = { it.id }) { ticket ->
                        WalkInTicketItem(
                            ticket = ticket,
                            selectedMonth = uiState.revenueDashboard.month,
                            selectedYear = uiState.revenueDashboard.year,
                            onEdit = { walkInToEdit = ticket },
                            onDelete = { viewModel.deleteWalkInTicketToTrash(ticket) }
                        )
                    }
                }
            }
        }
    }

    // --- DIALOGS ---

    if (showAddMemberDialog) {
        MemberRegistrationOrRenewalDialog(
            boMon = boMon,
            isRenewal = false,
            existingMember = null,
            allDepartmentMembers = members,
            maxStt = maxStt,
            suggestedStt = nextStt,
            availablePackages = uiState.packages,
            onDismiss = { showAddMemberDialog = false },
            onOpenPricingSettings = {
                showAddMemberDialog = false
                onOpenPricingSettings()
            },
            onConfirmNewMember = { stt, hoTen, sdt, loaiKhach, goiId, tenGoi, regIso, startIso, endExIso, price, paid, payIso, noteM, noteC ->
                viewModel.registerNewMember(
                    boMon = boMon,
                    stt = stt,
                    hoTen = hoTen,
                    soDienThoai = sdt,
                    loaiKhach = loaiKhach,
                    goiTapId = goiId,
                    tenGoiTap = tenGoi,
                    ngayDangKyIso = regIso,
                    ngayBatDauIso = startIso,
                    ngayKetThucDocQuyenIso = endExIso,
                    soTienHopDong = price,
                    soTienDaThu = paid,
                    ngayThanhToanIso = payIso,
                    ghiChuHoiVien = noteM,
                    ghiChuHopDong = noteC
                )
            },
            onConfirmRenewal = { _, _, _, _, _, _, _, _, _, _, _ -> }
        )
    }

    if (memberForRenewal != null) {
        val targetMember = members.firstOrNull { it.member.id == memberForRenewal!!.member.id } ?: memberForRenewal!!
        MemberRegistrationOrRenewalDialog(
            boMon = boMon,
            isRenewal = true,
            existingMember = targetMember,
            allDepartmentMembers = members,
            maxStt = maxStt,
            suggestedStt = nextStt,
            availablePackages = uiState.packages,
            onDismiss = { memberForRenewal = null },
            onOpenPricingSettings = {
                memberForRenewal = null
                onOpenPricingSettings()
            },
            onConfirmNewMember = { _, _, _, _, _, _, _, _, _, _, _, _, _, _ -> },
            onConfirmRenewal = { loaiHd, loaiBc, goiId, tenGoi, regIso, startIso, endExIso, price, paid, payIso, noteC ->
                viewModel.renewMember(
                    member = targetMember.member,
                    loaiHopDong = loaiHd,
                    loaiBaoCao = loaiBc,
                    goiTapId = goiId,
                    tenGoiTap = tenGoi,
                    ngayDangKyIso = regIso,
                    ngayBatDauIso = startIso,
                    ngayKetThucDocQuyenIso = endExIso,
                    soTienHopDong = price,
                    soTienDaThu = paid,
                    ngayThanhToanIso = payIso,
                    ghiChuHopDong = noteC
                )
            }
        )
    }

    if (selectedMemberProfile != null) {
        val currentMember = members.firstOrNull { it.member.id == selectedMemberProfile!!.member.id }
        if (currentMember != null) {
            MemberProfileDetailDialog(
                memberUi = currentMember,
                onDismiss = { selectedMemberProfile = null },
                onRequestRenew = {
                    val m = currentMember
                    selectedMemberProfile = null
                    memberForRenewal = m
                },
                onUpdateMemberInfo = { stt, name, phone, loai, note ->
                    viewModel.updateMemberProfile(currentMember.member, stt, name, phone, loai, note)
                },
                onUpdateContract = { contract, goiTap, loaiBc, startIso, endExIso, price, paid, payIso, note ->
                    viewModel.updateContract(contract, goiTap, loaiBc, startIso, endExIso, price, paid, payIso, note)
                },
                onCollectDebt = { contract, amount, payDateIso, note ->
                    viewModel.collectDebtPayment(contract, amount, payDateIso, note)
                },
                onDeleteMember = {
                    viewModel.deleteMemberToTrash(currentMember.member)
                    selectedMemberProfile = null
                }
            )
        } else {
            selectedMemberProfile = null
        }
    }

    if (showAddPtDialog) {
        val nextPtStt = (uiState.ptContracts.maxOfOrNull { it.contract.stt } ?: 0) + 1
        AddPtContractDialog(
            suggestedStt = nextPtStt,
            onDismiss = { showAddPtDialog = false },
            onConfirm = { stt, maKhach, hoTen, sdt, goiPt, tongBuoi, giaHd, daThu, ptCenter, ptCoach, payIso, note ->
                viewModel.createPtContract(
                    stt = stt,
                    maKhach = maKhach,
                    hoTen = hoTen,
                    soDienThoai = sdt,
                    goiPt = goiPt,
                    tongSoBuoi = tongBuoi,
                    soTienHopDong = giaHd,
                    soTienDaThu = daThu,
                    phanTramTrungTam = ptCenter,
                    phanTramPt = ptCoach,
                    ngayThanhToanIso = payIso,
                    ghiChu = note
                )
                showAddPtDialog = false
            }
        )
    }

    if (selectedPtForDetail != null) {
        val latestPt = uiState.ptContracts.firstOrNull { it.contract.id == selectedPtForDetail!!.contract.id }
        if (latestPt != null) {
            PtContractDetailDialog(
                ptUi = latestPt,
                selectedMonth = uiState.revenueDashboard.month,
                selectedYear = uiState.revenueDashboard.year,
                onDismiss = { selectedPtForDetail = null },
                onAddSession = { dateIso, count, note ->
                    viewModel.recordPtSession(latestPt, dateIso, count, note)
                },
                onUpdateSession = { session -> viewModel.updatePtSession(session) },
                onDeleteSession = { session -> viewModel.deletePtSession(session) },
                onUpdateContract = { updatedContract -> viewModel.updatePtContract(updatedContract) },
                onDeleteContract = {
                    viewModel.deletePtContractToTrash(latestPt.contract)
                    selectedPtForDetail = null
                }
            )
        } else {
            selectedPtForDetail = null
        }
    }

    if (showCustomWalkInDialog || walkInToEdit != null) {
        WalkInTicketDialog(
            existingTicket = walkInToEdit,
            onDismiss = {
                showCustomWalkInDialog = false
                walkInToEdit = null
            },
            onSaveNew = { loaiVe, tenVe, sl, tien, payIso, startIso, endExIso, note ->
                viewModel.addCustomWalkInTicket(loaiVe, tenVe, sl, tien, payIso, startIso, endExIso, note)
                showCustomWalkInDialog = false
            },
            onUpdateExisting = { updated ->
                viewModel.updateWalkInTicket(updated)
                walkInToEdit = null
            }
        )
    }
}

@Composable
private fun StatMetricTile(
    label: String,
    value: String,
    valueColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    val tokens = LocalAppDesignTokens.current
    Surface(
        color = tokens.elevatedSurface,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.border(1.dp, tokens.borderColor, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = valueColor,
                    modifier = Modifier.size(13.dp)
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = tokens.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                color = valueColor,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun EmptyDepartmentState(
    title: String,
    subtitle: String,
    accentColor: Color
) {
    val tokens = LocalAppDesignTokens.current
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = tokens.cardSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = if (tokens.isDark) 0.2f else 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PersonAdd,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(26.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = tokens.textPrimary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = tokens.textSecondary
            )
        }
    }
}

@Composable
private fun PtContractCardItem(
    ptUi: PtContractWithSessionsUi,
    selectedMonth: Int,
    selectedYear: Int,
    onRecordOneSessionToday: () -> Unit,
    onOpenDetail: () -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    val primaryColor = MaterialTheme.colorScheme.primary
    val c = ptUi.contract
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = tokens.cardSurface,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onOpenDetail)
            .border(1.dp, tokens.borderColor, RoundedCornerShape(14.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "#${c.stt} – ${c.hoTen} (${c.goiPt})",
                        style = MaterialTheme.typography.titleMedium,
                        color = tokens.textPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "SĐT: ${c.soDienThoai.ifBlank { "-" }} • Ngày TT: ${DateUtils.isoToDisplay(c.ngayThanhToan)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.textSecondary
                    )
                }
                Surface(
                    color = if (ptUi.remainingSessions > 0) tokens.statusActiveBg else tokens.statusExpiredBg,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "Còn ${ptUi.remainingSessions}/${c.tongSoBuoi} buổi",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (ptUi.remainingSessions > 0) tokens.statusActiveText else tokens.statusExpiredText,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = tokens.dividerColor)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Giá HĐ: ${DateUtils.formatVnd(c.soTienHopDong)} (${DateUtils.formatVnd(ptUi.monthlyAllocation.valuePerSession.toLong())}/buổi)",
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.textPrimary,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "T$selectedMonth/$selectedYear: Đã tập ${ptUi.sessionsUsedInSelectedMonth} buổi → Trung tâm (${c.phanTramTrungTam}%): ${DateUtils.formatVnd(ptUi.monthlyAllocation.centerAllocatedRevenue)} | PT (${c.phanTramPt}%): ${DateUtils.formatVnd(ptUi.monthlyAllocation.ptAllocatedShare)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = primaryColor,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onRecordOneSessionToday,
                    enabled = ptUi.remainingSessions > 0,
                    colors = ButtonDefaults.buttonColors(containerColor = GymPrimary, contentColor = Color.White),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("+1 Buổi", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun WalkInTicketItem(
    ticket: WalkInTicketEntity,
    selectedMonth: Int,
    selectedYear: Int,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    val primaryColor = MaterialTheme.colorScheme.primary
    val startSpec = LocalDateSpec.parseIso(ticket.ngayBatDauSuDung)
    val endExSpec = LocalDateSpec.parseIso(ticket.ngayKetThucDocQuyen)
    val lastDayDisplay = endExSpec?.let { DateUtils.toDisplayedLastTrainingDate(it).toDisplayString() } ?: ticket.ngayBatDauSuDung
    val alloc = if (startSpec != null && endExSpec != null) {
        FinancialEngine.calculateMonthlyAllocatedRevenue(
            startDate = startSpec,
            endExclusive = endExSpec,
            contractAmount = ticket.soTien,
            targetYear = selectedYear,
            targetMonth = selectedMonth
        )
    } else null

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = tokens.cardSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, tokens.borderColor, RoundedCornerShape(14.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${ticket.tenLoaiVe} (SL: ${ticket.soLuong})",
                        style = MaterialTheme.typography.titleSmall,
                        color = tokens.textPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• ${ticket.id}",
                        style = MaterialTheme.typography.labelSmall,
                        color = tokens.textSecondary
                    )
                }
                Text(
                    text = "Ngày thu: ${DateUtils.isoToDisplay(ticket.ngayThanhToan)} | Sử dụng: ${DateUtils.isoToDisplay(ticket.ngayBatDauSuDung)} → $lastDayDisplay",
                    style = MaterialTheme.typography.bodySmall,
                    color = tokens.textSecondary
                )
                if (alloc != null && alloc.daysInMonth > 0) {
                    Text(
                        text = "DT phân bổ T$selectedMonth/$selectedYear: ${DateUtils.formatVnd(alloc.allocatedAmount)} (${alloc.daysInMonth}/${alloc.totalContractDays} ngày)",
                        style = MaterialTheme.typography.labelSmall,
                        color = primaryColor,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                if (ticket.ghiChu.isNotBlank()) {
                    Text(
                        text = "Ghi chú: ${ticket.ghiChu}",
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.textSecondary
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = DateUtils.formatVnd(ticket.soTien),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = tokens.statusActiveText
                )
                Row {
                    IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Sửa vé lẻ", modifier = Modifier.size(16.dp), tint = tokens.textSecondary)
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(
                            Icons.Default.DeleteOutline,
                            contentDescription = "Xóa vé lẻ",
                            tint = tokens.statusExpiredText,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AddPtContractDialog(
    suggestedStt: Int,
    onDismiss: () -> Unit,
    onConfirm: (
        stt: Int,
        maKhach: String,
        hoTen: String,
        soDienThoai: String,
        goiPt: String,
        tongSoBuoi: Int,
        soTienHopDong: Long,
        soTienDaThu: Long,
        phanTramTrungTam: Int,
        phanTramPt: Int,
        ngayThanhToanIso: String,
        ghiChu: String
    ) -> Unit
) {
    var sttText by remember { mutableStateOf(suggestedStt.toString()) }
    var hoTen by remember { mutableStateOf("") }
    var sdt by remember { mutableStateOf("") }
    var goiPt by remember { mutableStateOf("Gói PT 10 buổi") }
    var tongBuoiText by remember { mutableStateOf("10") }
    var giaHdText by remember { mutableStateOf("1400000") }
    var daThuText by remember { mutableStateOf("1400000") }
    var payDateDisplay by remember { mutableStateOf(LocalDateSpec.today().toDisplayString()) }
    var ghiChu by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Thêm hợp đồng Khách tập PT (GYM)") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sttText,
                        onValueChange = { sttText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("STT *") },
                        singleLine = true,
                        modifier = Modifier.weight(0.35f)
                    )
                    OutlinedTextField(
                        value = hoTen,
                        onValueChange = { hoTen = it },
                        label = { Text("Họ tên khách PT *") },
                        singleLine = true,
                        modifier = Modifier.weight(0.65f)
                    )
                }
                OutlinedTextField(
                    value = sdt,
                    onValueChange = { sdt = it },
                    label = { Text("Số điện thoại") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = goiPt,
                        onValueChange = { goiPt = it },
                        label = { Text("Tên gói PT *") },
                        singleLine = true,
                        modifier = Modifier.weight(0.6f)
                    )
                    OutlinedTextField(
                        value = tongBuoiText,
                        onValueChange = { tongBuoiText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Tổng buổi *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(0.4f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = giaHdText,
                        onValueChange = {
                            val clean = it.filter { ch -> ch.isDigit() }
                            giaHdText = clean
                            daThuText = clean
                        },
                        label = { Text("Giá HĐ (VNĐ) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = daThuText,
                        onValueChange = { daThuText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Thực thu (VNĐ) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                DatePickerField(
                    label = "Ngày khách thanh toán",
                    dateDisplay = payDateDisplay,
                    onDateChanged = { payDateDisplay = it }
                )
                OutlinedTextField(
                    value = ghiChu,
                    onValueChange = { ghiChu = it },
                    label = { Text("Ghi chú") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Tỷ lệ phân bổ mặc định: Trung tâm hưởng 50% – PT hưởng 50% theo số buổi thực tế đã tập.",
                    style = MaterialTheme.typography.labelSmall,
                    color = GymPrimary
                )
                if (errorMsg != null) {
                    Text(errorMsg!!, color = StatusExpiredRed, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val stt = sttText.toIntOrNull() ?: 1
                    val tongBuoi = tongBuoiText.toIntOrNull() ?: 0
                    val giaHd = giaHdText.toLongOrNull() ?: 0L
                    val daThu = daThuText.toLongOrNull() ?: 0L
                    val payIso = DateUtils.displayToIso(payDateDisplay)
                    if (hoTen.isBlank() || tongBuoi <= 0 || giaHd <= 0L || payIso == null) {
                        errorMsg = "Vui lòng nhập đầy đủ Họ tên, Tổng số buổi (>0), Giá HĐ và Ngày thanh toán."
                        return@Button
                    }
                    onConfirm(
                        stt,
                        "PT-$stt",
                        hoTen,
                        sdt,
                        goiPt.ifBlank { "Gói PT $tongBuoi buổi" },
                        tongBuoi,
                        giaHd,
                        daThu,
                        50,
                        50,
                        payIso,
                        ghiChu
                    )
                }
            ) {
                Text("Lưu hợp đồng PT")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hủy") }
        }
    )
}

@Composable
private fun PtContractDetailDialog(
    ptUi: PtContractWithSessionsUi,
    selectedMonth: Int,
    selectedYear: Int,
    onDismiss: () -> Unit,
    onAddSession: (String, Int, String) -> Unit,
    onUpdateSession: (PtSessionEntity) -> Unit,
    onDeleteSession: (PtSessionEntity) -> Unit,
    onUpdateContract: (PtContractEntity) -> Unit,
    onDeleteContract: () -> Unit
) {
    val c = ptUi.contract
    var newSessionDateDisplay by remember { mutableStateOf(LocalDateSpec.today().toDisplayString()) }
    var newSessionCountText by remember { mutableStateOf("1") }
    var newSessionNote by remember { mutableStateOf("") }
    var sessionBeingEdited by remember { mutableStateOf<PtSessionEntity?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("#${c.stt} – ${c.hoTen}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("${c.goiPt} • Tổng ${c.tongSoBuoi} buổi • Giá: ${DateUtils.formatVnd(c.soTienHopDong)}", style = MaterialTheme.typography.bodySmall)
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = GymPrimary.copy(alpha = 0.08f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "Đã tập: ${ptUi.totalSessionsUsedAllTime}/${c.tongSoBuoi} buổi (Còn lại: ${ptUi.remainingSessions} buổi)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Kỳ T$selectedMonth/$selectedYear: Tập ${ptUi.sessionsUsedInSelectedMonth} buổi",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "• Doanh thu Trung tâm (50%): ${DateUtils.formatVnd(ptUi.monthlyAllocation.centerAllocatedRevenue)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = GymPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "• Phần PT hưởng (50%): ${DateUtils.formatVnd(ptUi.monthlyAllocation.ptAllocatedShare)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                if (ptUi.remainingSessions > 0) {
                    Text("Ghi nhận buổi tập PT mới:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DatePickerField(
                            label = "Ngày tập",
                            dateDisplay = newSessionDateDisplay,
                            onDateChanged = { newSessionDateDisplay = it },
                            modifier = Modifier.weight(0.65f)
                        )
                        OutlinedTextField(
                            value = newSessionCountText,
                            onValueChange = { newSessionCountText = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Số buổi") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(0.35f)
                        )
                    }
                    OutlinedTextField(
                        value = newSessionNote,
                        onValueChange = { newSessionNote = it },
                        label = { Text("Ghi chú buổi tập") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            val dIso = DateUtils.displayToIso(newSessionDateDisplay) ?: LocalDateSpec.today().toIsoString()
                            val cnt = (newSessionCountText.toIntOrNull() ?: 1).coerceAtLeast(1)
                            onAddSession(dIso, cnt, newSessionNote)
                            newSessionNote = ""
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Lưu buổi tập PT")
                    }
                }

                HorizontalDivider()
                Text(
                    text = "Lịch sử các buổi đã tập (${ptUi.sessions.size} lần ghi nhận):",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                if (ptUi.sessions.isEmpty()) {
                    Text("Chưa có buổi tập nào được ghi nhận.", style = MaterialTheme.typography.bodySmall)
                } else {
                    ptUi.sessions.forEach { s ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Ngày ${DateUtils.isoToDisplay(s.ngayTap)} • ${s.soBuoi} buổi",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                if (s.ghiChu.isNotBlank()) {
                                    Text(s.ghiChu, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            Row {
                                IconButton(onClick = { sessionBeingEdited = s }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Sửa buổi PT", modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = { onDeleteSession(s) }) {
                                    Icon(
                                        Icons.Default.DeleteOutline,
                                        contentDescription = "Xóa buổi PT",
                                        tint = StatusExpiredRed,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                HorizontalDivider()
                TextButton(
                    onClick = onDeleteContract,
                    colors = ButtonDefaults.textButtonColors(contentColor = StatusExpiredRed)
                ) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Chuyển hợp đồng PT này vào thùng rác")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Đóng") }
        }
    )

    if (sessionBeingEdited != null) {
        val target = sessionBeingEdited!!
        var editDate by remember(target) { mutableStateOf(DateUtils.isoToDisplay(target.ngayTap)) }
        var editCount by remember(target) { mutableStateOf(target.soBuoi.toString()) }
        var editNote by remember(target) { mutableStateOf(target.ghiChu) }

        AlertDialog(
            onDismissRequest = { sessionBeingEdited = null },
            title = { Text("Sửa buổi tập PT") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DatePickerField(
                        label = "Ngày tập",
                        dateDisplay = editDate,
                        onDateChanged = { editDate = it }
                    )
                    OutlinedTextField(
                        value = editCount,
                        onValueChange = { editCount = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số buổi") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editNote,
                        onValueChange = { editNote = it },
                        label = { Text("Ghi chú") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val dIso = DateUtils.displayToIso(editDate) ?: target.ngayTap
                        val cnt = (editCount.toIntOrNull() ?: 1).coerceAtLeast(1)
                        onUpdateSession(target.copy(ngayTap = dIso, soBuoi = cnt, ghiChu = editNote))
                        sessionBeingEdited = null
                    }
                ) {
                    Text("Cập nhật")
                }
            },
            dismissButton = {
                TextButton(onClick = { sessionBeingEdited = null }) { Text("Hủy") }
            }
        )
    }
}

/**
 * Hộp thoại thêm / sửa Vé khách tập buổi lẻ & tuần lẻ (Phần 10).
 * Tùy chọn: 1 ngày lẻ, 2 buổi lẻ, 3 buổi lẻ, 5 buổi lẻ, 1 tuần lẻ, 2 tuần lẻ, Vé khác.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun WalkInTicketDialog(
    existingTicket: WalkInTicketEntity?,
    onDismiss: () -> Unit,
    onSaveNew: (
        loaiVe: String,
        tenLoaiVe: String,
        soLuong: Int,
        soTien: Long,
        ngayThanhToanIso: String,
        ngayBatDauIso: String,
        ngayKetThucDocQuyenIso: String,
        ghiChu: String
    ) -> Unit,
    onUpdateExisting: (WalkInTicketEntity) -> Unit
) {
    val today = remember { LocalDateSpec.today() }
    val presets = listOf(
        Triple("1 ngày lẻ", LoaiVeKhachLe.NGAY_LE, 30_000L to 1),
        Triple("2 buổi lẻ", LoaiVeKhachLe.NGAY_LE, 60_000L to 2),
        Triple("3 buổi lẻ", LoaiVeKhachLe.NGAY_LE, 90_000L to 3),
        Triple("5 buổi lẻ", LoaiVeKhachLe.NGAY_LE, 150_000L to 5),
        Triple("1 tuần lẻ", LoaiVeKhachLe.TUAN_LE, 150_000L to 7),
        Triple("2 tuần lẻ", LoaiVeKhachLe.TUAN_LE, 250_000L to 14)
    )

    var tenLoaiVe by remember { mutableStateOf(existingTicket?.tenLoaiVe ?: "1 ngày lẻ") }
    var loaiVe by remember { mutableStateOf(existingTicket?.loaiVe ?: LoaiVeKhachLe.NGAY_LE) }
    var soLuongText by remember { mutableStateOf((existingTicket?.soLuong ?: 1).toString()) }
    var soTienText by remember { mutableStateOf((existingTicket?.soTien ?: 30_000L).toString()) }
    var payDateDisplay by remember {
        mutableStateOf(existingTicket?.let { DateUtils.isoToDisplay(it.ngayThanhToan) } ?: today.toDisplayString())
    }
    var startDateDisplay by remember {
        mutableStateOf(existingTicket?.let { DateUtils.isoToDisplay(it.ngayBatDauSuDung) } ?: today.toDisplayString())
    }
    var lastDayDisplay by remember {
        val endEx = existingTicket?.let { LocalDateSpec.parseIso(it.ngayKetThucDocQuyen) } ?: today.plusDays(1)
        mutableStateOf(DateUtils.toDisplayedLastTrainingDate(endEx).toDisplayString())
    }
    var ghiChu by remember { mutableStateOf(existingTicket?.ghiChu ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existingTicket == null) "Thu tiền khách tập lẻ (GYM)" else "Sửa giao dịch khách lẻ") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Chọn nhanh loại vé:", style = MaterialTheme.typography.labelMedium)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    presets.forEach { (label, type, priceAndDays) ->
                        val (price, days) = priceAndDays
                        FilterChip(
                            selected = tenLoaiVe == label,
                            onClick = {
                                tenLoaiVe = label
                                loaiVe = type
                                soTienText = price.toString()
                                val sSpec = LocalDateSpec.parseDisplay(startDateDisplay) ?: today
                                val endEx = sSpec.plusDays(days)
                                lastDayDisplay = DateUtils.toDisplayedLastTrainingDate(endEx).toDisplayString()
                            },
                            label = { Text(label) }
                        )
                    }
                }

                OutlinedTextField(
                    value = tenLoaiVe,
                    onValueChange = { tenLoaiVe = it },
                    label = { Text("Loại vé") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = loaiVe == LoaiVeKhachLe.NGAY_LE,
                        onClick = { loaiVe = LoaiVeKhachLe.NGAY_LE },
                        label = { Text("Nhóm Buổi lẻ / Ngày lẻ") }
                    )
                    FilterChip(
                        selected = loaiVe == LoaiVeKhachLe.TUAN_LE,
                        onClick = { loaiVe = LoaiVeKhachLe.TUAN_LE },
                        label = { Text("Nhóm Tuần lẻ") }
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = soLuongText,
                        onValueChange = { soLuongText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số lượng") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(0.4f)
                    )
                    OutlinedTextField(
                        value = soTienText,
                        onValueChange = { soTienText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số tiền (VNĐ)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(0.6f)
                    )
                }
                DatePickerField(
                    label = "Ngày thu tiền",
                    dateDisplay = payDateDisplay,
                    onDateChanged = { payDateDisplay = it }
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DatePickerField(
                        label = "Từ ngày",
                        dateDisplay = startDateDisplay,
                        onDateChanged = { startDateDisplay = it },
                        modifier = Modifier.weight(1f)
                    )
                    DatePickerField(
                        label = "Đến hết ngày",
                        dateDisplay = lastDayDisplay,
                        onDateChanged = { lastDayDisplay = it },
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = ghiChu,
                    onValueChange = { ghiChu = it },
                    label = { Text("Ghi chú (không bắt buộc)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val sl = (soLuongText.toIntOrNull() ?: 1).coerceAtLeast(1)
                    val tien = soTienText.toLongOrNull() ?: 30_000L
                    val paySpec = LocalDateSpec.parseDisplay(payDateDisplay) ?: today
                    val startSpec = LocalDateSpec.parseDisplay(startDateDisplay) ?: today
                    val lastSpec = LocalDateSpec.parseDisplay(lastDayDisplay) ?: startSpec
                    val endExSpec = DateUtils.toExclusiveEndDate(
                        if (lastSpec < startSpec) startSpec else lastSpec
                    )

                    if (existingTicket == null) {
                        onSaveNew(
                            loaiVe,
                            tenLoaiVe.ifBlank { "Vé khách lẻ" },
                            sl,
                            tien,
                            paySpec.toIsoString(),
                            startSpec.toIsoString(),
                            endExSpec.toIsoString(),
                            ghiChu
                        )
                    } else {
                        onUpdateExisting(
                            existingTicket.copy(
                                loaiVe = loaiVe,
                                tenLoaiVe = tenLoaiVe.ifBlank { "Vé khách lẻ" },
                                soLuong = sl,
                                soTien = tien,
                                ngayThanhToan = paySpec.toIsoString(),
                                ngayBatDauSuDung = startSpec.toIsoString(),
                                ngayKetThucDocQuyen = endExSpec.toIsoString(),
                                ghiChu = ghiChu
                            )
                        )
                    }
                }
            ) {
                Text("Lưu giao dịch")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hủy") }
        }
    )
}
