# Thiết kế lại Tab DOANH THU – 89 FITNESS & YOGA

Nâng cấp giao diện và luồng điều hướng của tab **DOANH THU** theo mô hình danh mục 2 cấp đồng bộ với màn hình **CÀI ĐẶT**, giúp chủ phòng tập truy cập tách biệt **Doanh thu GYM**, **Doanh thu YOGA** và **Xuất tài liệu báo cáo (8 báo cáo PDF A4 & Excel)** nhanh gọn, rõ ràng mà vẫn bảo toàn 100% dữ liệu và công thức tài chính hiện có.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> Các quyết định thiết kế và trải nghiệm người dùng dưới đây đã được xác nhận và chuẩn hóa trước khi triển khai.

- **Quyết định đã xác nhận 1 (Badge tóm tắt trên 3 thẻ danh mục)**: Trên 3 thẻ chức năng ở trang tổng quan **DOANH THU**, hiển thị kèm **badge tóm tắt nhỏ bên phải** đồng bộ hoàn toàn với phong cách thẻ danh mục của màn hình **CÀI ĐẶT** (hiển thị nhanh tổng doanh thu phân bổ của GYM, tổng doanh thu phân bổ của YOGA, và nhãn `"8 báo cáo"` cho mục Xuất tài liệu báo cáo).
- **Quyết định đã xác nhận 2 (Xử lý kỳ báo cáo ở màn hình con)**: Việc chọn và chuyển đổi kỳ báo cáo (**Tháng trước / Tháng sau**) được thực hiện tại trang tổng quan **DOANH THU**. Khi mở vào 3 màn hình con (**Doanh thu GYM**, **Doanh thu YOGA**, **Xuất tài liệu báo cáo**), thanh tiêu đề cố định phía trên chỉ hiển thị rõ kỳ báo cáo đang xem (`Kỳ báo cáo: Tháng MM/YYYY`) kèm nút **Quay lại**; khi quay lại trang tổng quan, kỳ báo cáo đã chọn luôn được giữ nguyên.
- **Loại bỏ hoàn toàn 3 nút lọc cũ trên trang tổng quan**: Xóa bỏ 3 chip lọc cũ (`Cả hai (Gym & Yoga)`, `Chỉ GYM`, `Chỉ YOGA`) khỏi trang tổng quan và thay thế hoàn toàn bằng 3 thẻ chức năng độc lập.

---

## 1. Overview & Core Concept

- **What It Does**:
  - Chuyển đổi tab **DOANH THU** từ một trang cuộn dài chứa tất cả bảng biểu sang **Trung tâm điều hướng Doanh thu & Báo cáo 2 cấp**:
    1. **Trang tổng quan DOANH THU**: Gồm bộ chọn **Kỳ báo cáo doanh thu (`Tháng MM / YYYY`)** cố định phía trên và danh sách 3 thẻ chức năng độc lập:
       - **A. Doanh thu GYM**: Xem doanh thu thực thu, doanh thu phân bổ và chi tiết GYM (Hội viên còn hạn/mới, Hội viên gia hạn, PT 50%/50%, Khách tập buổi lẻ & tuần lẻ).
       - **B. Doanh thu YOGA**: Xem doanh thu thực thu, doanh thu phân bổ và chi tiết YOGA (Hội viên còn hạn/mới, Hội viên gia hạn).
       - **C. Xuất tài liệu báo cáo**: Quản lý và xuất 8 báo cáo PDF A4 và Excel độc lập của GYM (5 báo cáo) và YOGA (3 báo cáo).
    2. **3 Màn hình con chuyên biệt**: Chạm vào từng thẻ sẽ mở màn hình chi tiết của riêng chức năng đó với thanh tiêu đề **Quay lại** cố định, hỗ trợ cả nút Back hệ thống Android.
- **Target Audience / Persona**: Chủ phòng tập và quản lý tài chính của **89 FITNESS & YOGA** cần tra cứu nhanh số liệu từng bộ môn hoặc xuất báo cáo kế toán theo tháng trên điện thoại bằng một tay.
- **Key Value**: Loại bỏ hoàn toàn sự rối mắt khi phải cuộn qua nhiều bảng biểu GYM, YOGA và 8 thẻ xuất file trên cùng một màn hình; tách bạch 100% số liệu thực thu & phân bổ của GYM và YOGA.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Chọn kỳ báo cáo tại trang tổng quan**:
   - Người dùng mở tab **DOANH THU**, nhìn thấy ngay thẻ **Kỳ báo cáo doanh thu (`Tháng MM / YYYY`)** với nút chuyển **Tháng trước (`<`)** và **Tháng sau (`>`)**.
   - Bên dưới là 3 thẻ danh mục độc lập: **Doanh thu GYM**, **Doanh thu YOGA**, **Xuất tài liệu báo cáo**.
2. **Xem báo cáo chi tiết Doanh thu GYM**:
   - Nhấn vào thẻ **Doanh thu GYM** → Mở màn hình con **Doanh thu GYM** cho đúng tháng/năm đã chọn.
   - Hiển thị thanh so sánh trực quan Thực thu GYM vs Phân bổ GYM, thẻ **A. DOANH THU THỰC THU (GYM)** (Tiền hội viên GYM & PT đã thanh toán + Tiền khách tập lẻ GYM đã đóng + Tổng tiền thực thu GYM) và thẻ **B. DOANH THU PHÂN BỔ – GYM** (5 nhóm: Hội viên còn hạn & đăng ký mới, Hội viên gia hạn, Khách tập PT 50% Trung tâm / 50% HLV, Khách tập buổi lẻ/ngày lẻ, Khách tập tuần lẻ).
   - Chạm vào bất kỳ dòng chỉ số nào sẽ mở hộp thoại truy xuất danh sách giao dịch / hợp đồng chi tiết.
3. **Xem báo cáo chi tiết Doanh thu YOGA**:
   - Nhấn vào thẻ **Doanh thu YOGA** → Mở màn hình con **Doanh thu YOGA** cho đúng tháng/năm đã chọn.
   - Hiển thị thanh so sánh trực quan Thực thu YOGA vs Phân bổ YOGA, thẻ **A. DOANH THU THỰC THU (YOGA)** (chỉ tính các giao dịch thanh toán của hội viên YOGA trong tháng, không lẫn GYM hay khách lẻ GYM) và thẻ **B. DOANH THU PHÂN BỔ – YOGA** (Hội viên YOGA còn hạn & đăng ký mới, Hội viên YOGA gia hạn).
4. **Xuất 8 báo cáo PDF A4 & Excel**:
   - Nhấn vào thẻ **Xuất tài liệu báo cáo** → Mở màn hình con **Xuất tài liệu báo cáo** hiển thị kỳ báo cáo đang chọn và 2 nhóm rõ ràng:
     - **Nhóm GYM (5 báo cáo độc lập)**
     - **Nhóm YOGA (3 báo cáo độc lập)**
   - Mỗi báo cáo có đầy đủ 3 nút thao tác: **Lưu PDF A4**, **Chia sẻ PDF**, **Xuất Excel**.
5. **Quay lại trang tổng quan**:
   - Nhấn nút mũi tên **Quay lại** trên thanh tiêu đề màn hình con hoặc vuốt/nhấn nút Back của Android → Trở về trang tổng quan **DOANH THU** và giữ nguyên tháng/năm đang xem.

### Visual Identity & Theme

- **Aesthetic Direction**: Premium Modern Android UI – đồng bộ tuyệt đối với thiết kế thẻ danh mục của màn hình **CÀI ĐẶT** (`RoundedCornerShape(16.dp)`, viền `1.dp` tinh tế, hộp icon `46.dp` bo góc `12.dp`, badge tóm tắt nhỏ gọn và mũi tên điều hướng `KeyboardArrowRight`).
- **Color Palette & Mood**:
  - **Doanh thu GYM**: Tông Xanh dương / Navy (`GymPrimary` / `tokens.gymAccent`).
  - **Doanh thu YOGA**: Tông Tím / Plum (`YogaPrimary` / `tokens.yogaAccent`).
  - **Xuất tài liệu báo cáo**: Tông Xanh lá tài liệu (`tokens.statusActiveText` / Emerald) tạo điểm nhấn chuyên nghiệp cho tác vụ xuất bảng tính & PDF.
  - Hỗ trợ đầy đủ **Light Mode**, **Dark Mode** và **System Mode** thông qua hệ thống `LocalAppDesignTokens`.
- **Typography & Layout**:
  - Chuẩn hóa thuật ngữ nhất quán: **Doanh thu GYM**, **Doanh thu YOGA**, **Xuất tài liệu báo cáo**.
  - Khu vực chọn kỳ báo cáo hoặc thanh tiêu đề màn hình con được cố định phía trên (**Sticky Top**); chỉ phần nội dung bên dưới cuộn dọc mượt mà, không bao giờ che khuất thanh điều hướng dưới.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Điều hướng 2 cấp ngay trong màn hình Doanh thu (`RevenueSubScreen` state)**
  - *Chosen Approach*: Sử dụng trạng thái điều hướng nội bộ có lưu vết (`rememberSaveable`) gồm `OVERVIEW`, `GYM_REVENUE`, `YOGA_REVENUE`, và `EXPORT_REPORTS` kèm `BackHandler` tương tự kiến trúc `SettingsAndSystemScreen`.
  - *Why*: Chuyển cảnh tức thì, giữ nguyên trạng thái kỳ báo cáo (`month`/`year`) trong `ViewModel`, hỗ trợ nút Back vật lý/cử chỉ của Android và không ảnh hưởng đến thanh điều hướng chính.
- **Decision 2: Tách bạch dòng tiền thực thu riêng cho từng bộ môn ở màn hình con**
  - *Chosen Approach*: Tận dụng dữ liệu `cashFlowMemberGym`, `cashFlowPtGym`, `cashFlowWalkInGym`, `cashFlowMemberYoga` và lọc `cashFlowDetails` theo `boMon` có sẵn trong `MonthlyRevenueDashboardUi` để hiển thị chính xác dòng tiền thực thu riêng của GYM trong màn hình **Doanh thu GYM** và dòng tiền thực thu riêng của YOGA trong màn hình **Doanh thu YOGA**.
  - *Why*: Đảm bảo dữ liệu GYM và YOGA hoàn toàn độc lập ở cả phần Thực thu (Hệ thống A) lẫn Phân bổ (Hệ thống B), không cần thay đổi bất kỳ công thức tính toán nào trong `FinancialEngine` hay `ReportExporter`.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```
┌───────────────────────────────────────────────────────────────────────────┐
│                         GymYogaViewModel (Existing)                       │
│  • selectedYear / selectedMonth (Preserved across all Revenue sub-views)  │
│  • MonthlyRevenueDashboardUi (Gym Cash/Alloc, Yoga Cash/Alloc, Details)   │
│  • ReportExporter Integration (8 PDF A4 & Excel CSV Generators)           │
└─────────────────────────────────────┬─────────────────────────────────────┘
                                      │ StateFlow<AppUiState>
                                      ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                     RevenueScreen (Redesigned 2-Level UI)                 │
│  State: selectedSubScreen: RevenueSubScreen? (null = Overview)            │
├───────────────────────────────────────────────────────────────────────────┤
│  [1] OVERVIEW MODE (selectedSubScreen == null)                            │
│   ├── Sticky Period Selector Card ("Kỳ báo cáo doanh thu: Tháng MM/YYYY") │
│   │    └── Nút Tháng trước (<) / Tháng sau (>) (Đã bỏ 3 nút lọc cũ)       │
│   └── Scrollable 3 Category Cards (Đồng bộ kiểu dáng CÀI ĐẶT):            │
│        ├── Card A: Doanh thu GYM          [Badge: Tổng phân bổ GYM]   ──┐ │
│        ├── Card B: Doanh thu YOGA         [Badge: Tổng phân bổ YOGA]  ──┼─┤
│        └── Card C: Xuất tài liệu báo cáo  [Badge: 8 báo cáo]          ──┼─┤
│                                                                         │ │
│  [2] CHILD SCREEN MODE (selectedSubScreen != null + BackHandler)        │ │
│   ├── Sticky Sub-Screen Header (Nút Quay lại + Tiêu đề + Kỳ TMM/YYYY)   │ │
│   ├── Sub-screen A: GymRevenueDetailContent  ◄──────────────────────────┘ │
│   │    ├── Thanh so sánh Thực thu GYM vs Phân bổ GYM                      │
│   │    ├── A. Doanh thu thực thu (GYM: Hội viên & PT + Khách lẻ)          │
│   │    └── B. Doanh thu phân bổ – GYM (5 mục + Drill-down Dialog)         │
│   ├── Sub-screen B: YogaRevenueDetailContent ◄────────────────────────────┤
│   │    ├── Thanh so sánh Thực thu YOGA vs Phân bổ YOGA                    │
│   │    ├── A. Doanh thu thực thu (YOGA: Hội viên YOGA)                    │
│   │    └── B. Doanh thu phân bổ – YOGA (2 mục + Drill-down Dialog)        │
│   └── Sub-screen C: ReportExportCenterContent ◄───────────────────────────┘
│        ├── Nhóm 1: 5 Báo cáo bộ môn GYM (Lưu PDF A4 / Chia sẻ / Excel)    │
│        └── Nhóm 2: 3 Báo cáo bộ môn YOGA (Lưu PDF A4 / Chia sẻ / Excel)   │
└───────────────────────────────────────────────────────────────────────────┘
```

### Interactive Component & State Mapping

- **Chuyển đổi kỳ báo cáo (`viewModel.setMonthYear`)**: Thực hiện trực tiếp trên thẻ kỳ báo cáo ở trang tổng quan; `uiState.revenueDashboard` tự động tính toán lại toàn bộ chỉ số của tháng mới và truyền xuống cả 3 màn hình con.
- **Điều hướng vào màn hình con & Quay lại**:
  - Chạm vào thẻ **Doanh thu GYM** → `selectedSubScreen = RevenueSubScreen.GYM_REVENUE`.
  - Chạm vào thẻ **Doanh thu YOGA** → `selectedSubScreen = RevenueSubScreen.YOGA_REVENUE`.
  - Chạm vào thẻ **Xuất tài liệu báo cáo** → `selectedSubScreen = RevenueSubScreen.EXPORT_REPORTS`.
  - Chạm nút **Quay lại** trên thanh tiêu đề hoặc nhấn nút Back thiết bị → `selectedSubScreen = null` (trở về trang tổng quan với đúng tháng/năm đang chọn).
- **Truy xuất chi tiết (Drill-Down Dialog) & Xuất báo cáo**:
  - Giữ nguyên toàn bộ `RevenueDrillDownDialog` khi chạm vào từng dòng doanh thu thực thu hoặc phân bổ.
  - Giữ nguyên toàn bộ `ActivityResultContracts.CreateDocument` cho **Lưu PDF A4**, **Xuất Excel (CSV)** và `viewModel.sharePdfReportNow` cho **Chia sẻ PDF** đối với cả 8 báo cáo.
