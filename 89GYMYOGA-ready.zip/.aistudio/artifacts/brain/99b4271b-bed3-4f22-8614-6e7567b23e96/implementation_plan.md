# Nâng cấp Hệ thống Báo cáo PDF A4 & Excel — 89 FITNESS & YOGA

Hoàn thiện và chuẩn hóa hệ thống **8 báo cáo độc lập (5 báo cáo GYM & 3 báo cáo YOGA)** trên định dạng **PDF khổ A4 dọc** và **Excel (CSV chuẩn UTF-8 BOM)**, đồng bộ thuật ngữ kế toán – tài chính tiếng Việt, chuẩn hóa phương pháp diễn giải doanh thu phân bổ và tối ưu bố cục bảng biểu không tràn cột hoặc ép chữ dọc.

---

## Quyết định Thiết kế & Xác nhận từ Người dùng

> [!IMPORTANT]
> Toàn bộ dữ liệu hội viên, hợp đồng, lịch sử giao dịch và công thức tính toán doanh thu hiện có trong Room Database được **giữ nguyên 100%**. Đợt cập nhật này chỉ nâng cấp tầng xuất báo cáo, giao diện Trung tâm Báo cáo và bộ kiểm thử đối chiếu số liệu.

- **Quyết định 1 — Bố cục PDF Báo cáo tổng hợp doanh thu (GYM & YOGA)**: **Tách bảng tổng hợp A & B ở đầu trang, bảng chi tiết hợp đồng hội viên ở phía dưới** (theo lựa chọn của bạn). Phần đầu hiển thị rõ Khối **A. DOANH THU THỰC THU** và Khối **B. DOANH THU PHÂN BỔ** kèm mô tả phương pháp ghi nhận; phần tiếp theo trình bày **Bảng chi tiết hợp đồng hội viên trong kỳ** với tiêu đề cột lặp lại khi sang trang mới.
- **Quyết định 2 — Bố cục Trung tâm Xuất Báo cáo tại màn hình DOANH THU**: **Chia thành 2 nhóm trực quan rõ ràng: Nhóm 5 báo cáo GYM và Nhóm 3 báo cáo YOGA** (theo lựa chọn của bạn), mỗi báo cáo đều trang bị đủ 3 nút thao tác: **Lưu PDF A4**, **Chia sẻ PDF** và **Xuất Excel**.

---

## 1. Tổng quan & Hệ thống 8 Báo cáo Độc lập

Ứng dụng cung cấp **8 báo cáo độc lập** tách biệt hoàn toàn dữ liệu giữa hai bộ môn **GYM** và **YOGA**:

### Nhóm 1: Báo cáo Bộ môn GYM (5 báo cáo)
1. **Báo cáo hội viên GYM còn hạn & đăng ký mới** (`Bộ môn: GYM`) — Chỉ lấy hợp đồng hội viên GYM thuộc nhóm còn hạn từ tháng trước chuyển sang và đăng ký mới trong tháng.
2. **Báo cáo hội viên GYM gia hạn** (`Bộ môn: GYM`) — Chỉ lấy hợp đồng hội viên GYM thuộc nhóm gia hạn phát sinh hiệu lực trong tháng.
3. **Báo cáo khách tập PT (GYM)** (`Bộ môn: GYM`) — Thống kê các hợp đồng PT, số buổi đã tập trong kỳ, số buổi còn lại và phân chia doanh thu 50% Trung tâm / 50% Huấn luyện viên.
4. **Báo cáo khách tập buổi lẻ & tuần lẻ (GYM)** (`Bộ môn: GYM`) — Thống kê vé ngày lẻ và vé tuần lẻ có ngày sử dụng phát sinh trong tháng báo cáo.
5. **Báo cáo tổng hợp doanh thu GYM** (`Bộ môn: GYM`) — Tổng hợp **A. Doanh thu thực thu**, **B. Doanh thu phân bổ** của riêng bộ môn GYM kèm bảng chi tiết hợp đồng hội viên GYM phía dưới.

### Nhóm 2: Báo cáo Bộ môn YOGA (3 báo cáo)
6. **Báo cáo hội viên YOGA còn hạn & đăng ký mới** (`Bộ môn: YOGA`) — Chỉ lấy hợp đồng hội viên YOGA thuộc nhóm còn hạn và đăng ký mới trong tháng.
7. **Báo cáo hội viên YOGA gia hạn** (`Bộ môn: YOGA`) — Chỉ lấy hợp đồng hội viên YOGA thuộc nhóm gia hạn trong tháng.
8. **Báo cáo tổng hợp doanh thu YOGA** (`Bộ môn: YOGA`) — Tổng hợp **A. Doanh thu thực thu**, **B. Doanh thu phân bổ** của riêng bộ môn YOGA kèm bảng chi tiết hợp đồng hội viên YOGA phía dưới.

---

## 2. Chuẩn hóa Thuật ngữ Kế toán & Diễn giải Nghiệp vụ

### 2.1. Chuẩn hóa Tiêu đề Cột trên từng Bảng Báo cáo

| Loại báo cáo | Danh sách cột chuẩn hóa trên PDF A4 & Excel |
| :--- | :--- |
| **Báo cáo hội viên (Mục 1, 2, 6, 7 & Bảng chi tiết Mục 5, 8)** | `STT` \| `Họ tên` \| `Gói tập` \| `Ngày bắt đầu HĐ` \| `Ngày kết thúc HĐ` \| `Giá trị hợp đồng` \| `Doanh thu phân bổ trong tháng` |
| **Báo cáo khách tập PT (Mục 3)** | `STT` \| `Họ tên khách PT` \| `Gói PT` \| `Tổng số buổi` \| `Số buổi đã tập trong T[MM]/[YYYY]` \| `Số buổi còn lại` \| `Giá trị hợp đồng PT` \| `Phần doanh thu Trung tâm (50%)` \| `Phần doanh thu Huấn luyện viên (50%)` |
| **Báo cáo khách tập buổi lẻ & tuần lẻ (Mục 4)** | `STT` \| `Mã GD` \| `Loại vé` \| `Số ngày sử dụng` \| `Ngày thanh toán` \| `Thời gian sử dụng` \| `Số tiền thực thu` \| `Doanh thu phân bổ trong tháng` |

### 2.2. Chuẩn hóa Nhóm & Phương pháp Diễn giải Doanh thu (Bắt buộc)

- **Nhóm A — `A. DOANH THU THỰC THU`**:
  - *Mô tả nhóm*: `"Tổng số tiền thực tế đã nhận trong tháng, tính theo ngày thanh toán."`
  - *Dòng tổng cộng nhóm A*: **`TỔNG TIỀN THỰC THU TRONG THÁNG`**
- **Nhóm B — `B. DOANH THU PHÂN BỔ`**:
  - *Mô tả nhóm*: `"Giá trị dịch vụ được phân bổ vào tháng báo cáo theo thời gian hiệu lực hợp đồng hoặc dịch vụ đã sử dụng."`
  - *Diễn giải từng hạng mục trong Nhóm B và trên giao diện*:
    - Hội viên GYM / YOGA (Còn hạn & đăng ký mới, Gia hạn): **`"Phân bổ theo số ngày hiệu lực của hợp đồng trong tháng"`** *(tuyệt đối không dùng cụm từ "Phân bổ theo ngày tập thực tế")*.
    - Khách tập PT: **`"Phân bổ theo số buổi PT thực tế đã hoàn thành trong tháng"`**.
    - Khách tập buổi lẻ / vé ngày: **`"Ghi nhận theo ngày sử dụng"`**.
    - Khách tập tuần lẻ / vé tuần: **`"Phân bổ theo số ngày sử dụng thuộc tháng báo cáo"`**.
  - *Dòng tổng cộng nhóm B*: **`TỔNG DOANH THU PHÂN BỔ`**

---

## 3. Thiết kế Bố cục Trang PDF Khổ A4 Dọc & Trạng thái Không có Dữ liệu

- **Khổ giấy chuẩn A4 dọc (`595 x 842 pt`)**:
  - **Phần Quốc hiệu / Đầu trang**: Thương hiệu **`89 FITNESS & YOGA`**, Tiêu đề báo cáo in đậm sắc nét, dòng thông tin chuẩn **`Bộ môn: GYM`** hoặc **`Bộ môn: YOGA`** (không gộp chung `GYM & YOGA`), **`Kỳ báo cáo: Tháng MM/YYYY`**, **`Đơn vị tiền tệ: VNĐ`**.
  - **Tiêu đề bảng tự động xuống dòng thông minh (Multi-line Header Wrapping)**: Đo chiều rộng từng tiêu đề cột để tự động ngắt dòng thành 2 dòng cân đối trong thanh tiêu đề bảng, loại bỏ hoàn toàn hiện tượng tràn chữ sang cột bên cạnh hoặc ép chữ dọc.
  - **Định dạng số liệu**: Ngày tháng chuẩn `DD/MM/YYYY`; các cột tiền tệ và số lượng căn phải có dấu chấm phân cách hàng nghìn (`500.000`, `1.500.000đ`); dòng **`TỔNG CỘNG`** cuối bảng được tô nền nổi bật và in đậm.
  - **Chân trang & Phân trang tự động**: Lặp lại thanh tiêu đề bảng khi danh sách chuyển sang trang tiếp theo; hiển thị chân trang `"89 FITNESS & YOGA — Báo cáo tài chính & hội viên"` kèm `"Trang X / Y"`.
- **Xử lý khi Báo cáo không có dữ liệu**:
  - Gộp toàn bộ chiều ngang của hàng dữ liệu (`Full-width Merged Row`) để hiển thị thông báo **`"Không có dữ liệu trong kỳ báo cáo"`** căn giữa trang trọng, tuyệt đối không bị ngắt chữ bất thường trong cột hẹp.
  - Vẫn hiển thị đầy đủ dòng **`TỔNG CỘNG`** phía dưới với giá trị **`0đ`**.

---

## 4. Kiến trúc Luồng Xuất Báo cáo & Đối chiếu Số liệu

```
┌────────────────────────────────────────────────────────────────────────────┐
│                  MÀN HÌNH DOANH THU (RevenueScreen)                        │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │ Kỳ báo cáo: Tháng MM/YYYY  │  A. Doanh thu thực thu  │ B. Phân bổ    │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │ TRUNG TÂM XUẤT BÁO CÁO PDF A4 & EXCEL                                │  │
│  │  ├─ Nhóm 1: BÁO CÁO BỘ MÔN GYM (Mục 1 → 5)                           │  │
│  │  │    [Lưu PDF A4]   [Chia sẻ PDF]   [Xuất Excel]                    │  │
│  │  └─ Nhóm 2: BÁO CÁO BỘ MÔN YOGA (Mục 6 → 8)                          │  │
│  │       [Lưu PDF A4]   [Chia sẻ PDF]   [Xuất Excel]                    │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└───────────────────────────────────────┬────────────────────────────────────┘
                                        │
                                        ▼
┌────────────────────────────────────────────────────────────────────────────┐
│               TẦNG TỔNG HỢP DỮ LIỆU (GymYogaViewModel)                     │
│  • Tách riêng nguồn hợp đồng GYM (CON_HAN_GYM, GIA_HAN_GYM, TONG_HOP_GYM)  │
│  • Tách riêng nguồn hợp đồng YOGA (CON_HAN_YOGA, GIA_HAN_YOGA, TONG_HOP)   │
│  • Tính toán PT (50%/50%) & Khách lẻ (Số ngày sử dụng, Thực thu, Phân bổ)  │
│  • Chuẩn hóa diễn giải: "Phân bổ theo số ngày hiệu lực của hợp đồng..."    │
└───────────────────────────────────────┬────────────────────────────────────┘
                                        │
                    ┌───────────────────┴───────────────────┐
                    ▼                                       ▼
┌───────────────────────────────────────┐ ┌──────────────────────────────────┐
│     BỘ DỰNG PDF A4 (ReportExporter)   │ │  BỘ XUẤT EXCEL CSV (UTF-8 BOM)   │
│ • Đầu trang 89 FITNESS & YOGA         │ │ • Tiêu đề báo cáo, Bộ môn & Kỳ   │
│ • Multi-line Header & Auto-Pagination │ │ • Hàng tiêu đề cột chuẩn hóa     │
│ • Tách Bảng A, Bảng B & Bảng Chi tiết │ │ • Giữ số nguyên phục vụ tính toán│
│ • Hàng trống gộp cột căn giữa + Tổng 0│ │ • Dòng TỔNG CỘNG khớp 100% UI    │
└───────────────────────────────────────┘ └──────────────────────────────────┘
```
