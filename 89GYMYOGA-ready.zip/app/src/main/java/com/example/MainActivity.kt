package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.local.BoMon
import com.example.data.repository.GymYogaRepository
import com.example.ui.screens.DepartmentMemberScreen
import com.example.ui.screens.RevenueScreen
import com.example.ui.screens.SettingsAndSystemScreen
import com.example.ui.screens.TrackingScreen
import com.example.ui.theme.AppAccentMode
import com.example.ui.theme.GymPrimary
import com.example.ui.theme.GymYogaManagerTheme
import com.example.ui.theme.StatusActiveGreen
import com.example.ui.theme.StatusActiveGreenBg
import com.example.ui.theme.YogaPrimary
import com.example.ui.viewmodel.GymYogaViewModel
import com.example.ui.viewmodel.GymYogaViewModelFactory

enum class MainNavTab(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val accentMode: AppAccentMode
) {
    GYM("gym", "GYM", Icons.Default.FitnessCenter, AppAccentMode.GYM),
    YOGA("yoga", "YOGA", Icons.Default.SelfImprovement, AppAccentMode.YOGA),
    REVENUE("revenue", "DOANH THU", Icons.Default.BarChart, AppAccentMode.REVENUE),
    TRACKING("tracking", "THEO DÕI", Icons.Default.Visibility, AppAccentMode.TRACKING)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GymYogaManagerApp()
        }
    }
}

@Composable
fun GymYogaManagerApp() {
    val context = LocalContext.current
    val repository = remember {
        val db = AppDatabase.getInstance(context)
        GymYogaRepository(db.appDao())
    }
    val viewModel: GymYogaViewModel = viewModel(
        factory = GymYogaViewModelFactory(repository)
    )

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    var currentTab by remember { mutableStateOf(MainNavTab.GYM) }
    var showSettingsScreen by remember { mutableStateOf(false) }

    LaunchedEffect(statusMessage) {
        val msg = statusMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    GymYogaManagerTheme(
        darkTheme = uiState.darkMode,
        accentMode = currentTab.accentMode
    ) {
        val activeTopAccent = when {
            showSettingsScreen -> GymPrimary
            currentTab == MainNavTab.YOGA -> YogaPrimary
            else -> GymPrimary
        }

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp,
                    shadowElevation = 2.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "GYM & YOGA MANAGER",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = activeTopAccent
                            )
                            Text(
                                text = when {
                                    showSettingsScreen -> "Cài đặt bảng giá, Golden Test Cases & Sao lưu"
                                    currentTab == MainNavTab.GYM -> "Quản lý Hội viên GYM, PT & Khách tập lẻ"
                                    currentTab == MainNavTab.YOGA -> "Quản lý Hội viên YOGA (Phân hệ độc lập)"
                                    currentTab == MainNavTab.REVENUE -> "Doanh thu Dòng tiền & Doanh thu Phân bổ"
                                    else -> "Theo dõi thời hạn hội viên bằng mắt"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val allGoldenPassed = uiState.goldenTestResults.all { it.passed }
                            if (allGoldenPassed) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(StatusActiveGreenBg)
                                        .clickable { showSettingsScreen = true }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                        .testTag("golden_test_badge")
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = StatusActiveGreen,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "7/7 Test PASS",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = StatusActiveGreen,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                            }

                            IconButton(
                                onClick = { showSettingsScreen = !showSettingsScreen },
                                modifier = Modifier.testTag("top_settings_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = "Cài đặt & Bảng giá",
                                    tint = activeTopAccent
                                )
                            }
                        }
                    }
                }
            },
            bottomBar = {
                if (!showSettingsScreen) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 6.dp
                    ) {
                        MainNavTab.entries.forEach { tab ->
                            val selected = currentTab == tab
                            val tabColor = if (tab == MainNavTab.YOGA) YogaPrimary else GymPrimary
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    currentTab = tab
                                    showSettingsScreen = false
                                },
                                icon = {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = tabColor,
                                    indicatorColor = tabColor
                                ),
                                modifier = Modifier.testTag("nav_tab_${tab.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (showSettingsScreen) {
                    SettingsAndSystemScreen(
                        uiState = uiState,
                        viewModel = viewModel,
                        onBack = { showSettingsScreen = false }
                    )
                } else {
                    when (currentTab) {
                        MainNavTab.GYM -> DepartmentMemberScreen(
                            boMon = BoMon.GYM,
                            uiState = uiState,
                            viewModel = viewModel,
                            onOpenPricingSettings = { showSettingsScreen = true }
                        )
                        MainNavTab.YOGA -> DepartmentMemberScreen(
                            boMon = BoMon.YOGA,
                            uiState = uiState,
                            viewModel = viewModel,
                            onOpenPricingSettings = { showSettingsScreen = true }
                        )
                        MainNavTab.REVENUE -> RevenueScreen(
                            uiState = uiState,
                            viewModel = viewModel
                        )
                        MainNavTab.TRACKING -> TrackingScreen(
                            uiState = uiState,
                            viewModel = viewModel,
                            onOpenPricingSettings = { showSettingsScreen = true }
                        )
                    }
                }
            }
        }
    }
}
