package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

object BoMon {
    const val GYM = "GYM"
    const val YOGA = "YOGA"
}

object DoiTuong {
    const val NAM = "NAM"
    const val NU = "NU"
    const val TRE_EM = "TRE_EM"
    const val YOGA_CHUNG = "YOGA_CHUNG"

    fun labelVi(code: String): String = when (code) {
        NAM -> "Nam"
        NU -> "Nữ"
        TRE_EM -> "Trẻ em"
        YOGA_CHUNG -> "Yoga"
        else -> code
    }
}

object LoaiBaoCao {
    const val CON_HAN = "CON_HAN"
    const val GIA_HAN = "GIA_HAN"

    fun labelVi(code: String): String = when (code) {
        CON_HAN -> "Còn hạn / Đăng ký mới"
        GIA_HAN -> "Gia hạn / Đăng ký lại"
        else -> code
    }
}

object LoaiHopDong {
    const val DANG_KY_MOI = "DANG_KY_MOI"
    const val GIA_HAN = "GIA_HAN"
    const val DANG_KY_LAI = "DANG_KY_LAI"

    fun labelVi(code: String): String = when (code) {
        DANG_KY_MOI -> "Đăng ký mới"
        GIA_HAN -> "Gia hạn nối tiếp"
        DANG_KY_LAI -> "Đăng ký lại sau nghỉ"
        else -> code
    }
}

object TrangThaiThanhToan {
    const val DA_THANH_TOAN = "DA_THANH_TOAN"
    const val CON_NO = "CON_NO"

    fun labelVi(code: String): String = when (code) {
        DA_THANH_TOAN -> "Đã thanh toán đủ"
        CON_NO -> "Còn nợ"
        else -> code
    }
}

object LoaiVeKhachLe {
    const val NGAY_LE = "NGAY_LE"
    const val TUAN_LE = "TUAN_LE"

    fun labelVi(code: String): String = when (code) {
        NGAY_LE -> "Vé buổi lẻ / ngày lẻ"
        TUAN_LE -> "Vé tuần lẻ"
        else -> code
    }
}

/**
 * 1. Bảng hội viên (Phần 5, 6, 17)
 */
@Entity(
    tableName = "hoi_vien",
    indices = [
        Index(value = ["boMon", "stt"]),
        Index(value = ["boMon", "soDienThoai"])
    ]
)
data class MemberEntity(
    @PrimaryKey val id: String,
    val boMon: String, // GYM hoặc YOGA (hoạt động độc lập)
    val stt: Int,
    val hoTen: String,
    val soDienThoai: String,
    val loaiKhach: String, // NAM, NU, TRE_EM hoặc YOGA_CHUNG
    val ngayTao: String, // YYYY-MM-DD
    val ghiChu: String = "",
    val trangThaiXoa: Boolean = false
)

/**
 * 2. Bảng hợp đồng (Phần 5.3, 7, 12, 13, 17)
 * Lưu ý:
 * - Không bao giờ ghi đè hợp đồng cũ khi gia hạn.
 * - ngayKetThucDocQuyen là ngày kết thúc độc quyền [ngayBatDau, ngayKetThucDocQuyen).
 *   Trên giao diện hiển thị ngày cuối cùng được tập = ngayKetThucDocQuyen - 1 ngày.
 */
@Entity(
    tableName = "hop_dong",
    indices = [
        Index(value = ["hoiVienId"]),
        Index(value = ["boMon", "ngayBatDau", "ngayKetThucDocQuyen"])
    ]
)
data class MemberContractEntity(
    @PrimaryKey val id: String,
    val hoiVienId: String,
    val boMon: String,
    val loaiBaoCao: String, // CON_HAN hoặc GIA_HAN (Lưu ở cấp hợp đồng)
    val loaiHopDong: String, // DANG_KY_MOI, GIA_HAN, DANG_KY_LAI
    val goiTapId: String? = null,
    val goiTap: String, // Tên gói tập lưu cứng tại thời điểm ký
    val ngayDangKy: String, // YYYY-MM-DD
    val ngayBatDau: String, // YYYY-MM-DD (inclusive)
    val ngayKetThucDocQuyen: String, // YYYY-MM-DD (exclusive)
    val soTienHopDong: Long, // Giá trị hợp đồng lưu cứng
    val soTienDaThu: Long, // Số tiền thực tế đã thu
    val ngayThanhToan: String, // YYYY-MM-DD
    val trangThaiThanhToan: String, // DA_THANH_TOAN hoặc CON_NO
    val ghiChu: String = "",
    val trangThaiXoa: Boolean = false
)

/**
 * 3. Bảng giao dịch thanh toán (Phần 11.1, 16, 17)
 * Ghi nhận dòng tiền thực tế theo ngày thanh toán.
 */
@Entity(
    tableName = "giao_dich_thanh_toan",
    indices = [
        Index(value = ["hopDongId"]),
        Index(value = ["boMon", "ngayThanhToan"])
    ]
)
data class PaymentTransactionEntity(
    @PrimaryKey val id: String,
    val hopDongId: String,
    val hoiVienId: String,
    val boMon: String,
    val loaiNguon: String, // HOP_DONG_HOI_VIEN hoặc HOP_DONG_PT
    val soTien: Long,
    val ngayThanhToan: String, // YYYY-MM-DD
    val ghiChu: String = ""
)

/**
 * 4. Bảng gói tập & bảng giá (Phần 4)
 * Đối với Yoga (Gói 1, Gói 2, Gói 3): soThang ban đầu là null cho đến khi chủ phòng tập cấu hình trong Cài đặt.
 */
@Entity(tableName = "goi_tap")
data class PricingPackageEntity(
    @PrimaryKey val id: String,
    val boMon: String, // GYM hoặc YOGA
    val doiTuong: String, // NAM, NU, TRE_EM, YOGA_CHUNG
    val tenGoi: String,
    val soThang: Int?, // null nếu chưa cấu hình (ví dụ 3 gói Yoga mặc định)
    val soNgayTuyChinh: Int? = null,
    val giaTien: Long,
    val thuTuHienThi: Int = 0,
    val dangHoatDong: Boolean = true
)

/**
 * 5. Bảng hợp đồng PT (Phần 9, 17) - Chỉ áp dụng cho GYM
 */
@Entity(tableName = "hop_dong_pt")
data class PtContractEntity(
    @PrimaryKey val id: String,
    val stt: Int,
    val maKhach: String,
    val hoTen: String,
    val soDienThoai: String,
    val goiPt: String,
    val tongSoBuoi: Int,
    val soTienHopDong: Long,
    val soTienDaThu: Long,
    val phanTramTrungTam: Int = 50,
    val phanTramPt: Int = 50,
    val ngayThanhToan: String, // YYYY-MM-DD
    val ngayTao: String, // YYYY-MM-DD
    val ghiChu: String = "",
    val trangThaiXoa: Boolean = false
)

/**
 * 6. Bảng lịch sử buổi tập PT (Phần 9, 17)
 */
@Entity(
    tableName = "buoi_tap_pt",
    indices = [Index(value = ["ptContractId", "ngayTap"])]
)
data class PtSessionEntity(
    @PrimaryKey val id: String,
    val ptContractId: String,
    val ngayTap: String, // YYYY-MM-DD
    val soBuoi: Int = 1,
    val ghiChu: String = ""
)

/**
 * 7. Bảng khách tập buổi lẻ và tuần lẻ (Phần 10, 17) - Chỉ áp dụng cho GYM
 */
@Entity(
    tableName = "khach_tap_le",
    indices = [Index(value = ["ngayThanhToan"])]
)
data class WalkInTicketEntity(
    @PrimaryKey val id: String,
    val loaiVe: String, // NGAY_LE hoặc TUAN_LE
    val tenLoaiVe: String, // "1 ngày lẻ", "2 buổi lẻ", "1 tuần lẻ", v.v.
    val soLuong: Int,
    val soTien: Long,
    val ngayThanhToan: String, // YYYY-MM-DD (Ngày thu tiền)
    val ngayBatDauSuDung: String, // YYYY-MM-DD (inclusive)
    val ngayKetThucDocQuyen: String, // YYYY-MM-DD (exclusive)
    val ghiChu: String = "",
    val trangThaiXoa: Boolean = false
)

/**
 * 8. Bảng cấu hình (Phần 16)
 */
@Entity(tableName = "cau_hinh")
data class AppConfigEntity(
    @PrimaryKey val key: String,
    val value: String
)

/**
 * 9. Bảng lịch sử thay đổi (Phần 16)
 */
@Entity(tableName = "lich_su_thay_doi")
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val timestampMillis: Long,
    val actionType: String,
    val description: String
)
