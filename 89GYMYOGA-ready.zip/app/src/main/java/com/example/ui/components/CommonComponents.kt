package com.example.ui.components

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.BoMon
import com.example.data.local.DoiTuong
import com.example.data.local.LoaiBaoCao
import com.example.data.local.LoaiHopDong
import com.example.data.local.MemberContractEntity
import com.example.data.local.PricingPackageEntity
import com.example.domain.DateUtils
import com.example.domain.FinancialEngine
import com.example.domain.LocalDateSpec
import com.example.domain.MemberTrackingStatus
import com.example.ui.theme.GymPrimary
import com.example.ui.theme.StatusActiveGreen
import com.example.ui.theme.StatusActiveGreenBg
import com.example.ui.theme.StatusExpiredRed
import com.example.ui.theme.StatusExpiredRedBg
import com.example.ui.theme.StatusExpiring15Amber
import com.example.ui.theme.StatusExpiring15AmberBg
import com.example.ui.theme.StatusExpiring7Orange
import com.example.ui.theme.StatusExpiring7OrangeBg
import com.example.ui.theme.StatusExpiringTodayOrange
import com.example.ui.theme.StatusExpiringTodayOrangeBg
import com.example.ui.theme.YogaPrimary
import com.example.ui.viewmodel.MemberWithContractsUi

@Composable
fun TrackingStatusBadge(
    status: MemberTrackingStatus,
    remainingDays: Int,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, textLabel) = when (status) {
        MemberTrackingStatus.ACTIVE_OVER_15 -> Triple(
            StatusActiveGreenBg,
            StatusActiveGreen,
            "Còn $remainingDays ngày"
        )
        MemberTrackingStatus.EXPIRING_8_TO_15 -> Triple(
            StatusExpiring15AmberBg,
            StatusExpiring15Amber,
            "Còn $remainingDays ngày"
        )
        MemberTrackingStatus.EXPIRING_1_TO_7 -> Triple(
            StatusExpiring7OrangeBg,
            StatusExpiring7Orange,
            "Sắp hết ($remainingDays ngày)"
        )
        MemberTrackingStatus.EXPIRING_TODAY -> Triple(
            StatusExpiringTodayOrangeBg,
            StatusExpiringTodayOrange,
            "Hôm nay hết hạn"
        )
        MemberTrackingStatus.EXPIRED -> Triple(
            StatusExpiredRedBg,
            StatusExpiredRed,
            if (remainingDays < 0) "Quá hạn ${-remainingDays} ngày" else "Đã hết hạn"
        )
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = textLabel,
            style = MaterialTheme.typography.labelMedium,
            color = textColor,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun DepartmentBadge(boMon: String, modifier: Modifier = Modifier) {
    val isYoga = boMon == BoMon.YOGA
    val color = if (isYoga) YogaPrimary else GymPrimary
    val bg = if (isYoga) Color(0xFFF3E5F5) else Color(0xFFE3F2FD)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = boMon,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun DatePickerField(
    label: String,
    dateDisplay: String, // dd/MM/yyyy
    onDateChanged: (String) -> Unit,
    modifier: Modifier = Modifier,
    supportingText: String? = null,
    testTag: String = "date_field"
) {
    val context = LocalContext.current
    val parsed = LocalDateSpec.parseDisplay(dateDisplay) ?: LocalDateSpec.today()

    OutlinedTextField(
        value = dateDisplay,
        onValueChange = { onDateChanged(it) },
        label = { Text(label) },
        placeholder = { Text("dd/MM/yyyy") },
        singleLine = true,
        supportingText = supportingText?.let { { Text(it) } },
        trailingIcon = {
            IconButton(
                onClick = {
                    DatePickerDialog(
                        context,
                        { _, y, m, d ->
                            val selected = LocalDateSpec(y, m + 1, d)
                            onDateChanged(selected.toDisplayString())
                        },
                        parsed.year,
                        parsed.month - 1,
                        parsed.day
                    ).show()
                }
            ) {
                Icon(
                    imageVector = Icons.Default.CalendarMonth,
                    contentDescription = "Chọn ngày $label"
                )
            }
        },
        modifier = modifier.fillMaxWidth().testTag(testTag)
    )
}

/**
 * Hàng hiển thị hội viên tinh gọn, cao cấp (không lồng nhiều card, rõ STT, Họ tên, Gói, Hạn tập, Số tiền, SĐT).
 */
@Composable
fun MemberRowItem(
    item: MemberWithContractsUi,
    accentColor: Color,
    onClick: () -> Unit,
    onQuickRenew: () -> Unit,
    modifier: Modifier = Modifier
) {
    val latest = item.latestContract
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f), RoundedCornerShape(14.dp)),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(accentColor.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "#${item.member.stt}",
                            style = MaterialTheme.typography.labelLarge,
                            color = accentColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.member.hoTen,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val subInfo = buildString {
                            if (item.member.soDienThoai.isNotBlank()) {
                                append(item.member.soDienThoai)
                            } else {
                                append("Chưa có SĐT")
                            }
                            if (item.member.boMon == BoMon.GYM) {
                                append(" • ")
                                append(DoiTuong.labelVi(item.member.loaiKhach))
                            }
                        }
                        Text(
                            text = subInfo,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                TrackingStatusBadge(
                    status = item.trackingStatus,
                    remainingDays = item.remainingDays
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = latest?.goiTap ?: "Chưa có hợp đồng",
                        style = MaterialTheme.typography.labelLarge,
                        color = accentColor
                    )
                    Text(
                        text = "Tập: ${item.startDateDisplay} → ${item.lastTrainingDateDisplay}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = DateUtils.formatVnd(latest?.soTienDaThu ?: 0L),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    if (item.totalDebt > 0L) {
                        Text(
                            text = "Còn nợ: ${DateUtils.formatVnd(item.totalDebt)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = StatusExpiredRed
                        )
                    } else {
                        Text(
                            text = "Đã thu đủ",
                            style = MaterialTheme.typography.labelSmall,
                            color = StatusActiveGreen
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))
                OutlinedButton(
                    onClick = onQuickRenew,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("renew_member_${item.member.stt}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Gia hạn",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Gia hạn", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

/**
 * Hộp thoại Đăng ký Hội viên mới hoặc Gia hạn hợp đồng mới (Phần 5, 6, 7).
 * Đảm bảo:
 * - Gợi ý STT tiếp theo, hiển thị STT lớn nhất hiện tại.
 * - Cảnh báo khi trùng STT hoặc trùng Số điện thoại (không tự ý ghi đè hồ sơ cũ).
 * - Khi gia hạn: tự động áp dụng Quy tắc gia hạn (Trường hợp 1, 2, 3 ở Phần 7.1).
 * - Cho phép sửa thủ công Ngày bắt đầu, Ngày hết hạn cuối cùng được tập, và Số tiền.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MemberRegistrationOrRenewalDialog(
    boMon: String,
    isRenewal: Boolean,
    existingMember: MemberWithContractsUi? = null,
    allDepartmentMembers: List<MemberWithContractsUi>,
    maxStt: Int,
    suggestedStt: Int,
    availablePackages: List<PricingPackageEntity>,
    onDismiss: () -> Unit,
    onOpenPricingSettings: () -> Unit,
    onConfirmNewMember: (
        stt: Int,
        hoTen: String,
        soDienThoai: String,
        loaiKhach: String,
        goiTapId: String?,
        tenGoiTap: String,
        ngayDangKyIso: String,
        ngayBatDauIso: String,
        ngayKetThucDocQuyenIso: String,
        soTienHopDong: Long,
        soTienDaThu: Long,
        ngayThanhToanIso: String,
        ghiChuHoiVien: String,
        ghiChuHopDong: String
    ) -> Unit,
    onConfirmRenewal: (
        loaiHopDong: String,
        loaiBaoCao: String,
        goiTapId: String?,
        tenGoiTap: String,
        ngayDangKyIso: String,
        ngayBatDauIso: String,
        ngayKetThucDocQuyenIso: String,
        soTienHopDong: Long,
        soTienDaThu: Long,
        ngayThanhToanIso: String,
        ghiChuHopDong: String
    ) -> Unit
) {
    val accentColor = if (boMon == BoMon.YOGA) YogaPrimary else GymPrimary
    val todaySpec = remember { LocalDateSpec.today() }

    var sttText by remember {
        mutableStateOf(
            if (isRenewal && existingMember != null) existingMember.member.stt.toString()
            else suggestedStt.toString()
        )
    }
    var hoTen by remember { mutableStateOf(existingMember?.member?.hoTen ?: "") }
    var soDienThoai by remember { mutableStateOf(existingMember?.member?.soDienThoai ?: "") }
    var selectedDoiTuong by remember {
        mutableStateOf(
            existingMember?.member?.loaiKhach
                ?: if (boMon == BoMon.GYM) DoiTuong.NAM else DoiTuong.YOGA_CHUNG
        )
    }

    val filteredPackages = remember(boMon, selectedDoiTuong, availablePackages) {
        availablePackages.filter { pkg ->
            pkg.boMon == boMon && (boMon == BoMon.YOGA || pkg.doiTuong == selectedDoiTuong)
        }
    }

    var selectedPackage by remember(filteredPackages) {
        mutableStateOf(filteredPackages.firstOrNull())
    }
    var customPackageName by remember(selectedPackage) {
        mutableStateOf(selectedPackage?.tenGoi ?: if (boMon == BoMon.GYM) "1 tháng" else "Gói 1")
    }
    var contractPriceText by remember(selectedPackage) {
        mutableStateOf((selectedPackage?.giaTien ?: 300_000L).toString())
    }
    var collectedPriceText by remember(selectedPackage) {
        mutableStateOf((selectedPackage?.giaTien ?: 300_000L).toString())
    }

    var registrationDateDisplay by remember { mutableStateOf(todaySpec.toDisplayString()) }
    var paymentDateDisplay by remember { mutableStateOf(todaySpec.toDisplayString()) }

    // Calculate default start date per Phần 7.1
    val previousEndExclusiveSpec = remember(existingMember) {
        existingMember?.latestContract?.ngayKetThucDocQuyen?.let { LocalDateSpec.parseIso(it) }
    }

    var startDateDisplay by remember {
        val regSpec = LocalDateSpec.parseDisplay(registrationDateDisplay) ?: todaySpec
        val autoStart = if (isRenewal) {
            FinancialEngine.calculateRenewalStartDate(previousEndExclusiveSpec, regSpec)
        } else {
            regSpec
        }
        mutableStateOf(autoStart.toDisplayString())
    }

    // Calculate default displayed last training day = exclusiveEnd - 1 day
    var lastTrainingDateDisplay by remember {
        val startSpec = LocalDateSpec.parseDisplay(startDateDisplay) ?: todaySpec
        val endEx = FinancialEngine.calculateExclusiveEndDate(
            startDate = startSpec,
            months = selectedPackage?.soThang ?: 1,
            customDays = selectedPackage?.soNgayTuyChinh
        )
        mutableStateOf(DateUtils.toDisplayedLastTrainingDate(endEx).toDisplayString())
    }

    // Update start date & expiry date automatically when registrationDate or selectedPackage changes
    LaunchedEffect(registrationDateDisplay, selectedPackage) {
        val regSpec = LocalDateSpec.parseDisplay(registrationDateDisplay) ?: return@LaunchedEffect
        val computedStart = if (isRenewal) {
            FinancialEngine.calculateRenewalStartDate(previousEndExclusiveSpec, regSpec)
        } else {
            regSpec
        }
        startDateDisplay = computedStart.toDisplayString()
        val pkg = selectedPackage
        if (pkg != null) {
            customPackageName = pkg.tenGoi
            contractPriceText = pkg.giaTien.toString()
            collectedPriceText = pkg.giaTien.toString()
            if (pkg.soThang != null || pkg.soNgayTuyChinh != null) {
                val endEx = FinancialEngine.calculateExclusiveEndDate(
                    startDate = computedStart,
                    months = pkg.soThang,
                    customDays = pkg.soNgayTuyChinh
                )
                lastTrainingDateDisplay = DateUtils.toDisplayedLastTrainingDate(endEx).toDisplayString()
            }
        }
    }

    var ghiChuHoiVien by remember { mutableStateOf(existingMember?.member?.ghiChu ?: "") }
    var ghiChuHopDong by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Check duplicate STT or duplicate phone (Phần 5.1)
    val parsedStt = sttText.toIntOrNull()
    val duplicateSttMember = remember(parsedStt, allDepartmentMembers, isRenewal) {
        if (isRenewal || parsedStt == null) null
        else allDepartmentMembers.firstOrNull { it.member.stt == parsedStt }
    }
    val duplicatePhoneMember = remember(soDienThoai, allDepartmentMembers, isRenewal) {
        val trimmed = soDienThoai.trim()
        if (isRenewal || trimmed.isEmpty()) null
        else allDepartmentMembers.firstOrNull { it.member.soDienThoai == trimmed }
    }

    val startSpecPreview = LocalDateSpec.parseDisplay(startDateDisplay)
    val lastDaySpecPreview = LocalDateSpec.parseDisplay(lastTrainingDateDisplay)
    val endExPreview = lastDaySpecPreview?.let { DateUtils.toExclusiveEndDate(it) }
    val totalDaysPreview = if (startSpecPreview != null && endExPreview != null) {
        DateUtils.daysBetween(startSpecPreview, endExPreview)
    } else 0

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        DepartmentBadge(boMon = boMon)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isRenewal) "Gia hạn hợp đồng $boMon" else "Đăng ký hội viên $boMon mới",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Đóng")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (!isRenewal) {
                    Surface(
                        color = accentColor.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "STT lớn nhất hiện tại: $maxStt",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Gợi ý tiếp theo: #$suggestedStt",
                                style = MaterialTheme.typography.labelMedium,
                                color = accentColor,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { sttText = suggestedStt.toString() }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = sttText,
                            onValueChange = { sttText = it.filter { ch -> ch.isDigit() } },
                            label = { Text("STT *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(0.35f).testTag("input_stt")
                        )
                        OutlinedTextField(
                            value = hoTen,
                            onValueChange = { hoTen = it },
                            label = { Text("Họ và tên *") },
                            singleLine = true,
                            modifier = Modifier.weight(0.65f).testTag("input_ho_ten")
                        )
                    }

                    if (duplicateSttMember != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        WarningBanner(
                            text = "Cảnh báo: STT #$parsedStt đang trùng với hội viên \"${duplicateSttMember.member.hoTen}\". Hệ thống sẽ KHÔNG ghi đè hồ sơ cũ nếu bạn tiếp tục lưu."
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = soDienThoai,
                        onValueChange = { soDienThoai = it },
                        label = { Text("Số điện thoại") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_sdt")
                    )

                    if (duplicatePhoneMember != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        WarningBanner(
                            text = "Cảnh báo: SĐT ${soDienThoai.trim()} đang trùng với hội viên \"${duplicatePhoneMember.member.hoTen}\" (STT #${duplicatePhoneMember.member.stt})."
                        )
                    }

                    if (boMon == BoMon.GYM) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Đối tượng bảng giá Gym:",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf(
                                DoiTuong.NAM to "Nam",
                                DoiTuong.NU to "Nữ",
                                DoiTuong.TRE_EM to "Trẻ em"
                            ).forEach { (code, label) ->
                                FilterChip(
                                    selected = selectedDoiTuong == code,
                                    onClick = { selectedDoiTuong = code },
                                    label = { Text(label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = accentColor.copy(alpha = 0.15f),
                                        selectedLabelColor = accentColor
                                    )
                                )
                            }
                        }
                    }
                } else if (existingMember != null) {
                    // Thông tin hội viên khi gia hạn
                    Surface(
                        color = accentColor.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Hội viên: #${existingMember.member.stt} – ${existingMember.member.hoTen}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Hợp đồng gần nhất hết hạn tập ngày: ${existingMember.lastTrainingDateDisplay}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            val regSpec = LocalDateSpec.parseDisplay(registrationDateDisplay)
                            if (regSpec != null && previousEndExclusiveSpec != null) {
                                val ruleExplanation = when {
                                    regSpec < previousEndExclusiveSpec ->
                                        "Quy tắc TH1 (Gia hạn sớm): Hợp đồng mới tự động nối tiếp ngày ${previousEndExclusiveSpec.toDisplayString()}."
                                    regSpec == previousEndExclusiveSpec ->
                                        "Quy tắc TH2 (Đúng ngày nối tiếp): Hợp đồng mới bắt đầu ngày ${previousEndExclusiveSpec.toDisplayString()}."
                                    else -> {
                                        val restDays = DateUtils.daysBetween(previousEndExclusiveSpec, regSpec)
                                        "Quy tắc TH3 (Đăng ký lại sau nghỉ $restDays ngày): Hợp đồng mới bắt đầu ngày ${regSpec.toDisplayString()}, không tính doanh thu những ngày nghỉ."
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = ruleExplanation,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = accentColor,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Chọn gói tập ($boMon):",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    filteredPackages.forEach { pkg ->
                        val isSelected = selectedPackage?.id == pkg.id
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                selectedPackage = pkg
                                customPackageName = pkg.tenGoi
                                contractPriceText = pkg.giaTien.toString()
                                collectedPriceText = pkg.giaTien.toString()
                                val startSpec = LocalDateSpec.parseDisplay(startDateDisplay) ?: todaySpec
                                if (pkg.soThang != null || pkg.soNgayTuyChinh != null) {
                                    val endEx = FinancialEngine.calculateExclusiveEndDate(
                                        startDate = startSpec,
                                        months = pkg.soThang,
                                        customDays = pkg.soNgayTuyChinh
                                    )
                                    lastTrainingDateDisplay = DateUtils.toDisplayedLastTrainingDate(endEx).toDisplayString()
                                }
                            },
                            label = {
                                val durText = when {
                                    pkg.soThang != null -> "${pkg.soThang}T"
                                    pkg.soNgayTuyChinh != null -> "${pkg.soNgayTuyChinh}N"
                                    else -> "Chưa cấu hình hạn"
                                }
                                Text("${pkg.tenGoi} (${DateUtils.formatVnd(pkg.giaTien)} • $durText)")
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = accentColor.copy(alpha = 0.16f),
                                selectedLabelColor = accentColor
                            )
                        )
                    }
                }

                if (boMon == BoMon.YOGA && selectedPackage != null && selectedPackage?.soThang == null && selectedPackage?.soNgayTuyChinh == null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        color = StatusExpiring15AmberBg,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.WarningAmber,
                                contentDescription = null,
                                tint = StatusExpiring15Amber,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Gói Yoga này chưa được cấu hình thời hạn mặc định trong Cài đặt. Vui lòng kiểm tra Ngày hết hạn hoặc mở Cài đặt bảng giá.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = StatusExpiring15Amber
                                )
                                TextButton(onClick = onOpenPricingSettings) {
                                    Text("Mở Cài đặt thời hạn Yoga", color = YogaPrimary, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = customPackageName,
                    onValueChange = { customPackageName = it },
                    label = { Text("Tên gói tập lưu trong hợp đồng *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))
                DatePickerField(
                    label = if (isRenewal) "Ngày đăng ký gia hạn *" else "Ngày đăng ký *",
                    dateDisplay = registrationDateDisplay,
                    onDateChanged = {
                        registrationDateDisplay = it
                        paymentDateDisplay = it
                    },
                    testTag = "input_ngay_dang_ky"
                )

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DatePickerField(
                        label = "Ngày bắt đầu tập *",
                        dateDisplay = startDateDisplay,
                        onDateChanged = { newStart ->
                            startDateDisplay = newStart
                            val sSpec = LocalDateSpec.parseDisplay(newStart)
                            val pkg = selectedPackage
                            if (sSpec != null && (pkg?.soThang != null || pkg?.soNgayTuyChinh != null)) {
                                val endEx = FinancialEngine.calculateExclusiveEndDate(
                                    startDate = sSpec,
                                    months = pkg.soThang,
                                    customDays = pkg.soNgayTuyChinh
                                )
                                lastTrainingDateDisplay = DateUtils.toDisplayedLastTrainingDate(endEx).toDisplayString()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        testTag = "input_ngay_bat_dau"
                    )
                    DatePickerField(
                        label = "Ngày hết hạn (cuối) *",
                        dateDisplay = lastTrainingDateDisplay,
                        onDateChanged = { lastTrainingDateDisplay = it },
                        modifier = Modifier.weight(1f),
                        testTag = "input_ngay_het_han"
                    )
                }

                if (totalDaysPreview > 0 && endExPreview != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Thời hạn hợp đồng: $totalDaysPreview ngày thực tế (Kết thúc độc quyền nội bộ: ${endExPreview.toDisplayString()})",
                        style = MaterialTheme.typography.labelSmall,
                        color = accentColor
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = contractPriceText,
                        onValueChange = {
                            val clean = it.filter { ch -> ch.isDigit() }
                            contractPriceText = clean
                            collectedPriceText = clean
                        },
                        label = { Text("Giá hợp đồng (VNĐ) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("input_gia_hop_dong")
                    )
                    OutlinedTextField(
                        value = collectedPriceText,
                        onValueChange = { collectedPriceText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Thực thu (VNĐ) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("input_thuc_thu")
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                DatePickerField(
                    label = "Ngày thanh toán thực tế (Tính dòng tiền)",
                    dateDisplay = paymentDateDisplay,
                    onDateChanged = { paymentDateDisplay = it },
                    testTag = "input_ngay_thanh_toan"
                )

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = ghiChuHopDong,
                    onValueChange = { ghiChuHopDong = it },
                    label = { Text("Ghi chú hợp đồng") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMessage!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = StatusExpiredRed,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Hủy")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val sttVal = sttText.toIntOrNull()
                            if (!isRenewal && (sttVal == null || sttVal <= 0)) {
                                errorMessage = "Vui lòng nhập STT hợp lệ (> 0)."
                                return@Button
                            }
                            if (!isRenewal && hoTen.isBlank()) {
                                errorMessage = "Vui lòng nhập Họ và tên hội viên."
                                return@Button
                            }
                            val regSpec = LocalDateSpec.parseDisplay(registrationDateDisplay)
                            val startSpec = LocalDateSpec.parseDisplay(startDateDisplay)
                            val lastDaySpec = LocalDateSpec.parseDisplay(lastTrainingDateDisplay)
                            val paySpec = LocalDateSpec.parseDisplay(paymentDateDisplay)

                            if (regSpec == null || startSpec == null || lastDaySpec == null || paySpec == null) {
                                errorMessage = "Định dạng ngày không hợp lệ (Chuẩn dd/MM/yyyy)."
                                return@Button
                            }
                            val exclusiveEndSpec = DateUtils.toExclusiveEndDate(lastDaySpec)
                            if (DateUtils.daysBetween(startSpec, exclusiveEndSpec) <= 0) {
                                errorMessage = "Ngày hết hạn cuối cùng phải lớn hơn hoặc bằng ngày bắt đầu."
                                return@Button
                            }
                            val contractAmount = contractPriceText.toLongOrNull() ?: 0L
                            val collectedAmount = collectedPriceText.toLongOrNull() ?: 0L
                            if (contractAmount <= 0L) {
                                errorMessage = "Giá trị hợp đồng phải lớn hơn 0đ."
                                return@Button
                            }

                            if (!isRenewal) {
                                onConfirmNewMember(
                                    sttVal!!,
                                    hoTen.trim(),
                                    soDienThoai.trim(),
                                    selectedDoiTuong,
                                    selectedPackage?.id,
                                    customPackageName.ifBlank { "Gói tập $boMon" },
                                    regSpec.toIsoString(),
                                    startSpec.toIsoString(),
                                    exclusiveEndSpec.toIsoString(),
                                    contractAmount,
                                    collectedAmount,
                                    paySpec.toIsoString(),
                                    ghiChuHoiVien,
                                    ghiChuHopDong
                                )
                            } else {
                                val loaiHd = if (previousEndExclusiveSpec != null && regSpec > previousEndExclusiveSpec) {
                                    LoaiHopDong.DANG_KY_LAI
                                } else {
                                    LoaiHopDong.GIA_HAN
                                }
                                onConfirmRenewal(
                                    loaiHd,
                                    LoaiBaoCao.GIA_HAN,
                                    selectedPackage?.id,
                                    customPackageName.ifBlank { "Gói gia hạn $boMon" },
                                    regSpec.toIsoString(),
                                    startSpec.toIsoString(),
                                    exclusiveEndSpec.toIsoString(),
                                    contractAmount,
                                    collectedAmount,
                                    paySpec.toIsoString(),
                                    ghiChuHopDong
                                )
                            }
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                        modifier = Modifier.testTag("confirm_save_member_btn")
                    ) {
                        Text(if (isRenewal) "Lưu hợp đồng gia hạn" else "Lưu hội viên & hợp đồng")
                    }
                }
            }
        }
    }
}

@Composable
fun WarningBanner(text: String) {
    Surface(
        color = StatusExpiring15AmberBg,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.WarningAmber,
                contentDescription = null,
                tint = StatusExpiring15Amber,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodySmall,
                color = StatusExpiring15Amber,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

/**
 * Hồ sơ chi tiết hội viên + Toàn bộ lịch sử hợp đồng + Lịch sử thanh toán + Sửa hợp đồng / Thu nợ (Phần 5.2, 5.3, 7.2).
 */
@Composable
fun MemberProfileDetailDialog(
    memberUi: MemberWithContractsUi,
    onDismiss: () -> Unit,
    onRequestRenew: () -> Unit,
    onUpdateMemberInfo: (Int, String, String, String, String) -> Unit,
    onUpdateContract: (MemberContractEntity, String, String, String, String, Long, Long, String, String) -> Unit,
    onCollectDebt: (MemberContractEntity, Long, String, String) -> Unit,
    onDeleteMember: () -> Unit
) {
    val boMon = memberUi.member.boMon
    val accentColor = if (boMon == BoMon.YOGA) YogaPrimary else GymPrimary

    var showEditMemberForm by remember { mutableStateOf(false) }
    var contractToEdit by remember { mutableStateOf<MemberContractEntity?>(null) }
    var contractForDebtCollection by remember { mutableStateOf<MemberContractEntity?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        DepartmentBadge(boMon = boMon)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Mã: ${memberUi.member.id}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Đóng")
                    }
                }

                Text(
                    text = "#${memberUi.member.stt} – ${memberUi.member.hoTen}",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "SĐT: ${memberUi.member.soDienThoai.ifBlank { "Chưa cập nhật" }} • Ngày tạo: ${DateUtils.isoToDisplay(memberUi.member.ngayTao)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (memberUi.member.ghiChu.isNotBlank()) {
                    Text(
                        text = "Ghi chú: ${memberUi.member.ghiChu}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = onRequestRenew,
                        colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Gia hạn hợp đồng mới")
                    }
                    OutlinedButton(onClick = { showEditMemberForm = !showEditMemberForm }) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Sửa hồ sơ")
                    }
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(
                            Icons.Default.DeleteOutline,
                            contentDescription = "Xóa hội viên",
                            tint = StatusExpiredRed
                        )
                    }
                }

                if (showEditMemberForm) {
                    Spacer(modifier = Modifier.height(12.dp))
                    EditMemberInlineSection(
                        member = memberUi.member,
                        accentColor = accentColor,
                        onSave = { stt, name, phone, loai, note ->
                            onUpdateMemberInfo(stt, name, phone, loai, note)
                            showEditMemberForm = false
                        },
                        onCancel = { showEditMemberForm = false }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(12.dp))

                // Lịch sử toàn bộ hợp đồng (Phần 5.3)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.History, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Lịch sử hợp đồng (${memberUi.contracts.size} hợp đồng)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "Mỗi lần đăng ký hoặc gia hạn tạo một hợp đồng độc lập. Chạm 'Sửa ngày/giá' để điều chỉnh thủ công.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))
                memberUi.contracts.forEachIndexed { idx, contract ->
                    val startSpec = LocalDateSpec.parseIso(contract.ngayBatDau)
                    val endExSpec = LocalDateSpec.parseIso(contract.ngayKetThucDocQuyen)
                    val lastDayStr = endExSpec?.let { DateUtils.toDisplayedLastTrainingDate(it).toDisplayString() } ?: "-"
                    val totalDays = if (startSpec != null && endExSpec != null) {
                        DateUtils.daysBetween(startSpec, endExSpec)
                    } else 0
                    val debt = (contract.soTienHopDong - contract.soTienDaThu).coerceAtLeast(0L)
                    val schedule = if (startSpec != null && endExSpec != null) {
                        FinancialEngine.generateFullContractSchedule(startSpec, endExSpec, contract.soTienHopDong)
                    } else emptyList()

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${idx + 1}. ${contract.goiTap}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = accentColor
                                )
                                Text(
                                    text = LoaiBaoCao.labelVi(contract.loaiBaoCao),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Bắt đầu: ${DateUtils.isoToDisplay(contract.ngayBatDau)} → Hết hạn tập: $lastDayStr ($totalDays ngày)",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Giá HĐ: ${DateUtils.formatVnd(contract.soTienHopDong)} | Đã thu: ${DateUtils.formatVnd(contract.soTienDaThu)} (Ngày TT: ${DateUtils.isoToDisplay(contract.ngayThanhToan)})",
                                style = MaterialTheme.typography.bodySmall
                            )
                            if (schedule.isNotEmpty()) {
                                val scheduleText = schedule.joinToString(" • ") {
                                    "T${it.month}/${it.year}: ${DateUtils.formatVnd(it.allocatedAmount)} (${it.daysInMonth}n)"
                                }
                                Text(
                                    text = "Phân bổ: $scheduleText",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = accentColor
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { contractToEdit = contract },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Sửa ngày / giá", style = MaterialTheme.typography.labelSmall)
                                }
                                if (debt > 0L) {
                                    Button(
                                        onClick = { contractForDebtCollection = contract },
                                        colors = ButtonDefaults.buttonColors(containerColor = StatusActiveGreen),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Thu nợ ${DateUtils.formatVnd(debt)}", style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                    }
                }

                // Lịch sử thanh toán (Phần 5.2)
                Spacer(modifier = Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Payments, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Lịch sử thanh toán (${memberUi.payments.size} giao dịch)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                if (memberUi.payments.isEmpty()) {
                    Text(
                        text = "Chưa có giao dịch thanh toán.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    memberUi.payments.forEach { p ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = p.ghiChu.ifBlank { "Thanh toán hợp đồng" },
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "Ngày thu: ${DateUtils.isoToDisplay(p.ngayThanhToan)} • Mã: ${p.id}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = DateUtils.formatVnd(p.soTien),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = StatusActiveGreen
                            )
                        }
                    }
                }
            }
        }
    }

    if (contractToEdit != null) {
        EditContractDialog(
            contract = contractToEdit!!,
            onDismiss = { contractToEdit = null },
            onSave = { goiTap, loaiBc, startIso, endExIso, price, paid, payDateIso, note ->
                onUpdateContract(
                    contractToEdit!!,
                    goiTap,
                    loaiBc,
                    startIso,
                    endExIso,
                    price,
                    paid,
                    payDateIso,
                    note
                )
                contractToEdit = null
            }
        )
    }

    if (contractForDebtCollection != null) {
        val c = contractForDebtCollection!!
        val remainingDebt = (c.soTienHopDong - c.soTienDaThu).coerceAtLeast(0L)
        var collectText by remember(c) { mutableStateOf(remainingDebt.toString()) }
        var collectDate by remember { mutableStateOf(LocalDateSpec.today().toDisplayString()) }
        var collectNote by remember { mutableStateOf("Thu nợ hợp đồng ${c.goiTap}") }

        AlertDialog(
            onDismissRequest = { contractForDebtCollection = null },
            title = { Text("Thu nợ hợp đồng") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Còn nợ: ${DateUtils.formatVnd(remainingDebt)}")
                    OutlinedTextField(
                        value = collectText,
                        onValueChange = { collectText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số tiền thu thêm (VNĐ)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    DatePickerField(
                        label = "Ngày thu thực tế",
                        dateDisplay = collectDate,
                        onDateChanged = { collectDate = it }
                    )
                    OutlinedTextField(
                        value = collectNote,
                        onValueChange = { collectNote = it },
                        label = { Text("Ghi chú") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = collectText.toLongOrNull() ?: 0L
                        val dIso = DateUtils.displayToIso(collectDate) ?: LocalDateSpec.today().toIsoString()
                        if (amt > 0L) {
                            onCollectDebt(c, amt, dIso, collectNote)
                        }
                        contractForDebtCollection = null
                    }
                ) {
                    Text("Xác nhận thu")
                }
            },
            dismissButton = {
                TextButton(onClick = { contractForDebtCollection = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Chuyển hội viên vào thùng rác?") },
            text = {
                Text("Hồ sơ hội viên \"${memberUi.member.hoTen}\" sẽ được chuyển vào Thùng rác trong phần Cài đặt và có thể khôi phục khi cần.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteMember()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusExpiredRed)
                ) {
                    Text("Chuyển vào thùng rác")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Hủy")
                }
            }
        )
    }
}

@Composable
private fun EditMemberInlineSection(
    member: com.example.data.local.MemberEntity,
    accentColor: Color,
    onSave: (Int, String, String, String, String) -> Unit,
    onCancel: () -> Unit
) {
    var sttText by remember { mutableStateOf(member.stt.toString()) }
    var hoTen by remember { mutableStateOf(member.hoTen) }
    var sdt by remember { mutableStateOf(member.soDienThoai) }
    var loaiKhach by remember { mutableStateOf(member.loaiKhach) }
    var ghiChu by remember { mutableStateOf(member.ghiChu) }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = accentColor.copy(alpha = 0.06f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Chỉnh sửa thông tin hồ sơ", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = sttText,
                    onValueChange = { sttText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("STT") },
                    singleLine = true,
                    modifier = Modifier.weight(0.35f)
                )
                OutlinedTextField(
                    value = hoTen,
                    onValueChange = { hoTen = it },
                    label = { Text("Họ và tên") },
                    singleLine = true,
                    modifier = Modifier.weight(0.65f)
                )
            }
            OutlinedTextField(
                value = sdt,
                onValueChange = { sdt = it },
                label = { Text("Số điện thoại") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = ghiChu,
                onValueChange = { ghiChu = it },
                label = { Text("Ghi chú") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                TextButton(onClick = onCancel) { Text("Đóng") }
                Button(
                    onClick = {
                        val stt = sttText.toIntOrNull() ?: member.stt
                        if (hoTen.isNotBlank()) {
                            onSave(stt, hoTen, sdt, loaiKhach, ghiChu)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor)
                ) {
                    Text("Lưu thay đổi")
                }
            }
        }
    }
}

/**
 * Hộp thoại chỉnh sửa Ngày bắt đầu, Ngày hết hạn cuối cùng, Giá trị hợp đồng, Loại báo cáo (Phần 7.2 & 13.3).
 */
@Composable
fun EditContractDialog(
    contract: MemberContractEntity,
    onDismiss: () -> Unit,
    onSave: (
        goiTap: String,
        loaiBaoCao: String,
        startIso: String,
        endExclusiveIso: String,
        price: Long,
        paid: Long,
        payDateIso: String,
        note: String
    ) -> Unit
) {
    val initialEndEx = LocalDateSpec.parseIso(contract.ngayKetThucDocQuyen) ?: LocalDateSpec.today().plusMonths(1)
    val initialLastTrainDay = DateUtils.toDisplayedLastTrainingDate(initialEndEx)

    var goiTap by remember { mutableStateOf(contract.goiTap) }
    var loaiBaoCao by remember { mutableStateOf(contract.loaiBaoCao) }
    var startDisplay by remember { mutableStateOf(DateUtils.isoToDisplay(contract.ngayBatDau)) }
    var lastDayDisplay by remember { mutableStateOf(initialLastTrainDay.toDisplayString()) }
    var priceText by remember { mutableStateOf(contract.soTienHopDong.toString()) }
    var paidText by remember { mutableStateOf(contract.soTienDaThu.toString()) }
    var payDateDisplay by remember { mutableStateOf(DateUtils.isoToDisplay(contract.ngayThanhToan)) }
    var ghiChu by remember { mutableStateOf(contract.ghiChu) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Chỉnh sửa hợp đồng & Phân bổ") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = goiTap,
                    onValueChange = { goiTap = it },
                    label = { Text("Gói tập") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = loaiBaoCao == LoaiBaoCao.CON_HAN,
                        onClick = { loaiBaoCao = LoaiBaoCao.CON_HAN },
                        label = { Text("Còn hạn / Mới") }
                    )
                    FilterChip(
                        selected = loaiBaoCao == LoaiBaoCao.GIA_HAN,
                        onClick = { loaiBaoCao = LoaiBaoCao.GIA_HAN },
                        label = { Text("Gia hạn") }
                    )
                }
                DatePickerField(
                    label = "Ngày bắt đầu tập",
                    dateDisplay = startDisplay,
                    onDateChanged = { startDisplay = it }
                )
                DatePickerField(
                    label = "Ngày hết hạn cuối cùng được tập",
                    dateDisplay = lastDayDisplay,
                    onDateChanged = { lastDayDisplay = it }
                )
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Giá trị hợp đồng (VNĐ)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = paidText,
                    onValueChange = { paidText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Số tiền thực tế đã thu (VNĐ)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                DatePickerField(
                    label = "Ngày thanh toán",
                    dateDisplay = payDateDisplay,
                    onDateChanged = { payDateDisplay = it }
                )
                OutlinedTextField(
                    value = ghiChu,
                    onValueChange = { ghiChu = it },
                    label = { Text("Ghi chú") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (errorMsg != null) {
                    Text(errorMsg!!, color = StatusExpiredRed, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val sSpec = LocalDateSpec.parseDisplay(startDisplay)
                    val lSpec = LocalDateSpec.parseDisplay(lastDayDisplay)
                    val pSpec = LocalDateSpec.parseDisplay(payDateDisplay)
                    if (sSpec == null || lSpec == null || pSpec == null) {
                        errorMsg = "Ngày không hợp lệ (dd/MM/yyyy)."
                        return@Button
                    }
                    val endEx = DateUtils.toExclusiveEndDate(lSpec)
                    if (DateUtils.daysBetween(sSpec, endEx) <= 0) {
                        errorMsg = "Ngày hết hạn cuối cùng phải >= ngày bắt đầu."
                        return@Button
                    }
                    val price = priceText.toLongOrNull() ?: 0L
                    val paid = paidText.toLongOrNull() ?: 0L
                    onSave(
                        goiTap.ifBlank { contract.goiTap },
                        loaiBaoCao,
                        sSpec.toIsoString(),
                        endEx.toIsoString(),
                        price,
                        paid,
                        pSpec.toIsoString(),
                        ghiChu
                    )
                }
            ) {
                Text("Lưu & Tính lại doanh thu")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Hủy")
            }
        }
    )
}
