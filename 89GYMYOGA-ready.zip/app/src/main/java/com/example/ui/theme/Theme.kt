package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class AppAccentMode {
    GYM,
    YOGA,
    REVENUE,
    TRACKING
}

private val GymLightScheme = lightColorScheme(
    primary = GymPrimary,
    onPrimary = Color.White,
    primaryContainer = GymPrimaryLight,
    onPrimaryContainer = GymPrimaryDark,
    secondary = GymPrimaryDark,
    onSecondary = Color.White,
    background = GymBackground,
    onBackground = Slate900,
    surface = GymSurface,
    onSurface = Slate900,
    surfaceVariant = Color(0xFFEEF2F8),
    onSurfaceVariant = Slate600,
    outline = Slate200
)

private val YogaLightScheme = lightColorScheme(
    primary = YogaPrimary,
    onPrimary = Color.White,
    primaryContainer = YogaPrimaryLight,
    onPrimaryContainer = YogaPrimaryDark,
    secondary = YogaPrimaryDark,
    onSecondary = Color.White,
    background = YogaBackground,
    onBackground = Slate900,
    surface = YogaSurface,
    onSurface = Slate900,
    surfaceVariant = Color(0xFFF3ECF9),
    onSurfaceVariant = Slate600,
    outline = Slate200
)

private val RevenueLightScheme = lightColorScheme(
    primary = GymPrimary,
    onPrimary = Color.White,
    primaryContainer = GymPrimaryLight,
    onPrimaryContainer = GymPrimaryDark,
    secondary = YogaPrimary,
    onSecondary = Color.White,
    background = GymBackground,
    onBackground = Slate900,
    surface = Color.White,
    onSurface = Slate900,
    surfaceVariant = Color(0xFFEEF2F8),
    onSurfaceVariant = Slate600,
    outline = Slate200
)

private val DarkGymScheme = darkColorScheme(
    primary = Color(0xFF64B5F6),
    onPrimary = Color(0xFF06254D),
    primaryContainer = GymPrimaryDark,
    onPrimaryContainer = Color(0xFFD1E9FF),
    secondary = Color(0xFF90CAF9),
    background = Color(0xFF0B1120),
    onBackground = Color(0xFFF8FAFC),
    surface = Color(0xFF151F32),
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = Color(0xFF1E293B),
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF334155)
)

private val DarkYogaScheme = darkColorScheme(
    primary = Color(0xFFCE93D8),
    onPrimary = Color(0xFF380954),
    primaryContainer = YogaPrimaryDark,
    onPrimaryContainer = Color(0xFFF3E5F5),
    secondary = Color(0xFFE1BEE7),
    background = Color(0xFF130D1E),
    onBackground = Color(0xFFF8FAFC),
    surface = Color(0xFF211732),
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = Color(0xFF2E2144),
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF473564)
)

@Composable
fun GymYogaManagerTheme(
    darkTheme: Boolean = false,
    accentMode: AppAccentMode = AppAccentMode.GYM,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        when (accentMode) {
            AppAccentMode.YOGA -> DarkYogaScheme
            else -> DarkGymScheme
        }
    } else {
        when (accentMode) {
            AppAccentMode.GYM -> GymLightScheme
            AppAccentMode.YOGA -> YogaLightScheme
            AppAccentMode.REVENUE, AppAccentMode.TRACKING -> RevenueLightScheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
