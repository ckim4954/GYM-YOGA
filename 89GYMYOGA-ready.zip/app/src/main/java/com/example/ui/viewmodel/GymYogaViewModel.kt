package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppConfigEntity
import com.example.data.local.AuditLogEntity
import com.example.data.local.BoMon
import com.example.data.local.LoaiBaoCao
import com.example.data.local.LoaiVeKhachLe
import com.example.data.local.MemberContractEntity
import com.example.data.local.MemberEntity
import com.example.data.local.PaymentTransactionEntity
import com.example.data.local.PricingPackageEntity
import com.example.data.local.PtContractEntity
import com.example.data.local.PtSessionEntity
import com.example.data.local.WalkInTicketEntity
import com.example.data.repository.GymYogaRepository
import com.example.domain.DateUtils
import com.example.domain.FinancialEngine
import com.example.domain.GoldenTestCaseResult
import com.example.domain.LocalDateSpec
import com.example.domain.MemberTrackingStatus
import com.example.domain.PtSessionAllocationResult
import com.example.ui.theme.ThemeModePreference
import com.example.util.DriveAccountProfile
import com.example.util.DriveBackupFileItem
import com.example.util.GoogleDriveBackupManager
import com.example.util.MemberReportRow
import com.example.util.PdfReportType
import com.example.util.PtReportRow
import com.example.util.ReportExporter
import com.example.util.SummaryMetricRow
import com.example.util.WalkInReportRow
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class MemberWithContractsUi(
    val member: MemberEntity,
    val contracts: List<MemberContractEntity>,
    val payments: List<PaymentTransactionEntity>,
    val latestContract: MemberContractEntity?,
    val startDateDisplay: String,
    val registrationDateDisplay: String,
    val lastTrainingDateDisplay: String,
    val trackingStatus: MemberTrackingStatus,
    val remainingDays: Int,
    val totalDebt: Long
)

data class PtContractWithSessionsUi(
    val contract: PtContractEntity,
    val sessions: List<PtSessionEntity>,
    val totalSessionsUsedAllTime: Int,
    val remainingSessions: Int,
    val sessionsUsedInSelectedMonth: Int,
    val monthlyAllocation: PtSessionAllocationResult
)

data class ContractAllocationDetailItem(
    val contract: MemberContractEntity,
    val member: MemberEntity?,
    val daysInMonth: Int,
    val totalContractDays: Int,
    val allocatedAmount: Long,
    val lastTrainingDateDisplay: String
)

data class WalkInAllocationDetailItem(
    val ticket: WalkInTicketEntity,
    val daysInMonth: Int,
    val totalDays: Int,
    val allocatedAmount: Long
)

data class CashFlowDetailItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val boMon: String,
    val ngayThanhToanDisplay: String,
    val amount: Long,
    val categoryLabel: String
)

data class MonthlyRevenueDashboardUi(
    val year: Int,
    val month: Int,
    val departmentFilter: String, // "CA_HAI", "GYM", "YOGA"
    // A. Doanh thu dòng tiền
    val cashFlowMemberGym: Long,
    val cashFlowMemberYoga: Long,
    val cashFlowPtGym: Long,
    val cashFlowWalkInGym: Long,
    val totalCashFlowMember: Long,
    val totalCashFlowWalkIn: Long,
    val totalCashFlowAll: Long,
    val cashFlowDetails: List<CashFlowDetailItem>,
    // B. Doanh thu phân bổ GYM
    val gymAllocatedConHan: Long,
    val gymAllocatedGiaHan: Long,
    val gymAllocatedPtCenter: Long,
    val gymAllocatedPtCoach: Long,
    val gymAllocatedDailyWalkIn: Long,
    val gymAllocatedWeeklyWalkIn: Long,
    val totalGymAllocated: Long,
    // B. Doanh thu phân bổ YOGA
    val yogaAllocatedConHan: Long,
    val yogaAllocatedGiaHan: Long,
    val totalYogaAllocated: Long,
    // C. Chi tiết truy xuất nguồn gốc
    val gymConHanDetails: List<ContractAllocationDetailItem>,
    val gymGiaHanDetails: List<ContractAllocationDetailItem>,
    val yogaConHanDetails: List<ContractAllocationDetailItem>,
    val yogaGiaHanDetails: List<ContractAllocationDetailItem>,
    val ptDetailsInMonth: List<PtContractWithSessionsUi>,
    val dailyWalkInDetails: List<WalkInAllocationDetailItem>,
    val weeklyWalkInDetails: List<WalkInAllocationDetailItem>
)

data class AppUiState(
    val isLoading: Boolean = false,
    val gymMembers: List<MemberWithContractsUi> = emptyList(),
    val yogaMembers: List<MemberWithContractsUi> = emptyList(),
    val allTrackingMembers: List<MemberWithContractsUi> = emptyList(),
    val maxSttGym: Int = 0,
    val nextSttGym: Int = 1,
    val maxSttYoga: Int = 0,
    val nextSttYoga: Int = 1,
    val packages: List<PricingPackageEntity> = emptyList(),
    val ptContracts: List<PtContractWithSessionsUi> = emptyList(),
    val walkInTickets: List<WalkInTicketEntity> = emptyList(),
    val deletedMembers: List<MemberEntity> = emptyList(),
    val deletedPtContracts: List<PtContractEntity> = emptyList(),
    val deletedWalkInTickets: List<WalkInTicketEntity> = emptyList(),
    val revenueDashboard: MonthlyRevenueDashboardUi = MonthlyRevenueDashboardUi(
        year = LocalDateSpec.today().year,
        month = LocalDateSpec.today().month,
        departmentFilter = "CA_HAI",
        cashFlowMemberGym = 0L,
        cashFlowMemberYoga = 0L,
        cashFlowPtGym = 0L,
        cashFlowWalkInGym = 0L,
        totalCashFlowMember = 0L,
        totalCashFlowWalkIn = 0L,
        totalCashFlowAll = 0L,
        cashFlowDetails = emptyList(),
        gymAllocatedConHan = 0L,
        gymAllocatedGiaHan = 0L,
        gymAllocatedPtCenter = 0L,
        gymAllocatedPtCoach = 0L,
        gymAllocatedDailyWalkIn = 0L,
        gymAllocatedWeeklyWalkIn = 0L,
        totalGymAllocated = 0L,
        yogaAllocatedConHan = 0L,
        yogaAllocatedGiaHan = 0L,
        totalYogaAllocated = 0L,
        gymConHanDetails = emptyList(),
        gymGiaHanDetails = emptyList(),
        yogaConHanDetails = emptyList(),
        yogaGiaHanDetails = emptyList(),
        ptDetailsInMonth = emptyList(),
        dailyWalkInDetails = emptyList(),
        weeklyWalkInDetails = emptyList()
    ),
    val auditLogs: List<AuditLogEntity> = emptyList(),
    val goldenTestResults: List<GoldenTestCaseResult> = FinancialEngine.runAllGoldenTestCases(),
    val themeMode: ThemeModePreference = ThemeModePreference.LIGHT,
    val darkMode: Boolean = false,
    val googleAccountEmail: String? = null,
    val googleAccountName: String? = null,
    val isGoogleConnected: Boolean = false,
    val autoDriveBackupEnabled: Boolean = false,
    val lastDriveBackupTime: String? = null,
    val driveBackups: List<DriveBackupFileItem> = emptyList(),
    val isDriveBusy: Boolean = false,
    val driveStatusMessage: String? = null
)

private data class DriveRuntimeState(
    val activeAccessToken: String? = null,
    val driveBackups: List<DriveBackupFileItem> = emptyList(),
    val isDriveBusy: Boolean = false,
    val driveStatusMessage: String? = null
)

class GymYogaViewModel(
    private val repository: GymYogaRepository
) : ViewModel() {

    private val _selectedYear = MutableStateFlow(LocalDateSpec.today().year)
    val selectedYear: StateFlow<Int> = _selectedYear.asStateFlow()

    private val _selectedMonth = MutableStateFlow(LocalDateSpec.today().month)
    val selectedMonth: StateFlow<Int> = _selectedMonth.asStateFlow()

    private val _revenueDeptFilter = MutableStateFlow("CA_HAI") // "CA_HAI", "GYM", "YOGA"
    val revenueDeptFilter: StateFlow<String> = _revenueDeptFilter.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _driveRuntime = MutableStateFlow(DriveRuntimeState())

    init {
        viewModelScope.launch {
            repository.ensureDefaultPricingSeeded()
        }
    }

    private data class CoreDbSnapshot(
        val members: List<MemberEntity>,
        val contracts: List<MemberContractEntity>,
        val payments: List<PaymentTransactionEntity>,
        val packages: List<PricingPackageEntity>,
        val ptContracts: List<PtContractEntity>,
        val ptSessions: List<PtSessionEntity>,
        val walkIns: List<WalkInTicketEntity>
    )

    private data class TrashAndConfigSnapshot(
        val deletedMembers: List<MemberEntity>,
        val deletedPtContracts: List<PtContractEntity>,
        val deletedWalkIns: List<WalkInTicketEntity>,
        val configs: List<AppConfigEntity>,
        val logs: List<AuditLogEntity>
    )

    private val coreSnapshotFlow = combine(
        repository.activeMembers,
        repository.activeContracts,
        repository.allPayments,
        repository.activePackages,
        combine(
            repository.activePtContracts,
            repository.allPtSessions,
            repository.activeWalkInTickets
        ) { ptC, ptS, walkIn -> Triple(ptC, ptS, walkIn) }
    ) { members, contracts, payments, packages, ptAndWalkIn ->
        CoreDbSnapshot(
            members = members,
            contracts = contracts,
            payments = payments,
            packages = packages,
            ptContracts = ptAndWalkIn.first,
            ptSessions = ptAndWalkIn.second,
            walkIns = ptAndWalkIn.third
        )
    }

    private val trashAndConfigFlow = combine(
        repository.deletedMembers,
        repository.deletedPtContracts,
        repository.deletedWalkInTickets,
        repository.configs,
        repository.auditLogs
    ) { delM, delPt, delW, cfgs, logs ->
        TrashAndConfigSnapshot(
            deletedMembers = delM,
            deletedPtContracts = delPt,
            deletedWalkIns = delW,
            configs = cfgs,
            logs = logs
        )
    }

    private val filterFlow = combine(
        _selectedYear,
        _selectedMonth,
        _revenueDeptFilter
    ) { y, m, d -> Triple(y, m, d) }

    val uiState: StateFlow<AppUiState> = combine(
        coreSnapshotFlow,
        trashAndConfigFlow,
        filterFlow,
        _driveRuntime
    ) { core, trashCfg, (targetYear, targetMonth, deptFilter), driveState ->
        val today = LocalDateSpec.today()
        val contractsByMember = core.contracts.groupBy { it.hoiVienId }
        val paymentsByMember = core.payments.groupBy { it.hoiVienId }
        val membersById = core.members.associateBy { it.id }

        val memberUiList = core.members.map { member ->
            val mContracts = (contractsByMember[member.id] ?: emptyList())
                .sortedByDescending { it.ngayKetThucDocQuyen }
            val mPayments = (paymentsByMember[member.id] ?: emptyList())
                .sortedByDescending { it.ngayThanhToan }
            val latest = mContracts.firstOrNull()

            val startDateSpec = latest?.let { LocalDateSpec.parseIso(it.ngayBatDau) }
            val endExclusiveSpec = latest?.let { LocalDateSpec.parseIso(it.ngayKetThucDocQuyen) }
            val regDateSpec = latest?.let { LocalDateSpec.parseIso(it.ngayDangKy) }

            val (status, remDays) = if (endExclusiveSpec != null) {
                FinancialEngine.evaluateTrackingStatus(today, endExclusiveSpec)
            } else {
                MemberTrackingStatus.EXPIRED to -1
            }

            val lastTrainingDateStr = if (endExclusiveSpec != null) {
                DateUtils.toDisplayedLastTrainingDate(endExclusiveSpec).toDisplayString()
            } else {
                "-"
            }

            val totalDebt = mContracts.sumOf { (it.soTienHopDong - it.soTienDaThu).coerceAtLeast(0L) }

            MemberWithContractsUi(
                member = member,
                contracts = mContracts,
                payments = mPayments,
                latestContract = latest,
                startDateDisplay = startDateSpec?.toDisplayString() ?: "-",
                registrationDateDisplay = regDateSpec?.toDisplayString() ?: "-",
                lastTrainingDateDisplay = lastTrainingDateStr,
                trackingStatus = status,
                remainingDays = remDays,
                totalDebt = totalDebt
            )
        }

        val gymMembers = memberUiList.filter { it.member.boMon == BoMon.GYM }.sortedBy { it.member.stt }
        val yogaMembers = memberUiList.filter { it.member.boMon == BoMon.YOGA }.sortedBy { it.member.stt }

        val maxSttGym = gymMembers.maxOfOrNull { it.member.stt } ?: 0
        val maxSttYoga = yogaMembers.maxOfOrNull { it.member.stt } ?: 0

        // Phần 8.1: Mặc định sắp xếp ngày hết hạn gần nhất ở trên, xa hơn ở dưới
        val allTrackingSorted = memberUiList.sortedWith(
            compareBy<MemberWithContractsUi> {
                // Ưu tiên hội viên còn hạn (sắp hết hạn nhất ở trên), sau đó đến đã hết hạn
                if (it.remainingDays >= 0) 0 else 1
            }.thenBy {
                if (it.remainingDays >= 0) it.remainingDays else -it.remainingDays
            }.thenBy { it.member.stt }
        )

        // PT Contracts & Sessions
        val monthPrefix = String.format("%04d-%02d", targetYear, targetMonth)
        val sessionsByPtContract = core.ptSessions.groupBy { it.ptContractId }
        val ptContractUiList = core.ptContracts.map { pt ->
            val allSessions = (sessionsByPtContract[pt.id] ?: emptyList()).sortedByDescending { it.ngayTap }
            val usedAllTime = allSessions.sumOf { it.soBuoi }
            val remaining = (pt.tongSoBuoi - usedAllTime).coerceAtLeast(0)
            val usedInMonth = allSessions
                .filter { it.ngayTap.startsWith(monthPrefix) }
                .sumOf { it.soBuoi }
            val alloc = FinancialEngine.calculatePtMonthlyAllocation(
                contractTotalAmount = pt.soTienHopDong,
                totalSessions = pt.tongSoBuoi,
                centerPercent = pt.phanTramTrungTam,
                ptPercent = pt.phanTramPt,
                sessionsUsedInMonth = usedInMonth
            )
            PtContractWithSessionsUi(
                contract = pt,
                sessions = allSessions,
                totalSessionsUsedAllTime = usedAllTime,
                remainingSessions = remaining,
                sessionsUsedInSelectedMonth = usedInMonth,
                monthlyAllocation = alloc
            )
        }

        // --- DOANH THU DÒNG TIỀN (Phần 11.1) ---
        val paymentsInMonth = core.payments.filter { it.ngayThanhToan.startsWith(monthPrefix) }
        val walkInsPaidInMonth = core.walkIns.filter { it.ngayThanhToan.startsWith(monthPrefix) }

        val cashFlowMemberGym = paymentsInMonth
            .filter { it.boMon == BoMon.GYM && it.loaiNguon == "HOP_DONG_HOI_VIEN" }
            .sumOf { it.soTien }
        val cashFlowMemberYoga = paymentsInMonth
            .filter { it.boMon == BoMon.YOGA && it.loaiNguon == "HOP_DONG_HOI_VIEN" }
            .sumOf { it.soTien }
        val cashFlowPtGym = paymentsInMonth
            .filter { it.boMon == BoMon.GYM && it.loaiNguon == "HOP_DONG_PT" }
            .sumOf { it.soTien }
        val cashFlowWalkInGym = walkInsPaidInMonth.sumOf { it.soTien }

        val cashFlowDetails = mutableListOf<CashFlowDetailItem>()
        paymentsInMonth.forEach { p ->
            val member = membersById[p.hoiVienId]
            val title = if (p.loaiNguon == "HOP_DONG_PT") {
                "Thu PT: ${p.ghiChu}"
            } else {
                "Hội viên ${p.boMon}: ${member?.hoTen ?: p.hoiVienId} (STT ${member?.stt ?: "-"})"
            }
            cashFlowDetails.add(
                CashFlowDetailItem(
                    id = p.id,
                    title = title,
                    subtitle = p.ghiChu,
                    boMon = p.boMon,
                    ngayThanhToanDisplay = DateUtils.isoToDisplay(p.ngayThanhToan),
                    amount = p.soTien,
                    categoryLabel = if (p.loaiNguon == "HOP_DONG_PT") "PT Gym" else "Hội viên ${p.boMon}"
                )
            )
        }
        walkInsPaidInMonth.forEach { w ->
            cashFlowDetails.add(
                CashFlowDetailItem(
                    id = w.id,
                    title = "Khách lẻ GYM: ${w.tenLoaiVe} (SL: ${w.soLuong})",
                    subtitle = w.ghiChu.ifBlank { "Thu trực tiếp tại quầy" },
                    boMon = BoMon.GYM,
                    ngayThanhToanDisplay = DateUtils.isoToDisplay(w.ngayThanhToan),
                    amount = w.soTien,
                    categoryLabel = "Khách lẻ GYM"
                )
            )
        }

        // --- DOANH THU PHÂN BỔ (Phần 11.2, 12, 13) ---
        val gymConHanDetails = mutableListOf<ContractAllocationDetailItem>()
        val gymGiaHanDetails = mutableListOf<ContractAllocationDetailItem>()
        val yogaConHanDetails = mutableListOf<ContractAllocationDetailItem>()
        val yogaGiaHanDetails = mutableListOf<ContractAllocationDetailItem>()

        core.contracts.forEach { contract ->
            val startSpec = LocalDateSpec.parseIso(contract.ngayBatDau) ?: return@forEach
            val endExSpec = LocalDateSpec.parseIso(contract.ngayKetThucDocQuyen) ?: return@forEach
            val alloc = FinancialEngine.calculateMonthlyAllocatedRevenue(
                startDate = startSpec,
                endExclusive = endExSpec,
                contractAmount = contract.soTienHopDong,
                targetYear = targetYear,
                targetMonth = targetMonth
            )
            if (alloc.daysInMonth > 0 && alloc.allocatedAmount > 0L) {
                val item = ContractAllocationDetailItem(
                    contract = contract,
                    member = membersById[contract.hoiVienId],
                    daysInMonth = alloc.daysInMonth,
                    totalContractDays = alloc.totalContractDays,
                    allocatedAmount = alloc.allocatedAmount,
                    lastTrainingDateDisplay = DateUtils.toDisplayedLastTrainingDate(endExSpec).toDisplayString()
                )
                if (contract.boMon == BoMon.GYM) {
                    if (contract.loaiBaoCao == LoaiBaoCao.GIA_HAN) {
                        gymGiaHanDetails.add(item)
                    } else {
                        gymConHanDetails.add(item)
                    }
                } else if (contract.boMon == BoMon.YOGA) {
                    if (contract.loaiBaoCao == LoaiBaoCao.GIA_HAN) {
                        yogaGiaHanDetails.add(item)
                    } else {
                        yogaConHanDetails.add(item)
                    }
                }
            }
        }

        val dailyWalkInDetails = mutableListOf<WalkInAllocationDetailItem>()
        val weeklyWalkInDetails = mutableListOf<WalkInAllocationDetailItem>()

        core.walkIns.forEach { ticket ->
            val startSpec = LocalDateSpec.parseIso(ticket.ngayBatDauSuDung) ?: return@forEach
            val endExSpec = LocalDateSpec.parseIso(ticket.ngayKetThucDocQuyen) ?: return@forEach
            val alloc = FinancialEngine.calculateMonthlyAllocatedRevenue(
                startDate = startSpec,
                endExclusive = endExSpec,
                contractAmount = ticket.soTien,
                targetYear = targetYear,
                targetMonth = targetMonth
            )
            if (alloc.daysInMonth > 0 && alloc.allocatedAmount > 0L) {
                val detail = WalkInAllocationDetailItem(
                    ticket = ticket,
                    daysInMonth = alloc.daysInMonth,
                    totalDays = alloc.totalContractDays,
                    allocatedAmount = alloc.allocatedAmount
                )
                if (ticket.loaiVe == LoaiVeKhachLe.TUAN_LE) {
                    weeklyWalkInDetails.add(detail)
                } else {
                    dailyWalkInDetails.add(detail)
                }
            }
        }

        val gymAllocatedConHan = gymConHanDetails.sumOf { it.allocatedAmount }
        val gymAllocatedGiaHan = gymGiaHanDetails.sumOf { it.allocatedAmount }
        val gymAllocatedPtCenter = ptContractUiList.sumOf { it.monthlyAllocation.centerAllocatedRevenue }
        val gymAllocatedPtCoach = ptContractUiList.sumOf { it.monthlyAllocation.ptAllocatedShare }
        val gymAllocatedDailyWalkIn = dailyWalkInDetails.sumOf { it.allocatedAmount }
        val gymAllocatedWeeklyWalkIn = weeklyWalkInDetails.sumOf { it.allocatedAmount }

        val totalGymAllocated = gymAllocatedConHan + gymAllocatedGiaHan +
            gymAllocatedPtCenter + gymAllocatedDailyWalkIn + gymAllocatedWeeklyWalkIn

        val yogaAllocatedConHan = yogaConHanDetails.sumOf { it.allocatedAmount }
        val yogaAllocatedGiaHan = yogaGiaHanDetails.sumOf { it.allocatedAmount }
        val totalYogaAllocated = yogaAllocatedConHan + yogaAllocatedGiaHan

        val totalCashFlowMemberFiltered = when (deptFilter) {
            BoMon.GYM -> cashFlowMemberGym + cashFlowPtGym
            BoMon.YOGA -> cashFlowMemberYoga
            else -> cashFlowMemberGym + cashFlowPtGym + cashFlowMemberYoga
        }
        val totalCashFlowWalkInFiltered = when (deptFilter) {
            BoMon.YOGA -> 0L
            else -> cashFlowWalkInGym
        }

        val cfgMap = trashCfg.configs.associate { it.key to it.value }
        val savedThemeRaw = cfgMap["THEME_MODE"]
            ?: if (cfgMap["DARK_MODE"] == "true") "DARK" else "LIGHT"
        val resolvedThemeMode = ThemeModePreference.fromConfigString(savedThemeRaw)
        val darkModeEnabled = resolvedThemeMode == ThemeModePreference.DARK
        val googleEmail = cfgMap["GOOGLE_DRIVE_EMAIL"]?.takeIf { it.isNotBlank() }
        val googleName = cfgMap["GOOGLE_DRIVE_NAME"]?.takeIf { it.isNotBlank() }
        val autoDriveBackup = cfgMap["GOOGLE_DRIVE_AUTO_BACKUP"] == "true"
        val lastDriveBackupTime = cfgMap["GOOGLE_DRIVE_LAST_BACKUP"]?.takeIf { it.isNotBlank() }

        AppUiState(
            isLoading = false,
            gymMembers = gymMembers,
            yogaMembers = yogaMembers,
            allTrackingMembers = allTrackingSorted,
            maxSttGym = maxSttGym,
            nextSttGym = maxSttGym + 1,
            maxSttYoga = maxSttYoga,
            nextSttYoga = maxSttYoga + 1,
            packages = core.packages,
            ptContracts = ptContractUiList,
            walkInTickets = core.walkIns,
            deletedMembers = trashCfg.deletedMembers,
            deletedPtContracts = trashCfg.deletedPtContracts,
            deletedWalkInTickets = trashCfg.deletedWalkIns,
            revenueDashboard = MonthlyRevenueDashboardUi(
                year = targetYear,
                month = targetMonth,
                departmentFilter = deptFilter,
                cashFlowMemberGym = cashFlowMemberGym,
                cashFlowMemberYoga = cashFlowMemberYoga,
                cashFlowPtGym = cashFlowPtGym,
                cashFlowWalkInGym = cashFlowWalkInGym,
                totalCashFlowMember = totalCashFlowMemberFiltered,
                totalCashFlowWalkIn = totalCashFlowWalkInFiltered,
                totalCashFlowAll = totalCashFlowMemberFiltered + totalCashFlowWalkInFiltered,
                cashFlowDetails = cashFlowDetails.filter {
                    deptFilter == "CA_HAI" || it.boMon == deptFilter
                },
                gymAllocatedConHan = gymAllocatedConHan,
                gymAllocatedGiaHan = gymAllocatedGiaHan,
                gymAllocatedPtCenter = gymAllocatedPtCenter,
                gymAllocatedPtCoach = gymAllocatedPtCoach,
                gymAllocatedDailyWalkIn = gymAllocatedDailyWalkIn,
                gymAllocatedWeeklyWalkIn = gymAllocatedWeeklyWalkIn,
                totalGymAllocated = totalGymAllocated,
                yogaAllocatedConHan = yogaAllocatedConHan,
                yogaAllocatedGiaHan = yogaAllocatedGiaHan,
                totalYogaAllocated = totalYogaAllocated,
                gymConHanDetails = gymConHanDetails.sortedBy { it.member?.stt ?: 0 },
                gymGiaHanDetails = gymGiaHanDetails.sortedBy { it.member?.stt ?: 0 },
                yogaConHanDetails = yogaConHanDetails.sortedBy { it.member?.stt ?: 0 },
                yogaGiaHanDetails = yogaGiaHanDetails.sortedBy { it.member?.stt ?: 0 },
                ptDetailsInMonth = ptContractUiList.filter { it.sessionsUsedInSelectedMonth > 0 || it.contract.ngayThanhToan.startsWith(monthPrefix) },
                dailyWalkInDetails = dailyWalkInDetails,
                weeklyWalkInDetails = weeklyWalkInDetails
            ),
            auditLogs = trashCfg.logs,
            goldenTestResults = FinancialEngine.runAllGoldenTestCases(),
            themeMode = resolvedThemeMode,
            darkMode = darkModeEnabled,
            googleAccountEmail = googleEmail,
            googleAccountName = googleName,
            isGoogleConnected = !googleEmail.isNullOrBlank() && !driveState.activeAccessToken.isNullOrBlank(),
            autoDriveBackupEnabled = autoDriveBackup,
            lastDriveBackupTime = lastDriveBackupTime,
            driveBackups = driveState.driveBackups,
            isDriveBusy = driveState.isDriveBusy,
            driveStatusMessage = driveState.driveStatusMessage
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AppUiState(isLoading = true)
    )

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun showMessage(msg: String) {
        _statusMessage.value = msg
    }

    fun setMonthYear(month: Int, year: Int) {
        _selectedMonth.value = month.coerceIn(1, 12)
        _selectedYear.value = year.coerceIn(2000, 2100)
    }

    fun setRevenueDepartmentFilter(filter: String) {
        _revenueDeptFilter.value = filter
    }

    fun setThemeMode(mode: ThemeModePreference) {
        viewModelScope.launch {
            repository.setConfig("THEME_MODE", mode.configValue)
            repository.setConfig("DARK_MODE", (mode == ThemeModePreference.DARK).toString())
        }
    }

    fun toggleDarkMode(enabled: Boolean) {
        setThemeMode(if (enabled) ThemeModePreference.DARK else ThemeModePreference.LIGHT)
    }

    // --- THAO TÁC HỘI VIÊN & HỢP ĐỒNG ---

    fun registerNewMember(
        boMon: String,
        stt: Int,
        hoTen: String,
        soDienThoai: String,
        loaiKhach: String,
        goiTapId: String?,
        tenGoiTap: String,
        ngayDangKyIso: String,
        ngayBatDauIso: String,
        ngayKetThucDocQuyenIso: String,
        soTienHopDong: Long,
        soTienDaThu: Long,
        ngayThanhToanIso: String,
        ghiChuHoiVien: String,
        ghiChuHopDong: String
    ) {
        viewModelScope.launch {
            repository.createNewMemberAndContract(
                boMon = boMon,
                stt = stt,
                hoTen = hoTen,
                soDienThoai = soDienThoai,
                loaiKhach = loaiKhach,
                goiTapId = goiTapId,
                tenGoiTap = tenGoiTap,
                ngayDangKyIso = ngayDangKyIso,
                ngayBatDauIso = ngayBatDauIso,
                ngayKetThucDocQuyenIso = ngayKetThucDocQuyenIso,
                soTienHopDong = soTienHopDong,
                soTienDaThu = soTienDaThu,
                ngayThanhToanIso = ngayThanhToanIso,
                ghiChuHoiVien = ghiChuHoiVien,
                ghiChuHopDong = ghiChuHopDong
            )
            _statusMessage.value = "Đã thêm hội viên $boMon: $hoTen (STT $stt)"
        }
    }

    fun renewMember(
        member: MemberEntity,
        loaiHopDong: String,
        loaiBaoCao: String,
        goiTapId: String?,
        tenGoiTap: String,
        ngayDangKyIso: String,
        ngayBatDauIso: String,
        ngayKetThucDocQuyenIso: String,
        soTienHopDong: Long,
        soTienDaThu: Long,
        ngayThanhToanIso: String,
        ghiChuHopDong: String
    ) {
        viewModelScope.launch {
            repository.renewMemberContract(
                member = member,
                loaiHopDong = loaiHopDong,
                loaiBaoCao = loaiBaoCao,
                goiTapId = goiTapId,
                tenGoiTap = tenGoiTap,
                ngayDangKyIso = ngayDangKyIso,
                ngayBatDauIso = ngayBatDauIso,
                ngayKetThucDocQuyenIso = ngayKetThucDocQuyenIso,
                soTienHopDong = soTienHopDong,
                soTienDaThu = soTienDaThu,
                ngayThanhToanIso = ngayThanhToanIso,
                ghiChuHopDong = ghiChuHopDong
            )
            _statusMessage.value = "Đã tạo hợp đồng gia hạn mới cho ${member.hoTen}"
        }
    }

    fun updateMemberProfile(
        member: MemberEntity,
        newStt: Int,
        newHoTen: String,
        newSoDienThoai: String,
        newLoaiKhach: String,
        newGhiChu: String
    ) {
        viewModelScope.launch {
            repository.updateMemberProfile(
                member = member,
                newStt = newStt,
                newHoTen = newHoTen,
                newSoDienThoai = newSoDienThoai,
                newLoaiKhach = newLoaiKhach,
                newGhiChu = newGhiChu
            )
            _statusMessage.value = "Đã cập nhật hồ sơ hội viên $newHoTen"
        }
    }

    fun updateContract(
        contract: MemberContractEntity,
        newGoiTap: String,
        newLoaiBaoCao: String,
        newNgayBatDauIso: String,
        newNgayKetThucDocQuyenIso: String,
        newSoTienHopDong: Long,
        newSoTienDaThu: Long,
        newNgayThanhToanIso: String,
        newGhiChu: String
    ) {
        viewModelScope.launch {
            repository.updateContractDetails(
                contract = contract,
                newGoiTap = newGoiTap,
                newLoaiBaoCao = newLoaiBaoCao,
                newNgayBatDauIso = newNgayBatDauIso,
                newNgayKetThucDocQuyenIso = newNgayKetThucDocQuyenIso,
                newSoTienHopDong = newSoTienHopDong,
                newSoTienDaThu = newSoTienDaThu,
                newNgayThanhToanIso = newNgayThanhToanIso,
                newGhiChu = newGhiChu
            )
            _statusMessage.value = "Đã cập nhật hợp đồng & tính lại doanh thu phân bổ"
        }
    }

    fun collectDebtPayment(
        contract: MemberContractEntity,
        amountToCollect: Long,
        paymentDateIso: String,
        note: String
    ) {
        viewModelScope.launch {
            repository.collectAdditionalPaymentForContract(
                contract = contract,
                amountToCollect = amountToCollect,
                paymentDateIso = paymentDateIso,
                note = note
            )
            _statusMessage.value = "Đã ghi nhận thu thêm ${DateUtils.formatVnd(amountToCollect)}"
        }
    }

    fun deleteMemberToTrash(member: MemberEntity) {
        viewModelScope.launch {
            repository.softDeleteMember(member)
            _statusMessage.value = "Đã chuyển ${member.hoTen} vào thùng rác"
        }
    }

    fun restoreMember(member: MemberEntity) {
        viewModelScope.launch {
            repository.restoreMemberFromTrash(member)
            _statusMessage.value = "Đã khôi phục hội viên ${member.hoTen}"
        }
    }

    fun permanentlyDeleteMember(member: MemberEntity) {
        viewModelScope.launch {
            repository.permanentlyDeleteMember(member)
            _statusMessage.value = "Đã xóa vĩnh viễn hồ sơ ${member.hoTen}"
        }
    }

    // --- KHÁCH TẬP BUỔI LẺ & TUẦN LẺ (Phần 10) ---

    /**
     * Nút thao tác nhanh: THU NGAY 1 NGÀY LẺ – 30.000đ
     */
    fun quickCollectOneDayWalkIn() {
        viewModelScope.launch {
            val today = LocalDateSpec.today()
            val tomorrow = today.plusDays(1)
            repository.createWalkInTicket(
                loaiVe = LoaiVeKhachLe.NGAY_LE,
                tenLoaiVe = "1 ngày lẻ",
                soLuong = 1,
                soTien = 30_000L,
                ngayThanhToanIso = today.toIsoString(),
                ngayBatDauSuDungIso = today.toIsoString(),
                ngayKetThucDocQuyenIso = tomorrow.toIsoString(),
                ghiChu = "Thu nhanh 1 ngày lẻ tại quầy"
            )
            _statusMessage.value = "Đã thu ngay 1 ngày lẻ – 30.000đ (${today.toDisplayString()})"
        }
    }

    fun addCustomWalkInTicket(
        loaiVe: String,
        tenLoaiVe: String,
        soLuong: Int,
        soTien: Long,
        ngayThanhToanIso: String,
        ngayBatDauSuDungIso: String,
        ngayKetThucDocQuyenIso: String,
        ghiChu: String
    ) {
        viewModelScope.launch {
            repository.createWalkInTicket(
                loaiVe = loaiVe,
                tenLoaiVe = tenLoaiVe,
                soLuong = soLuong,
                soTien = soTien,
                ngayThanhToanIso = ngayThanhToanIso,
                ngayBatDauSuDungIso = ngayBatDauSuDungIso,
                ngayKetThucDocQuyenIso = ngayKetThucDocQuyenIso,
                ghiChu = ghiChu
            )
            _statusMessage.value = "Đã lưu vé khách lẻ: $tenLoaiVe (${DateUtils.formatVnd(soTien)})"
        }
    }

    fun updateWalkInTicket(ticket: WalkInTicketEntity) {
        viewModelScope.launch {
            repository.updateWalkInTicket(ticket)
            _statusMessage.value = "Đã cập nhật giao dịch khách lẻ"
        }
    }

    fun deleteWalkInTicketToTrash(ticket: WalkInTicketEntity) {
        viewModelScope.launch {
            repository.softDeleteWalkInTicket(ticket)
            _statusMessage.value = "Đã chuyển giao dịch khách lẻ vào thùng rác"
        }
    }

    fun restoreWalkInTicket(ticket: WalkInTicketEntity) {
        viewModelScope.launch {
            repository.restoreWalkInTicket(ticket)
            _statusMessage.value = "Đã khôi phục giao dịch khách lẻ"
        }
    }

    // --- QUẢN LÝ PT (Phần 9) ---

    fun createPtContract(
        stt: Int,
        maKhach: String,
        hoTen: String,
        soDienThoai: String,
        goiPt: String,
        tongSoBuoi: Int,
        soTienHopDong: Long,
        soTienDaThu: Long,
        phanTramTrungTam: Int,
        phanTramPt: Int,
        ngayThanhToanIso: String,
        ghiChu: String
    ) {
        viewModelScope.launch {
            repository.createPtContract(
                stt = stt,
                maKhach = maKhach,
                hoTen = hoTen,
                soDienThoai = soDienThoai,
                goiPt = goiPt,
                tongSoBuoi = tongSoBuoi,
                soTienHopDong = soTienHopDong,
                soTienDaThu = soTienDaThu,
                phanTramTrungTam = phanTramTrungTam,
                phanTramPt = phanTramPt,
                ngayThanhToanIso = ngayThanhToanIso,
                ghiChu = ghiChu
            )
            _statusMessage.value = "Đã tạo hợp đồng PT: $hoTen ($tongSoBuoi buổi)"
        }
    }

    fun updatePtContract(ptContract: PtContractEntity) {
        viewModelScope.launch {
            repository.updatePtContract(ptContract)
            _statusMessage.value = "Đã cập nhật hợp đồng PT: ${ptContract.hoTen}"
        }
    }

    fun recordPtSession(
        ptContract: PtContractWithSessionsUi,
        ngayTapIso: String,
        soBuoi: Int,
        ghiChu: String
    ) {
        if (soBuoi <= 0) return
        if (ptContract.remainingSessions < soBuoi) {
            _statusMessage.value = "Số buổi còn lại (${ptContract.remainingSessions}) không đủ để ghi nhận $soBuoi buổi!"
            return
        }
        viewModelScope.launch {
            repository.addPtSession(
                ptContractId = ptContract.contract.id,
                ngayTapIso = ngayTapIso,
                soBuoi = soBuoi,
                ghiChu = ghiChu
            )
            _statusMessage.value = "Đã ghi nhận $soBuoi buổi tập PT cho ${ptContract.contract.hoTen}"
        }
    }

    fun updatePtSession(session: PtSessionEntity) {
        viewModelScope.launch {
            repository.updatePtSession(session)
            _statusMessage.value = "Đã cập nhật buổi tập PT & tính lại doanh thu tháng"
        }
    }

    fun deletePtSession(session: PtSessionEntity) {
        viewModelScope.launch {
            repository.deletePtSession(session)
            _statusMessage.value = "Đã xóa buổi tập PT & tính lại doanh thu tháng"
        }
    }

    fun deletePtContractToTrash(ptContract: PtContractEntity) {
        viewModelScope.launch {
            repository.softDeletePtContract(ptContract)
            _statusMessage.value = "Đã chuyển hợp đồng PT ${ptContract.hoTen} vào thùng rác"
        }
    }

    fun restorePtContract(ptContract: PtContractEntity) {
        viewModelScope.launch {
            repository.restorePtContract(ptContract)
            _statusMessage.value = "Đã khôi phục hợp đồng PT ${ptContract.hoTen}"
        }
    }

    // --- BẢNG GIÁ & GÓI TẬP (Phần 4) ---

    fun savePricingPackage(pkg: PricingPackageEntity) {
        viewModelScope.launch {
            repository.saveOrUpdatePricingPackage(pkg)
            _statusMessage.value = "Đã lưu gói tập: ${pkg.tenGoi} (${DateUtils.formatVnd(pkg.giaTien)})"
        }
    }

    fun deletePricingPackage(pkg: PricingPackageEntity) {
        viewModelScope.launch {
            repository.deletePricingPackage(pkg)
            _statusMessage.value = "Đã xóa gói tập ${pkg.tenGoi}"
        }
    }

    // --- XUẤT BÁO CÁO PDF A4 & EXCEL/CSV (Phần 15) ---

    fun writePdfReportToStream(
        reportType: PdfReportType,
        outputStream: OutputStream
    ) {
        val rev = uiState.value.revenueDashboard
        writePdfReportForDashboard(reportType, rev, outputStream)
    }

    internal fun writePdfReportForDashboard(
        reportType: PdfReportType,
        rev: MonthlyRevenueDashboardUi,
        outputStream: OutputStream
    ) {
        val memberRows = buildMemberReportRowsForType(reportType, rev)
        val ptRows = buildPtReportRows(rev)
        val walkInRows = buildWalkInReportRows(rev)
        val (cashFlowSummary, allocatedSummary, totalCash, totalAlloc) = buildSummaryMetrics(reportType, rev)

        ReportExporter.writePdfReport(
            outputStream = outputStream,
            reportType = reportType,
            boMonFilterLabel = reportType.boMon,
            month = rev.month,
            year = rev.year,
            memberRows = memberRows,
            ptRows = ptRows,
            walkInRows = walkInRows,
            summaryCashFlowRows = cashFlowSummary,
            summaryAllocatedRows = allocatedSummary,
            totalCashFlow = totalCash,
            totalAllocated = totalAlloc
        )
    }

    fun sharePdfReportNow(context: Context, reportType: PdfReportType) {
        val rev = uiState.value.revenueDashboard
        val fileName = "BaoCao_${reportType.code}_T${rev.month}_${rev.year}.pdf"
        val res = ReportExporter.sharePdfFile(context, fileName) { out ->
            writePdfReportToStream(reportType, out)
        }
        if (res.isFailure) {
            _statusMessage.value = "Lỗi khi xuất PDF: ${res.exceptionOrNull()?.message}"
        }
    }

    fun buildCsvForReport(reportType: PdfReportType): String {
        val rev = uiState.value.revenueDashboard
        return buildCsvForDashboard(reportType, rev)
    }

    internal fun buildCsvForDashboard(
        reportType: PdfReportType,
        rev: MonthlyRevenueDashboardUi
    ): String {
        val memberRows = buildMemberReportRowsForType(reportType, rev)
        val ptRows = buildPtReportRows(rev)
        val walkInRows = buildWalkInReportRows(rev)
        val (cashFlowSummary, allocatedSummary, totalCash, totalAlloc) = buildSummaryMetrics(reportType, rev)

        return ReportExporter.buildExcelCsvContent(
            reportType = reportType,
            month = rev.month,
            year = rev.year,
            memberRows = memberRows,
            ptRows = ptRows,
            walkInRows = walkInRows,
            summaryCashFlowRows = cashFlowSummary,
            summaryAllocatedRows = allocatedSummary,
            totalCashFlow = totalCash,
            totalAllocated = totalAlloc
        )
    }

    fun shareExcelCsvReportNow(context: Context, reportType: PdfReportType) {
        val rev = uiState.value.revenueDashboard
        val fileName = "BaoCao_${reportType.code}_T${rev.month}_${rev.year}.csv"
        val csvContent = buildCsvForReport(reportType)
        val res = ReportExporter.shareCsvOrJsonFile(context, fileName, "text/csv", csvContent)
        if (res.isFailure) {
            _statusMessage.value = "Lỗi khi xuất Excel/CSV: ${res.exceptionOrNull()?.message}"
        }
    }

    internal fun buildMemberReportRowsForType(
        reportType: PdfReportType,
        rev: MonthlyRevenueDashboardUi
    ): List<MemberReportRow> {
        val sourceList = when (reportType) {
            PdfReportType.CON_HAN_GYM -> rev.gymConHanDetails.filter { it.contract.boMon == BoMon.GYM }
            PdfReportType.GIA_HAN_GYM -> rev.gymGiaHanDetails.filter { it.contract.boMon == BoMon.GYM }
            PdfReportType.TONG_HOP_GYM -> (rev.gymConHanDetails + rev.gymGiaHanDetails).filter { it.contract.boMon == BoMon.GYM }
            PdfReportType.CON_HAN_YOGA -> rev.yogaConHanDetails.filter { it.contract.boMon == BoMon.YOGA }
            PdfReportType.GIA_HAN_YOGA -> rev.yogaGiaHanDetails.filter { it.contract.boMon == BoMon.YOGA }
            PdfReportType.TONG_HOP_YOGA -> (rev.yogaConHanDetails + rev.yogaGiaHanDetails).filter { it.contract.boMon == BoMon.YOGA }
            else -> emptyList()
        }

        return sourceList.mapIndexed { idx, item ->
            val loaiBaoCaoLabel = if (item.contract.loaiBaoCao == LoaiBaoCao.GIA_HAN) {
                "Gia hạn"
            } else {
                "Còn hạn & Đăng ký mới"
            }
            MemberReportRow(
                stt = item.member?.stt ?: (idx + 1),
                hoTen = item.member?.hoTen ?: item.contract.hoiVienId,
                boMon = item.contract.boMon,
                goiTap = item.contract.goiTap,
                loaiBaoCaoLabel = loaiBaoCaoLabel,
                ngayDangKyDisplay = DateUtils.isoToDisplay(item.contract.ngayDangKy),
                ngayBatDauDisplay = DateUtils.isoToDisplay(item.contract.ngayBatDau),
                ngayHetHanDisplay = item.lastTrainingDateDisplay,
                soTienHopDong = item.contract.soTienHopDong,
                soNgayTrongThang = item.daysInMonth,
                tongSoNgayHopDong = item.totalContractDays,
                doanhThuPhanBo = item.allocatedAmount
            )
        }
    }

    internal fun buildPtReportRows(rev: MonthlyRevenueDashboardUi): List<PtReportRow> {
        return rev.ptDetailsInMonth
            .sortedBy { it.contract.stt }
            .map { pt ->
                PtReportRow(
                    stt = pt.contract.stt,
                    hoTen = pt.contract.hoTen,
                    goiPt = pt.contract.goiPt,
                    tongSoBuoi = pt.contract.tongSoBuoi,
                    soBuoiDaTapTrongThang = pt.sessionsUsedInSelectedMonth,
                    soBuoiConLai = pt.remainingSessions,
                    soTienHopDong = pt.contract.soTienHopDong,
                    doanhThuTrungTam = pt.monthlyAllocation.centerAllocatedRevenue,
                    doanhThuPt = pt.monthlyAllocation.ptAllocatedShare
                )
            }
    }

    internal fun buildWalkInReportRows(rev: MonthlyRevenueDashboardUi): List<WalkInReportRow> {
        val combined = (rev.dailyWalkInDetails + rev.weeklyWalkInDetails)
        return combined.mapIndexed { index, item ->
            val endEx = LocalDateSpec.parseIso(item.ticket.ngayKetThucDocQuyen)
            val lastDayStr = endEx?.let { DateUtils.toDisplayedLastTrainingDate(it).toDisplayString() } ?: item.ticket.ngayBatDauSuDung
            val startStr = DateUtils.isoToDisplay(item.ticket.ngayBatDauSuDung)
            val periodDisplay = if (startStr == lastDayStr) startStr else "$startStr - $lastDayStr"

            WalkInReportRow(
                stt = index + 1,
                maGiaoDich = item.ticket.id,
                tenLoaiVe = item.ticket.tenLoaiVe,
                soLuong = item.ticket.soLuong,
                soNgaySuDung = item.daysInMonth,
                ngayThuDisplay = DateUtils.isoToDisplay(item.ticket.ngayThanhToan),
                thoiGianSuDungDisplay = periodDisplay,
                soTienThanhToan = item.ticket.soTien,
                doanhThuPhanBoThang = item.allocatedAmount
            )
        }
    }

    internal data class SummaryMetricsResult(
        val cashRows: List<SummaryMetricRow>,
        val allocRows: List<SummaryMetricRow>,
        val totalCash: Long,
        val totalAlloc: Long
    )

    internal fun buildSummaryMetrics(
        reportType: PdfReportType,
        rev: MonthlyRevenueDashboardUi
    ): SummaryMetricsResult {
        return if (reportType == PdfReportType.TONG_HOP_YOGA) {
            val cashRows = listOf(
                SummaryMetricRow(
                    hangMuc = "Tiền hội viên YOGA đã thanh toán",
                    moTa = "Tính theo ngày thanh toán thực tế trong tháng",
                    soLuongBanGhi = rev.cashFlowDetails.count { it.boMon == BoMon.YOGA },
                    donViBanGhi = "GD",
                    soTien = rev.cashFlowMemberYoga
                )
            )
            val allocRows = listOf(
                SummaryMetricRow(
                    hangMuc = "1. Hội viên YOGA còn hạn & đăng ký mới",
                    moTa = ReportExporter.METHOD_MEMBER_ALLOCATION,
                    soLuongBanGhi = rev.yogaConHanDetails.size,
                    donViBanGhi = "HĐ",
                    soTien = rev.yogaAllocatedConHan
                ),
                SummaryMetricRow(
                    hangMuc = "2. Hội viên YOGA gia hạn",
                    moTa = ReportExporter.METHOD_MEMBER_ALLOCATION,
                    soLuongBanGhi = rev.yogaGiaHanDetails.size,
                    donViBanGhi = "HĐ",
                    soTien = rev.yogaAllocatedGiaHan
                )
            )
            SummaryMetricsResult(cashRows, allocRows, rev.cashFlowMemberYoga, rev.totalYogaAllocated)
        } else {
            val cashRows = listOf(
                SummaryMetricRow(
                    hangMuc = "Tiền hội viên GYM & PT đã thanh toán",
                    moTa = "Tính theo ngày thanh toán thực tế trong tháng",
                    soLuongBanGhi = rev.cashFlowDetails.count { it.boMon == BoMon.GYM && it.categoryLabel != "Khách lẻ GYM" },
                    donViBanGhi = "GD",
                    soTien = rev.cashFlowMemberGym + rev.cashFlowPtGym
                ),
                SummaryMetricRow(
                    hangMuc = "Tiền khách tập buổi lẻ & tuần lẻ (GYM)",
                    moTa = "Tính theo ngày thanh toán thực tế trong tháng",
                    soLuongBanGhi = rev.cashFlowDetails.count { it.categoryLabel == "Khách lẻ GYM" },
                    donViBanGhi = "GD",
                    soTien = rev.cashFlowWalkInGym
                )
            )
            val allocRows = listOf(
                SummaryMetricRow(
                    hangMuc = "1. Hội viên GYM còn hạn & đăng ký mới",
                    moTa = ReportExporter.METHOD_MEMBER_ALLOCATION,
                    soLuongBanGhi = rev.gymConHanDetails.size,
                    donViBanGhi = "HĐ",
                    soTien = rev.gymAllocatedConHan
                ),
                SummaryMetricRow(
                    hangMuc = "2. Hội viên GYM gia hạn",
                    moTa = ReportExporter.METHOD_MEMBER_ALLOCATION,
                    soLuongBanGhi = rev.gymGiaHanDetails.size,
                    donViBanGhi = "HĐ",
                    soTien = rev.gymAllocatedGiaHan
                ),
                SummaryMetricRow(
                    hangMuc = "3. Khách tập PT (Phần doanh thu Trung tâm 50%)",
                    moTa = ReportExporter.METHOD_PT_ALLOCATION,
                    soLuongBanGhi = rev.ptDetailsInMonth.count { it.sessionsUsedInSelectedMonth > 0 },
                    donViBanGhi = "HĐ",
                    soTien = rev.gymAllocatedPtCenter
                ),
                SummaryMetricRow(
                    hangMuc = "4. Khách tập buổi lẻ / ngày lẻ (GYM)",
                    moTa = ReportExporter.METHOD_DAILY_WALK_IN,
                    soLuongBanGhi = rev.dailyWalkInDetails.size,
                    donViBanGhi = "vé",
                    soTien = rev.gymAllocatedDailyWalkIn
                ),
                SummaryMetricRow(
                    hangMuc = "5. Khách tập tuần lẻ (GYM)",
                    moTa = ReportExporter.METHOD_WEEKLY_WALK_IN,
                    soLuongBanGhi = rev.weeklyWalkInDetails.size,
                    donViBanGhi = "vé",
                    soTien = rev.gymAllocatedWeeklyWalkIn
                )
            )
            SummaryMetricsResult(
                cashRows = cashRows,
                allocRows = allocRows,
                totalCash = rev.cashFlowMemberGym + rev.cashFlowPtGym + rev.cashFlowWalkInGym,
                totalAlloc = rev.totalGymAllocated
            )
        }
    }

    // --- SAO LƯU & KHÔI PHỤC DỮ LIỆU JSON (Phần 16) ---

    suspend fun exportBackupJson(): String {
        return repository.exportBackupJsonString()
    }

    fun validateBackupJson(jsonString: String): Result<String> {
        return repository.validateBackupJson(jsonString)
    }

    fun restoreBackupJson(jsonString: String, onComplete: (Result<Unit>) -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.restoreFromBackupJson(jsonString)
            if (res.isSuccess) {
                _statusMessage.value = "Đã khôi phục toàn bộ dữ liệu thành công!"
            } else {
                _statusMessage.value = "Lỗi khôi phục: ${res.exceptionOrNull()?.message}"
            }
            onComplete(res)
        }
    }

    // --- GOOGLE SIGN-IN & GOOGLE DRIVE BACKUP / RESTORE (Phần VIII) ---

    fun onGoogleAuthorized(profile: DriveAccountProfile) {
        viewModelScope.launch {
            repository.setConfig("GOOGLE_DRIVE_EMAIL", profile.email)
            repository.setConfig("GOOGLE_DRIVE_NAME", profile.displayName)
            _driveRuntime.value = _driveRuntime.value.copy(
                activeAccessToken = profile.accessToken,
                driveStatusMessage = "Đã kết nối tài khoản Google: ${profile.email}"
            )
            _statusMessage.value = "Đã đăng nhập Google Drive: ${profile.email}"
            refreshDriveBackupsList()
        }
    }

    fun onGoogleAuthError(errorMessage: String) {
        _driveRuntime.value = _driveRuntime.value.copy(
            isDriveBusy = false,
            driveStatusMessage = errorMessage
        )
        _statusMessage.value = errorMessage
    }

    fun disconnectGoogleAccount(context: Context) {
        viewModelScope.launch {
            val token = _driveRuntime.value.activeAccessToken
            if (!token.isNullOrBlank()) {
                GoogleDriveBackupManager.revokeAccess(context, token)
            }
            repository.setConfig("GOOGLE_DRIVE_EMAIL", "")
            repository.setConfig("GOOGLE_DRIVE_NAME", "")
            _driveRuntime.value = DriveRuntimeState(
                driveStatusMessage = "Đã ngắt kết nối tài khoản Google Drive."
            )
            _statusMessage.value = "Đã đăng xuất tài khoản Google Drive"
        }
    }

    fun setAutoDriveBackup(enabled: Boolean) {
        viewModelScope.launch {
            repository.setConfig("GOOGLE_DRIVE_AUTO_BACKUP", enabled.toString())
            _statusMessage.value = if (enabled) {
                "Đã bật tự động sao lưu lên Google Drive"
            } else {
                "Đã tắt tự động sao lưu Google Drive"
            }
        }
    }

    fun refreshDriveBackupsList() {
        val token = _driveRuntime.value.activeAccessToken
        if (token.isNullOrBlank()) {
            _driveRuntime.value = _driveRuntime.value.copy(
                driveStatusMessage = "Phiên làm việc Google Drive đã hết hạn hoặc chưa kết nối. Vui lòng bấm Kết nối Google Drive."
            )
            return
        }
        viewModelScope.launch {
            _driveRuntime.value = _driveRuntime.value.copy(isDriveBusy = true)
            val result = GoogleDriveBackupManager.listBackupsFromDrive(token)
            result.fold(
                onSuccess = { list ->
                    _driveRuntime.value = _driveRuntime.value.copy(
                        isDriveBusy = false,
                        driveBackups = list,
                        driveStatusMessage = "Đã tải danh sách (${list.size} bản sao lưu trên Google Drive)"
                    )
                },
                onFailure = { err ->
                    _driveRuntime.value = _driveRuntime.value.copy(
                        isDriveBusy = false,
                        driveStatusMessage = err.message ?: "Không thể tải danh sách sao lưu từ Google Drive"
                    )
                }
            )
        }
    }

    fun backupToGoogleDriveNow() {
        val token = _driveRuntime.value.activeAccessToken
        if (token.isNullOrBlank()) {
            val msg = "Vui lòng đăng nhập Google Drive trước khi sao lưu đám mây."
            _driveRuntime.value = _driveRuntime.value.copy(driveStatusMessage = msg)
            _statusMessage.value = msg
            return
        }
        viewModelScope.launch {
            _driveRuntime.value = _driveRuntime.value.copy(
                isDriveBusy = true,
                driveStatusMessage = "Đang đóng gói dữ liệu và tải lên Google Drive..."
            )
            val jsonContent = repository.exportBackupJsonString()
            val uploadResult = GoogleDriveBackupManager.uploadBackupToDrive(token, jsonContent)
            uploadResult.fold(
                onSuccess = { uploadedItem ->
                    val nowFormatted = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
                    repository.setConfig("GOOGLE_DRIVE_LAST_BACKUP", nowFormatted)
                    val refreshed = GoogleDriveBackupManager.listBackupsFromDrive(token).getOrDefault(listOf(uploadedItem))
                    _driveRuntime.value = _driveRuntime.value.copy(
                        isDriveBusy = false,
                        driveBackups = refreshed,
                        driveStatusMessage = "Sao lưu thành công: ${uploadedItem.name} ($nowFormatted)"
                    )
                    _statusMessage.value = "Đã sao lưu lên Google Drive thành công ($nowFormatted)"
                },
                onFailure = { err ->
                    val errMsg = err.message ?: "Lỗi khi tải bản sao lưu lên Google Drive."
                    _driveRuntime.value = _driveRuntime.value.copy(
                        isDriveBusy = false,
                        driveStatusMessage = errMsg
                    )
                    _statusMessage.value = errMsg
                }
            )
        }
    }

    fun downloadAndValidateDriveBackup(
        item: DriveBackupFileItem,
        onValidated: (Result<Pair<String, String>>) -> Unit
    ) {
        val token = _driveRuntime.value.activeAccessToken
        if (token.isNullOrBlank()) {
            val msg = "Vui lòng kết nối lại Google Drive để tải bản sao lưu."
            _driveRuntime.value = _driveRuntime.value.copy(driveStatusMessage = msg)
            onValidated(Result.failure(IllegalStateException(msg)))
            return
        }
        viewModelScope.launch {
            _driveRuntime.value = _driveRuntime.value.copy(
                isDriveBusy = true,
                driveStatusMessage = "Đang tải và kiểm tra tính hợp lệ của ${item.name}..."
            )
            val downloadRes = GoogleDriveBackupManager.downloadBackupFromDrive(token, item.id)
            downloadRes.fold(
                onSuccess = { jsonString ->
                    val validationRes = repository.validateBackupJson(jsonString)
                    validationRes.fold(
                        onSuccess = { summaryText ->
                            _driveRuntime.value = _driveRuntime.value.copy(
                                isDriveBusy = false,
                                driveStatusMessage = "Bản sao lưu hợp lệ. Sẵn sàng khôi phục."
                            )
                            onValidated(Result.success(jsonString to summaryText))
                        },
                        onFailure = { valErr ->
                            val msg = "File trên Drive không hợp lệ: ${valErr.message}"
                            _driveRuntime.value = _driveRuntime.value.copy(
                                isDriveBusy = false,
                                driveStatusMessage = msg
                            )
                            onValidated(Result.failure(valErr))
                        }
                    )
                },
                onFailure = { dlErr ->
                    val msg = dlErr.message ?: "Không thể tải file sao lưu từ Google Drive."
                    _driveRuntime.value = _driveRuntime.value.copy(
                        isDriveBusy = false,
                        driveStatusMessage = msg
                    )
                    onValidated(Result.failure(dlErr))
                }
            )
        }
    }

    fun confirmRestoreFromDriveJson(
        context: Context,
        jsonString: String,
        onComplete: (Result<Unit>) -> Unit = {}
    ) {
        viewModelScope.launch {
            _driveRuntime.value = _driveRuntime.value.copy(
                isDriveBusy = true,
                driveStatusMessage = "Đang tạo bản sao lưu an toàn cục bộ trước khi khôi phục..."
            )
            val currentLocalJson = repository.exportBackupJsonString()
            val safetyPath = GoogleDriveBackupManager.saveLocalSafetySnapshot(context, currentLocalJson)
            val res = repository.restoreFromBackupJson(jsonString)
            if (res.isSuccess) {
                val msg = if (safetyPath != null) {
                    "Khôi phục từ Google Drive thành công! (Đã lưu bản dự phòng an toàn trên máy)"
                } else {
                    "Khôi phục toàn bộ dữ liệu từ Google Drive thành công!"
                }
                _driveRuntime.value = _driveRuntime.value.copy(
                    isDriveBusy = false,
                    driveStatusMessage = msg
                )
                _statusMessage.value = msg
            } else {
                val errMsg = "Lỗi khôi phục: ${res.exceptionOrNull()?.message}"
                _driveRuntime.value = _driveRuntime.value.copy(
                    isDriveBusy = false,
                    driveStatusMessage = errMsg
                )
                _statusMessage.value = errMsg
            }
            onComplete(res)
        }
    }
}

class GymYogaViewModelFactory(
    private val repository: GymYogaRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(GymYogaViewModel::class.java)) {
            return GymYogaViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
