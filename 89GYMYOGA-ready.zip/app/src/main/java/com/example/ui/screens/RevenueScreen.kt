package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.BoMon
import com.example.domain.DateUtils
import com.example.ui.theme.GymPrimary
import com.example.ui.theme.LocalAppDesignTokens
import com.example.ui.theme.YogaPrimary
import com.example.ui.viewmodel.AppUiState
import com.example.ui.viewmodel.CashFlowDetailItem
import com.example.ui.viewmodel.ContractAllocationDetailItem
import com.example.ui.viewmodel.GymYogaViewModel
import com.example.ui.viewmodel.MonthlyRevenueDashboardUi
import com.example.ui.viewmodel.PtContractWithSessionsUi
import com.example.ui.viewmodel.WalkInAllocationDetailItem
import com.example.util.PdfReportType

/**
 * Ba danh mục chức năng độc lập của trang tổng quan DOANH THU
 * (Đồng bộ thiết kế với danh mục của màn hình CÀI ĐẶT).
 */
enum class RevenueCategory(
    val code: String,
    val title: String,
    val subtitle: String
) {
    GYM_REVENUE(
        code = "gym",
        title = "Doanh thu GYM",
        subtitle = "Xem doanh thu thực thu, doanh thu phân bổ và chi tiết GYM."
    ),
    YOGA_REVENUE(
        code = "yoga",
        title = "Doanh thu YOGA",
        subtitle = "Xem doanh thu thực thu, doanh thu phân bổ và chi tiết YOGA."
    ),
    EXPORT_REPORTS(
        code = "export",
        title = "Xuất tài liệu báo cáo",
        subtitle = "Quản lý và xuất 8 báo cáo PDF A4 và Excel của GYM và YOGA."
    )
}

private sealed class RevenueDrillDownSheet {
    data class CashFlowList(val title: String, val items: List<CashFlowDetailItem>) : RevenueDrillDownSheet()
    data class ContractAllocationList(val title: String, val accent: Color, val items: List<ContractAllocationDetailItem>) : RevenueDrillDownSheet()
    data class PtAllocationList(val title: String, val items: List<PtContractWithSessionsUi>, val month: Int, val year: Int) : RevenueDrillDownSheet()
    data class WalkInAllocationList(val title: String, val items: List<WalkInAllocationDetailItem>) : RevenueDrillDownSheet()
}

@Composable
fun RevenueScreen(
    uiState: AppUiState,
    viewModel: GymYogaViewModel
) {
    val tokens = LocalAppDesignTokens.current
    val context = LocalContext.current
    val rev = uiState.revenueDashboard
    val gymAccent = tokens.gymAccent
    val yogaAccent = tokens.yogaAccent
    val cashAccent = tokens.statusActiveText

    // null = Trang tổng quan DOANH THU (3 thẻ chức năng); khác null = Màn hình con tương ứng
    var selectedCategory by rememberSaveable { mutableStateOf<RevenueCategory?>(null) }
    var activeDrillDown by remember { mutableStateOf<RevenueDrillDownSheet?>(null) }
    var pendingPdfExportType by remember { mutableStateOf<PdfReportType?>(null) }
    var pendingCsvExportType by remember { mutableStateOf<PdfReportType?>(null) }

    BackHandler(enabled = selectedCategory != null) {
        selectedCategory = null
    }

    val savePdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val reportType = pendingPdfExportType
        if (uri != null && reportType != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    viewModel.writePdfReportToStream(reportType, out)
                }
                viewModel.showMessage("Đã xuất báo cáo PDF A4: ${reportType.titleVi}")
            } catch (e: Exception) {
                viewModel.showMessage("Lỗi ghi tệp PDF: ${e.message}")
            }
        }
        pendingPdfExportType = null
    }

    val saveCsvLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        val reportType = pendingCsvExportType
        if (uri != null && reportType != null) {
            try {
                val csv = viewModel.buildCsvForReport(reportType)
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(csv.toByteArray(Charsets.UTF_8))
                }
                viewModel.showMessage("Đã xuất file Excel (CSV): ${reportType.titleVi}")
            } catch (e: Exception) {
                viewModel.showMessage("Lỗi ghi tệp CSV: ${e.message}")
            }
        }
        pendingCsvExportType = null
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.background)
    ) {
        if (selectedCategory == null) {
            // ==================== TRANG TỔNG QUAN DOANH THU ====================
            // 1. Khu vực chọn Kỳ báo cáo cố định phía trên (Không còn 3 nút lọc cũ)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(tokens.background)
                    .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 10.dp)
            ) {
                OverviewPeriodSelectorCard(
                    month = rev.month,
                    year = rev.year,
                    onPreviousMonth = {
                        if (rev.month == 1) {
                            viewModel.setMonthYear(12, rev.year - 1)
                        } else {
                            viewModel.setMonthYear(rev.month - 1, rev.year)
                        }
                    },
                    onNextMonth = {
                        if (rev.month == 12) {
                            viewModel.setMonthYear(1, rev.year + 1)
                        } else {
                            viewModel.setMonthYear(rev.month + 1, rev.year)
                        }
                    }
                )
            }

            // 2. Danh sách 3 thẻ chức năng độc lập cuộn dọc theo phong cách CÀI ĐẶT
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(RevenueCategory.entries, key = { it.code }) { category ->
                    val (catIcon, catBadgeText, catAccent) = when (category) {
                        RevenueCategory.GYM_REVENUE -> Triple(
                            Icons.Default.FitnessCenter,
                            DateUtils.formatVnd(rev.totalGymAllocated),
                            gymAccent
                        )
                        RevenueCategory.YOGA_REVENUE -> Triple(
                            Icons.Default.SelfImprovement,
                            DateUtils.formatVnd(rev.totalYogaAllocated),
                            yogaAccent
                        )
                        RevenueCategory.EXPORT_REPORTS -> Triple(
                            Icons.Default.TableView,
                            "${PdfReportType.entries.size} báo cáo",
                            cashAccent
                        )
                    }

                    RevenueCategoryCardItem(
                        category = category,
                        icon = catIcon,
                        badgeText = catBadgeText,
                        accentColor = catAccent,
                        onClick = { selectedCategory = category }
                    )
                }
            }
        } else {
            // ==================== MÀN HÌNH CON CHUYÊN BIỆT ====================
            val currentCategory = selectedCategory!!
            val subAccent = when (currentCategory) {
                RevenueCategory.GYM_REVENUE -> gymAccent
                RevenueCategory.YOGA_REVENUE -> yogaAccent
                RevenueCategory.EXPORT_REPORTS -> cashAccent
            }

            // Thanh tiêu đề cố định của màn hình con (Nút Quay lại + Hiển thị kỳ báo cáo đang xem)
            RevenueSubScreenStickyHeader(
                title = currentCategory.title,
                month = rev.month,
                year = rev.year,
                accentColor = subAccent,
                onBack = { selectedCategory = null }
            )
            HorizontalDivider(color = tokens.borderColor)

            // Nội dung cuộn dọc của màn hình con
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (currentCategory) {
                    RevenueCategory.GYM_REVENUE -> {
                        item {
                            GymRevenueSubScreenContent(
                                rev = rev,
                                ptContracts = uiState.ptContracts,
                                gymAccent = gymAccent,
                                cashAccent = cashAccent,
                                onOpenDrillDown = { activeDrillDown = it }
                            )
                        }
                    }

                    RevenueCategory.YOGA_REVENUE -> {
                        item {
                            YogaRevenueSubScreenContent(
                                rev = rev,
                                yogaAccent = yogaAccent,
                                cashAccent = cashAccent,
                                onOpenDrillDown = { activeDrillDown = it }
                            )
                        }
                    }

                    RevenueCategory.EXPORT_REPORTS -> {
                        item {
                            ExportReportsSubScreenContent(
                                month = rev.month,
                                year = rev.year,
                                gymAccent = gymAccent,
                                yogaAccent = yogaAccent,
                                exportAccent = cashAccent,
                                onSavePdfToDevice = { reportType ->
                                    pendingPdfExportType = reportType
                                    val defaultName = "BaoCao_${reportType.code}_T${rev.month}_${rev.year}.pdf"
                                    savePdfLauncher.launch(defaultName)
                                },
                                onSharePdf = { reportType ->
                                    viewModel.sharePdfReportNow(context, reportType)
                                },
                                onExportExcelCsv = { reportType ->
                                    pendingCsvExportType = reportType
                                    val defaultCsvName = "BaoCao_${reportType.code}_T${rev.month}_${rev.year}.csv"
                                    saveCsvLauncher.launch(defaultCsvName)
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    // Hộp thoại truy xuất chi tiết (Drill-down modal dialog)
    if (activeDrillDown != null) {
        RevenueDrillDownDialog(
            sheet = activeDrillDown!!,
            onDismiss = { activeDrillDown = null }
        )
    }
}

/**
 * Thẻ chọn Kỳ báo cáo trên trang tổng quan DOANH THU (Không chứa 3 nút lọc cũ).
 */
@Composable
private fun OverviewPeriodSelectorCard(
    month: Int,
    year: Int,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = tokens.cardSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Kỳ báo cáo doanh thu",
                    style = MaterialTheme.typography.labelMedium,
                    color = tokens.textSecondary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Tháng %02d / %04d".format(month, year),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = tokens.textPrimary,
                    maxLines = 1
                )
            }

            Surface(
                color = tokens.elevatedSurface,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.border(1.dp, tokens.borderColor, RoundedCornerShape(12.dp))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 4.dp)
                ) {
                    IconButton(
                        onClick = onPreviousMonth,
                        modifier = Modifier.testTag("prev_month_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                            contentDescription = "Tháng trước",
                            tint = tokens.textPrimary
                        )
                    }
                    Text(
                        text = "T%02d/%04d".format(month, year),
                        style = MaterialTheme.typography.titleSmall,
                        color = tokens.textPrimary,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    IconButton(
                        onClick = onNextMonth,
                        modifier = Modifier.testTag("next_month_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Tháng sau",
                            tint = tokens.textPrimary
                        )
                    }
                }
            }
        }
    }
}

/**
 * Thẻ danh mục chức năng trên trang tổng quan DOANH THU (Đồng bộ với SettingsCategoryCardItem).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RevenueCategoryCardItem(
    category: RevenueCategory,
    icon: ImageVector,
    badgeText: String,
    accentColor: Color,
    onClick: () -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = tokens.cardSurface,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
            .testTag("revenue_category_${category.code}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(accentColor.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    FlowRow(
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = category.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = tokens.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = accentColor.copy(alpha = if (tokens.isDark) 0.22f else 0.12f),
                            modifier = Modifier.align(Alignment.CenterVertically)
                        ) {
                            Text(
                                text = badgeText,
                                style = MaterialTheme.typography.labelSmall,
                                color = accentColor,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                maxLines = 1
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = category.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.textSecondary
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Mở ${category.title}",
                tint = tokens.textSecondary
            )
        }
    }
}

/**
 * Thanh tiêu đề cố định của màn hình con (Nút Quay lại + Chỉ hiển thị kỳ đang xem).
 */
@Composable
private fun RevenueSubScreenStickyHeader(
    title: String,
    month: Int,
    year: Int,
    accentColor: Color,
    onBack: () -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    Surface(
        color = tokens.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("revenue_subscreen_back_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Quay lại tổng quan Doanh thu",
                        tint = tokens.textPrimary
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = tokens.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Kỳ báo cáo: Tháng %02d / %04d".format(month, year),
                        style = MaterialTheme.typography.labelSmall,
                        color = tokens.textSecondary,
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = accentColor.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)
            ) {
                Text(
                    text = "T%02d/%04d".format(month, year),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = accentColor,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    maxLines = 1
                )
            }
        }
    }
}

/**
 * MÀN HÌNH CON 1: DOANH THU GYM (Giữ nguyên toàn bộ dữ liệu thực thu & phân bổ của GYM).
 */
@Composable
private fun GymRevenueSubScreenContent(
    rev: MonthlyRevenueDashboardUi,
    ptContracts: List<PtContractWithSessionsUi>,
    gymAccent: Color,
    cashAccent: Color,
    onOpenDrillDown: (RevenueDrillDownSheet) -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    val gymCashMemberAndPt = rev.cashFlowMemberGym + rev.cashFlowPtGym
    val gymCashWalkIn = rev.cashFlowWalkInGym
    val gymCashTotal = gymCashMemberAndPt + gymCashWalkIn
    val gymCashDetailsAll = remember(rev.cashFlowDetails) {
        rev.cashFlowDetails.filter { it.boMon == BoMon.GYM }
    }
    val gymCashDetailsMemberAndPt = remember(gymCashDetailsAll) {
        gymCashDetailsAll.filter { it.categoryLabel != "Khách lẻ GYM" }
    }
    val gymCashDetailsWalkIn = remember(gymCashDetailsAll) {
        gymCashDetailsAll.filter { it.categoryLabel == "Khách lẻ GYM" }
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // 1. Thanh so sánh trực quan Thực thu GYM vs Phân bổ GYM
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = tokens.cardSurface,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                RevenueComparisonBar(
                    cashFlowTotal = gymCashTotal,
                    allocatedTotal = rev.totalGymAllocated,
                    gymAllocated = rev.totalGymAllocated,
                    yogaAllocated = 0L,
                    cashColor = cashAccent,
                    gymColor = gymAccent,
                    yogaColor = gymAccent
                )
            }
        }

        // 2. A. DOANH THU THỰC THU (GYM)
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = tokens.cardSurface,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(tokens.statusActiveBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.AccountBalanceWallet,
                            contentDescription = null,
                            tint = cashAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "A. DOANH THU THỰC THU – GYM",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary
                        )
                        Text(
                            text = "Tổng số tiền GYM thực tế đã nhận trong tháng, tính theo ngày thanh toán.",
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.textSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = tokens.dividerColor)
                Spacer(modifier = Modifier.height(8.dp))

                ClickableRevenueMetricRow(
                    label = "Tổng tiền hội viên GYM & PT đã thanh toán",
                    subLabel = "Gồm hội viên GYM đăng ký/gia hạn (${DateUtils.formatVnd(rev.cashFlowMemberGym)}) & PT (${DateUtils.formatVnd(rev.cashFlowPtGym)})",
                    amount = gymCashMemberAndPt,
                    accentColor = cashAccent,
                    onClick = {
                        onOpenDrillDown(
                            RevenueDrillDownSheet.CashFlowList(
                                title = "Chi tiết tiền thực thu hội viên GYM & PT T${rev.month}/${rev.year}",
                                items = gymCashDetailsMemberAndPt
                            )
                        )
                    }
                )

                ClickableRevenueMetricRow(
                    label = "Tổng tiền khách tập lẻ đã đóng (GYM)",
                    subLabel = "Vé ngày lẻ & tuần lẻ thu trong tháng",
                    amount = gymCashWalkIn,
                    accentColor = cashAccent,
                    onClick = {
                        onOpenDrillDown(
                            RevenueDrillDownSheet.CashFlowList(
                                title = "Chi tiết tiền thực thu khách lẻ GYM T${rev.month}/${rev.year}",
                                items = gymCashDetailsWalkIn
                            )
                        )
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = tokens.statusActiveBg,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            onOpenDrillDown(
                                RevenueDrillDownSheet.CashFlowList(
                                    title = "Toàn bộ giao dịch thực thu GYM T${rev.month}/${rev.year}",
                                    items = gymCashDetailsAll
                                )
                            )
                        }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "TỔNG TIỀN THỰC THU TRONG THÁNG (GYM)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = cashAccent
                            )
                            Text(
                                text = "${gymCashDetailsAll.size} giao dịch thanh toán • Chạm để truy xuất",
                                style = MaterialTheme.typography.labelSmall,
                                color = cashAccent
                            )
                        }
                        Text(
                            text = DateUtils.formatVnd(gymCashTotal),
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = cashAccent
                        )
                    }
                }
            }
        }

        // 3. B. DOANH THU PHÂN BỔ – GYM
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = tokens.cardSurface,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(gymAccent.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.PieChart,
                            contentDescription = null,
                            tint = gymAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "B. DOANH THU PHÂN BỔ – GYM",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary
                        )
                        Text(
                            text = "Giá trị dịch vụ được phân bổ vào tháng báo cáo theo thời gian hiệu lực hợp đồng hoặc dịch vụ đã sử dụng.",
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.textSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = tokens.dividerColor)
                Spacer(modifier = Modifier.height(6.dp))

                ClickableRevenueMetricRow(
                    label = "1. Hội viên GYM còn hạn & đăng ký mới",
                    subLabel = "${rev.gymConHanDetails.size} HĐ • Phân bổ theo số ngày hiệu lực của hợp đồng trong tháng",
                    amount = rev.gymAllocatedConHan,
                    accentColor = gymAccent,
                    onClick = {
                        onOpenDrillDown(
                            RevenueDrillDownSheet.ContractAllocationList(
                                title = "Chi tiết: Hội viên GYM còn hạn & đăng ký mới - T${rev.month}/${rev.year}",
                                accent = gymAccent,
                                items = rev.gymConHanDetails
                            )
                        )
                    }
                )

                ClickableRevenueMetricRow(
                    label = "2. Hội viên GYM gia hạn",
                    subLabel = "${rev.gymGiaHanDetails.size} HĐ • Phân bổ theo số ngày hiệu lực của hợp đồng trong tháng",
                    amount = rev.gymAllocatedGiaHan,
                    accentColor = gymAccent,
                    onClick = {
                        onOpenDrillDown(
                            RevenueDrillDownSheet.ContractAllocationList(
                                title = "Chi tiết: Hội viên GYM gia hạn - T${rev.month}/${rev.year}",
                                accent = gymAccent,
                                items = rev.gymGiaHanDetails
                            )
                        )
                    }
                )

                ClickableRevenueMetricRow(
                    label = "3. Khách tập PT (Phần doanh thu Trung tâm 50%)",
                    subLabel = "Phân bổ theo số buổi PT thực tế đã hoàn thành trong tháng • Phần HLV (50%): ${DateUtils.formatVnd(rev.gymAllocatedPtCoach)}",
                    amount = rev.gymAllocatedPtCenter,
                    accentColor = gymAccent,
                    onClick = {
                        onOpenDrillDown(
                            RevenueDrillDownSheet.PtAllocationList(
                                title = "Chi tiết doanh thu phân bổ PT - T${rev.month}/${rev.year}",
                                items = ptContracts,
                                month = rev.month,
                                year = rev.year
                            )
                        )
                    }
                )

                ClickableRevenueMetricRow(
                    label = "4. Khách tập buổi lẻ / ngày lẻ (GYM)",
                    subLabel = "${rev.dailyWalkInDetails.size} vé • Ghi nhận theo ngày sử dụng",
                    amount = rev.gymAllocatedDailyWalkIn,
                    accentColor = gymAccent,
                    onClick = {
                        onOpenDrillDown(
                            RevenueDrillDownSheet.WalkInAllocationList(
                                title = "Chi tiết: Khách tập buổi lẻ / ngày lẻ - T${rev.month}/${rev.year}",
                                items = rev.dailyWalkInDetails
                            )
                        )
                    }
                )

                ClickableRevenueMetricRow(
                    label = "5. Khách tập tuần lẻ (GYM)",
                    subLabel = "${rev.weeklyWalkInDetails.size} vé • Phân bổ theo số ngày sử dụng thuộc tháng báo cáo",
                    amount = rev.gymAllocatedWeeklyWalkIn,
                    accentColor = gymAccent,
                    onClick = {
                        onOpenDrillDown(
                            RevenueDrillDownSheet.WalkInAllocationList(
                                title = "Chi tiết: Khách tập tuần lẻ - T${rev.month}/${rev.year}",
                                items = rev.weeklyWalkInDetails
                            )
                        )
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = gymAccent.copy(alpha = if (tokens.isDark) 0.18f else 0.1f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            onOpenDrillDown(
                                RevenueDrillDownSheet.ContractAllocationList(
                                    title = "Tất cả hợp đồng GYM phân bổ T${rev.month}/${rev.year}",
                                    accent = gymAccent,
                                    items = rev.gymConHanDetails + rev.gymGiaHanDetails
                                )
                            )
                        }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "TỔNG DOANH THU PHÂN BỔ (GYM)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = gymAccent
                            )
                            Text(
                                text = "Còn hạn + Gia hạn + PT (Trung tâm) + Khách lẻ",
                                style = MaterialTheme.typography.labelSmall,
                                color = gymAccent
                            )
                        }
                        Text(
                            text = DateUtils.formatVnd(rev.totalGymAllocated),
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = gymAccent
                        )
                    }
                }
            }
        }
    }
}

/**
 * MÀN HÌNH CON 2: DOANH THU YOGA (Giữ nguyên toàn bộ dữ liệu thực thu & phân bổ của YOGA).
 */
@Composable
private fun YogaRevenueSubScreenContent(
    rev: MonthlyRevenueDashboardUi,
    yogaAccent: Color,
    cashAccent: Color,
    onOpenDrillDown: (RevenueDrillDownSheet) -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    val yogaCashTotal = rev.cashFlowMemberYoga
    val yogaCashDetailsAll = remember(rev.cashFlowDetails) {
        rev.cashFlowDetails.filter { it.boMon == BoMon.YOGA }
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // 1. Thanh so sánh trực quan Thực thu YOGA vs Phân bổ YOGA
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = tokens.cardSurface,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                RevenueComparisonBar(
                    cashFlowTotal = yogaCashTotal,
                    allocatedTotal = rev.totalYogaAllocated,
                    gymAllocated = 0L,
                    yogaAllocated = rev.totalYogaAllocated,
                    cashColor = cashAccent,
                    gymColor = yogaAccent,
                    yogaColor = yogaAccent
                )
            }
        }

        // 2. A. DOANH THU THỰC THU (YOGA)
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = tokens.cardSurface,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(tokens.statusActiveBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.AccountBalanceWallet,
                            contentDescription = null,
                            tint = cashAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "A. DOANH THU THỰC THU – YOGA",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary
                        )
                        Text(
                            text = "Tổng số tiền YOGA thực tế đã nhận trong tháng, tính theo ngày thanh toán.",
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.textSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = tokens.dividerColor)
                Spacer(modifier = Modifier.height(8.dp))

                ClickableRevenueMetricRow(
                    label = "Tổng tiền hội viên YOGA đã thanh toán",
                    subLabel = "Gồm hội viên YOGA đăng ký mới & gia hạn đóng tiền trong tháng",
                    amount = yogaCashTotal,
                    accentColor = cashAccent,
                    onClick = {
                        onOpenDrillDown(
                            RevenueDrillDownSheet.CashFlowList(
                                title = "Chi tiết tiền thực thu hội viên YOGA T${rev.month}/${rev.year}",
                                items = yogaCashDetailsAll
                            )
                        )
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = tokens.statusActiveBg,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            onOpenDrillDown(
                                RevenueDrillDownSheet.CashFlowList(
                                    title = "Toàn bộ giao dịch thực thu YOGA T${rev.month}/${rev.year}",
                                    items = yogaCashDetailsAll
                                )
                            )
                        }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "TỔNG TIỀN THỰC THU TRONG THÁNG (YOGA)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = cashAccent
                            )
                            Text(
                                text = "${yogaCashDetailsAll.size} giao dịch thanh toán • Chạm để truy xuất",
                                style = MaterialTheme.typography.labelSmall,
                                color = cashAccent
                            )
                        }
                        Text(
                            text = DateUtils.formatVnd(yogaCashTotal),
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = cashAccent
                        )
                    }
                }
            }
        }

        // 3. B. DOANH THU PHÂN BỔ – YOGA
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = tokens.cardSurface,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(yogaAccent.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.PieChart,
                            contentDescription = null,
                            tint = yogaAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "B. DOANH THU PHÂN BỔ – YOGA",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary
                        )
                        Text(
                            text = "Giá trị dịch vụ được phân bổ vào tháng báo cáo theo thời gian hiệu lực hợp đồng hoặc dịch vụ đã sử dụng.",
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.textSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = tokens.dividerColor)
                Spacer(modifier = Modifier.height(6.dp))

                ClickableRevenueMetricRow(
                    label = "1. Hội viên YOGA còn hạn & đăng ký mới",
                    subLabel = "${rev.yogaConHanDetails.size} HĐ • Phân bổ theo số ngày hiệu lực của hợp đồng trong tháng",
                    amount = rev.yogaAllocatedConHan,
                    accentColor = yogaAccent,
                    onClick = {
                        onOpenDrillDown(
                            RevenueDrillDownSheet.ContractAllocationList(
                                title = "Chi tiết: Hội viên YOGA còn hạn & đăng ký mới - T${rev.month}/${rev.year}",
                                accent = yogaAccent,
                                items = rev.yogaConHanDetails
                            )
                        )
                    }
                )

                ClickableRevenueMetricRow(
                    label = "2. Hội viên YOGA gia hạn",
                    subLabel = "${rev.yogaGiaHanDetails.size} HĐ • Phân bổ theo số ngày hiệu lực của hợp đồng trong tháng",
                    amount = rev.yogaAllocatedGiaHan,
                    accentColor = yogaAccent,
                    onClick = {
                        onOpenDrillDown(
                            RevenueDrillDownSheet.ContractAllocationList(
                                title = "Chi tiết: Hội viên YOGA gia hạn - T${rev.month}/${rev.year}",
                                accent = yogaAccent,
                                items = rev.yogaGiaHanDetails
                            )
                        )
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = yogaAccent.copy(alpha = if (tokens.isDark) 0.18f else 0.1f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            onOpenDrillDown(
                                RevenueDrillDownSheet.ContractAllocationList(
                                    title = "Tất cả hợp đồng YOGA phân bổ T${rev.month}/${rev.year}",
                                    accent = yogaAccent,
                                    items = rev.yogaConHanDetails + rev.yogaGiaHanDetails
                                )
                            )
                        }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "TỔNG DOANH THU PHÂN BỔ (YOGA)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = yogaAccent
                            )
                            Text(
                                text = "Doanh thu còn hạn/mới + Doanh thu gia hạn",
                                style = MaterialTheme.typography.labelSmall,
                                color = yogaAccent
                            )
                        }
                        Text(
                            text = DateUtils.formatVnd(rev.totalYogaAllocated),
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = yogaAccent
                        )
                    }
                }
            }
        }
    }
}

/**
 * MÀN HÌNH CON 3: XUẤT TÀI LIỆU BÁO CÁO (Đầy đủ 8 báo cáo PDF A4 & Excel: 5 GYM + 3 YOGA).
 */
@Composable
private fun ExportReportsSubScreenContent(
    month: Int,
    year: Int,
    gymAccent: Color,
    yogaAccent: Color,
    exportAccent: Color,
    onSavePdfToDevice: (PdfReportType) -> Unit,
    onSharePdf: (PdfReportType) -> Unit,
    onExportExcelCsv: (PdfReportType) -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = tokens.cardSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(exportAccent.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PictureAsPdf,
                        contentDescription = null,
                        tint = exportAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Hệ thống 8 Báo cáo PDF A4 & Excel (T%02d/%04d)".format(month, year),
                        style = MaterialTheme.typography.titleMedium,
                        color = tokens.textPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Tách riêng hoàn toàn bộ môn GYM (5 báo cáo) và YOGA (3 báo cáo). Hỗ trợ Lưu PDF A4, Chia sẻ PDF và Xuất Excel.",
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.textSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // NHÓM 1: 5 BÁO CÁO BỘ MÔN GYM
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = gymAccent.copy(alpha = if (tokens.isDark) 0.18f else 0.10f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.FitnessCenter,
                        contentDescription = null,
                        tint = gymAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "NHÓM GYM – 5 BÁO CÁO",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = gymAccent
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))

            PdfReportType.gymReports.forEach { reportType ->
                ReportExportCardRow(
                    reportType = reportType,
                    onSavePdfToDevice = { onSavePdfToDevice(reportType) },
                    onSharePdf = { onSharePdf(reportType) },
                    onExportExcelCsv = { onExportExcelCsv(reportType) }
                )
                Spacer(modifier = Modifier.height(10.dp))
            }

            Spacer(modifier = Modifier.height(6.dp))

            // NHÓM 2: 3 BÁO CÁO BỘ MÔN YOGA
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = yogaAccent.copy(alpha = if (tokens.isDark) 0.18f else 0.10f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.SelfImprovement,
                        contentDescription = null,
                        tint = yogaAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "NHÓM YOGA – 3 BÁO CÁO",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = yogaAccent
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))

            PdfReportType.yogaReports.forEach { reportType ->
                ReportExportCardRow(
                    reportType = reportType,
                    onSavePdfToDevice = { onSavePdfToDevice(reportType) },
                    onSharePdf = { onSharePdf(reportType) },
                    onExportExcelCsv = { onExportExcelCsv(reportType) }
                )
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }
}

@Composable
private fun RevenueComparisonBar(
    cashFlowTotal: Long,
    allocatedTotal: Long,
    gymAllocated: Long,
    yogaAllocated: Long,
    cashColor: Color,
    gymColor: Color,
    yogaColor: Color
) {
    val tokens = LocalAppDesignTokens.current
    val maxVal = maxOf(cashFlowTotal, allocatedTotal, 1L).toFloat()
    val cashFraction = (cashFlowTotal.toFloat() / maxVal).coerceIn(0.04f, 1f)
    val allocFraction = (allocatedTotal.toFloat() / maxVal).coerceIn(0.04f, 1f)

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.BarChart,
                contentDescription = null,
                tint = tokens.textSecondary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "So sánh nhanh trong kỳ",
                style = MaterialTheme.typography.labelMedium,
                color = tokens.textSecondary,
                fontWeight = FontWeight.SemiBold
            )
        }

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Thực thu dòng tiền", style = MaterialTheme.typography.labelSmall, color = tokens.textSecondary)
                Text(
                    DateUtils.formatVnd(cashFlowTotal),
                    style = MaterialTheme.typography.labelMedium,
                    color = cashColor,
                    fontWeight = FontWeight.Bold
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(tokens.dividerColor)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(cashFraction)
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(cashColor)
                )
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = buildString {
                        append("Doanh thu phân bổ")
                        if (gymAllocated > 0L && yogaAllocated > 0L) {
                            append(" (GYM + YOGA)")
                        }
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = tokens.textSecondary
                )
                Text(
                    DateUtils.formatVnd(allocatedTotal),
                    style = MaterialTheme.typography.labelMedium,
                    color = if (gymAllocated == 0L && yogaAllocated > 0L) yogaColor else gymColor,
                    fontWeight = FontWeight.Bold
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(tokens.dividerColor)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(allocFraction)
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (gymAllocated == 0L && yogaAllocated > 0L) yogaColor else gymColor)
                )
            }
        }
    }
}

@Composable
private fun ClickableRevenueMetricRow(
    label: String,
    subLabel: String,
    amount: Long,
    accentColor: Color,
    onClick: () -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = tokens.textPrimary,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subLabel,
                style = MaterialTheme.typography.labelSmall,
                color = tokens.textSecondary
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = DateUtils.formatVnd(amount),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = accentColor
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Xem chi tiết",
                tint = tokens.textSecondary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun ReportExportCardRow(
    reportType: PdfReportType,
    onSavePdfToDevice: () -> Unit,
    onSharePdf: () -> Unit,
    onExportExcelCsv: () -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    val isYogaReport = reportType.boMon == BoMon.YOGA
    val solidColor = if (isYogaReport) YogaPrimary else GymPrimary
    val labelAccent = if (isYogaReport) tokens.yogaAccent else tokens.gymAccent

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = tokens.elevatedSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, tokens.borderColor, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = reportType.cardTitleVi,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = labelAccent,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = labelAccent.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)
                ) {
                    Text(
                        text = "Bộ môn: ${reportType.boMon}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = labelAccent,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = reportType.methodologyVi,
                style = MaterialTheme.typography.labelSmall,
                color = tokens.textSecondary
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onSavePdfToDevice,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = solidColor,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                    modifier = Modifier
                        .weight(1.15f)
                        .testTag("btn_pdf_${reportType.code}")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Lưu PDF A4",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                OutlinedButton(
                    onClick = onSharePdf,
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_share_${reportType.code}")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Chia sẻ PDF",
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                OutlinedButton(
                    onClick = onExportExcelCsv,
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                    modifier = Modifier
                        .weight(0.95f)
                        .testTag("btn_excel_${reportType.code}")
                ) {
                    Icon(Icons.Default.TableView, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Xuất Excel",
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun RevenueDrillDownDialog(
    sheet: RevenueDrillDownSheet,
    onDismiss: () -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    val gymAccent = if (tokens.isDark) Color(0xFF5B9BD5) else GymPrimary

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .heightIn(max = 680.dp)
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(20.dp),
            color = tokens.surface
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // STICKY TOP HEADER BAR
                Surface(
                    color = tokens.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = when (sheet) {
                                is RevenueDrillDownSheet.CashFlowList -> sheet.title
                                is RevenueDrillDownSheet.ContractAllocationList -> sheet.title
                                is RevenueDrillDownSheet.PtAllocationList -> sheet.title
                                is RevenueDrillDownSheet.WalkInAllocationList -> sheet.title
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = tokens.textPrimary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = onDismiss) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "Đóng",
                                tint = tokens.textPrimary
                            )
                        }
                    }
                }
                HorizontalDivider(color = tokens.borderColor)

                // SCROLLABLE DRILL-DOWN BODY
                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                ) {
                    when (sheet) {
                        is RevenueDrillDownSheet.CashFlowList -> {
                            if (sheet.items.isEmpty()) {
                                Text(
                                    "Không có giao dịch thu tiền nào trong mục này.",
                                    color = tokens.textSecondary
                                )
                            } else {
                                sheet.items.forEach { item ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                item.title,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = tokens.textPrimary,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                "Ngày thu: ${item.ngayThanhToanDisplay} • Mã GD: ${item.id}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = tokens.textSecondary
                                            )
                                        }
                                        Text(
                                            text = DateUtils.formatVnd(item.amount),
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = tokens.statusActiveText
                                        )
                                    }
                                    HorizontalDivider(color = tokens.dividerColor)
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Tổng cộng (${sheet.items.size} giao dịch): ${DateUtils.formatVnd(sheet.items.sumOf { it.amount })}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.statusActiveText
                                )
                            }
                        }

                        is RevenueDrillDownSheet.ContractAllocationList -> {
                            if (sheet.items.isEmpty()) {
                                Text(
                                    "Không có hợp đồng nào phát sinh doanh thu phân bổ trong mục này.",
                                    color = tokens.textSecondary
                                )
                            } else {
                                sheet.items.forEach { item ->
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "#${item.member?.stt ?: "-"} ${item.member?.hoTen ?: item.contract.hoiVienId} (${item.contract.goiTap})",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = tokens.textPrimary,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                text = DateUtils.formatVnd(item.allocatedAmount),
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = sheet.accent
                                            )
                                        }
                                        Text(
                                            text = "Hiệu lực: ${DateUtils.isoToDisplay(item.contract.ngayBatDau)} → ${item.lastTrainingDateDisplay} • Mã HĐ: ${item.contract.id}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = tokens.textSecondary
                                        )
                                        Text(
                                            text = "Công thức: ${DateUtils.formatVnd(item.contract.soTienHopDong)} × ${item.daysInMonth} ngày / ${item.totalContractDays} ngày = ${DateUtils.formatVnd(item.allocatedAmount)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = sheet.accent
                                        )
                                    }
                                    HorizontalDivider(color = tokens.dividerColor)
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Tổng phân bổ (${sheet.items.size} hợp đồng): ${DateUtils.formatVnd(sheet.items.sumOf { it.allocatedAmount })}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = sheet.accent
                                )
                            }
                        }

                        is RevenueDrillDownSheet.PtAllocationList -> {
                            if (sheet.items.isEmpty()) {
                                Text("Chưa có hợp đồng PT nào.", color = tokens.textSecondary)
                            } else {
                                sheet.items.forEach { pt ->
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "#${pt.contract.stt} ${pt.contract.hoTen} (${pt.contract.goiPt})",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = tokens.textPrimary,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                text = "TT: ${DateUtils.formatVnd(pt.monthlyAllocation.centerAllocatedRevenue)}",
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = gymAccent
                                            )
                                        }
                                        Text(
                                            text = "Giá HĐ: ${DateUtils.formatVnd(pt.contract.soTienHopDong)} / ${pt.contract.tongSoBuoi} buổi • Đã tập T${sheet.month}: ${pt.sessionsUsedInSelectedMonth} buổi (Còn lại: ${pt.remainingSessions} buổi)",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = tokens.textSecondary
                                        )
                                        Text(
                                            text = "Trung tâm (50%): ${DateUtils.formatVnd(pt.monthlyAllocation.centerAllocatedRevenue)} | PT hưởng (50%): ${DateUtils.formatVnd(pt.monthlyAllocation.ptAllocatedShare)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = gymAccent
                                        )
                                    }
                                    HorizontalDivider(color = tokens.dividerColor)
                                }
                            }
                        }

                        is RevenueDrillDownSheet.WalkInAllocationList -> {
                            if (sheet.items.isEmpty()) {
                                Text(
                                    "Không có giao dịch khách lẻ phân bổ trong tháng này.",
                                    color = tokens.textSecondary
                                )
                            } else {
                                sheet.items.forEach { w ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "${w.ticket.tenLoaiVe} (SL: ${w.ticket.soLuong}) • ${w.ticket.id}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = tokens.textPrimary,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                text = "Giá vé: ${DateUtils.formatVnd(w.ticket.soTien)} × ${w.daysInMonth}/${w.totalDays} ngày trong tháng",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = tokens.textSecondary
                                            )
                                        }
                                        Text(
                                            text = DateUtils.formatVnd(w.allocatedAmount),
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = gymAccent
                                        )
                                    }
                                    HorizontalDivider(color = tokens.dividerColor)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
