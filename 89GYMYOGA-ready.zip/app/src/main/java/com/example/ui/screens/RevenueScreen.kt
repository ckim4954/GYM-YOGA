package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.BoMon
import com.example.domain.DateUtils
import com.example.ui.theme.GymPrimary
import com.example.ui.theme.RevenuePrimary
import com.example.ui.theme.StatusActiveGreen
import com.example.ui.theme.YogaPrimary
import com.example.ui.viewmodel.AppUiState
import com.example.ui.viewmodel.CashFlowDetailItem
import com.example.ui.viewmodel.ContractAllocationDetailItem
import com.example.ui.viewmodel.GymYogaViewModel
import com.example.ui.viewmodel.PtContractWithSessionsUi
import com.example.ui.viewmodel.WalkInAllocationDetailItem
import com.example.util.PdfReportType

private sealed class RevenueDrillDownSheet {
    data class CashFlowList(val title: String, val items: List<CashFlowDetailItem>) : RevenueDrillDownSheet()
    data class ContractAllocationList(val title: String, val accent: Color, val items: List<ContractAllocationDetailItem>) : RevenueDrillDownSheet()
    data class PtAllocationList(val title: String, val items: List<PtContractWithSessionsUi>, val month: Int, val year: Int) : RevenueDrillDownSheet()
    data class WalkInAllocationList(val title: String, val items: List<WalkInAllocationDetailItem>) : RevenueDrillDownSheet()
}

@Composable
fun RevenueScreen(
    uiState: AppUiState,
    viewModel: GymYogaViewModel
) {
    val context = LocalContext.current
    val rev = uiState.revenueDashboard
    var activeDrillDown by remember { mutableStateOf<RevenueDrillDownSheet?>(null) }
    var pendingPdfExportType by remember { mutableStateOf<PdfReportType?>(null) }
    var pendingCsvExportType by remember { mutableStateOf<PdfReportType?>(null) }

    // SAF launcher to save PDF A4 directly to device storage
    val savePdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val reportType = pendingPdfExportType
        if (uri != null && reportType != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    viewModel.writePdfReportToStream(reportType, out)
                }
                viewModel.showMessage("Đã xuất báo cáo PDF A4: ${reportType.titleVi}")
            } catch (e: Exception) {
                viewModel.showMessage("Lỗi ghi tệp PDF: ${e.message}")
            }
        }
        pendingPdfExportType = null
    }

    // SAF launcher to save CSV/Excel directly to device storage
    val saveCsvLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        val reportType = pendingCsvExportType
        if (uri != null && reportType != null) {
            try {
                val csv = viewModel.buildCsvForReport(reportType)
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(csv.toByteArray(Charsets.UTF_8))
                }
                viewModel.showMessage("Đã xuất file Excel (CSV): ${reportType.titleVi}")
            } catch (e: Exception) {
                viewModel.showMessage("Lỗi ghi tệp CSV: ${e.message}")
            }
        }
        pendingCsvExportType = null
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Month/Year Picker & Department Filter (Phần 14)
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "KỲ BÁO CÁO DOANH THU",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Tháng %02d / %04d".format(rev.month, rev.year),
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = GymPrimary
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = {
                                    if (rev.month == 1) {
                                        viewModel.setMonthYear(12, rev.year - 1)
                                    } else {
                                        viewModel.setMonthYear(rev.month - 1, rev.year)
                                    }
                                },
                                modifier = Modifier.testTag("prev_month_btn")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Tháng trước")
                            }
                            Text(
                                text = "T${rev.month}/${rev.year}",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(
                                onClick = {
                                    if (rev.month == 12) {
                                        viewModel.setMonthYear(1, rev.year + 1)
                                    } else {
                                        viewModel.setMonthYear(rev.month + 1, rev.year)
                                    }
                                },
                                modifier = Modifier.testTag("next_month_btn")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Tháng sau")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            "CA_HAI" to "Cả hai (Gym & Yoga)",
                            BoMon.GYM to "Chỉ GYM",
                            BoMon.YOGA to "Chỉ YOGA"
                        ).forEach { (code, label) ->
                            val selected = rev.departmentFilter == code
                            val chipColor = when (code) {
                                BoMon.YOGA -> YogaPrimary
                                BoMon.GYM -> GymPrimary
                                else -> RevenuePrimary
                            }
                            FilterChip(
                                selected = selected,
                                onClick = { viewModel.setRevenueDepartmentFilter(code) },
                                label = {
                                    Text(
                                        label,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = chipColor.copy(alpha = 0.15f),
                                    selectedLabelColor = chipColor
                                ),
                                modifier = Modifier.testTag("rev_filter_$code")
                            )
                        }
                    }
                }
            }
        }

        // 2. HỆ THỐNG A: DOANH THU DÒNG TIỀN (Phần 11.1 & 14.A)
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StatusActiveGreen.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(StatusActiveGreen.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = StatusActiveGreen,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "A. DOANH THU DÒNG TIỀN (THỰC THU)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = StatusActiveGreen
                                )
                                Text(
                                    text = "Tính theo ngày thanh toán thực tế trong T${rev.month}/${rev.year} (chạm vào số để xem chi tiết)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                    Spacer(modifier = Modifier.height(8.dp))

                    ClickableRevenueMetricRow(
                        label = "Tổng tiền hội viên đã thanh toán",
                        subLabel = "Gồm hội viên đăng ký/gia hạn & PT thực đóng trong tháng",
                        amount = rev.totalCashFlowMember,
                        accentColor = StatusActiveGreen,
                        onClick = {
                            activeDrillDown = RevenueDrillDownSheet.CashFlowList(
                                title = "Chi tiết dòng tiền hội viên T${rev.month}/${rev.year}",
                                items = rev.cashFlowDetails.filter { it.categoryLabel != "Khách lẻ GYM" }
                            )
                        }
                    )

                    if (rev.departmentFilter != BoMon.YOGA) {
                        ClickableRevenueMetricRow(
                            label = "Tổng tiền khách tập lẻ đã đóng (Gym)",
                            subLabel = "Vé ngày lẻ & tuần lẻ thu trong tháng",
                            amount = rev.totalCashFlowWalkIn,
                            accentColor = StatusActiveGreen,
                            onClick = {
                                activeDrillDown = RevenueDrillDownSheet.CashFlowList(
                                    title = "Chi tiết dòng tiền khách lẻ T${rev.month}/${rev.year}",
                                    items = rev.cashFlowDetails.filter { it.categoryLabel == "Khách lẻ GYM" }
                                )
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = StatusActiveGreen.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                activeDrillDown = RevenueDrillDownSheet.CashFlowList(
                                    title = "Toàn bộ giao dịch dòng tiền T${rev.month}/${rev.year}",
                                    items = rev.cashFlowDetails
                                )
                            }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "TỔNG THỰC THU DÒNG TIỀN",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = StatusActiveGreen
                                )
                                Text(
                                    text = "${rev.cashFlowDetails.size} giao dịch thanh toán • Nhấn để truy xuất",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StatusActiveGreen
                                )
                            }
                            Text(
                                text = DateUtils.formatVnd(rev.totalCashFlowAll),
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = StatusActiveGreen
                            )
                        }
                    }
                }
            }
        }

        // 3. HỆ THỐNG B1: DOANH THU PHÂN BỔ GYM (Phần 11.2, 12, 13.1, 14.B)
        if (rev.departmentFilter == "CA_HAI" || rev.departmentFilter == BoMon.GYM) {
            item {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, GymPrimary.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(GymPrimary.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.PieChart,
                                    contentDescription = null,
                                    tint = GymPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "B1. DOANH THU PHÂN BỔ – GYM",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = GymPrimary
                                )
                                Text(
                                    text = "Ghi nhận theo số ngày dịch vụ thực tế trong T${rev.month}/${rev.year}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                        Spacer(modifier = Modifier.height(6.dp))

                        ClickableRevenueMetricRow(
                            label = "1. Hội viên còn hạn & đăng ký mới (Gym)",
                            subLabel = "${rev.gymConHanDetails.size} hợp đồng phát sinh ngày tập trong tháng",
                            amount = rev.gymAllocatedConHan,
                            accentColor = GymPrimary,
                            onClick = {
                                activeDrillDown = RevenueDrillDownSheet.ContractAllocationList(
                                    title = "Chi tiết: Hội viên còn hạn & mới (GYM) - T${rev.month}/${rev.year}",
                                    accent = GymPrimary,
                                    items = rev.gymConHanDetails
                                )
                            }
                        )

                        ClickableRevenueMetricRow(
                            label = "2. Hội viên gia hạn (Gym)",
                            subLabel = "${rev.gymGiaHanDetails.size} hợp đồng gia hạn/đăng ký lại trong tháng",
                            amount = rev.gymAllocatedGiaHan,
                            accentColor = GymPrimary,
                            onClick = {
                                activeDrillDown = RevenueDrillDownSheet.ContractAllocationList(
                                    title = "Chi tiết: Hội viên gia hạn (GYM) - T${rev.month}/${rev.year}",
                                    accent = GymPrimary,
                                    items = rev.gymGiaHanDetails
                                )
                            }
                        )

                        ClickableRevenueMetricRow(
                            label = "3. Khách tập PT (Phần Trung tâm hưởng 50%)",
                            subLabel = "Phần PT hưởng 50%: ${DateUtils.formatVnd(rev.gymAllocatedPtCoach)} • Tổng PT: ${DateUtils.formatVnd(rev.gymAllocatedPtCenter + rev.gymAllocatedPtCoach)}",
                            amount = rev.gymAllocatedPtCenter,
                            accentColor = GymPrimary,
                            onClick = {
                                activeDrillDown = RevenueDrillDownSheet.PtAllocationList(
                                    title = "Chi tiết doanh thu phân bổ PT - T${rev.month}/${rev.year}",
                                    items = uiState.ptContracts,
                                    month = rev.month,
                                    year = rev.year
                                )
                            }
                        )

                        ClickableRevenueMetricRow(
                            label = "4. Khách tập buổi lẻ / ngày lẻ (Gym)",
                            subLabel = "${rev.dailyWalkInDetails.size} giao dịch vé ngày sử dụng trong tháng",
                            amount = rev.gymAllocatedDailyWalkIn,
                            accentColor = GymPrimary,
                            onClick = {
                                activeDrillDown = RevenueDrillDownSheet.WalkInAllocationList(
                                    title = "Chi tiết: Khách tập buổi lẻ / ngày lẻ - T${rev.month}/${rev.year}",
                                    items = rev.dailyWalkInDetails
                                )
                            }
                        )

                        ClickableRevenueMetricRow(
                            label = "5. Khách tập tuần lẻ (Gym)",
                            subLabel = "${rev.weeklyWalkInDetails.size} giao dịch vé tuần phân bổ theo ngày trong tháng",
                            amount = rev.gymAllocatedWeeklyWalkIn,
                            accentColor = GymPrimary,
                            onClick = {
                                activeDrillDown = RevenueDrillDownSheet.WalkInAllocationList(
                                    title = "Chi tiết: Khách tập tuần lẻ - T${rev.month}/${rev.year}",
                                    items = rev.weeklyWalkInDetails
                                )
                            }
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            color = GymPrimary.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    activeDrillDown = RevenueDrillDownSheet.ContractAllocationList(
                                        title = "Tất cả hợp đồng GYM phân bổ T${rev.month}/${rev.year}",
                                        accent = GymPrimary,
                                        items = rev.gymConHanDetails + rev.gymGiaHanDetails
                                    )
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "TỔNG DOANH THU PHÂN BỔ GYM",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = GymPrimary
                                    )
                                    Text(
                                        text = "Còn hạn + Gia hạn + PT (Trung tâm) + Khách lẻ",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = GymPrimary
                                    )
                                }
                                Text(
                                    text = DateUtils.formatVnd(rev.totalGymAllocated),
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = GymPrimary
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4. HỆ THỐNG B2: DOANH THU PHÂN BỔ YOGA (Phần 13.2, 14.B)
        if (rev.departmentFilter == "CA_HAI" || rev.departmentFilter == BoMon.YOGA) {
            item {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, YogaPrimary.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(YogaPrimary.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.PieChart,
                                    contentDescription = null,
                                    tint = YogaPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "B2. DOANH THU PHÂN BỔ – YOGA",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = YogaPrimary
                                )
                                Text(
                                    text = "Độc lập hoàn toàn với GYM (không cộng PT hoặc khách lẻ)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                        Spacer(modifier = Modifier.height(6.dp))

                        ClickableRevenueMetricRow(
                            label = "1. Hội viên còn hạn & đăng ký mới (Yoga)",
                            subLabel = "${rev.yogaConHanDetails.size} hợp đồng Yoga phát sinh ngày tập trong tháng",
                            amount = rev.yogaAllocatedConHan,
                            accentColor = YogaPrimary,
                            onClick = {
                                activeDrillDown = RevenueDrillDownSheet.ContractAllocationList(
                                    title = "Chi tiết: Hội viên còn hạn & mới (YOGA) - T${rev.month}/${rev.year}",
                                    accent = YogaPrimary,
                                    items = rev.yogaConHanDetails
                                )
                            }
                        )

                        ClickableRevenueMetricRow(
                            label = "2. Hội viên gia hạn (Yoga)",
                            subLabel = "${rev.yogaGiaHanDetails.size} hợp đồng Yoga gia hạn trong tháng",
                            amount = rev.yogaAllocatedGiaHan,
                            accentColor = YogaPrimary,
                            onClick = {
                                activeDrillDown = RevenueDrillDownSheet.ContractAllocationList(
                                    title = "Chi tiết: Hội viên gia hạn (YOGA) - T${rev.month}/${rev.year}",
                                    accent = YogaPrimary,
                                    items = rev.yogaGiaHanDetails
                                )
                            }
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            color = YogaPrimary.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    activeDrillDown = RevenueDrillDownSheet.ContractAllocationList(
                                        title = "Tất cả hợp đồng YOGA phân bổ T${rev.month}/${rev.year}",
                                        accent = YogaPrimary,
                                        items = rev.yogaConHanDetails + rev.yogaGiaHanDetails
                                    )
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "TỔNG DOANH THU PHÂN BỔ YOGA",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = YogaPrimary
                                    )
                                    Text(
                                        text = "Doanh thu còn hạn/mới + Doanh thu gia hạn",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = YogaPrimary
                                    )
                                }
                                Text(
                                    text = DateUtils.formatVnd(rev.totalYogaAllocated),
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = YogaPrimary
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. TRUNG TÂM XUẤT BÁO CÁO PDF A4 & EXCEL (Phần 15)
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = null,
                            tint = GymPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "XUẤT BÁO CÁO PDF A4 & EXCEL (THÁNG ${rev.month}/${rev.year})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Chuẩn khổ A4 đứng, không tràn cột, lặp tiêu đề khi sang trang, đánh số trang & dòng tổng cộng.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    PdfReportType.entries.forEach { reportType ->
                        ReportExportCardRow(
                            reportType = reportType,
                            month = rev.month,
                            year = rev.year,
                            onSavePdfToDevice = {
                                pendingPdfExportType = reportType
                                val defaultName = "BaoCao_${reportType.code}_T${rev.month}_${rev.year}.pdf"
                                savePdfLauncher.launch(defaultName)
                            },
                            onSharePdf = {
                                viewModel.sharePdfReportNow(context, reportType)
                            },
                            onExportExcelCsv = {
                                pendingCsvExportType = reportType
                                val defaultCsvName = "BaoCao_${reportType.code}_T${rev.month}_${rev.year}.csv"
                                saveCsvLauncher.launch(defaultCsvName)
                            }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }
    }

    // Drill-down modal dialog (Phần 14.C)
    if (activeDrillDown != null) {
        RevenueDrillDownDialog(
            sheet = activeDrillDown!!,
            onDismiss = { activeDrillDown = null }
        )
    }
}

@Composable
private fun ClickableRevenueMetricRow(
    label: String,
    subLabel: String,
    amount: Long,
    accentColor: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subLabel,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = DateUtils.formatVnd(amount),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = accentColor
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Xem chi tiết",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun ReportExportCardRow(
    reportType: PdfReportType,
    month: Int,
    year: Int,
    onSavePdfToDevice: () -> Unit,
    onSharePdf: () -> Unit,
    onExportExcelCsv: () -> Unit
) {
    val isYogaReport = reportType == PdfReportType.TONG_HOP_YOGA
    val accent = if (isYogaReport) YogaPrimary else GymPrimary

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = reportType.titleVi,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = accent
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onSavePdfToDevice,
                    colors = ButtonDefaults.buttonColors(containerColor = accent),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).testTag("btn_pdf_${reportType.code}")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Lưu PDF A4", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(
                    onClick = onSharePdf,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Chia sẻ PDF", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(
                    onClick = onExportExcelCsv,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.TableView, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Excel", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun RevenueDrillDownDialog(
    sheet: RevenueDrillDownSheet,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 20.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = when (sheet) {
                            is RevenueDrillDownSheet.CashFlowList -> sheet.title
                            is RevenueDrillDownSheet.ContractAllocationList -> sheet.title
                            is RevenueDrillDownSheet.PtAllocationList -> sheet.title
                            is RevenueDrillDownSheet.WalkInAllocationList -> sheet.title
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Đóng")
                    }
                }
                HorizontalDivider()
                Spacer(modifier = Modifier.height(10.dp))

                when (sheet) {
                    is RevenueDrillDownSheet.CashFlowList -> {
                        if (sheet.items.isEmpty()) {
                            Text("Không có giao dịch thu tiền nào trong mục này.")
                        } else {
                            sheet.items.forEach { item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(item.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                        Text(
                                            "Ngày thu: ${item.ngayThanhToanDisplay} • Mã GD: ${item.id}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = DateUtils.formatVnd(item.amount),
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = StatusActiveGreen
                                    )
                                }
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Tổng cộng (${sheet.items.size} giao dịch): ${DateUtils.formatVnd(sheet.items.sumOf { it.amount })}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = StatusActiveGreen
                            )
                        }
                    }

                    is RevenueDrillDownSheet.ContractAllocationList -> {
                        if (sheet.items.isEmpty()) {
                            Text("Không có hợp đồng nào phát sinh doanh thu phân bổ trong mục này.")
                        } else {
                            sheet.items.forEach { item ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "#${item.member?.stt ?: "-"} ${item.member?.hoTen ?: item.contract.hoiVienId} (${item.contract.goiTap})",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = DateUtils.formatVnd(item.allocatedAmount),
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = sheet.accent
                                        )
                                    }
                                    Text(
                                        text = "Hiệu lực: ${DateUtils.isoToDisplay(item.contract.ngayBatDau)} → ${item.lastTrainingDateDisplay} • Mã HĐ: ${item.contract.id}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "Công thức: ${DateUtils.formatVnd(item.contract.soTienHopDong)} × ${item.daysInMonth} ngày / ${item.totalContractDays} ngày = ${DateUtils.formatVnd(item.allocatedAmount)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = sheet.accent
                                    )
                                }
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Tổng phân bổ (${sheet.items.size} hợp đồng): ${DateUtils.formatVnd(sheet.items.sumOf { it.allocatedAmount })}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = sheet.accent
                            )
                        }
                    }

                    is RevenueDrillDownSheet.PtAllocationList -> {
                        if (sheet.items.isEmpty()) {
                            Text("Chưa có hợp đồng PT nào.")
                        } else {
                            sheet.items.forEach { pt ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "#${pt.contract.stt} ${pt.contract.hoTen} (${pt.contract.goiPt})",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "TT: ${DateUtils.formatVnd(pt.monthlyAllocation.centerAllocatedRevenue)}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = GymPrimary
                                        )
                                    }
                                    Text(
                                        text = "Giá HĐ: ${DateUtils.formatVnd(pt.contract.soTienHopDong)} / ${pt.contract.tongSoBuoi} buổi • Đã tập T${sheet.month}: ${pt.sessionsUsedInSelectedMonth} buổi (Còn lại: ${pt.remainingSessions} buổi)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "Trung tâm (50%): ${DateUtils.formatVnd(pt.monthlyAllocation.centerAllocatedRevenue)} | PT hưởng (50%): ${DateUtils.formatVnd(pt.monthlyAllocation.ptAllocatedShare)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = GymPrimary
                                    )
                                }
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                            }
                        }
                    }

                    is RevenueDrillDownSheet.WalkInAllocationList -> {
                        if (sheet.items.isEmpty()) {
                            Text("Không có giao dịch khách lẻ phân bổ trong tháng này.")
                        } else {
                            sheet.items.forEach { w ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${w.ticket.tenLoaiVe} (SL: ${w.ticket.soLuong}) • ${w.ticket.id}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Giá vé: ${DateUtils.formatVnd(w.ticket.soTien)} × ${w.daysInMonth}/${w.totalDays} ngày trong tháng",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = DateUtils.formatVnd(w.allocatedAmount),
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = GymPrimary
                                    )
                                }
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                            }
                        }
                    }
                }
            }
        }
    }
}
