package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.BoMon
import com.example.domain.MemberTrackingStatus
import com.example.ui.components.DepartmentBadge
import com.example.ui.components.MemberProfileDetailDialog
import com.example.ui.components.MemberRegistrationOrRenewalDialog
import com.example.ui.components.PaginationAndJumpToSttBar
import com.example.ui.components.TrackingStatusBadge
import com.example.ui.components.paginateItems
import com.example.ui.theme.GymPrimary
import com.example.ui.theme.LocalAppDesignTokens
import com.example.ui.theme.YogaPrimary
import com.example.ui.viewmodel.AppUiState
import com.example.ui.viewmodel.GymYogaViewModel
import com.example.ui.viewmodel.MemberWithContractsUi
import kotlinx.coroutines.launch

/**
 * Loại bỏ hoàn toàn nhóm Còn hạn (>15 ngày) khỏi màn hình THEO DÕI (Section 7.2 & 7.3).
 * Chỉ giữ lại 3 nhóm cần hành động: Hôm nay hết hạn, Sắp hết hạn (1–15 ngày) và Đã hết hạn.
 */
fun filterActionableTrackingMembers(
    allMembers: List<MemberWithContractsUi>
): List<MemberWithContractsUi> {
    return allMembers.filter { item ->
        item.trackingStatus != MemberTrackingStatus.ACTIVE_OVER_15 && item.remainingDays <= 15
    }
}

enum class TrackingFilterOption(val label: String) {
    ALL("Tất cả cần theo dõi"),
    GYM("GYM"),
    YOGA("YOGA"),
    HOM_NAY_HET_HAN("Hôm nay hết hạn"),
    SAP_HET_HAN("Sắp hết hạn (1–15 ngày)"),
    DA_HET_HAN("Đã hết hạn")
}

enum class TrackingSortOption(val label: String) {
    EXPIRY_NEAREST("Hết hạn gần nhất ↑"),
    EXPIRY_FARTHEST("Hết hạn xa nhất ↓"),
    STT_ASC("Số thứ tự (STT) ↑"),
    NAME_AZ("Họ và tên (A → Z)")
}

@Composable
fun TrackingScreen(
    uiState: AppUiState,
    viewModel: GymYogaViewModel,
    onOpenPricingSettings: () -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    val scope = rememberCoroutineScope()
    val primaryColor = MaterialTheme.colorScheme.primary

    var selectedFilter by rememberSaveable { mutableStateOf(TrackingFilterOption.ALL) }
    var selectedSort by rememberSaveable { mutableStateOf(TrackingSortOption.EXPIRY_NEAREST) }
    var searchQuery by rememberSaveable { mutableStateOf("") }

    // Pagination states (25 / 50 / 100, default 50)
    var pageSize by rememberSaveable { mutableIntStateOf(50) }
    var currentPage by rememberSaveable { mutableIntStateOf(1) }
    var highlightedMemberId by remember { mutableStateOf<String?>(null) }
    val trackingListState = rememberLazyListState()

    var selectedMemberDetail by remember { mutableStateOf<MemberWithContractsUi?>(null) }
    var memberForRenewal by remember { mutableStateOf<MemberWithContractsUi?>(null) }

    val allMembers = uiState.allTrackingMembers

    // Lọc bỏ hoàn toàn hội viên Còn hạn (>15 ngày) khỏi màn hình THEO DÕI
    val actionableMembers = remember(allMembers) {
        filterActionableTrackingMembers(allMembers)
    }

    // 4 chỉ số thống kê cần hành động (Không bao giờ có Còn hạn > 15 ngày)
    val countToday = remember(actionableMembers) {
        actionableMembers.count { it.trackingStatus == MemberTrackingStatus.EXPIRING_TODAY }
    }
    val count1To7 = remember(actionableMembers) {
        actionableMembers.count { it.trackingStatus == MemberTrackingStatus.EXPIRING_1_TO_7 }
    }
    val count8To15 = remember(actionableMembers) {
        actionableMembers.count { it.trackingStatus == MemberTrackingStatus.EXPIRING_8_TO_15 }
    }
    val countExpired = remember(actionableMembers) {
        actionableMembers.count { it.trackingStatus == MemberTrackingStatus.EXPIRED }
    }

    val filteredAndSorted = remember(actionableMembers, selectedFilter, selectedSort, searchQuery) {
        val q = searchQuery.trim().lowercase()
        val byFilter = actionableMembers.filter { item ->
            val matchFilter = when (selectedFilter) {
                TrackingFilterOption.ALL -> true
                TrackingFilterOption.GYM -> item.member.boMon == BoMon.GYM
                TrackingFilterOption.YOGA -> item.member.boMon == BoMon.YOGA
                TrackingFilterOption.HOM_NAY_HET_HAN ->
                    item.trackingStatus == MemberTrackingStatus.EXPIRING_TODAY
                TrackingFilterOption.SAP_HET_HAN ->
                    item.trackingStatus == MemberTrackingStatus.EXPIRING_1_TO_7 ||
                        item.trackingStatus == MemberTrackingStatus.EXPIRING_8_TO_15
                TrackingFilterOption.DA_HET_HAN ->
                    item.trackingStatus == MemberTrackingStatus.EXPIRED
            }
            val matchSearch = if (q.isEmpty()) true else {
                item.member.stt.toString().contains(q) ||
                    item.member.hoTen.lowercase().contains(q) ||
                    item.member.soDienThoai.lowercase().contains(q)
            }
            matchFilter && matchSearch
        }

        when (selectedSort) {
            TrackingSortOption.EXPIRY_NEAREST -> byFilter.sortedWith(
                compareBy<MemberWithContractsUi> { if (it.remainingDays >= 0) 0 else 1 }
                    .thenBy { if (it.remainingDays >= 0) it.remainingDays else -it.remainingDays }
                    .thenBy { it.member.stt }
            )
            TrackingSortOption.EXPIRY_FARTHEST -> byFilter.sortedByDescending { it.remainingDays }
            TrackingSortOption.STT_ASC -> byFilter.sortedBy { it.member.stt }
            TrackingSortOption.NAME_AZ -> byFilter.sortedBy { it.member.hoTen.lowercase() }
        }
    }

    val paginationSlice = remember(filteredAndSorted, pageSize, currentPage) {
        paginateItems(
            items = filteredAndSorted,
            pageSize = pageSize,
            requestedPage = currentPage
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.background)
    ) {
        // ================= STICKY TOP SECTION =================
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.background)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // 1. Overview Card với lưới 2x2 cân đối (Không bao giờ bị cắt mất thẻ bên phải)
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = tokens.cardSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, tokens.borderColor, RoundedCornerShape(14.dp))
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(primaryColor.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Visibility,
                                contentDescription = null,
                                tint = primaryColor,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Theo dõi hết hạn & sắp hết hạn (${actionableMembers.size} HV)",
                                style = MaterialTheme.typography.titleSmall,
                                color = tokens.textPrimary,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Tập trung hội viên hết hạn hôm nay, sắp hết hạn (1–15 ngày) và đã hết hạn",
                                style = MaterialTheme.typography.labelSmall,
                                color = tokens.textSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // 2x2 Responsive Grid cho 4 thẻ trạng thái (Section 7.4)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            StatusCounterCard(
                                label = "Hôm nay hết hạn",
                                count = countToday,
                                icon = Icons.Default.NotificationsActive,
                                bgColor = tokens.statusTodayBg,
                                textColor = tokens.statusTodayText,
                                isSelected = selectedFilter == TrackingFilterOption.HOM_NAY_HET_HAN,
                                onClick = {
                                    selectedFilter = TrackingFilterOption.HOM_NAY_HET_HAN
                                    currentPage = 1
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("tracking_card_today")
                            )
                            StatusCounterCard(
                                label = "Sắp hết (1–7 ngày)",
                                count = count1To7,
                                icon = Icons.Default.WarningAmber,
                                bgColor = tokens.statusUrgentBg,
                                textColor = tokens.statusUrgentText,
                                isSelected = selectedFilter == TrackingFilterOption.SAP_HET_HAN,
                                onClick = {
                                    selectedFilter = TrackingFilterOption.SAP_HET_HAN
                                    currentPage = 1
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("tracking_card_1_to_7")
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            StatusCounterCard(
                                label = "Sắp hết (8–15 ngày)",
                                count = count8To15,
                                icon = Icons.Default.Schedule,
                                bgColor = tokens.statusWarningBg,
                                textColor = tokens.statusWarningText,
                                isSelected = selectedFilter == TrackingFilterOption.SAP_HET_HAN,
                                onClick = {
                                    selectedFilter = TrackingFilterOption.SAP_HET_HAN
                                    currentPage = 1
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("tracking_card_8_to_15")
                            )
                            StatusCounterCard(
                                label = "Đã hết hạn",
                                count = countExpired,
                                icon = Icons.Default.EventBusy,
                                bgColor = tokens.statusExpiredBg,
                                textColor = tokens.statusExpiredText,
                                isSelected = selectedFilter == TrackingFilterOption.DA_HET_HAN,
                                onClick = {
                                    selectedFilter = TrackingFilterOption.DA_HET_HAN
                                    currentPage = 1
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("tracking_card_expired")
                            )
                        }
                    }
                }
            }

            // 2. Search input (Placeholder chuẩn Section 7.5: "Tìm STT, họ tên hoặc SĐT")
            OutlinedTextField(
                value = searchQuery,
                onValueChange = {
                    searchQuery = it
                    currentPage = 1
                    highlightedMemberId = null
                },
                placeholder = {
                    Text(
                        "Tìm STT, họ tên hoặc SĐT",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = primaryColor) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = {
                                searchQuery = ""
                                currentPage = 1
                                highlightedMemberId = null
                            }
                        ) {
                            Icon(Icons.Default.Clear, contentDescription = "Xóa")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = primaryColor,
                    unfocusedBorderColor = tokens.borderColor,
                    unfocusedContainerColor = tokens.cardSurface,
                    focusedContainerColor = tokens.cardSurface
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tracking_search_input")
            )

            // 3. Filter & Sort rows (Section 7.6)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TrackingFilterOption.entries.forEach { opt ->
                    val selected = selectedFilter == opt
                    FilterChip(
                        selected = selected,
                        onClick = {
                            selectedFilter = opt
                            currentPage = 1
                            highlightedMemberId = null
                        },
                        label = {
                            Text(
                                opt.label,
                                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                                maxLines = 1,
                                softWrap = false
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = primaryColor.copy(alpha = if (tokens.isDark) 0.22f else 0.14f),
                            selectedLabelColor = primaryColor
                        ),
                        modifier = Modifier.testTag("tracking_filter_${opt.name}")
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Sort,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = tokens.textSecondary
                )
                Text(
                    text = "Sắp xếp:",
                    style = MaterialTheme.typography.labelSmall,
                    color = tokens.textSecondary
                )
                TrackingSortOption.entries.forEach { sortOpt ->
                    val isSelected = selectedSort == sortOpt
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            selectedSort = sortOpt
                            currentPage = 1
                            highlightedMemberId = null
                        },
                        label = {
                            Text(
                                sortOpt.label,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    )
                }
            }

            // 4. Pagination & Jump to STT Bar (Section 7.8)
            PaginationAndJumpToSttBar(
                totalItems = paginationSlice.totalItems,
                startIndexOneBased = paginationSlice.startIndexOneBased,
                endIndexOneBased = paginationSlice.endIndexOneBased,
                currentPage = paginationSlice.currentPage,
                totalPages = paginationSlice.totalPages,
                pageSize = pageSize,
                onPageSizeChange = { newSize ->
                    pageSize = newSize
                    currentPage = 1
                    highlightedMemberId = null
                    scope.launch { trackingListState.scrollToItem(0) }
                },
                onPageChange = { targetPage ->
                    currentPage = targetPage
                    highlightedMemberId = null
                    scope.launch { trackingListState.scrollToItem(0) }
                },
                allFilteredMembers = filteredAndSorted,
                onJumpToMatch = { match ->
                    currentPage = match.targetPage
                    highlightedMemberId = match.memberId
                    scope.launch {
                        trackingListState.animateScrollToItem(match.indexWithinPage)
                    }
                    viewModel.showMessage("Đã chuyển tới STT #${match.stt} – ${match.hoTen} (Trang ${match.targetPage})")
                },
                accentColor = primaryColor,
                testTagPrefix = "pagination_tracking"
            )
        }

        HorizontalDivider(color = tokens.borderColor)

        // ================= SCROLLABLE TRACKING LIST =================
        LazyColumn(
            state = trackingListState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (paginationSlice.pageItems.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = tokens.cardSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Không có hội viên sắp hết hạn hoặc đã hết hạn trong mục lọc này",
                                style = MaterialTheme.typography.titleMedium,
                                color = tokens.textPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Các hội viên còn hạn trên 15 ngày được quản lý tại tab GYM và YOGA.",
                                style = MaterialTheme.typography.bodySmall,
                                color = tokens.textSecondary
                            )
                        }
                    }
                }
            } else {
                items(paginationSlice.pageItems, key = { it.member.id }) { item ->
                    TrackingMemberItemCard(
                        item = item,
                        isHighlighted = highlightedMemberId == item.member.id,
                        onClick = { selectedMemberDetail = item },
                        onQuickRenew = { memberForRenewal = item }
                    )
                }
            }
        }
    }

    if (selectedMemberDetail != null) {
        val current = allMembers.firstOrNull { it.member.id == selectedMemberDetail!!.member.id }
        if (current != null) {
            MemberProfileDetailDialog(
                memberUi = current,
                onDismiss = { selectedMemberDetail = null },
                onRequestRenew = {
                    selectedMemberDetail = null
                    memberForRenewal = current
                },
                onUpdateMemberInfo = { stt, name, phone, loai, note ->
                    viewModel.updateMemberProfile(current.member, stt, name, phone, loai, note)
                },
                onUpdateContract = { contract, goiTap, loaiBc, startIso, endExIso, price, paid, payIso, note ->
                    viewModel.updateContract(contract, goiTap, loaiBc, startIso, endExIso, price, paid, payIso, note)
                },
                onCollectDebt = { contract, amt, payIso, note ->
                    viewModel.collectDebtPayment(contract, amt, payIso, note)
                },
                onDeleteMember = {
                    viewModel.deleteMemberToTrash(current.member)
                    selectedMemberDetail = null
                }
            )
        } else {
            selectedMemberDetail = null
        }
    }

    if (memberForRenewal != null) {
        val target = allMembers.firstOrNull { it.member.id == memberForRenewal!!.member.id } ?: memberForRenewal!!
        val isYoga = target.member.boMon == BoMon.YOGA
        MemberRegistrationOrRenewalDialog(
            boMon = target.member.boMon,
            isRenewal = true,
            existingMember = target,
            allDepartmentMembers = if (isYoga) uiState.yogaMembers else uiState.gymMembers,
            maxStt = if (isYoga) uiState.maxSttYoga else uiState.maxSttGym,
            suggestedStt = if (isYoga) uiState.nextSttYoga else uiState.nextSttGym,
            availablePackages = uiState.packages,
            onDismiss = { memberForRenewal = null },
            onOpenPricingSettings = {
                memberForRenewal = null
                onOpenPricingSettings()
            },
            onConfirmNewMember = { _, _, _, _, _, _, _, _, _, _, _, _, _, _ -> },
            onConfirmRenewal = { loaiHd, loaiBc, goiId, tenGoi, regIso, startIso, endExIso, price, paid, payIso, noteC ->
                viewModel.renewMember(
                    member = target.member,
                    loaiHopDong = loaiHd,
                    loaiBaoCao = loaiBc,
                    goiTapId = goiId,
                    tenGoiTap = tenGoi,
                    ngayDangKyIso = regIso,
                    ngayBatDauIso = startIso,
                    ngayKetThucDocQuyenIso = endExIso,
                    soTienHopDong = price,
                    soTienDaThu = paid,
                    ngayThanhToanIso = payIso,
                    ghiChuHopDong = noteC
                )
            }
        )
    }
}

@Composable
private fun StatusCounterCard(
    label: String,
    count: Int,
    icon: ImageVector,
    bgColor: Color,
    textColor: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = bgColor,
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .border(
                width = if (isSelected) 1.5.dp else 0.dp,
                color = if (isSelected) textColor else Color.Transparent,
                shape = RoundedCornerShape(10.dp)
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = textColor,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = textColor,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = textColor,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}

/**
 * Thẻ hội viên trên màn hình THEO DÕI (Section 7.7):
 * Hiển thị đầy đủ: STT, Bộ môn (GYM/YOGA), Họ tên đầy đủ (1 dòng không cắt ...), SĐT,
 * Trạng thái hạn, Gói tập, Ngày hết hạn và Nút Gia hạn.
 */
@Composable
private fun TrackingMemberItemCard(
    item: MemberWithContractsUi,
    isHighlighted: Boolean = false,
    onClick: () -> Unit,
    onQuickRenew: () -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    val isYoga = item.member.boMon == BoMon.YOGA
    val deptColor = if (isYoga) {
        if (tokens.isDark) Color(0xFFD3B8E2) else YogaPrimary
    } else {
        if (tokens.isDark) Color(0xFF8CC0EE) else GymPrimary
    }

    val borderColor = if (isHighlighted) deptColor else tokens.borderColor
    val borderWidth = if (isHighlighted) 2.dp else 1.dp

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = tokens.cardSurface,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .border(borderWidth, borderColor, RoundedCornerShape(14.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(deptColor.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "#${item.member.stt}",
                            style = MaterialTheme.typography.labelLarge,
                            color = deptColor,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            DepartmentBadge(boMon = item.member.boMon)
                            Spacer(modifier = Modifier.width(6.dp))
                            // Họ tên đầy đủ trên 1 dòng, không cắt ..., cuộn ngang khi tên quá dài
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .horizontalScroll(rememberScrollState())
                                    .clickable(onClick = onClick)
                            ) {
                                Text(
                                    text = item.member.hoTen,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = tokens.textPrimary,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                        Text(
                            text = "SĐT: ${item.member.soDienThoai.ifBlank { "Chưa có SĐT" }} • ${item.trackingStatus.labelVi}",
                            style = MaterialTheme.typography.bodySmall,
                            color = tokens.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))
                TrackingStatusBadge(
                    status = item.trackingStatus,
                    remainingDays = item.remainingDays
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = tokens.dividerColor)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Gói: ${item.latestContract?.goiTap ?: "-"}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = deptColor
                    )
                    Text(
                        text = "Hết hạn tập: ${item.lastTrainingDateDisplay}",
                        style = MaterialTheme.typography.titleSmall,
                        color = tokens.textPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = onQuickRenew,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("tracking_renew_${item.member.stt}")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Gia hạn", style = MaterialTheme.typography.labelMedium, maxLines = 1, softWrap = false)
                }
            }
        }
    }
}
