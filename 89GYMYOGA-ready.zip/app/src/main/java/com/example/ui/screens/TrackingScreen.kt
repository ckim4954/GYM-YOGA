package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.BoMon
import com.example.domain.MemberTrackingStatus
import com.example.ui.components.DepartmentBadge
import com.example.ui.components.MemberProfileDetailDialog
import com.example.ui.components.MemberRegistrationOrRenewalDialog
import com.example.ui.components.TrackingStatusBadge
import com.example.ui.theme.GymPrimary
import com.example.ui.theme.StatusActiveGreen
import com.example.ui.theme.StatusExpiredRed
import com.example.ui.theme.StatusExpiring15Amber
import com.example.ui.theme.StatusExpiring7Orange
import com.example.ui.theme.StatusExpiringTodayOrange
import com.example.ui.theme.YogaPrimary
import com.example.ui.viewmodel.AppUiState
import com.example.ui.viewmodel.GymYogaViewModel
import com.example.ui.viewmodel.MemberWithContractsUi

enum class TrackingFilterOption(val label: String) {
    DEFAULT_ACTIVE("Mặc định (Đang còn hạn)"),
    ALL("Tất cả"),
    GYM("GYM"),
    YOGA("YOGA"),
    CON_HAN("Còn hạn (>15 ngày)"),
    SAP_HET_HAN("Sắp hết hạn (1–15 ngày)"),
    HOM_NAY_HET_HAN("Hôm nay hết hạn"),
    DA_HET_HAN("Đã hết hạn")
}

enum class TrackingSortOption(val label: String) {
    EXPIRY_NEAREST("Hết hạn gần nhất ↑"),
    EXPIRY_FARTHEST("Hết hạn xa nhất ↓"),
    STT_ASC("Số thứ tự (STT) ↑"),
    NAME_AZ("Họ và tên (A → Z)")
}

@Composable
fun TrackingScreen(
    uiState: AppUiState,
    viewModel: GymYogaViewModel,
    onOpenPricingSettings: () -> Unit
) {
    var selectedFilter by remember { mutableStateOf(TrackingFilterOption.DEFAULT_ACTIVE) }
    var selectedSort by remember { mutableStateOf(TrackingSortOption.EXPIRY_NEAREST) }
    var searchQuery by remember { mutableStateOf("") }

    var selectedMemberDetail by remember { mutableStateOf<MemberWithContractsUi?>(null) }
    var memberForRenewal by remember { mutableStateOf<MemberWithContractsUi?>(null) }

    val allMembers = uiState.allTrackingMembers

    // Counts for the 5 status categories (Phần 8.2)
    val countOver15 = remember(allMembers) { allMembers.count { it.trackingStatus == MemberTrackingStatus.ACTIVE_OVER_15 } }
    val count8To15 = remember(allMembers) { allMembers.count { it.trackingStatus == MemberTrackingStatus.EXPIRING_8_TO_15 } }
    val count1To7 = remember(allMembers) { allMembers.count { it.trackingStatus == MemberTrackingStatus.EXPIRING_1_TO_7 } }
    val countToday = remember(allMembers) { allMembers.count { it.trackingStatus == MemberTrackingStatus.EXPIRING_TODAY } }
    val countExpired = remember(allMembers) { allMembers.count { it.trackingStatus == MemberTrackingStatus.EXPIRED } }

    val filteredAndSorted = remember(allMembers, selectedFilter, selectedSort, searchQuery) {
        val q = searchQuery.trim().lowercase()
        val byFilter = allMembers.filter { item ->
            val matchFilter = when (selectedFilter) {
                TrackingFilterOption.DEFAULT_ACTIVE -> item.remainingDays >= 0
                TrackingFilterOption.ALL -> true
                TrackingFilterOption.GYM -> item.member.boMon == BoMon.GYM
                TrackingFilterOption.YOGA -> item.member.boMon == BoMon.YOGA
                TrackingFilterOption.CON_HAN -> item.remainingDays >= 0
                TrackingFilterOption.SAP_HET_HAN ->
                    item.trackingStatus == MemberTrackingStatus.EXPIRING_1_TO_7 ||
                        item.trackingStatus == MemberTrackingStatus.EXPIRING_8_TO_15
                TrackingFilterOption.HOM_NAY_HET_HAN ->
                    item.trackingStatus == MemberTrackingStatus.EXPIRING_TODAY
                TrackingFilterOption.DA_HET_HAN ->
                    item.trackingStatus == MemberTrackingStatus.EXPIRED
            }
            val matchSearch = if (q.isEmpty()) true else {
                item.member.stt.toString().contains(q) ||
                    item.member.hoTen.lowercase().contains(q) ||
                    item.member.soDienThoai.lowercase().contains(q)
            }
            matchFilter && matchSearch
        }

        when (selectedSort) {
            TrackingSortOption.EXPIRY_NEAREST -> byFilter.sortedWith(
                compareBy<MemberWithContractsUi> { if (it.remainingDays >= 0) 0 else 1 }
                    .thenBy { if (it.remainingDays >= 0) it.remainingDays else -it.remainingDays }
                    .thenBy { it.member.stt }
            )
            TrackingSortOption.EXPIRY_FARTHEST -> byFilter.sortedByDescending { it.remainingDays }
            TrackingSortOption.STT_ASC -> byFilter.sortedBy { it.member.stt }
            TrackingSortOption.NAME_AZ -> byFilter.sortedBy { it.member.hoTen.lowercase() }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 88.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header card explaining visual monitoring
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Visibility,
                            contentDescription = null,
                            tint = GymPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "THEO DÕI THỜI HẠN HỘI VIÊN",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Ưu tiên người sắp hết hạn nhất ở trên để chủ phòng tập quan sát nhanh bằng mắt.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // 5 Status summary pills (Phần 8.2)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatusCounterCard(
                            label = "Hôm nay hết hạn",
                            count = countToday,
                            color = StatusExpiringTodayOrange,
                            onClick = { selectedFilter = TrackingFilterOption.HOM_NAY_HET_HAN }
                        )
                        StatusCounterCard(
                            label = "Sắp hết (1–7 ngày)",
                            count = count1To7,
                            color = StatusExpiring7Orange,
                            onClick = { selectedFilter = TrackingFilterOption.SAP_HET_HAN }
                        )
                        StatusCounterCard(
                            label = "Sắp hết (8–15 ngày)",
                            count = count8To15,
                            color = StatusExpiring15Amber,
                            onClick = { selectedFilter = TrackingFilterOption.SAP_HET_HAN }
                        )
                        StatusCounterCard(
                            label = "Còn hạn (>15 ngày)",
                            count = countOver15,
                            color = StatusActiveGreen,
                            onClick = { selectedFilter = TrackingFilterOption.CON_HAN }
                        )
                        StatusCounterCard(
                            label = "Đã hết hạn",
                            count = countExpired,
                            color = StatusExpiredRed,
                            onClick = { selectedFilter = TrackingFilterOption.DA_HET_HAN }
                        )
                    }
                }
            }
        }

        // Search input (Tên, STT, SĐT)
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Tìm theo STT, Họ tên hoặc Số điện thoại...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Xóa")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedContainerColor = MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tracking_search_input")
            )
        }

        // Filter chips (Phần 8.4)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TrackingFilterOption.entries.forEach { opt ->
                        val selected = selectedFilter == opt
                        FilterChip(
                            selected = selected,
                            onClick = { selectedFilter = opt },
                            label = {
                                Text(
                                    opt.label,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = GymPrimary.copy(alpha = 0.15f),
                                selectedLabelColor = GymPrimary
                            ),
                            modifier = Modifier.testTag("tracking_filter_${opt.name}")
                        )
                    }
                }

                // Sort selector row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Sort,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Sắp xếp:",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TrackingSortOption.entries.forEach { sortOpt ->
                        val isSelected = selectedSort == sortOpt
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedSort = sortOpt },
                            label = { Text(sortOpt.label, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }
        }

        if (filteredAndSorted.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Không có hội viên trong mục lọc này",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Chuyển sang bộ lọc 'Tất cả' hoặc 'Đã hết hạn' để kiểm tra toàn bộ danh sách.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(filteredAndSorted, key = { it.member.id }) { item ->
                TrackingMemberItemCard(
                    item = item,
                    onClick = { selectedMemberDetail = item },
                    onQuickRenew = { memberForRenewal = item }
                )
            }
        }
    }

    if (selectedMemberDetail != null) {
        val current = allMembers.firstOrNull { it.member.id == selectedMemberDetail!!.member.id }
        if (current != null) {
            MemberProfileDetailDialog(
                memberUi = current,
                onDismiss = { selectedMemberDetail = null },
                onRequestRenew = {
                    selectedMemberDetail = null
                    memberForRenewal = current
                },
                onUpdateMemberInfo = { stt, name, phone, loai, note ->
                    viewModel.updateMemberProfile(current.member, stt, name, phone, loai, note)
                },
                onUpdateContract = { contract, goiTap, loaiBc, startIso, endExIso, price, paid, payIso, note ->
                    viewModel.updateContract(contract, goiTap, loaiBc, startIso, endExIso, price, paid, payIso, note)
                },
                onCollectDebt = { contract, amt, payIso, note ->
                    viewModel.collectDebtPayment(contract, amt, payIso, note)
                },
                onDeleteMember = {
                    viewModel.deleteMemberToTrash(current.member)
                    selectedMemberDetail = null
                }
            )
        } else {
            selectedMemberDetail = null
        }
    }

    if (memberForRenewal != null) {
        val target = allMembers.firstOrNull { it.member.id == memberForRenewal!!.member.id } ?: memberForRenewal!!
        val isYoga = target.member.boMon == BoMon.YOGA
        MemberRegistrationOrRenewalDialog(
            boMon = target.member.boMon,
            isRenewal = true,
            existingMember = target,
            allDepartmentMembers = if (isYoga) uiState.yogaMembers else uiState.gymMembers,
            maxStt = if (isYoga) uiState.maxSttYoga else uiState.maxSttGym,
            suggestedStt = if (isYoga) uiState.nextSttYoga else uiState.nextSttGym,
            availablePackages = uiState.packages,
            onDismiss = { memberForRenewal = null },
            onOpenPricingSettings = {
                memberForRenewal = null
                onOpenPricingSettings()
            },
            onConfirmNewMember = { _, _, _, _, _, _, _, _, _, _, _, _, _, _ -> },
            onConfirmRenewal = { loaiHd, loaiBc, goiId, tenGoi, regIso, startIso, endExIso, price, paid, payIso, noteC ->
                viewModel.renewMember(
                    member = target.member,
                    loaiHopDong = loaiHd,
                    loaiBaoCao = loaiBc,
                    goiTapId = goiId,
                    tenGoiTap = tenGoi,
                    ngayDangKyIso = regIso,
                    ngayBatDauIso = startIso,
                    ngayKetThucDocQuyenIso = endExIso,
                    soTienHopDong = price,
                    soTienDaThu = paid,
                    ngayThanhToanIso = payIso,
                    ghiChuHopDong = noteC
                )
            }
        )
    }
}

@Composable
private fun StatusCounterCard(
    label: String,
    count: Int,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = color.copy(alpha = 0.1f),
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = color
            )
        }
    }
}

/**
 * Hiển thị đúng 7 thông tin theo Phần 8.3:
 * STT | Họ tên | Số điện thoại | Gói tập | Ngày hết hạn | Số ngày còn lại | Trạng thái
 */
@Composable
private fun TrackingMemberItemCard(
    item: MemberWithContractsUi,
    onClick: () -> Unit,
    onQuickRenew: () -> Unit
) {
    val isYoga = item.member.boMon == BoMon.YOGA
    val deptColor = if (isYoga) YogaPrimary else GymPrimary

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f), RoundedCornerShape(14.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(deptColor.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "#${item.member.stt}",
                            style = MaterialTheme.typography.labelLarge,
                            color = deptColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            DepartmentBadge(boMon = item.member.boMon)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = item.member.hoTen,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(
                            text = "SĐT: ${item.member.soDienThoai.ifBlank { "Chưa có SĐT" }} • ${item.trackingStatus.labelVi}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                TrackingStatusBadge(
                    status = item.trackingStatus,
                    remainingDays = item.remainingDays
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Gói: ${item.latestContract?.goiTap ?: "-"}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = deptColor
                    )
                    Text(
                        text = "Hết hạn tập cuối: ${item.lastTrainingDateDisplay}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                }

                OutlinedButton(
                    onClick = onQuickRenew,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Gia hạn", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}
