package com.example.ui.screens

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PriceChange
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SettingsBrightness
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.data.local.BoMon
import com.example.data.local.DoiTuong
import com.example.data.local.PricingPackageEntity
import com.example.domain.DateUtils
import com.example.domain.GoldenTestCaseResult
import com.example.domain.LocalDateSpec
import com.example.ui.theme.GymPrimary
import com.example.ui.theme.LocalAppDesignTokens
import com.example.ui.theme.ThemeModePreference
import com.example.ui.theme.YogaPrimary
import com.example.ui.viewmodel.AppUiState
import com.example.ui.viewmodel.GymYogaViewModel
import com.example.util.DriveBackupFileItem
import com.example.util.GoogleDriveBackupManager
import com.example.util.ReportExporter
import java.util.UUID
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsAndSystemScreen(
    uiState: AppUiState,
    viewModel: GymYogaViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val tokens = LocalAppDesignTokens.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val primaryColor = MaterialTheme.colorScheme.primary
    val gymAccent = tokens.gymAccent
    val yogaAccent = tokens.yogaAccent

    // -1 = Tất cả nhóm chức năng (cuộn dọc liền mạch), 0 = Bảng giá, 1 = Giao diện & Sao lưu, 2 = Thùng rác, 3 = Kiểm thử
    var activeSection by remember { mutableIntStateOf(-1) }
    var packageToEdit by remember { mutableStateOf<PricingPackageEntity?>(null) }
    var showAddPackageDialog by remember { mutableStateOf(false) }

    var pendingRestoreJson by remember { mutableStateOf<String?>(null) }
    var pendingRestoreSummary by remember { mutableStateOf<String?>(null) }
    var pendingRestoreIsFromDrive by remember { mutableStateOf(false) }

    val googleAuthIntentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            scope.launch {
                val res = GoogleDriveBackupManager.handleAuthorizationIntentResult(context, result.data)
                res.fold(
                    onSuccess = { profile -> viewModel.onGoogleAuthorized(profile) },
                    onFailure = { err ->
                        viewModel.onGoogleAuthError(err.message ?: "Không thể hoàn tất cấp quyền Google Drive.")
                    }
                )
            }
        } else {
            viewModel.onGoogleAuthError("Đã hủy đăng nhập Google Drive.")
        }
    }

    val startGoogleSignIn: () -> Unit = {
        scope.launch {
            val authRes = GoogleDriveBackupManager.authorize(context)
            authRes.fold(
                onSuccess = { outcome ->
                    if (outcome.pendingIntent != null) {
                        val req = IntentSenderRequest.Builder(outcome.pendingIntent.intentSender).build()
                        googleAuthIntentLauncher.launch(req)
                    } else if (outcome.profile != null) {
                        viewModel.onGoogleAuthorized(outcome.profile)
                    }
                },
                onFailure = { err ->
                    viewModel.onGoogleAuthError(
                        err.message ?: "Không thể khởi tạo đăng nhập Google Drive trên thiết bị này."
                    )
                }
            )
        }
    }

    val exportBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val json = viewModel.exportBackupJson()
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(json.toByteArray(Charsets.UTF_8))
                    }
                    viewModel.showMessage("Đã sao lưu toàn bộ dữ liệu ra file JSON thành công!")
                } catch (e: Exception) {
                    viewModel.showMessage("Lỗi sao lưu: ${e.message}")
                }
            }
        }
    }

    val importBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val jsonText = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.readText() ?: ""
                val validation = viewModel.validateBackupJson(jsonText)
                if (validation.isSuccess) {
                    pendingRestoreIsFromDrive = false
                    pendingRestoreJson = jsonText
                    pendingRestoreSummary = validation.getOrNull()
                } else {
                    viewModel.showMessage(validation.exceptionOrNull()?.message ?: "File sao lưu không hợp lệ")
                }
            } catch (e: Exception) {
                viewModel.showMessage("Không thể đọc file: ${e.message}")
            }
        }
    }

    val showPricing = activeSection == -1 || activeSection == 0
    val showThemeAndBackup = activeSection == -1 || activeSection == 1
    val showTrash = activeSection == -1 || activeSection == 2
    val showDiagnostics = (activeSection == -1 || activeSection == 3) && BuildConfig.DEBUG

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.background)
    ) {
        // STICKY TOP HEADER BAR (Responsive — Không bao giờ bóp tiêu đề "Cài đặt")
        Surface(
            color = tokens.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("settings_back_btn")
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Quay lại",
                                tint = tokens.textPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Cài đặt hệ thống",
                                style = MaterialTheme.typography.titleLarge,
                                color = tokens.textPrimary,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "89 FITNESS & YOGA · Quản trị & Sao lưu",
                                style = MaterialTheme.typography.labelSmall,
                                color = tokens.textSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Compact quick theme pill that never squeezes the header title
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = tokens.elevatedSurface,
                        modifier = Modifier
                            .border(1.dp, tokens.borderColor, RoundedCornerShape(10.dp))
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                val nextMode = when (uiState.themeMode) {
                                    ThemeModePreference.LIGHT -> ThemeModePreference.DARK
                                    ThemeModePreference.DARK -> ThemeModePreference.SYSTEM
                                    ThemeModePreference.SYSTEM -> ThemeModePreference.LIGHT
                                }
                                viewModel.setThemeMode(nextMode)
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = when (uiState.themeMode) {
                                    ThemeModePreference.LIGHT -> Icons.Default.LightMode
                                    ThemeModePreference.DARK -> Icons.Default.DarkMode
                                    ThemeModePreference.SYSTEM -> Icons.Default.SettingsBrightness
                                },
                                contentDescription = "Chế độ giao diện",
                                tint = primaryColor,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = uiState.themeMode.shortLabelVi,
                                style = MaterialTheme.typography.labelMedium,
                                color = tokens.textPrimary,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Quick section filter chips (Default: "Tất cả" shows all vertical sections smoothly)
                val trashCount = uiState.deletedMembers.size + uiState.deletedPtContracts.size + uiState.deletedWalkInTickets.size
                val sectionFilters = buildList {
                    add(Triple(-1, "Tất cả mục", Icons.Default.Settings))
                    add(Triple(0, "Bảng giá & Gói tập", Icons.Default.PriceChange))
                    add(Triple(1, "Giao diện & Sao lưu", Icons.Default.CloudSync))
                    add(Triple(2, "Thùng rác ($trashCount)", Icons.Default.RestoreFromTrash))
                    if (BuildConfig.DEBUG) {
                        add(Triple(3, "Kiểm thử", Icons.Default.Science))
                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    sectionFilters.forEach { (idx, label, icon) ->
                        val selected = activeSection == idx
                        FilterChip(
                            selected = selected,
                            onClick = { activeSection = idx },
                            label = {
                                Text(
                                    label,
                                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                                    maxLines = 1
                                )
                            },
                            leadingIcon = {
                                Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = primaryColor.copy(alpha = if (tokens.isDark) 0.24f else 0.14f),
                                selectedLabelColor = primaryColor,
                                selectedLeadingIconColor = primaryColor
                            ),
                            modifier = if (idx >= 0) Modifier.testTag("settings_tab_$idx") else Modifier.testTag("settings_tab_all")
                        )
                    }
                }
            }
        }
        HorizontalDivider(color = tokens.borderColor)

        // VERTICAL SCROLLABLE FUNCTIONAL GROUPS
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // NHÓM 1: GIAO DIỆN HIỂN THỊ (LIGHT MODE / DARK MODE / THEO HỆ THỐNG ANDROID)
            if (showThemeAndBackup) {
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = tokens.cardSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(primaryColor.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Palette,
                                        contentDescription = null,
                                        tint = primaryColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Giao diện hiển thị (Cyber Fitness Theme)",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = tokens.textPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Chuyển đổi tức thì giữa Light Mode, Dark Mode và Theo hệ thống. Báo cáo PDF A4 & Excel luôn giữ nền sáng chuẩn in ấn.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = tokens.textSecondary
                                    )
                                }
                            }

                            BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                                val isWide = maxWidth >= 380.dp
                                if (isWide) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        ThemeModePreference.entries.forEach { mode ->
                                            ThemeOptionTile(
                                                mode = mode,
                                                isSelected = uiState.themeMode == mode,
                                                primaryColor = primaryColor,
                                                onClick = { viewModel.setThemeMode(mode) },
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .testTag("theme_mode_${mode.configValue}")
                                            )
                                        }
                                    }
                                } else {
                                    Column(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        ThemeModePreference.entries.forEach { mode ->
                                            ThemeOptionTile(
                                                mode = mode,
                                                isSelected = uiState.themeMode == mode,
                                                primaryColor = primaryColor,
                                                onClick = { viewModel.setThemeMode(mode) },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .testTag("theme_mode_${mode.configValue}")
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // NHÓM 2: BẢNG GIÁ & GÓI TẬP (GYM & YOGA — ĐÃ CHUẨN HÓA YOGA 1, 2, 3 THÁNG)
            if (showPricing) {
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = tokens.cardSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(gymAccent.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PriceChange,
                                            contentDescription = null,
                                            tint = gymAccent,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Bảng giá & Gói tập GYM / YOGA",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = tokens.textPrimary,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Các hợp đồng cũ luôn giữ nguyên mức giá và thời hạn đã ký.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = tokens.textSecondary
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = { showAddPackageDialog = true },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = GymPrimary,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Thêm gói", maxLines = 1)
                                }
                            }

                            val groups = listOf(
                                Triple(BoMon.GYM, DoiTuong.NAM, "Bảng giá GYM Nam"),
                                Triple(BoMon.GYM, DoiTuong.NU, "Bảng giá GYM Nữ"),
                                Triple(BoMon.GYM, DoiTuong.TRE_EM, "Bảng giá GYM Trẻ em"),
                                Triple(BoMon.YOGA, DoiTuong.YOGA_CHUNG, "Bảng giá YOGA")
                            )

                            groups.forEach { (boMon, doiTuong, groupTitle) ->
                                val pkgs = uiState.packages.filter { it.boMon == boMon && it.doiTuong == doiTuong }
                                val accent = if (boMon == BoMon.YOGA) yogaAccent else gymAccent
                                val groupIcon = if (boMon == BoMon.YOGA) Icons.Default.SelfImprovement else Icons.Default.FitnessCenter

                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = tokens.elevatedSurface,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, tokens.borderColor, RoundedCornerShape(12.dp))
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = groupIcon,
                                                contentDescription = null,
                                                tint = accent,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Text(
                                                text = groupTitle,
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = accent
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        pkgs.forEachIndexed { idx, pkg ->
                                            val resolvedMonths = pkg.soThang ?: when (pkg.giaTien) {
                                                500_000L -> 1
                                                1_000_000L -> 2
                                                1_500_000L -> 3
                                                else -> null
                                            }
                                            val durationLabel = when {
                                                resolvedMonths != null -> "Thời hạn: $resolvedMonths tháng"
                                                pkg.soNgayTuyChinh != null -> "Thời hạn: ${pkg.soNgayTuyChinh} ngày"
                                                else -> "Thời hạn: 1 tháng"
                                            }
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 6.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = pkg.tenGoi,
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        color = tokens.textPrimary,
                                                        fontWeight = FontWeight.SemiBold,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    Text(
                                                        text = durationLabel,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = tokens.textSecondary
                                                    )
                                                }
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        text = DateUtils.formatVnd(pkg.giaTien),
                                                        style = MaterialTheme.typography.titleSmall,
                                                        fontWeight = FontWeight.Bold,
                                                        color = accent
                                                    )
                                                    IconButton(
                                                        onClick = { packageToEdit = pkg },
                                                        modifier = Modifier.size(36.dp)
                                                    ) {
                                                        Icon(
                                                            Icons.Default.Edit,
                                                            contentDescription = "Sửa gói ${pkg.tenGoi}",
                                                            tint = tokens.textSecondary,
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                    }
                                                    IconButton(
                                                        onClick = { viewModel.deletePricingPackage(pkg) },
                                                        modifier = Modifier.size(36.dp)
                                                    ) {
                                                        Icon(
                                                            Icons.Default.DeleteOutline,
                                                            contentDescription = "Xóa gói ${pkg.tenGoi}",
                                                            tint = tokens.statusExpiredText,
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                    }
                                                }
                                            }
                                            if (idx < pkgs.lastIndex) {
                                                HorizontalDivider(color = tokens.dividerColor)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // NHÓM 3: ĐĂNG NHẬP GOOGLE & SAO LƯU TRÊN GOOGLE DRIVE
            if (showThemeAndBackup) {
                item {
                    GoogleDriveBackupSectionCard(
                        uiState = uiState,
                        onConnectGoogle = startGoogleSignIn,
                        onDisconnectGoogle = { viewModel.disconnectGoogleAccount(context) },
                        onBackupNow = { viewModel.backupToGoogleDriveNow() },
                        onRefreshList = { viewModel.refreshDriveBackupsList() },
                        onToggleAutoBackup = { viewModel.setAutoDriveBackup(it) },
                        onSelectBackupToRestore = { backupItem ->
                            viewModel.downloadAndValidateDriveBackup(backupItem) { res ->
                                res.onSuccess { (jsonStr, summaryStr) ->
                                    pendingRestoreIsFromDrive = true
                                    pendingRestoreJson = jsonStr
                                    pendingRestoreSummary = summaryStr
                                }
                            }
                        }
                    )
                }

                // NHÓM 4: SAO LƯU & KHÔI PHỤC TỆP JSON TRÊN MÁY (OFFLINE STORAGE)
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = tokens.cardSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(primaryColor.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Storage,
                                        contentDescription = null,
                                        tint = primaryColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Sao lưu & Khôi phục tệp JSON trên thiết bị",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = tokens.textPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Bao gồm toàn bộ 9 bảng dữ liệu: Hội viên Gym & Yoga, Hợp đồng, Giao dịch, Bảng giá, Khách PT, Buổi tập PT, Khách lẻ, Cấu hình và Lịch sử.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = tokens.textSecondary
                                    )
                                }
                            }

                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        exportBackupLauncher.launch("89FitnessYoga_Backup_${LocalDateSpec.today().toIsoString()}.json")
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = GymPrimary,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("btn_export_backup_json")
                                ) {
                                    Icon(Icons.Default.Backup, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Lưu file JSON", maxLines = 1)
                                }

                                OutlinedButton(
                                    onClick = {
                                        scope.launch {
                                            val json = viewModel.exportBackupJson()
                                            val fileName = "89FitnessYoga_Backup_${LocalDateSpec.today().toIsoString()}.json"
                                            ReportExporter.shareCsvOrJsonFile(
                                                context = context,
                                                fileName = fileName,
                                                mimeType = "application/json",
                                                content = json
                                            )
                                        }
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Chia sẻ JSON", maxLines = 1)
                                }
                            }

                            HorizontalDivider(color = tokens.dividerColor)

                            Text(
                                text = "Khôi phục từ tệp sao lưu JSON trên máy",
                                style = MaterialTheme.typography.titleSmall,
                                color = tokens.textPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Hệ thống kiểm tra tính hợp lệ của file sao lưu và yêu cầu xác nhận trước khi ghi đè dữ liệu.",
                                style = MaterialTheme.typography.bodySmall,
                                color = tokens.textSecondary
                            )
                            OutlinedButton(
                                onClick = {
                                    importBackupLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("btn_import_backup_json")
                            ) {
                                Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Chọn file JSON từ thiết bị để khôi phục", maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }

            // NHÓM 5: THÙNG RÁC (Khôi phục dữ liệu xóa nhầm)
            if (showTrash) {
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = tokens.cardSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(tokens.statusWarningBg),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.RestoreFromTrash,
                                        contentDescription = null,
                                        tint = tokens.statusWarningText,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Thùng rác & Khôi phục dữ liệu đã xóa",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = tokens.textPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Dữ liệu xóa tạm thời có thể được khôi phục nguyên trạng bất cứ lúc nào.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = tokens.textSecondary
                                    )
                                }
                            }

                            if (uiState.deletedMembers.isEmpty() && uiState.deletedPtContracts.isEmpty() && uiState.deletedWalkInTickets.isEmpty()) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = tokens.elevatedSurface,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "Thùng rác đang trống.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = tokens.textSecondary,
                                        modifier = Modifier.padding(14.dp)
                                    )
                                }
                            } else {
                                uiState.deletedMembers.forEach { m ->
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = tokens.elevatedSurface,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .border(1.dp, tokens.borderColor, RoundedCornerShape(12.dp))
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "[Hội viên ${m.boMon}] #${m.stt} – ${m.hoTen}",
                                                    style = MaterialTheme.typography.titleSmall,
                                                    color = tokens.textPrimary,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = "SĐT: ${m.soDienThoai.ifBlank { "Chưa có" }}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = tokens.textSecondary
                                                )
                                            }
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                TextButton(onClick = { viewModel.restoreMember(m) }) {
                                                    Icon(
                                                        Icons.Default.Restore,
                                                        contentDescription = null,
                                                        tint = tokens.statusActiveText,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Khôi phục", color = tokens.statusActiveText, fontWeight = FontWeight.Bold)
                                                }
                                                IconButton(onClick = { viewModel.permanentlyDeleteMember(m) }) {
                                                    Icon(
                                                        Icons.Default.DeleteForever,
                                                        contentDescription = "Xóa vĩnh viễn",
                                                        tint = tokens.statusExpiredText
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                uiState.deletedPtContracts.forEach { pt ->
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = tokens.elevatedSurface,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .border(1.dp, tokens.borderColor, RoundedCornerShape(12.dp))
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "[PT Gym] #${pt.stt} – ${pt.hoTen} (${pt.goiPt})",
                                                style = MaterialTheme.typography.titleSmall,
                                                color = tokens.textPrimary,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.weight(1f)
                                            )
                                            TextButton(onClick = { viewModel.restorePtContract(pt) }) {
                                                Text("Khôi phục", color = tokens.statusActiveText, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }

                                uiState.deletedWalkInTickets.forEach { w ->
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = tokens.elevatedSurface,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .border(1.dp, tokens.borderColor, RoundedCornerShape(12.dp))
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "[Khách lẻ] ${w.tenLoaiVe} – ${DateUtils.formatVnd(w.soTien)}",
                                                style = MaterialTheme.typography.titleSmall,
                                                color = tokens.textPrimary,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.weight(1f)
                                            )
                                            TextButton(onClick = { viewModel.restoreWalkInTicket(w) }) {
                                                Text("Khôi phục", color = tokens.statusActiveText, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // NHÓM 6: CHẨN ĐOÁN CÔNG THỨC TÀI CHÍNH (Debug)
            if (showDiagnostics) {
                val allPassed = uiState.goldenTestResults.all { it.passed }
                val passCount = uiState.goldenTestResults.count { it.passed }
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (allPassed) tokens.statusActiveBg else tokens.statusExpiredBg,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Science,
                                contentDescription = null,
                                tint = if (allPassed) tokens.statusActiveText else tokens.statusExpiredText,
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Kiểm thử công thức tài chính: $passCount/${uiState.goldenTestResults.size} PASS",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (allPassed) tokens.statusActiveText else tokens.statusExpiredText
                                )
                                Text(
                                    text = "Chạy độc lập trong bộ nhớ để xác minh độ chính xác của công thức phân bổ.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (allPassed) tokens.statusActiveText else tokens.statusExpiredText
                                )
                            }
                        }
                    }
                }

                items(uiState.goldenTestResults, key = { it.id }) { test ->
                    GoldenTestResultCard(test)
                }
            }
        }
    }

    if (showAddPackageDialog || packageToEdit != null) {
        PricingPackageDialog(
            existing = packageToEdit,
            onDismiss = {
                showAddPackageDialog = false
                packageToEdit = null
            },
            onSave = { pkg ->
                viewModel.savePricingPackage(pkg)
                showAddPackageDialog = false
                packageToEdit = null
            }
        )
    }

    if (pendingRestoreJson != null) {
        AlertDialog(
            onDismissRequest = {
                pendingRestoreJson = null
                pendingRestoreSummary = null
            },
            title = {
                Text(
                    if (pendingRestoreIsFromDrive) "Xác nhận khôi phục từ Google Drive?"
                    else "Xác nhận khôi phục & ghi đè dữ liệu?"
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = pendingRestoreSummary ?: "",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = tokens.statusActiveText
                    )
                    Text(
                        text = if (pendingRestoreIsFromDrive) {
                            "Hệ thống sẽ tự động tạo một bản sao lưu dự phòng an toàn trên máy trước khi khôi phục dữ liệu từ Google Drive. Bạn có chắc chắn muốn tiếp tục?"
                        } else {
                            "Cảnh báo: Thao tác này sẽ thay thế dữ liệu hiện tại bằng dữ liệu trong bản sao lưu. Bạn có chắc chắn muốn tiếp tục?"
                        },
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val json = pendingRestoreJson
                        val fromDrive = pendingRestoreIsFromDrive
                        pendingRestoreJson = null
                        pendingRestoreSummary = null
                        if (json != null) {
                            if (fromDrive) {
                                viewModel.confirmRestoreFromDriveJson(context, json)
                            } else {
                                viewModel.restoreBackupJson(json)
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = tokens.statusExpiredText, contentColor = Color.White)
                ) {
                    Text("Xác nhận Khôi phục")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        pendingRestoreJson = null
                        pendingRestoreSummary = null
                    }
                ) {
                    Text("Hủy")
                }
            }
        )
    }
}

@Composable
private fun ThemeOptionTile(
    mode: ThemeModePreference,
    isSelected: Boolean,
    primaryColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalAppDesignTokens.current
    val icon = when (mode) {
        ThemeModePreference.LIGHT -> Icons.Default.LightMode
        ThemeModePreference.DARK -> Icons.Default.DarkMode
        ThemeModePreference.SYSTEM -> Icons.Default.SettingsBrightness
    }
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) {
            primaryColor.copy(alpha = if (tokens.isDark) 0.24f else 0.12f)
        } else {
            tokens.elevatedSurface
        },
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) primaryColor else tokens.borderColor,
                shape = RoundedCornerShape(12.dp)
            )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) primaryColor else tokens.textSecondary,
                modifier = Modifier.size(18.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = mode.shortLabelVi,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (isSelected) primaryColor else tokens.textPrimary,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = mode.labelVi,
                    style = MaterialTheme.typography.labelSmall,
                    color = tokens.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (isSelected) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Đang chọn",
                    tint = primaryColor,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun GoogleDriveBackupSectionCard(
    uiState: AppUiState,
    onConnectGoogle: () -> Unit,
    onDisconnectGoogle: () -> Unit,
    onBackupNow: () -> Unit,
    onRefreshList: () -> Unit,
    onToggleAutoBackup: (Boolean) -> Unit,
    onSelectBackupToRestore: (DriveBackupFileItem) -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    val primaryColor = MaterialTheme.colorScheme.primary
    val hasSavedEmail = !uiState.googleAccountEmail.isNullOrBlank()
    val isConnected = uiState.isGoogleConnected

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = tokens.cardSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isConnected) tokens.statusActiveBg
                                else primaryColor.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isConnected) Icons.Default.CloudDone else Icons.Default.CloudOff,
                            contentDescription = null,
                            tint = if (isConnected) tokens.statusActiveText else primaryColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Sao lưu đám mây Google Drive",
                            style = MaterialTheme.typography.titleMedium,
                            color = tokens.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Lưu trữ trong thư mục riêng 89_Fitness_Yoga_Backups trên Google Drive của bạn",
                            style = MaterialTheme.typography.bodySmall,
                            color = tokens.textSecondary
                        )
                    }
                }
                if (uiState.isDriveBusy) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.5.dp,
                        color = primaryColor
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = tokens.elevatedSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, tokens.borderColor, RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = null,
                                tint = if (hasSavedEmail) primaryColor else tokens.textSecondary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (hasSavedEmail) {
                                        uiState.googleAccountName?.takeIf { it.isNotBlank() } ?: uiState.googleAccountEmail!!
                                    } else {
                                        "Chưa kết nối tài khoản Google"
                                    },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = tokens.textPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = when {
                                        isConnected -> "${uiState.googleAccountEmail} • Đã kết nối Drive"
                                        hasSavedEmail -> "${uiState.googleAccountEmail} • Cần bấm kết nối lại phiên làm việc"
                                        else -> "Ứng dụng vẫn hoạt động đầy đủ offline khi chưa đăng nhập"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isConnected) tokens.statusActiveText else tokens.textSecondary
                                )
                            }
                        }

                        if (hasSavedEmail) {
                            IconButton(
                                onClick = onDisconnectGoogle,
                                enabled = !uiState.isDriveBusy
                            ) {
                                Icon(
                                    Icons.Default.Logout,
                                    contentDescription = "Đăng xuất Google Drive",
                                    tint = tokens.statusExpiredText,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    if (!uiState.lastDriveBackupTime.isNullOrBlank()) {
                        Text(
                            text = "Lần sao lưu gần nhất lên Drive: ${uiState.lastDriveBackupTime}",
                            style = MaterialTheme.typography.labelSmall,
                            color = primaryColor,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    if (!uiState.driveStatusMessage.isNullOrBlank()) {
                        Text(
                            text = uiState.driveStatusMessage,
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.textSecondary
                        )
                    }
                }
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (!isConnected) {
                    Button(
                        onClick = onConnectGoogle,
                        enabled = !uiState.isDriveBusy,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GymPrimary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_connect_google_drive")
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (hasSavedEmail) "Kết nối lại Google Drive" else "Đăng nhập Google Drive",
                            maxLines = 1
                        )
                    }
                } else {
                    Button(
                        onClick = onBackupNow,
                        enabled = !uiState.isDriveBusy,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GymPrimary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("btn_backup_to_drive_now")
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Sao lưu lên Drive", maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = onRefreshList,
                        enabled = !uiState.isDriveBusy,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(0.8f)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Làm mới", maxLines = 1)
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Tự động sao lưu định kỳ khi có mạng",
                        style = MaterialTheme.typography.bodyMedium,
                        color = tokens.textPrimary,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Tự động đồng bộ bản sao lưu mới lên thư mục Google Drive",
                        style = MaterialTheme.typography.labelSmall,
                        color = tokens.textSecondary
                    )
                }
                Switch(
                    checked = uiState.autoDriveBackupEnabled,
                    onCheckedChange = onToggleAutoBackup
                )
            }

            if (uiState.driveBackups.isNotEmpty()) {
                HorizontalDivider(color = tokens.dividerColor)
                Text(
                    text = "Các bản sao lưu trên Google Drive (${uiState.driveBackups.size})",
                    style = MaterialTheme.typography.titleSmall,
                    color = tokens.textPrimary,
                    fontWeight = FontWeight.Bold
                )
                uiState.driveBackups.take(8).forEach { item ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = tokens.elevatedSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, tokens.borderColor, RoundedCornerShape(10.dp))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.name,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = tokens.textPrimary,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                val kbSize = (item.sizeBytes / 1024L).coerceAtLeast(1L)
                                Text(
                                    text = "Tạo lúc: ${item.createdTimeDisplay} • ${kbSize} KB",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = tokens.textSecondary
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            OutlinedButton(
                                onClick = { onSelectBackupToRestore(item) },
                                enabled = !uiState.isDriveBusy,
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    Icons.Default.CloudDownload,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Khôi phục", style = MaterialTheme.typography.labelSmall, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GoldenTestResultCard(test: GoldenTestCaseResult) {
    val tokens = LocalAppDesignTokens.current
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = tokens.cardSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (test.passed) tokens.borderColor else tokens.statusExpiredText,
                RoundedCornerShape(14.dp)
            )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = test.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = tokens.textPrimary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (test.passed) tokens.statusActiveBg else tokens.statusExpiredBg)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (test.passed) "PASS" else "FAIL",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (test.passed) tokens.statusActiveText else tokens.statusExpiredText,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = test.description,
                style = MaterialTheme.typography.bodySmall,
                color = tokens.textSecondary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Kỳ vọng: ${test.expectedDisplay}",
                style = MaterialTheme.typography.labelSmall,
                color = tokens.textSecondary
            )
            Text(
                text = "Thực tế: ${test.actualDisplay}",
                style = MaterialTheme.typography.labelMedium,
                color = if (test.passed) tokens.statusActiveText else tokens.statusExpiredText,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun PricingPackageDialog(
    existing: PricingPackageEntity?,
    onDismiss: () -> Unit,
    onSave: (PricingPackageEntity) -> Unit
) {
    var boMon by remember { mutableStateOf(existing?.boMon ?: BoMon.GYM) }
    var doiTuong by remember {
        mutableStateOf(
            existing?.doiTuong ?: if (boMon == BoMon.YOGA) DoiTuong.YOGA_CHUNG else DoiTuong.NAM
        )
    }
    var tenGoi by remember { mutableStateOf(existing?.tenGoi ?: "") }
    val initialMonths = existing?.soThang ?: if (existing?.boMon == BoMon.YOGA) {
        when (existing.giaTien) {
            500_000L -> 1
            1_000_000L -> 2
            1_500_000L -> 3
            else -> 1
        }
    } else 1
    var soThangText by remember { mutableStateOf(initialMonths.toString()) }
    var soNgayText by remember { mutableStateOf(existing?.soNgayTuyChinh?.toString() ?: "") }
    var giaTienText by remember { mutableStateOf((existing?.giaTien ?: 500_000L).toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Thêm gói tập mới" else "Chỉnh sửa gói tập & thời hạn") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = boMon == BoMon.GYM,
                        onClick = {
                            boMon = BoMon.GYM
                            doiTuong = DoiTuong.NAM
                        },
                        label = { Text("GYM") }
                    )
                    FilterChip(
                        selected = boMon == BoMon.YOGA,
                        onClick = {
                            boMon = BoMon.YOGA
                            doiTuong = DoiTuong.YOGA_CHUNG
                        },
                        label = { Text("YOGA") }
                    )
                }

                if (boMon == BoMon.GYM) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            DoiTuong.NAM to "Nam",
                            DoiTuong.NU to "Nữ",
                            DoiTuong.TRE_EM to "Trẻ em"
                        ).forEach { (code, label) ->
                            FilterChip(
                                selected = doiTuong == code,
                                onClick = { doiTuong = code },
                                label = { Text(label) }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = tenGoi,
                    onValueChange = { tenGoi = it },
                    label = { Text("Tên gói tập *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = soThangText,
                        onValueChange = { soThangText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số tháng") },
                        placeholder = { Text("VD: 1, 2, 3, 12") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = soNgayText,
                        onValueChange = { soNgayText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Hoặc số ngày") },
                        placeholder = { Text("Tùy chọn") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = giaTienText,
                    onValueChange = { giaTienText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Đơn giá (VNĐ) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val price = giaTienText.toLongOrNull() ?: 0L
                    val months = soThangText.toIntOrNull()?.takeIf { it > 0 }
                    val days = soNgayText.toIntOrNull()?.takeIf { it > 0 }
                    if (tenGoi.isNotBlank() && price > 0L) {
                        val pkg = PricingPackageEntity(
                            id = existing?.id ?: "PKG_${boMon}_${UUID.randomUUID().toString().take(6).uppercase()}",
                            boMon = boMon,
                            doiTuong = if (boMon == BoMon.YOGA) DoiTuong.YOGA_CHUNG else doiTuong,
                            tenGoi = tenGoi.trim(),
                            soThang = months ?: if (days == null) 1 else null,
                            soNgayTuyChinh = days,
                            giaTien = price,
                            thuTuHienThi = existing?.thuTuHienThi ?: 99,
                            dangHoatDong = true
                        )
                        onSave(pkg)
                    }
                }
            ) {
                Text("Lưu gói tập")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hủy") }
        }
    )
}
