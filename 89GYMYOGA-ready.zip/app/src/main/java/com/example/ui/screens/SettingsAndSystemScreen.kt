package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PriceChange
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.BoMon
import com.example.data.local.DoiTuong
import com.example.data.local.PricingPackageEntity
import com.example.domain.DateUtils
import com.example.domain.GoldenTestCaseResult
import com.example.ui.theme.GymPrimary
import com.example.ui.theme.StatusActiveGreen
import com.example.ui.theme.StatusActiveGreenBg
import com.example.ui.theme.StatusExpiredRed
import com.example.ui.theme.StatusExpiredRedBg
import com.example.ui.theme.StatusExpiring15Amber
import com.example.ui.theme.YogaPrimary
import com.example.ui.viewmodel.AppUiState
import com.example.ui.viewmodel.GymYogaViewModel
import com.example.util.ReportExporter
import java.util.UUID
import kotlinx.coroutines.launch

@Composable
fun SettingsAndSystemScreen(
    uiState: AppUiState,
    viewModel: GymYogaViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // 0 = Bảng giá & Gói tập, 1 = Golden Test Cases (Phần 18), 2 = Sao lưu & Khôi phục JSON, 3 = Thùng rác
    var activeSection by remember { mutableIntStateOf(0) }
    var packageToEdit by remember { mutableStateOf<PricingPackageEntity?>(null) }
    var showAddPackageDialog by remember { mutableStateOf(false) }

    // Backup / Restore states
    var pendingRestoreJson by remember { mutableStateOf<String?>(null) }
    var pendingRestoreSummary by remember { mutableStateOf<String?>(null) }

    val exportBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val json = viewModel.exportBackupJson()
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(json.toByteArray(Charsets.UTF_8))
                    }
                    viewModel.showMessage("Đã sao lưu toàn bộ dữ liệu ra file JSON thành công!")
                } catch (e: Exception) {
                    viewModel.showMessage("Lỗi sao lưu: ${e.message}")
                }
            }
        }
    }

    val importBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val jsonText = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.readText() ?: ""
                val validation = viewModel.validateBackupJson(jsonText)
                if (validation.isSuccess) {
                    pendingRestoreJson = jsonText
                    pendingRestoreSummary = validation.getOrNull()
                } else {
                    viewModel.showMessage(validation.exceptionOrNull()?.message ?: "File sao lưu không hợp lệ")
                }
            } catch (e: Exception) {
                viewModel.showMessage("Không thể đọc file: ${e.message}")
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header with Back button & Dark Mode toggle
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_btn")) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại")
                            }
                            Column {
                                Text(
                                    text = "CÀI ĐẶT, BẢNG GIÁ & HỆ THỐNG",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Cấu hình gói tập, kiểm thử Golden Test Cases & Sao lưu dữ liệu",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.DarkMode,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Switch(
                                checked = uiState.darkMode,
                                onCheckedChange = { viewModel.toggleDarkMode(it) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Triple(0, "Bảng giá & Gói tập", Icons.Default.PriceChange),
                            Triple(1, "Golden Test Cases (7/7)", Icons.Default.Science),
                            Triple(2, "Sao lưu & Khôi phục", Icons.Default.Backup),
                            Triple(3, "Thùng rác (${uiState.deletedMembers.size + uiState.deletedPtContracts.size + uiState.deletedWalkInTickets.size})", Icons.Default.RestoreFromTrash)
                        ).forEach { (idx, label, icon) ->
                            val selected = activeSection == idx
                            FilterChip(
                                selected = selected,
                                onClick = { activeSection = idx },
                                label = { Text(label, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium) },
                                leadingIcon = { Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = GymPrimary.copy(alpha = 0.15f),
                                    selectedLabelColor = GymPrimary
                                ),
                                modifier = Modifier.testTag("settings_tab_$idx")
                            )
                        }
                    }
                }
            }
        }

        when (activeSection) {
            0 -> {
                // PHẦN 4: BẢNG GIÁ VÀ QUẢN LÝ GÓI TẬP
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Quản lý Bảng giá GYM & YOGA",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Giá trong hợp đồng cũ được giữ nguyên khi cập nhật bảng giá. Hãy cấu hình thời hạn cho 3 gói Yoga tại đây.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { showAddPackageDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = GymPrimary)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Thêm gói")
                        }
                    }
                }

                val groups = listOf(
                    Triple(BoMon.GYM, DoiTuong.NAM, "4.1. Bảng giá GYM Nam"),
                    Triple(BoMon.GYM, DoiTuong.NU, "4.2. Bảng giá GYM Nữ"),
                    Triple(BoMon.GYM, DoiTuong.TRE_EM, "4.3. Bảng giá GYM Trẻ em"),
                    Triple(BoMon.YOGA, DoiTuong.YOGA_CHUNG, "4.4. Bảng giá YOGA (Cấu hình thời hạn)")
                )

                groups.forEach { (boMon, doiTuong, groupTitle) ->
                    val pkgs = uiState.packages.filter { it.boMon == boMon && it.doiTuong == doiTuong }
                    val accent = if (boMon == BoMon.YOGA) YogaPrimary else GymPrimary
                    item {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surface,
                            tonalElevation = 1.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, accent.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = groupTitle,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = accent
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                pkgs.forEach { pkg ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = pkg.tenGoi,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            val durationLabel = when {
                                                pkg.soThang != null -> "Thời hạn: ${pkg.soThang} tháng"
                                                pkg.soNgayTuyChinh != null -> "Thời hạn: ${pkg.soNgayTuyChinh} ngày"
                                                else -> "Chưa thiết lập thời hạn (Chạm Sửa để cấu hình)"
                                            }
                                            Text(
                                                text = durationLabel,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (pkg.soThang == null && pkg.soNgayTuyChinh == null) StatusExpiring15Amber
                                                else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = DateUtils.formatVnd(pkg.giaTien),
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = accent
                                            )
                                            IconButton(onClick = { packageToEdit = pkg }) {
                                                Icon(Icons.Default.Edit, contentDescription = "Sửa gói", modifier = Modifier.size(18.dp))
                                            }
                                            IconButton(onClick = { viewModel.deletePricingPackage(pkg) }) {
                                                Icon(
                                                    Icons.Default.DeleteOutline,
                                                    contentDescription = "Xóa gói",
                                                    tint = StatusExpiredRed,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // PHẦN 18: GOLDEN TEST CASES
                val allPassed = uiState.goldenTestResults.all { it.passed }
                val passCount = uiState.goldenTestResults.count { it.passed }
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (allPassed) StatusActiveGreenBg else StatusExpiredRedBg,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (allPassed) StatusActiveGreen else StatusExpiredRed,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "KẾT QUẢ KIỂM THỬ TỰ ĐỘNG: $passCount/${uiState.goldenTestResults.size} PASS",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (allPassed) StatusActiveGreen else StatusExpiredRed
                                )
                                Text(
                                    text = "Dữ liệu kiểm thử chạy độc lập trong bộ nhớ, tuyệt đối không trộn vào dữ liệu kinh doanh thật.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (allPassed) StatusActiveGreen else StatusExpiredRed
                                )
                            }
                        }
                    }
                }

                items(uiState.goldenTestResults, key = { it.id }) { test ->
                    GoldenTestResultCard(test)
                }
            }

            2 -> {
                // PHẦN 16: SAO LƯU & KHÔI PHỤC DỮ LIỆU JSON
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 1.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Sao lưu & Khôi phục dữ liệu toàn hệ thống (JSON)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Bao gồm toàn bộ 9 bảng dữ liệu: Hội viên Gym & Yoga, Hợp đồng, Lịch sử thanh toán, Bảng giá, Khách PT, Buổi tập PT, Khách lẻ, Cấu hình và Lịch sử thay đổi.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = {
                                        exportBackupLauncher.launch("GymYogaManager_Backup_${com.example.domain.LocalDateSpec.today().toIsoString()}.json")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = GymPrimary),
                                    modifier = Modifier.weight(1f).testTag("btn_export_backup_json")
                                ) {
                                    Icon(Icons.Default.Backup, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Lưu file Sao lưu JSON")
                                }

                                OutlinedButton(
                                    onClick = {
                                        scope.launch {
                                            val json = viewModel.exportBackupJson()
                                            val fileName = "GymYogaManager_Backup_${com.example.domain.LocalDateSpec.today().toIsoString()}.json"
                                            ReportExporter.shareCsvOrJsonFile(
                                                context = context,
                                                fileName = fileName,
                                                mimeType = "application/json",
                                                content = json
                                            )
                                        }
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Chia sẻ file JSON")
                                }
                            }

                            HorizontalDivider()

                            Text(
                                text = "Khôi phục từ bản sao lưu JSON",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Hệ thống sẽ kiểm tra tính hợp lệ của file sao lưu và yêu cầu xác nhận trước khi ghi đè dữ liệu.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedButton(
                                onClick = {
                                    importBackupLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                                },
                                modifier = Modifier.fillMaxWidth().testTag("btn_import_backup_json")
                            ) {
                                Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Chọn file JSON để khôi phục dữ liệu")
                            }
                        }
                    }
                }
            }

            3 -> {
                // THÙNG RÁC (Khôi phục dữ liệu xóa nhầm - Phần 16)
                item {
                    Text(
                        text = "Thùng rác (Khôi phục dữ liệu đã xóa nhầm)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (uiState.deletedMembers.isEmpty() && uiState.deletedPtContracts.isEmpty() && uiState.deletedWalkInTickets.isEmpty()) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Thùng rác đang trống.",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(20.dp)
                            )
                        }
                    }
                } else {
                    items(uiState.deletedMembers, key = { it.id }) { m ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "[Hội viên ${m.boMon}] #${m.stt} – ${m.hoTen}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "SĐT: ${m.soDienThoai}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                                Row {
                                    TextButton(onClick = { viewModel.restoreMember(m) }) {
                                        Text("Khôi phục", color = StatusActiveGreen, fontWeight = FontWeight.Bold)
                                    }
                                    IconButton(onClick = { viewModel.permanentlyDeleteMember(m) }) {
                                        Icon(
                                            Icons.Default.DeleteForever,
                                            contentDescription = "Xóa vĩnh viễn",
                                            tint = StatusExpiredRed
                                        )
                                    }
                                }
                            }
                        }
                    }

                    items(uiState.deletedPtContracts, key = { it.id }) { pt ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "[PT Gym] #${pt.stt} – ${pt.hoTen} (${pt.goiPt})",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(onClick = { viewModel.restorePtContract(pt) }) {
                                    Text("Khôi phục", color = StatusActiveGreen, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    items(uiState.deletedWalkInTickets, key = { it.id }) { w ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "[Khách lẻ] ${w.tenLoaiVe} – ${DateUtils.formatVnd(w.soTien)}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(onClick = { viewModel.restoreWalkInTicket(w) }) {
                                    Text("Khôi phục", color = StatusActiveGreen, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddPackageDialog || packageToEdit != null) {
        PricingPackageDialog(
            existing = packageToEdit,
            onDismiss = {
                showAddPackageDialog = false
                packageToEdit = null
            },
            onSave = { pkg ->
                viewModel.savePricingPackage(pkg)
                showAddPackageDialog = false
                packageToEdit = null
            }
        )
    }

    if (pendingRestoreJson != null) {
        AlertDialog(
            onDismissRequest = {
                pendingRestoreJson = null
                pendingRestoreSummary = null
            },
            title = { Text("Xác nhận khôi phục & ghi đè dữ liệu?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = pendingRestoreSummary ?: "",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = StatusActiveGreen
                    )
                    Text(
                        text = "Cảnh báo: Thao tác này sẽ thay thế dữ liệu hiện tại bằng dữ liệu trong bản sao lưu. Bạn có chắc chắn muốn tiếp tục?",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val json = pendingRestoreJson
                        pendingRestoreJson = null
                        pendingRestoreSummary = null
                        if (json != null) {
                            viewModel.restoreBackupJson(json)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusExpiredRed)
                ) {
                    Text("Xác nhận Khôi phục")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        pendingRestoreJson = null
                        pendingRestoreSummary = null
                    }
                ) {
                    Text("Hủy")
                }
            }
        )
    }
}

@Composable
private fun GoldenTestResultCard(test: GoldenTestCaseResult) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (test.passed) StatusActiveGreen.copy(alpha = 0.4f) else StatusExpiredRed,
                RoundedCornerShape(14.dp)
            )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = test.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (test.passed) StatusActiveGreenBg else StatusExpiredRedBg)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (test.passed) "PASS" else "FAIL",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (test.passed) StatusActiveGreen else StatusExpiredRed,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = test.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Kỳ vọng: ${test.expectedDisplay}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "Thực tế: ${test.actualDisplay}",
                style = MaterialTheme.typography.labelMedium,
                color = if (test.passed) StatusActiveGreen else StatusExpiredRed,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun PricingPackageDialog(
    existing: PricingPackageEntity?,
    onDismiss: () -> Unit,
    onSave: (PricingPackageEntity) -> Unit
) {
    var boMon by remember { mutableStateOf(existing?.boMon ?: BoMon.GYM) }
    var doiTuong by remember {
        mutableStateOf(
            existing?.doiTuong ?: if (boMon == BoMon.YOGA) DoiTuong.YOGA_CHUNG else DoiTuong.NAM
        )
    }
    var tenGoi by remember { mutableStateOf(existing?.tenGoi ?: "") }
    var soThangText by remember { mutableStateOf(existing?.soThang?.toString() ?: "") }
    var soNgayText by remember { mutableStateOf(existing?.soNgayTuyChinh?.toString() ?: "") }
    var giaTienText by remember { mutableStateOf((existing?.giaTien ?: 300_000L).toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Thêm gói tập mới" else "Chỉnh sửa gói tập & thời hạn") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = boMon == BoMon.GYM,
                        onClick = {
                            boMon = BoMon.GYM
                            doiTuong = DoiTuong.NAM
                        },
                        label = { Text("GYM") }
                    )
                    FilterChip(
                        selected = boMon == BoMon.YOGA,
                        onClick = {
                            boMon = BoMon.YOGA
                            doiTuong = DoiTuong.YOGA_CHUNG
                        },
                        label = { Text("YOGA") }
                    )
                }

                if (boMon == BoMon.GYM) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            DoiTuong.NAM to "Nam",
                            DoiTuong.NU to "Nữ",
                            DoiTuong.TRE_EM to "Trẻ em"
                        ).forEach { (code, label) ->
                            FilterChip(
                                selected = doiTuong == code,
                                onClick = { doiTuong = code },
                                label = { Text(label) }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = tenGoi,
                    onValueChange = { tenGoi = it },
                    label = { Text("Tên gói tập *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = soThangText,
                        onValueChange = { soThangText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số tháng") },
                        placeholder = { Text("VD: 1, 2, 3, 12") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = soNgayText,
                        onValueChange = { soNgayText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Hoặc số ngày") },
                        placeholder = { Text("Tùy chọn") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = giaTienText,
                    onValueChange = { giaTienText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Đơn giá (VNĐ) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val price = giaTienText.toLongOrNull() ?: 0L
                    val months = soThangText.toIntOrNull()?.takeIf { it > 0 }
                    val days = soNgayText.toIntOrNull()?.takeIf { it > 0 }
                    if (tenGoi.isNotBlank() && price > 0L) {
                        val pkg = PricingPackageEntity(
                            id = existing?.id ?: "PKG_${boMon}_${UUID.randomUUID().toString().take(6).uppercase()}",
                            boMon = boMon,
                            doiTuong = if (boMon == BoMon.YOGA) DoiTuong.YOGA_CHUNG else doiTuong,
                            tenGoi = tenGoi.trim(),
                            soThang = months,
                            soNgayTuyChinh = days,
                            giaTien = price,
                            thuTuHienThi = existing?.thuTuHienThi ?: 99,
                            dangHoatDong = true
                        )
                        onSave(pkg)
                    }
                }
            ) {
                Text("Lưu gói tập")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hủy") }
        }
    )
}
