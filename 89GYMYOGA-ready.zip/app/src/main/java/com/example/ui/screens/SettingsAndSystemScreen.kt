package com.example.ui.screens

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PriceChange
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.SettingsBrightness
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.BoMon
import com.example.data.local.DoiTuong
import com.example.data.local.PricingPackageEntity
import com.example.domain.DateUtils
import com.example.domain.GoldenTestCaseResult
import com.example.domain.LocalDateSpec
import com.example.ui.theme.GymPrimary
import com.example.ui.theme.LocalAppDesignTokens
import com.example.ui.theme.ThemeModePreference
import com.example.ui.viewmodel.AppUiState
import com.example.ui.viewmodel.GymYogaViewModel
import com.example.util.DriveBackupFileItem
import com.example.util.GoogleDriveBackupManager
import com.example.util.ReportExporter
import java.util.UUID
import kotlinx.coroutines.launch

/**
 * Các danh mục cài đặt độc lập (Section 8.1 & 8.2 — Đã loại bỏ hoàn toàn "Tất cả mục").
 */
enum class SettingsCategory(
    val id: Int,
    val title: String,
    val subtitle: String,
    val keywords: List<String>
) {
    PRICING(
        id = 0,
        title = "Bảng giá & Gói tập",
        subtitle = "Quản lý bảng giá GYM Nam, Nữ, Trẻ em và YOGA 1, 2, 3 tháng",
        keywords = listOf("bảng giá", "gói tập", "gym", "yoga", "500.000", "1.000.000", "1.500.000", "nam", "nữ", "trẻ em", "thời hạn", "tháng", "đơn giá")
    ),
    THEME(
        id = 1,
        title = "Giao diện & Chủ đề",
        subtitle = "Chuyển đổi chế độ Sáng (Light Mode), Tối (Dark Mode) và Theo hệ thống",
        keywords = listOf("giao diện", "chủ đề", "theme", "light mode", "dark mode", "sáng", "tối", "hệ thống", "màu sắc", "cyber")
    ),
    BACKUP(
        id = 2,
        title = "Dữ liệu & Sao lưu",
        subtitle = "Đăng nhập Google Drive, đổi tài khoản, sao lưu đám mây và xuất/nhập tệp JSON",
        keywords = listOf("dữ liệu", "sao lưu", "khôi phục", "google drive", "đăng nhập", "tài khoản", "gmail", "oauth", "sha-1", "json", "backup", "restore", "đám mây")
    ),
    TRASH(
        id = 3,
        title = "Thùng rác",
        subtitle = "Khôi phục hội viên, hợp đồng PT hoặc vé lẻ đã xóa tạm thời",
        keywords = listOf("thùng rác", "xóa", "khôi phục", "hội viên đã xóa", "pt đã xóa", "vé lẻ đã xóa")
    ),
    DIAGNOSTICS(
        id = 4,
        title = "Kiểm thử",
        subtitle = "Kiểm tra tự động độ chính xác các công thức tài chính & phân bổ doanh thu",
        keywords = listOf("kiểm thử", "chẩn đoán", "công thức", "phân bổ", "tài chính", "test", "pass")
    )
}

data class SettingsSearchableEntry(
    val id: String,
    val title: String,
    val description: String,
    val category: SettingsCategory,
    val keywords: List<String>
)

private val ALL_SEARCHABLE_SETTINGS = listOf(
    SettingsSearchableEntry(
        id = "pricing_gym",
        title = "Bảng giá GYM (Nam, Nữ, Trẻ em)",
        description = "Thêm, sửa hoặc xóa các gói tập GYM theo đối tượng",
        category = SettingsCategory.PRICING,
        keywords = listOf("gym", "nam", "nữ", "trẻ em", "bảng giá", "gói tập")
    ),
    SettingsSearchableEntry(
        id = "pricing_yoga",
        title = "Bảng giá YOGA (1 tháng, 2 tháng, 3 tháng)",
        description = "Quản lý gói tập Yoga 500.000đ, 1.000.000đ, 1.500.000đ",
        category = SettingsCategory.PRICING,
        keywords = listOf("yoga", "500", "1 tháng", "2 tháng", "3 tháng", "bảng giá")
    ),
    SettingsSearchableEntry(
        id = "theme_mode",
        title = "Chế độ giao diện (Sáng / Tối / Theo hệ thống)",
        description = "Chuyển đổi tức thì giữa Light Mode, Dark Mode và System",
        category = SettingsCategory.THEME,
        keywords = listOf("giao diện", "chủ đề", "sáng", "tối", "light", "dark", "theme")
    ),
    SettingsSearchableEntry(
        id = "google_drive_auth",
        title = "Đăng nhập & Đổi tài khoản Google Drive",
        description = "Kết nối tài khoản Google, đổi tài khoản hoặc đăng xuất",
        category = SettingsCategory.BACKUP,
        keywords = listOf("google", "drive", "đăng nhập", "đổi tài khoản", "gmail", "oauth", "sha-1")
    ),
    SettingsSearchableEntry(
        id = "google_drive_backup",
        title = "Sao lưu & Khôi phục trên Google Drive",
        description = "Tải bản sao lưu lên thư mục 89_Fitness_Yoga_Backups và khôi phục an toàn",
        category = SettingsCategory.BACKUP,
        keywords = listOf("sao lưu", "khôi phục", "drive", "đám mây", "tự động sao lưu")
    ),
    SettingsSearchableEntry(
        id = "local_json_backup",
        title = "Sao lưu & Khôi phục tệp JSON trên thiết bị",
        description = "Lưu file JSON ra bộ nhớ máy, chia sẻ hoặc nhập file JSON",
        category = SettingsCategory.BACKUP,
        keywords = listOf("json", "file", "thiết bị", "máy", "chia sẻ", "offline")
    ),
    SettingsSearchableEntry(
        id = "trash_restore",
        title = "Thùng rác & Khôi phục dữ liệu đã xóa",
        description = "Khôi phục hoặc xóa vĩnh viễn hội viên, hợp đồng PT, vé lẻ",
        category = SettingsCategory.TRASH,
        keywords = listOf("thùng rác", "xóa", "khôi phục", "hội viên")
    ),
    SettingsSearchableEntry(
        id = "golden_diagnostics",
        title = "Kiểm thử công thức tài chính & phân bổ",
        description = "Xem kết quả kiểm tra tự động các quy tắc nối tiếp và phân bổ doanh thu",
        category = SettingsCategory.DIAGNOSTICS,
        keywords = listOf("kiểm thử", "công thức", "tài chính", "phân bổ", "pass")
    )
)

fun searchSettingsEntries(query: String): List<SettingsSearchableEntry> {
    val q = query.trim().lowercase()
    if (q.isEmpty()) return emptyList()
    return ALL_SEARCHABLE_SETTINGS.filter { entry ->
        entry.title.lowercase().contains(q) ||
            entry.description.lowercase().contains(q) ||
            entry.category.title.lowercase().contains(q) ||
            entry.keywords.any { it.lowercase().contains(q) } ||
            entry.category.keywords.any { it.lowercase().contains(q) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsAndSystemScreen(
    uiState: AppUiState,
    viewModel: GymYogaViewModel,
    onBack: () -> Unit,
    initialCategory: SettingsCategory? = null
) {
    // null = Danh sách danh mục cài đặt cuộn dọc; khác null = Màn hình chi tiết của đúng danh mục đó
    var selectedCategory by rememberSaveable { mutableStateOf(initialCategory) }
    var searchQuery by rememberSaveable { mutableStateOf("") }

    BackHandler {
        when {
            searchQuery.isNotBlank() -> searchQuery = ""
            selectedCategory != null -> selectedCategory = null
            else -> onBack()
        }
    }

    val tokens = LocalAppDesignTokens.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val primaryColor = MaterialTheme.colorScheme.primary
    val gymAccent = tokens.gymAccent
    val yogaAccent = tokens.yogaAccent

    var packageToEdit by remember { mutableStateOf<PricingPackageEntity?>(null) }
    var showAddPackageDialog by remember { mutableStateOf(false) }

    var pendingRestoreJson by remember { mutableStateOf<String?>(null) }
    var pendingRestoreSummary by remember { mutableStateOf<String?>(null) }
    var pendingRestoreIsFromDrive by remember { mutableStateOf(false) }
    var pendingAuthEmailHint by remember { mutableStateOf<String?>(null) }

    // B2: Xử lý kết quả màn hình cấp quyền OAuth (Identity AuthorizationClient)
    val googleAuthIntentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            scope.launch {
                val res = GoogleDriveBackupManager.handleAuthorizationIntentResult(
                    context = context,
                    data = result.data,
                    fallbackEmail = pendingAuthEmailHint
                )
                res.fold(
                    onSuccess = { profile -> viewModel.onGoogleAuthorized(profile) },
                    onFailure = { err ->
                        viewModel.onGoogleAuthError(err.message ?: "Không thể hoàn tất cấp quyền Google Drive.")
                    }
                )
            }
        } else {
            viewModel.onGoogleAuthError("Đã hủy cấp quyền truy cập Google Drive.")
        }
    }

    // B1: Mở hộp thoại chọn tài khoản Google (Account Picker) trước, sau đó xin quyền Drive
    val googleAccountPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        scope.launch {
            val authRes = GoogleDriveBackupManager.handleAccountPickerResultAndAuthorize(
                context = context,
                data = result.data
            )
            authRes.fold(
                onSuccess = { outcome ->
                    pendingAuthEmailHint = outcome.selectedEmailHint
                    if (outcome.pendingIntent != null) {
                        val req = IntentSenderRequest.Builder(outcome.pendingIntent.intentSender).build()
                        googleAuthIntentLauncher.launch(req)
                    } else if (outcome.profile != null) {
                        viewModel.onGoogleAuthorized(outcome.profile)
                    }
                },
                onFailure = { err ->
                    viewModel.onGoogleAuthError(
                        err.message ?: "Không thể đăng nhập tài khoản Google trên thiết bị này."
                    )
                }
            )
        }
    }

    val startGoogleSignInWithPicker: (Boolean) -> Unit = { forceAccountPicker ->
        scope.launch {
            if (!GoogleDriveBackupManager.isNetworkAvailable(context)) {
                viewModel.onGoogleAuthError("Không có kết nối mạng. Vui lòng kiểm tra Wi-Fi/4G và thử lại.")
                return@launch
            }
            try {
                val pickerIntent = GoogleDriveBackupManager.prepareAccountPickerSignInIntent(
                    context = context,
                    forceAccountPicker = forceAccountPicker
                )
                googleAccountPickerLauncher.launch(pickerIntent)
            } catch (e: Exception) {
                // Fallback sang Identity AuthorizationClient trực tiếp nếu thiết bị không mở được Account Picker
                val authRes = GoogleDriveBackupManager.authorize(context)
                authRes.fold(
                    onSuccess = { outcome ->
                        if (outcome.pendingIntent != null) {
                            val req = IntentSenderRequest.Builder(outcome.pendingIntent.intentSender).build()
                            googleAuthIntentLauncher.launch(req)
                        } else if (outcome.profile != null) {
                            viewModel.onGoogleAuthorized(outcome.profile)
                        }
                    },
                    onFailure = { err ->
                        viewModel.onGoogleAuthError(
                            err.message ?: "Không thể khởi tạo đăng nhập Google Drive."
                        )
                    }
                )
            }
        }
    }

    val exportBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val json = viewModel.exportBackupJson()
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(json.toByteArray(Charsets.UTF_8))
                    }
                    viewModel.showMessage("Đã sao lưu toàn bộ dữ liệu ra file JSON thành công!")
                } catch (e: Exception) {
                    viewModel.showMessage("Lỗi sao lưu: ${e.message}")
                }
            }
        }
    }

    val importBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val jsonText = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.readText() ?: ""
                val validation = viewModel.validateBackupJson(jsonText)
                if (validation.isSuccess) {
                    pendingRestoreIsFromDrive = false
                    pendingRestoreJson = jsonText
                    pendingRestoreSummary = validation.getOrNull()
                } else {
                    viewModel.showMessage(validation.exceptionOrNull()?.message ?: "File sao lưu không hợp lệ")
                }
            } catch (e: Exception) {
                viewModel.showMessage("Không thể đọc file: ${e.message}")
            }
        }
    }

    val trashCount = uiState.deletedMembers.size + uiState.deletedPtContracts.size + uiState.deletedWalkInTickets.size
    val searchResults = remember(searchQuery) { searchSettingsEntries(searchQuery) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.background)
    ) {
        // ================= STICKY TOP HEADER & SEARCH BAR (Section 8.3 & 8.4) =================
        Surface(
            color = tokens.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        IconButton(
                            onClick = {
                                when {
                                    searchQuery.isNotBlank() -> searchQuery = ""
                                    selectedCategory != null -> selectedCategory = null
                                    else -> onBack()
                                }
                            },
                            modifier = Modifier.testTag("settings_back_btn")
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Quay lại",
                                tint = tokens.textPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = selectedCategory?.title ?: "Cài đặt hệ thống",
                                style = MaterialTheme.typography.titleLarge,
                                color = tokens.textPrimary,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (selectedCategory != null) {
                                    "Chạm nút Quay lại để về danh mục Cài đặt"
                                } else {
                                    "89 FITNESS & YOGA · Chọn danh mục cài đặt"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = tokens.textSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Compact quick theme pill
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = tokens.elevatedSurface,
                        modifier = Modifier
                            .border(1.dp, tokens.borderColor, RoundedCornerShape(10.dp))
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                val nextMode = when (uiState.themeMode) {
                                    ThemeModePreference.LIGHT -> ThemeModePreference.DARK
                                    ThemeModePreference.DARK -> ThemeModePreference.SYSTEM
                                    ThemeModePreference.SYSTEM -> ThemeModePreference.LIGHT
                                }
                                viewModel.setThemeMode(nextMode)
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = when (uiState.themeMode) {
                                    ThemeModePreference.LIGHT -> Icons.Default.LightMode
                                    ThemeModePreference.DARK -> Icons.Default.DarkMode
                                    ThemeModePreference.SYSTEM -> Icons.Default.SettingsBrightness
                                },
                                contentDescription = "Chế độ giao diện",
                                tint = primaryColor,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = uiState.themeMode.shortLabelVi,
                                style = MaterialTheme.typography.labelMedium,
                                color = tokens.textPrimary,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1
                            )
                        }
                    }
                }

                // Thanh tìm kiếm cài đặt cố định phía trên (Section 8.3: "Tìm kiếm cài đặt...")
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = "Tìm kiếm cài đặt...",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Tìm kiếm cài đặt",
                            tint = primaryColor
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Xóa tìm kiếm")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = primaryColor,
                        unfocusedBorderColor = tokens.borderColor,
                        unfocusedContainerColor = tokens.cardSurface,
                        focusedContainerColor = tokens.cardSurface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_search_input")
                )
            }
        }
        HorizontalDivider(color = tokens.borderColor)

        // ================= SCROLLABLE BODY (Section 8.2 & 8.4) =================
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (searchQuery.isNotBlank()) {
                // KẾT QUẢ TÌM KIẾM CÀI ĐẶT
                if (searchResults.isEmpty()) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = tokens.cardSurface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, tokens.borderColor, RoundedCornerShape(14.dp))
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Không tìm thấy mục cài đặt phù hợp với \"$searchQuery\"",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = tokens.textPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Gợi ý từ khóa: bảng giá, yoga, giao diện, tối, sáng, google drive, sao lưu, json, thùng rác, kiểm thử.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = tokens.textSecondary
                                )
                            }
                        }
                    }
                } else {
                    items(searchResults, key = { it.id }) { resultItem ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = tokens.cardSurface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable {
                                    selectedCategory = resultItem.category
                                    searchQuery = ""
                                }
                                .border(1.dp, tokens.borderColor, RoundedCornerShape(14.dp))
                                .testTag("settings_search_result_${resultItem.id}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = resultItem.category.title,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = primaryColor,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = resultItem.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = tokens.textPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = resultItem.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = tokens.textSecondary
                                    )
                                }
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                    contentDescription = "Mở cài đặt",
                                    tint = primaryColor
                                )
                            }
                        }
                    }
                }
            } else if (selectedCategory == null) {
                // MÀN HÌNH DANH SÁCH DANH MỤC CÀI ĐẶT CUỘN DỌC (Section 8.1 & 8.2 — Không có "Tất cả mục")
                items(SettingsCategory.entries, key = { it.id }) { category ->
                    val (catIcon, catBadgeText, catAccent) = when (category) {
                        SettingsCategory.PRICING -> Triple(
                            Icons.Default.PriceChange,
                            "${uiState.packages.size} gói tập",
                            gymAccent
                        )
                        SettingsCategory.THEME -> Triple(
                            Icons.Default.Palette,
                            uiState.themeMode.shortLabelVi,
                            primaryColor
                        )
                        SettingsCategory.BACKUP -> Triple(
                            Icons.Default.CloudSync,
                            if (uiState.isGoogleConnected) "Đã kết nối Drive" else "Drive & JSON",
                            if (uiState.isGoogleConnected) tokens.statusActiveText else primaryColor
                        )
                        SettingsCategory.TRASH -> Triple(
                            Icons.Default.RestoreFromTrash,
                            "$trashCount mục",
                            tokens.statusWarningText
                        )
                        SettingsCategory.DIAGNOSTICS -> {
                            val passCount = uiState.goldenTestResults.count { it.passed }
                            Triple(
                                Icons.Default.Science,
                                "$passCount/${uiState.goldenTestResults.size} PASS",
                                tokens.statusActiveText
                            )
                        }
                    }

                    SettingsCategoryCardItem(
                        category = category,
                        icon = catIcon,
                        badgeText = catBadgeText,
                        accentColor = catAccent,
                        onClick = { selectedCategory = category }
                    )
                }
            } else {
                // MÀN HÌNH CHI TIẾT CỦA ĐÚNG 1 DANH MỤC ĐANG CHỌN (Không hiển thị tất cả danh mục cùng lúc)
                when (selectedCategory!!) {
                    SettingsCategory.PRICING -> {
                        item {
                            PricingPackagesCategoryContent(
                                uiState = uiState,
                                gymAccent = gymAccent,
                                yogaAccent = yogaAccent,
                                onAddPackage = { showAddPackageDialog = true },
                                onEditPackage = { packageToEdit = it },
                                onDeletePackage = { viewModel.deletePricingPackage(it) }
                            )
                        }
                    }

                    SettingsCategory.THEME -> {
                        item {
                            ThemeCategoryContent(
                                uiState = uiState,
                                primaryColor = primaryColor,
                                onSelectThemeMode = { viewModel.setThemeMode(it) }
                            )
                        }
                    }

                    SettingsCategory.BACKUP -> {
                        item {
                            GoogleDriveBackupSectionCard(
                                context = context,
                                uiState = uiState,
                                onConnectGoogle = { startGoogleSignInWithPicker(false) },
                                onSwitchGoogleAccount = { startGoogleSignInWithPicker(true) },
                                onDisconnectGoogle = { viewModel.disconnectGoogleAccount(context) },
                                onBackupNow = { viewModel.backupToGoogleDriveNow() },
                                onRefreshList = { viewModel.refreshDriveBackupsList() },
                                onToggleAutoBackup = { viewModel.setAutoDriveBackup(it) },
                                onCopyText = { label, text ->
                                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                    cm?.setPrimaryClip(ClipData.newPlainText(label, text))
                                    viewModel.showMessage("Đã sao chép $label vào bộ nhớ tạm")
                                },
                                onSelectBackupToRestore = { backupItem ->
                                    viewModel.downloadAndValidateDriveBackup(backupItem) { res ->
                                        res.onSuccess { (jsonStr, summaryStr) ->
                                            pendingRestoreIsFromDrive = true
                                            pendingRestoreJson = jsonStr
                                            pendingRestoreSummary = summaryStr
                                        }
                                    }
                                }
                            )
                        }

                        item {
                            LocalJsonBackupSectionCard(
                                primaryColor = primaryColor,
                                onExportJson = {
                                    exportBackupLauncher.launch("89FitnessYoga_Backup_${LocalDateSpec.today().toIsoString()}.json")
                                },
                                onShareJson = {
                                    scope.launch {
                                        val json = viewModel.exportBackupJson()
                                        val fileName = "89FitnessYoga_Backup_${LocalDateSpec.today().toIsoString()}.json"
                                        ReportExporter.shareCsvOrJsonFile(
                                            context = context,
                                            fileName = fileName,
                                            mimeType = "application/json",
                                            content = json
                                        )
                                    }
                                },
                                onImportJson = {
                                    importBackupLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                                }
                            )
                        }
                    }

                    SettingsCategory.TRASH -> {
                        item {
                            TrashCategoryContent(
                                uiState = uiState,
                                viewModel = viewModel
                            )
                        }
                    }

                    SettingsCategory.DIAGNOSTICS -> {
                        val allPassed = uiState.goldenTestResults.all { it.passed }
                        val passCount = uiState.goldenTestResults.count { it.passed }
                        item {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (allPassed) tokens.statusActiveBg else tokens.statusExpiredBg,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Science,
                                        contentDescription = null,
                                        tint = if (allPassed) tokens.statusActiveText else tokens.statusExpiredText,
                                        modifier = Modifier.size(26.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Kiểm thử công thức tài chính: $passCount/${uiState.goldenTestResults.size} PASS",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = if (allPassed) tokens.statusActiveText else tokens.statusExpiredText
                                        )
                                        Text(
                                            text = "Chạy độc lập trong bộ nhớ để xác minh độ chính xác của công thức phân bổ.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = if (allPassed) tokens.statusActiveText else tokens.statusExpiredText
                                        )
                                    }
                                }
                            }
                        }

                        items(uiState.goldenTestResults, key = { it.id }) { test ->
                            GoldenTestResultCard(test)
                        }
                    }
                }
            }
        }
    }

    if (showAddPackageDialog || packageToEdit != null) {
        PricingPackageDialog(
            existing = packageToEdit,
            onDismiss = {
                showAddPackageDialog = false
                packageToEdit = null
            },
            onSave = { pkg ->
                viewModel.savePricingPackage(pkg)
                showAddPackageDialog = false
                packageToEdit = null
            }
        )
    }

    if (pendingRestoreJson != null) {
        AlertDialog(
            onDismissRequest = {
                pendingRestoreJson = null
                pendingRestoreSummary = null
            },
            title = {
                Text(
                    if (pendingRestoreIsFromDrive) "Xác nhận khôi phục từ Google Drive?"
                    else "Xác nhận khôi phục & ghi đè dữ liệu?"
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = pendingRestoreSummary ?: "",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = tokens.statusActiveText
                    )
                    Text(
                        text = if (pendingRestoreIsFromDrive) {
                            "Hệ thống sẽ tự động tạo một bản sao lưu dự phòng an toàn trên máy trước khi khôi phục dữ liệu từ Google Drive. Bạn có chắc chắn muốn tiếp tục?"
                        } else {
                            "Cảnh báo: Thao tác này sẽ thay thế dữ liệu hiện tại bằng dữ liệu trong bản sao lưu. Bạn có chắc chắn muốn tiếp tục?"
                        },
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val json = pendingRestoreJson
                        val fromDrive = pendingRestoreIsFromDrive
                        pendingRestoreJson = null
                        pendingRestoreSummary = null
                        if (json != null) {
                            if (fromDrive) {
                                viewModel.confirmRestoreFromDriveJson(context, json)
                            } else {
                                viewModel.restoreBackupJson(json)
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = tokens.statusExpiredText, contentColor = Color.White)
                ) {
                    Text("Xác nhận Khôi phục")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        pendingRestoreJson = null
                        pendingRestoreSummary = null
                    }
                ) {
                    Text("Hủy")
                }
            }
        )
    }
}

@Composable
private fun SettingsCategoryCardItem(
    category: SettingsCategory,
    icon: ImageVector,
    badgeText: String,
    accentColor: Color,
    onClick: () -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = tokens.cardSurface,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
            .testTag("settings_category_${category.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(accentColor.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = category.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = tokens.textPrimary,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = accentColor.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)
                        ) {
                            Text(
                                text = badgeText,
                                style = MaterialTheme.typography.labelSmall,
                                color = accentColor,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                maxLines = 1
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = category.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.textSecondary
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Mở ${category.title}",
                tint = tokens.textSecondary
            )
        }
    }
}

@Composable
private fun PricingPackagesCategoryContent(
    uiState: AppUiState,
    gymAccent: Color,
    yogaAccent: Color,
    onAddPackage: () -> Unit,
    onEditPackage: (PricingPackageEntity) -> Unit,
    onDeletePackage: (PricingPackageEntity) -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = tokens.cardSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(gymAccent.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PriceChange,
                            contentDescription = null,
                            tint = gymAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Bảng giá & Gói tập GYM / YOGA",
                            style = MaterialTheme.typography.titleMedium,
                            color = tokens.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Các hợp đồng cũ luôn giữ nguyên mức giá và thời hạn đã ký.",
                            style = MaterialTheme.typography.bodySmall,
                            color = tokens.textSecondary
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onAddPackage,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GymPrimary,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Thêm gói", maxLines = 1)
                }
            }

            val groups = listOf(
                Triple(BoMon.GYM, DoiTuong.NAM, "Bảng giá GYM Nam"),
                Triple(BoMon.GYM, DoiTuong.NU, "Bảng giá GYM Nữ"),
                Triple(BoMon.GYM, DoiTuong.TRE_EM, "Bảng giá GYM Trẻ em"),
                Triple(BoMon.YOGA, DoiTuong.YOGA_CHUNG, "Bảng giá YOGA")
            )

            groups.forEach { (boMon, doiTuong, groupTitle) ->
                val pkgs = uiState.packages.filter { it.boMon == boMon && it.doiTuong == doiTuong }
                val accent = if (boMon == BoMon.YOGA) yogaAccent else gymAccent
                val groupIcon = if (boMon == BoMon.YOGA) Icons.Default.SelfImprovement else Icons.Default.FitnessCenter

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = tokens.elevatedSurface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, tokens.borderColor, RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = groupIcon,
                                contentDescription = null,
                                tint = accent,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = groupTitle,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = accent
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        pkgs.forEachIndexed { idx, pkg ->
                            val resolvedMonths = pkg.soThang ?: when (pkg.giaTien) {
                                500_000L -> 1
                                1_000_000L -> 2
                                1_500_000L -> 3
                                else -> null
                            }
                            val durationLabel = when {
                                resolvedMonths != null -> "Thời hạn: $resolvedMonths tháng"
                                pkg.soNgayTuyChinh != null -> "Thời hạn: ${pkg.soNgayTuyChinh} ngày"
                                else -> "Thời hạn: 1 tháng"
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = pkg.tenGoi,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = tokens.textPrimary,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = durationLabel,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = tokens.textSecondary
                                    )
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = DateUtils.formatVnd(pkg.giaTien),
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = accent
                                    )
                                    IconButton(
                                        onClick = { onEditPackage(pkg) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Edit,
                                            contentDescription = "Sửa gói ${pkg.tenGoi}",
                                            tint = tokens.textSecondary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { onDeletePackage(pkg) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.DeleteOutline,
                                            contentDescription = "Xóa gói ${pkg.tenGoi}",
                                            tint = tokens.statusExpiredText,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                            if (idx < pkgs.lastIndex) {
                                HorizontalDivider(color = tokens.dividerColor)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ThemeCategoryContent(
    uiState: AppUiState,
    primaryColor: Color,
    onSelectThemeMode: (ThemeModePreference) -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = tokens.cardSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(primaryColor.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Palette,
                        contentDescription = null,
                        tint = primaryColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Giao diện hiển thị (Cyber Fitness Theme)",
                        style = MaterialTheme.typography.titleMedium,
                        color = tokens.textPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Chuyển đổi tức thì giữa Light Mode, Dark Mode và Theo hệ thống. Báo cáo PDF A4 & Excel luôn giữ nền sáng chuẩn in ấn.",
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.textSecondary
                    )
                }
            }

            BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                val isWide = maxWidth >= 380.dp
                if (isWide) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ThemeModePreference.entries.forEach { mode ->
                            ThemeOptionTile(
                                mode = mode,
                                isSelected = uiState.themeMode == mode,
                                primaryColor = primaryColor,
                                onClick = { onSelectThemeMode(mode) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("theme_mode_${mode.configValue}")
                            )
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ThemeModePreference.entries.forEach { mode ->
                            ThemeOptionTile(
                                mode = mode,
                                isSelected = uiState.themeMode == mode,
                                primaryColor = primaryColor,
                                onClick = { onSelectThemeMode(mode) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("theme_mode_${mode.configValue}")
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LocalJsonBackupSectionCard(
    primaryColor: Color,
    onExportJson: () -> Unit,
    onShareJson: () -> Unit,
    onImportJson: () -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = tokens.cardSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(primaryColor.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Storage,
                        contentDescription = null,
                        tint = primaryColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Sao lưu & Khôi phục tệp JSON trên thiết bị",
                        style = MaterialTheme.typography.titleMedium,
                        color = tokens.textPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Bao gồm toàn bộ 9 bảng dữ liệu: Hội viên Gym & Yoga, Hợp đồng, Giao dịch, Bảng giá, Khách PT, Buổi tập PT, Khách lẻ, Cấu hình và Lịch sử.",
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.textSecondary
                    )
                }
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onExportJson,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GymPrimary,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_export_backup_json")
                ) {
                    Icon(Icons.Default.Backup, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Lưu file JSON", maxLines = 1)
                }

                OutlinedButton(
                    onClick = onShareJson,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Chia sẻ JSON", maxLines = 1)
                }
            }

            HorizontalDivider(color = tokens.dividerColor)

            Text(
                text = "Khôi phục từ tệp sao lưu JSON trên máy",
                style = MaterialTheme.typography.titleSmall,
                color = tokens.textPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Hệ thống kiểm tra tính hợp lệ của file sao lưu và yêu cầu xác nhận trước khi ghi đè dữ liệu.",
                style = MaterialTheme.typography.bodySmall,
                color = tokens.textSecondary
            )
            OutlinedButton(
                onClick = onImportJson,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_import_backup_json")
            ) {
                Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Chọn file JSON từ thiết bị để khôi phục", maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun TrashCategoryContent(
    uiState: AppUiState,
    viewModel: GymYogaViewModel
) {
    val tokens = LocalAppDesignTokens.current
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = tokens.cardSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(tokens.statusWarningBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.RestoreFromTrash,
                        contentDescription = null,
                        tint = tokens.statusWarningText,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Thùng rác & Khôi phục dữ liệu đã xóa",
                        style = MaterialTheme.typography.titleMedium,
                        color = tokens.textPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Dữ liệu xóa tạm thời có thể được khôi phục nguyên trạng bất cứ lúc nào.",
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.textSecondary
                    )
                }
            }

            if (uiState.deletedMembers.isEmpty() && uiState.deletedPtContracts.isEmpty() && uiState.deletedWalkInTickets.isEmpty()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = tokens.elevatedSurface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Thùng rác đang trống.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = tokens.textSecondary,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            } else {
                uiState.deletedMembers.forEach { m ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = tokens.elevatedSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, tokens.borderColor, RoundedCornerShape(12.dp))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "[Hội viên ${m.boMon}] #${m.stt} – ${m.hoTen}",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = tokens.textPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "SĐT: ${m.soDienThoai.ifBlank { "Chưa có" }}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = tokens.textSecondary
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                TextButton(onClick = { viewModel.restoreMember(m) }) {
                                    Icon(
                                        Icons.Default.Restore,
                                        contentDescription = null,
                                        tint = tokens.statusActiveText,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Khôi phục", color = tokens.statusActiveText, fontWeight = FontWeight.Bold)
                                }
                                IconButton(onClick = { viewModel.permanentlyDeleteMember(m) }) {
                                    Icon(
                                        Icons.Default.DeleteForever,
                                        contentDescription = "Xóa vĩnh viễn",
                                        tint = tokens.statusExpiredText
                                    )
                                }
                            }
                        }
                    }
                }

                uiState.deletedPtContracts.forEach { pt ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = tokens.elevatedSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, tokens.borderColor, RoundedCornerShape(12.dp))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "[PT Gym] #${pt.stt} – ${pt.hoTen} (${pt.goiPt})",
                                style = MaterialTheme.typography.titleSmall,
                                color = tokens.textPrimary,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = { viewModel.restorePtContract(pt) }) {
                                Text("Khôi phục", color = tokens.statusActiveText, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                uiState.deletedWalkInTickets.forEach { w ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = tokens.elevatedSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, tokens.borderColor, RoundedCornerShape(12.dp))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "[Khách lẻ] ${w.tenLoaiVe} – ${DateUtils.formatVnd(w.soTien)}",
                                style = MaterialTheme.typography.titleSmall,
                                color = tokens.textPrimary,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = { viewModel.restoreWalkInTicket(w) }) {
                                Text("Khôi phục", color = tokens.statusActiveText, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ThemeOptionTile(
    mode: ThemeModePreference,
    isSelected: Boolean,
    primaryColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalAppDesignTokens.current
    val icon = when (mode) {
        ThemeModePreference.LIGHT -> Icons.Default.LightMode
        ThemeModePreference.DARK -> Icons.Default.DarkMode
        ThemeModePreference.SYSTEM -> Icons.Default.SettingsBrightness
    }
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) {
            primaryColor.copy(alpha = if (tokens.isDark) 0.24f else 0.12f)
        } else {
            tokens.elevatedSurface
        },
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) primaryColor else tokens.borderColor,
                shape = RoundedCornerShape(12.dp)
            )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) primaryColor else tokens.textSecondary,
                modifier = Modifier.size(18.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = mode.shortLabelVi,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (isSelected) primaryColor else tokens.textPrimary,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = mode.labelVi,
                    style = MaterialTheme.typography.labelSmall,
                    color = tokens.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (isSelected) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Đang chọn",
                    tint = primaryColor,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun GoogleDriveBackupSectionCard(
    context: Context,
    uiState: AppUiState,
    onConnectGoogle: () -> Unit,
    onSwitchGoogleAccount: () -> Unit,
    onDisconnectGoogle: () -> Unit,
    onBackupNow: () -> Unit,
    onRefreshList: () -> Unit,
    onToggleAutoBackup: (Boolean) -> Unit,
    onCopyText: (String, String) -> Unit,
    onSelectBackupToRestore: (DriveBackupFileItem) -> Unit
) {
    val tokens = LocalAppDesignTokens.current
    val primaryColor = MaterialTheme.colorScheme.primary
    val hasSavedEmail = !uiState.googleAccountEmail.isNullOrBlank()
    val isConnected = uiState.isGoogleConnected
    var showOAuthGuide by remember { mutableStateOf(false) }
    val runtimeSha1 = remember(context) { GoogleDriveBackupManager.getAppSigningSha1(context) }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = tokens.cardSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, tokens.borderColor, RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isConnected) tokens.statusActiveBg
                                else primaryColor.copy(alpha = if (tokens.isDark) 0.22f else 0.12f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isConnected) Icons.Default.CloudDone else Icons.Default.CloudOff,
                            contentDescription = null,
                            tint = if (isConnected) tokens.statusActiveText else primaryColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Sao lưu đám mây Google Drive",
                            style = MaterialTheme.typography.titleMedium,
                            color = tokens.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Lưu trữ trong thư mục riêng 89_Fitness_Yoga_Backups trên Google Drive của bạn",
                            style = MaterialTheme.typography.bodySmall,
                            color = tokens.textSecondary
                        )
                    }
                }
                if (uiState.isDriveBusy) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.5.dp,
                        color = primaryColor
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = tokens.elevatedSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, tokens.borderColor, RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = null,
                                tint = if (hasSavedEmail) primaryColor else tokens.textSecondary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (hasSavedEmail) {
                                        uiState.googleAccountName?.takeIf { it.isNotBlank() } ?: uiState.googleAccountEmail!!
                                    } else {
                                        "Chưa kết nối tài khoản Google"
                                    },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = tokens.textPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = when {
                                        isConnected -> "${uiState.googleAccountEmail} • Đã kết nối Drive"
                                        hasSavedEmail -> "${uiState.googleAccountEmail} • Cần bấm kết nối lại phiên làm việc"
                                        else -> "Hỗ trợ đăng nhập và chọn bất kỳ tài khoản Google nào trên thiết bị"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isConnected) tokens.statusActiveText else tokens.textSecondary
                                )
                            }
                        }

                        if (hasSavedEmail) {
                            IconButton(
                                onClick = onDisconnectGoogle,
                                enabled = !uiState.isDriveBusy,
                                modifier = Modifier.testTag("btn_disconnect_google_drive")
                            ) {
                                Icon(
                                    Icons.Default.Logout,
                                    contentDescription = "Đăng xuất Google Drive",
                                    tint = tokens.statusExpiredText,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    if (!uiState.lastDriveBackupTime.isNullOrBlank()) {
                        Text(
                            text = "Lần sao lưu gần nhất lên Drive: ${uiState.lastDriveBackupTime}",
                            style = MaterialTheme.typography.labelSmall,
                            color = primaryColor,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    if (!uiState.driveStatusMessage.isNullOrBlank()) {
                        Text(
                            text = uiState.driveStatusMessage,
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.textSecondary
                        )
                    }
                }
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (!isConnected) {
                    Button(
                        onClick = onConnectGoogle,
                        enabled = !uiState.isDriveBusy,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GymPrimary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("btn_connect_google_drive")
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (hasSavedEmail) "Kết nối lại Drive" else "Đăng nhập Google Drive",
                            maxLines = 1
                        )
                    }
                    OutlinedButton(
                        onClick = onSwitchGoogleAccount,
                        enabled = !uiState.isDriveBusy,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(0.9f)
                            .testTag("btn_switch_google_account")
                    ) {
                        Icon(Icons.Default.ManageAccounts, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Chọn tài khoản", maxLines = 1)
                    }
                } else {
                    Button(
                        onClick = onBackupNow,
                        enabled = !uiState.isDriveBusy,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GymPrimary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("btn_backup_to_drive_now")
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Sao lưu lên Drive", maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = onRefreshList,
                        enabled = !uiState.isDriveBusy,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(0.75f)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Làm mới", maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = onSwitchGoogleAccount,
                        enabled = !uiState.isDriveBusy,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(0.95f)
                            .testTag("btn_switch_google_account")
                    ) {
                        Icon(Icons.Default.ManageAccounts, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Đổi tài khoản", maxLines = 1)
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Tự động sao lưu định kỳ khi có mạng",
                        style = MaterialTheme.typography.bodyMedium,
                        color = tokens.textPrimary,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Tự động đồng bộ bản sao lưu mới lên thư mục Google Drive",
                        style = MaterialTheme.typography.labelSmall,
                        color = tokens.textSecondary
                    )
                }
                Switch(
                    checked = uiState.autoDriveBackupEnabled,
                    onCheckedChange = onToggleAutoBackup
                )
            }

            // Chẩn đoán cấu hình Google OAuth & SHA-1 thực tế cho mọi tài khoản (Section 9.1)
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = tokens.elevatedSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { showOAuthGuide = !showOAuthGuide }
                    .border(1.dp, tokens.borderColor, RoundedCornerShape(10.dp))
                    .testTag("oauth_diagnostic_card")
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = primaryColor,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Chẩn đoán cấu hình Google OAuth & SHA-1 (Cho mọi tài khoản)",
                                style = MaterialTheme.typography.labelMedium,
                                color = primaryColor,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = if (showOAuthGuide) "Thu gọn" else "Xem chi tiết",
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.textSecondary
                        )
                    }

                    if (showOAuthGuide) {
                        Text(
                            text = "Thông số thực tế của APK đang chạy trên thiết bị này:",
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.textSecondary
                        )
                        Text(
                            text = "• Package Name: ${context.packageName}\n• SHA-1 Fingerprint: $runtimeSha1\n• Scope: ${GoogleDriveBackupManager.DRIVE_FILE_SCOPE}",
                            style = MaterialTheme.typography.bodySmall,
                            color = tokens.textPrimary,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Lưu ý để mọi tài khoản Gmail đều đăng nhập được: Trên Google Cloud Console > OAuth consent screen, hãy chuyển Publishing status sang 'In production' (Đã xuất bản) và tạo Android OAuth Client ID khớp với Package Name + SHA-1 ở trên.",
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.textSecondary
                        )
                        OutlinedButton(
                            onClick = {
                                val summary = "Package: ${context.packageName}\nSHA-1: $runtimeSha1\nScope: ${GoogleDriveBackupManager.DRIVE_FILE_SCOPE}"
                                onCopyText("cấu hình OAuth & SHA-1", summary)
                            },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Sao chép Package Name & SHA-1", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            if (uiState.driveBackups.isNotEmpty()) {
                HorizontalDivider(color = tokens.dividerColor)
                Text(
                    text = "Các bản sao lưu trên Google Drive (${uiState.driveBackups.size})",
                    style = MaterialTheme.typography.titleSmall,
                    color = tokens.textPrimary,
                    fontWeight = FontWeight.Bold
                )
                uiState.driveBackups.take(8).forEach { item ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = tokens.elevatedSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, tokens.borderColor, RoundedCornerShape(10.dp))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.name,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = tokens.textPrimary,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                val kbSize = (item.sizeBytes / 1024L).coerceAtLeast(1L)
                                Text(
                                    text = "Tạo lúc: ${item.createdTimeDisplay} • ${kbSize} KB",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = tokens.textSecondary
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            OutlinedButton(
                                onClick = { onSelectBackupToRestore(item) },
                                enabled = !uiState.isDriveBusy,
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    Icons.Default.CloudDownload,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Khôi phục", style = MaterialTheme.typography.labelSmall, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GoldenTestResultCard(test: GoldenTestCaseResult) {
    val tokens = LocalAppDesignTokens.current
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = tokens.cardSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (test.passed) tokens.borderColor else tokens.statusExpiredText,
                RoundedCornerShape(14.dp)
            )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = test.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = tokens.textPrimary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (test.passed) tokens.statusActiveBg else tokens.statusExpiredBg)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (test.passed) "PASS" else "FAIL",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (test.passed) tokens.statusActiveText else tokens.statusExpiredText,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = test.description,
                style = MaterialTheme.typography.bodySmall,
                color = tokens.textSecondary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Kỳ vọng: ${test.expectedDisplay}",
                style = MaterialTheme.typography.labelSmall,
                color = tokens.textSecondary
            )
            Text(
                text = "Thực tế: ${test.actualDisplay}",
                style = MaterialTheme.typography.labelMedium,
                color = if (test.passed) tokens.statusActiveText else tokens.statusExpiredText,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun PricingPackageDialog(
    existing: PricingPackageEntity?,
    onDismiss: () -> Unit,
    onSave: (PricingPackageEntity) -> Unit
) {
    var boMon by remember { mutableStateOf(existing?.boMon ?: BoMon.GYM) }
    var doiTuong by remember {
        mutableStateOf(
            existing?.doiTuong ?: if (boMon == BoMon.YOGA) DoiTuong.YOGA_CHUNG else DoiTuong.NAM
        )
    }
    var tenGoi by remember { mutableStateOf(existing?.tenGoi ?: "") }
    val initialMonths = existing?.soThang ?: if (existing?.boMon == BoMon.YOGA) {
        when (existing.giaTien) {
            500_000L -> 1
            1_000_000L -> 2
            1_500_000L -> 3
            else -> 1
        }
    } else 1
    var soThangText by remember { mutableStateOf(initialMonths.toString()) }
    var soNgayText by remember { mutableStateOf(existing?.soNgayTuyChinh?.toString() ?: "") }
    var giaTienText by remember { mutableStateOf((existing?.giaTien ?: 500_000L).toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Thêm gói tập mới" else "Chỉnh sửa gói tập & thời hạn") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = boMon == BoMon.GYM,
                        onClick = {
                            boMon = BoMon.GYM
                            doiTuong = DoiTuong.NAM
                        },
                        label = { Text("GYM") }
                    )
                    FilterChip(
                        selected = boMon == BoMon.YOGA,
                        onClick = {
                            boMon = BoMon.YOGA
                            doiTuong = DoiTuong.YOGA_CHUNG
                        },
                        label = { Text("YOGA") }
                    )
                }

                if (boMon == BoMon.GYM) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            DoiTuong.NAM to "Nam",
                            DoiTuong.NU to "Nữ",
                            DoiTuong.TRE_EM to "Trẻ em"
                        ).forEach { (code, label) ->
                            FilterChip(
                                selected = doiTuong == code,
                                onClick = { doiTuong = code },
                                label = { Text(label) }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = tenGoi,
                    onValueChange = { tenGoi = it },
                    label = { Text("Tên gói tập *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = soThangText,
                        onValueChange = { soThangText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số tháng") },
                        placeholder = { Text("VD: 1, 2, 3, 12") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = soNgayText,
                        onValueChange = { soNgayText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Hoặc số ngày") },
                        placeholder = { Text("Tùy chọn") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = giaTienText,
                    onValueChange = { giaTienText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Đơn giá (VNĐ) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val price = giaTienText.toLongOrNull() ?: 0L
                    val months = soThangText.toIntOrNull()?.takeIf { it > 0 }
                    val days = soNgayText.toIntOrNull()?.takeIf { it > 0 }
                    if (tenGoi.isNotBlank() && price > 0L) {
                        val pkg = PricingPackageEntity(
                            id = existing?.id ?: "PKG_${boMon}_${UUID.randomUUID().toString().take(6).uppercase()}",
                            boMon = boMon,
                            doiTuong = if (boMon == BoMon.YOGA) DoiTuong.YOGA_CHUNG else doiTuong,
                            tenGoi = tenGoi.trim(),
                            soThang = months ?: if (days == null) 1 else null,
                            soNgayTuyChinh = days,
                            giaTien = price,
                            thuTuHienThi = existing?.thuTuHienThi ?: 99,
                            dangHoatDong = true
                        )
                        onSave(pkg)
                    }
                }
            ) {
                Text("Lưu gói tập")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hủy") }
        }
    )
}
