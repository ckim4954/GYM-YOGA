package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// --- GYM Light Theme Tokens (Modern Cyber Fitness - High Contrast Daylight) ---
val GymPrimary = Color(0xFF0F4C81)         // Deep Electric Blue / Navy
val GymPrimaryDark = Color(0xFF0A355C)
val GymSecondary = Color(0xFF0284C7)       // Metallic Blue
val GymPrimaryLight = Color(0xFFE0F2FE)
val GymBackground = Color(0xFFF4F6F9)      // Cool Light Gray
val GymSurface = Color(0xFFFFFFFF)         // Pure White
val GymTextPrimary = Color(0xFF0F172A)     // Deep Slate Ink
val GymTextSecondary = Color(0xFF475569)   // Muted Slate
val GymBorder = Color(0xFFCBD5E1)          // Crisp Light Gray Border

// --- YOGA Light Theme Tokens (Modern Cyber Fitness - Violet & Soft Lavender) ---
val YogaPrimary = Color(0xFF6B2FB5)        // Deep Cyber Violet
val YogaPrimaryDark = Color(0xFF4C1D95)
val YogaSecondary = Color(0xFF8B5CF6)      // Cyber Purple
val YogaPrimaryLight = Color(0xFFF3E8FF)   // Soft Lavender
val YogaBackground = Color(0xFFF7F4FA)     // Warm Lavender Gray
val YogaSurface = Color(0xFFFFFFFF)        // Pure White
val YogaTextPrimary = Color(0xFF1E142B)    // Deep Plum Ink
val YogaTextSecondary = Color(0xFF5B4E6B)  // Muted Violet Gray
val YogaBorder = Color(0xFFDDD3E8)         // Subtle Lavender Border

// --- Dark Mode Cyber Navy Layered Tokens (Section IV & V) ---
val DarkGymPrimary = Color(0xFF2997FF)            // Electric Blue
val DarkGymPrimaryContainer = Color(0xFF132F4C)   // Deep Navy Container
val DarkGymSecondary = Color(0xFF00D2FF)          // Metallic Cyan Blue
val DarkGymBackground = Color(0xFF0A0F18)         // Dark Navy Background
val DarkGymSurface = Color(0xFF111927)            // Navy Blue Surface
val DarkGymCardSurface = Color(0xFF182334)        // Multi-layered Dark Slate Card
val DarkGymTextPrimary = Color(0xFFF1F5F9)        // Crisp Ice White
val DarkGymTextSecondary = Color(0xFF94A3B8)      // Metallic Slate Gray
val DarkGymBorder = Color(0xFF26354D)             // Subtle Cyber Navy Border

val DarkYogaPrimary = Color(0xFFB366FF)           // Cyber Purple
val DarkYogaPrimaryContainer = Color(0xFF2D1948)  // Deep Violet Container
val DarkYogaSecondary = Color(0xFFD4A5FF)         // Soft Lavender
val DarkYogaBackground = Color(0xFF0E0B16)        // Dark Violet Navy Background
val DarkYogaSurface = Color(0xFF171224)           // Deep Plum Navy Surface
val DarkYogaCardSurface = Color(0xFF201931)       // Multi-layered Cyber Violet Card
val DarkYogaTextPrimary = Color(0xFFF5F0FF)       // Crisp Lavender White
val DarkYogaTextSecondary = Color(0xFFA799B7)     // Muted Lavender Gray
val DarkYogaBorder = Color(0xFF35284D)            // Subtle Cyber Violet Border

// --- Status Colors (Light Mode - High Contrast) ---
val StatusActiveGreen = Color(0xFF059669)         // Emerald Green
val StatusActiveGreenBg = Color(0xFFD1FAE5)

val StatusExpiring15Amber = Color(0xFFD97706)     // Amber
val StatusExpiring15AmberBg = Color(0xFFFEF3C7)

val StatusExpiring7Orange = Color(0xFFEA580C)     // Urgent Amber-Orange
val StatusExpiring7OrangeBg = Color(0xFFFFEDD5)

val StatusExpiringTodayOrange = Color(0xFFDC2626)
val StatusExpiringTodayOrangeBg = Color(0xFFFEE2E2)

val StatusExpiredRed = Color(0xFFDC2626)          // Crimson Red
val StatusExpiredRedBg = Color(0xFFFEE2E2)

val StatusInfoBlue = Color(0xFF0284C7)
val StatusInfoBlueBg = Color(0xFFE0F2FE)

// --- Status Colors (Dark Mode - Emerald, Amber, Red on Dark Navy) ---
val DarkStatusActiveGreen = Color(0xFF34D399)     // Emerald Green
val DarkStatusActiveGreenBg = Color(0xFF0E2E24)

val DarkStatusExpiringAmber = Color(0xFFFBBF24)   // Cyber Amber
val DarkStatusExpiringAmberBg = Color(0xFF33240C)

val DarkStatusExpiringOrange = Color(0xFFFB923C)
val DarkStatusExpiringOrangeBg = Color(0xFF381E10)

val DarkStatusExpiredRed = Color(0xFFF87171)      // Crimson Neon Red
val DarkStatusExpiredRedBg = Color(0xFF381519)

val DarkStatusInfoBlue = Color(0xFF38BDF8)
val DarkStatusInfoBlueBg = Color(0xFF0F293D)

val RevenuePrimary = Color(0xFF0F4C81)
val RevenuePrimaryDark = Color(0xFF0A355C)
