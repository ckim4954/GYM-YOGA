package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// GYM Palette (Phần 3.2)
val GymPrimary = Color(0xFF1565C0)
val GymPrimaryDark = Color(0xFF0D47A1)
val GymPrimaryLight = Color(0xFFE3F2FD)
val GymBackground = Color(0xFFF5F7FB)
val GymSurface = Color(0xFFFFFFFF)

// YOGA Palette (Phần 3.2)
val YogaPrimary = Color(0xFF7B1FA2)
val YogaPrimaryDark = Color(0xFF4A148C)
val YogaPrimaryLight = Color(0xFFF3E5F5)
val YogaBackground = Color(0xFFF8F5FC)
val YogaSurface = Color(0xFFFFFFFF)

// Revenue & Tracking Accents
val RevenuePrimary = Color(0xFF0F766E)
val RevenuePrimaryDark = Color(0xFF115E59)
val RevenuePrimaryLight = Color(0xFFCCFBF1)
val RevenueBackground = Color(0xFFF4F7F9)

val TrackingPrimary = Color(0xFF1E293B)
val TrackingPrimaryDark = Color(0xFF0F172A)

// Status Colors (Phần 3.2 & Phần 8.2)
val StatusActiveGreen = Color(0xFF15803D)
val StatusActiveGreenBg = Color(0xFFDCFCE7)

val StatusExpiring15Amber = Color(0xFFB45309)
val StatusExpiring15AmberBg = Color(0xFFFEF3C7)

val StatusExpiring7Orange = Color(0xFFC2410C)
val StatusExpiring7OrangeBg = Color(0xFFFFEDD5)

val StatusExpiringTodayOrange = Color(0xFFEA580C)
val StatusExpiringTodayOrangeBg = Color(0xFFFFEDD5)

val StatusExpiredRed = Color(0xFFB91C1C)
val StatusExpiredRedBg = Color(0xFFFEE2E2)

val StatusInactiveGray = Color(0xFF64748B)
val StatusInactiveGrayBg = Color(0xFFF1F5F9)

// Neutral & Dark Mode tokens
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
