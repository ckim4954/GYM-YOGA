package com.example.domain

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Calendar
import java.util.Locale

/**
 * Immutable calendar date (1-indexed month 1..12, day 1..31) with exact Gregorian
 * calendar arithmetic (28/29/30/31 days per month, 365/366 days per year).
 * Stored in DB as ISO "YYYY-MM-DD" and displayed on UI as "dd/MM/yyyy".
 */
data class LocalDateSpec(
    val year: Int,
    val month: Int,
    val day: Int
) : Comparable<LocalDateSpec> {

    override fun compareTo(other: LocalDateSpec): Int {
        if (year != other.year) return year.compareTo(other.year)
        if (month != other.month) return month.compareTo(other.month)
        return day.compareTo(other.day)
    }

    fun toIsoString(): String = String.format(Locale.US, "%04d-%02d-%02d", year, month, day)

    fun toDisplayString(): String = String.format(Locale.US, "%02d/%02d/%04d", day, month, year)

    /**
     * Exact epoch day calculation (Howard Hinnant civil_from_days / days_from_civil algorithm,
     * identical to java.time.LocalDate.toEpochDay).
     */
    fun toEpochDay(): Long {
        val y = year.toLong() - if (month <= 2) 1L else 0L
        val era = if (y >= 0) y / 400L else (y - 399L) / 400L
        val yoe = y - era * 400L // [0, 399]
        val m = month.toLong()
        val doy = (153L * (m + if (m > 2) -3L else 9L) + 2L) / 5L + day.toLong() - 1L // [0, 365]
        val doe = yoe * 365L + yoe / 4L - yoe / 100L + doy // [0, 146096]
        return era * 146097L + doe - 719468L
    }

    fun plusDays(daysToAdd: Int): LocalDateSpec {
        if (daysToAdd == 0) return this
        return fromEpochDay(toEpochDay() + daysToAdd.toLong())
    }

    fun minusDays(daysToSubtract: Int): LocalDateSpec = plusDays(-daysToSubtract)

    fun plusMonths(monthsToAdd: Int): LocalDateSpec {
        if (monthsToAdd == 0) return this
        val totalMonths = (year * 12 + (month - 1)) + monthsToAdd
        val newYear = Math.floorDiv(totalMonths, 12)
        val newMonth = Math.floorMod(totalMonths, 12) + 1
        val maxDay = DateUtils.daysInMonth(newYear, newMonth)
        val newDay = day.coerceAtMost(maxDay)
        return LocalDateSpec(newYear, newMonth, newDay)
    }

    companion object {
        fun fromEpochDay(epochDay: Long): LocalDateSpec {
            val z = epochDay + 719468L
            val era = if (z >= 0) z / 146097L else (z - 146096L) / 146097L
            val doe = z - era * 146097L // [0, 146096]
            val yoe = (doe - doe / 1460L + doe / 36524L - doe / 146096L) / 365L // [0, 399]
            val y = yoe + era * 400L
            val doy = doe - (365L * yoe + yoe / 4L - yoe / 100L) // [0, 365]
            val mp = (5L * doy + 2L) / 153L // [0, 11]
            val d = (doy - (153L * mp + 2L) / 5L + 1L).toInt() // [1, 31]
            val m = (mp + if (mp < 10L) 3L else -9L).toInt() // [1, 12]
            val finalYear = (y + if (m <= 2) 1L else 0L).toInt()
            return LocalDateSpec(finalYear, m, d)
        }

        fun today(): LocalDateSpec {
            val cal = Calendar.getInstance()
            return LocalDateSpec(
                year = cal.get(Calendar.YEAR),
                month = cal.get(Calendar.MONTH) + 1,
                day = cal.get(Calendar.DAY_OF_MONTH)
            )
        }

        fun parseIso(iso: String): LocalDateSpec? {
            val trimmed = iso.trim()
            if (trimmed.isEmpty()) return null
            // Accept both YYYY-MM-DD and dd/MM/yyyy gracefully
            if (trimmed.contains("/")) return parseDisplay(trimmed)
            val parts = trimmed.split("-")
            if (parts.size != 3) return null
            val y = parts[0].toIntOrNull() ?: return null
            val m = parts[1].toIntOrNull() ?: return null
            val d = parts[2].toIntOrNull() ?: return null
            if (!DateUtils.isValidDate(y, m, d)) return null
            return LocalDateSpec(y, m, d)
        }

        fun parseDisplay(display: String): LocalDateSpec? {
            val trimmed = display.trim()
            if (trimmed.isEmpty()) return null
            if (trimmed.contains("-")) return parseIso(trimmed)
            val parts = trimmed.split("/")
            if (parts.size != 3) return null
            val d = parts[0].toIntOrNull() ?: return null
            val m = parts[1].toIntOrNull() ?: return null
            val y = parts[2].toIntOrNull() ?: return null
            if (!DateUtils.isValidDate(y, m, d)) return null
            return LocalDateSpec(y, m, d)
        }
    }
}

object DateUtils {
    fun isLeapYear(year: Int): Boolean {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)
    }

    fun daysInMonth(year: Int, month: Int): Int {
        return when (month) {
            1, 3, 5, 7, 8, 10, 12 -> 31
            4, 6, 9, 11 -> 30
            2 -> if (isLeapYear(year)) 29 else 28
            else -> 30
        }
    }

    fun isValidDate(year: Int, month: Int, day: Int): Boolean {
        if (year !in 1970..2100) return false
        if (month !in 1..12) return false
        val maxDay = daysInMonth(year, month)
        return day in 1..maxDay
    }

    /**
     * Returns exact number of days in half-open interval [startInclusive, endExclusive).
     */
    fun daysBetween(startInclusive: LocalDateSpec, endExclusive: LocalDateSpec): Int {
        return (endExclusive.toEpochDay() - startInclusive.toEpochDay()).toInt()
    }

    /**
     * Given inclusive start date and exclusive end date, returns the displayed
     * "Ngày hết hạn cuối cùng được tập" = endExclusive - 1 day (Phần 12.1).
     */
    fun toDisplayedLastTrainingDate(endExclusive: LocalDateSpec): LocalDateSpec {
        return endExclusive.minusDays(1)
    }

    /**
     * Given displayed "Ngày hết hạn cuối cùng được tập", returns the internal
     * exclusive end date = displayedLastDay + 1 day (Phần 12.1).
     */
    fun toExclusiveEndDate(displayedLastTrainingDate: LocalDateSpec): LocalDateSpec {
        return displayedLastTrainingDate.plusDays(1)
    }

    fun isoToDisplay(iso: String): String {
        return LocalDateSpec.parseIso(iso)?.toDisplayString() ?: iso
    }

    fun displayToIso(display: String): String? {
        return LocalDateSpec.parseDisplay(display)?.toIsoString()
    }

    fun formatVnd(amount: Long, withUnit: Boolean = true): String {
        val symbols = DecimalFormatSymbols(Locale.US).apply {
            groupingSeparator = '.'
            decimalSeparator = ','
        }
        val formatter = DecimalFormat("#,###", symbols)
        val formatted = formatter.format(amount)
        return if (withUnit) "${formatted}đ" else formatted
    }
}
