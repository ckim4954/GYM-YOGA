package com.example.domain

import com.example.data.local.BoMon
import com.example.data.local.MemberContractEntity
import com.example.data.local.MemberEntity
import com.example.data.local.PaymentTransactionEntity
import com.example.data.local.PtContractEntity
import com.example.data.local.WalkInTicketEntity
import java.util.Locale
import kotlin.math.roundToLong

/**
 * Member status classification for THEO DÕI (Phần 8.2):
 * 1. Còn hạn trên 15 ngày (ACTIVE_OVER_15)
 * 2. Sắp hết hạn từ 8–15 ngày (EXPIRING_8_TO_15)
 * 3. Sắp hết hạn từ 1–7 ngày (EXPIRING_1_TO_7)
 * 4. Hôm nay hết hạn (EXPIRING_TODAY)
 * 5. Đã hết hạn (EXPIRED)
 */
enum class MemberTrackingStatus(val labelVi: String, val sortPriority: Int) {
    EXPIRING_TODAY("Hôm nay hết hạn", 1),
    EXPIRING_1_TO_7("Sắp hết hạn (1–7 ngày)", 2),
    EXPIRING_8_TO_15("Sắp hết hạn (8–15 ngày)", 3),
    ACTIVE_OVER_15("Còn hạn (> 15 ngày)", 4),
    EXPIRED("Đã hết hạn", 5)
}

data class MonthlyContractAllocationResult(
    val year: Int,
    val month: Int,
    val daysInMonth: Int,
    val totalContractDays: Int,
    val allocatedAmount: Long,
    val isLastMonthOfContract: Boolean
)

data class PtSessionAllocationResult(
    val totalSessionsInContract: Int,
    val contractTotalAmount: Long,
    val centerPercent: Int,
    val ptPercent: Int,
    val sessionsUsedInMonth: Int,
    val valuePerSession: Double,
    val centerAllocatedRevenue: Long,
    val ptAllocatedShare: Long,
    val totalAllocatedInMonth: Long
)

data class CashFlowTransactionRecord(
    val id: String,
    val boMon: String, // "GYM", "YOGA", hoặc "CHUA_XAC_DINH"
    val customerName: String,
    val serviceName: String,
    val paymentContent: String,
    val ngayThanhToanIso: String,
    val ngayThanhToanDisplay: String,
    val amount: Long,
    val categoryLabel: String, // "Hội viên GYM", "PT GYM", "Khách lẻ GYM", "Hội viên YOGA", "Thu khác YOGA"
    val title: String,
    val subtitle: String
)

data class MonthlyCashFlowSummaryResult(
    val year: Int,
    val month: Int,
    // A1. DOANH THU DÒNG TIỀN GYM
    val cashFlowMemberGym: Long,
    val cashFlowPtGym: Long,
    val cashFlowWalkInGym: Long,
    val totalCashFlowGym: Long,
    val gymTransactionCount: Int,
    val gymTransactions: List<CashFlowTransactionRecord>,
    // A2. DOANH THU DÒNG TIỀN YOGA
    val cashFlowMemberYoga: Long,
    val cashFlowOtherYoga: Long,
    val totalCashFlowYoga: Long,
    val yogaTransactionCount: Int,
    val yogaTransactions: List<CashFlowTransactionRecord>,
    // TỔNG THỰC THU TOÀN TRUNG TÂM = Thực thu GYM + Thực thu YOGA
    val totalCashFlowCenter: Long,
    val totalCenterTransactionCount: Int,
    // Giao dịch chưa đủ căn cứ xác định bộ môn (nếu có trong dữ liệu cũ)
    val unclassifiedTransactions: List<CashFlowTransactionRecord>
)

data class GoldenTestCaseResult(
    val id: Int,
    val title: String,
    val description: String,
    val expectedDisplay: String,
    val actualDisplay: String,
    val passed: Boolean
)

/**
 * Financial & Business Logic Engine implementing Parts 7, 8, 9, 10, 11, 12, 13, and 18.
 */
object FinancialEngine {

    /**
     * Phần 7.1: Quy tắc gia hạn
     * Given the previous contract's exclusive end date (where last training day = oldEndExclusive - 1)
     * and the registration/renewal date:
     * - Trường hợp 1: Gia hạn trước ngày hết hạn (renewalDate < oldEndExclusive)
     *   -> Hợp đồng mới bắt đầu nối tiếp ngay sau ngày cuối cùng được tập của hợp đồng cũ (= oldEndExclusive).
     * - Trường hợp 2: Gia hạn đúng ngày bắt đầu chu kỳ tiếp theo (renewalDate == oldEndExclusive)
     *   -> Hợp đồng mới bắt đầu ngày oldEndExclusive.
     * - Trường hợp 3: Đã hết hạn và nghỉ một khoảng thời gian (renewalDate > oldEndExclusive)
     *   -> Hợp đồng mới bắt đầu từ ngày đăng ký lại/thanh toán thực tế (renewalDate).
     */
    fun calculateRenewalStartDate(
        previousEndExclusive: LocalDateSpec?,
        renewalDate: LocalDateSpec
    ): LocalDateSpec {
        if (previousEndExclusive == null) return renewalDate
        return if (renewalDate <= previousEndExclusive) {
            previousEndExclusive
        } else {
            renewalDate
        }
    }

    /**
     * Calculates default exclusive end date from startDate and package duration (months or days).
     */
    fun calculateExclusiveEndDate(
        startDate: LocalDateSpec,
        months: Int?,
        customDays: Int? = null
    ): LocalDateSpec {
        if (customDays != null && customDays > 0) {
            return startDate.plusDays(customDays)
        }
        val m = months ?: 1
        return if (m > 0) startDate.plusMonths(m) else startDate.plusMonths(1)
    }

    /**
     * Phần 8.2: Phân loại trạng thái hội viên dựa trên ngày hiện tại (today) và
     * ngày hết hạn cuối cùng được tập (lastTrainingDate = endExclusive - 1 day).
     *
     * remainingDays = daysBetween(today, endExclusive) - 1 = (lastTrainingDate - today) in days:
     * - If lastTrainingDate < today (remainingDays < 0): Đã hết hạn (EXPIRED)
     * - If lastTrainingDate == today (remainingDays == 0): Hôm nay hết hạn (EXPIRING_TODAY)
     * - If remainingDays in 1..7: Sắp hết hạn từ 1–7 ngày (EXPIRING_1_TO_7)
     * - If remainingDays in 8..15: Sắp hết hạn từ 8–15 ngày (EXPIRING_8_TO_15)
     * - If remainingDays > 15: Còn hạn trên 15 ngày (ACTIVE_OVER_15)
     *
     * Note on remaining days display:
     * When today == lastTrainingDate, 0 days after today (Hôm nay hết hạn).
     * When lastTrainingDate > today, remainingDays = (lastTrainingDate.toEpochDay() - today.toEpochDay()).
     */
    fun evaluateTrackingStatus(
        today: LocalDateSpec,
        endExclusive: LocalDateSpec
    ): Pair<MemberTrackingStatus, Int> {
        val lastTrainingDate = DateUtils.toDisplayedLastTrainingDate(endExclusive)
        val diffDays = (lastTrainingDate.toEpochDay() - today.toEpochDay()).toInt()
        val status = when {
            diffDays < 0 -> MemberTrackingStatus.EXPIRED
            diffDays == 0 -> MemberTrackingStatus.EXPIRING_TODAY
            diffDays in 1..7 -> MemberTrackingStatus.EXPIRING_1_TO_7
            diffDays in 8..15 -> MemberTrackingStatus.EXPIRING_8_TO_15
            else -> MemberTrackingStatus.ACTIVE_OVER_15
        }
        return status to diffDays
    }

    /**
     * Phần 12: Công thức doanh thu phân bổ hội viên (và vé tuần lẻ trải qua nhiều tháng).
     *
     * Interval: [startDate, endExclusive)
     * Total days = endExclusive - startDate
     *
     * Rounding rule (Phần 12.4):
     * - Các tháng đầu và tháng giữa: Math.round(contractAmount * daysInMonth / totalDays)
     * - Tháng cuối cùng: lấy tổng giá trị hợp đồng trừ tổng doanh thu đã phân bổ ở các tháng trước
     *   (tính theo tổng số ngày trước tháng cuối: contractAmount - Math.round(contractAmount * daysBeforeLastMonth / totalDays)),
     *   đảm bảo tổng phân bổ không vượt hoặc thiếu so với giá trị hợp đồng.
     */
    fun calculateMonthlyAllocatedRevenue(
        startDate: LocalDateSpec,
        endExclusive: LocalDateSpec,
        contractAmount: Long,
        targetYear: Int,
        targetMonth: Int
    ): MonthlyContractAllocationResult {
        val totalDays = DateUtils.daysBetween(startDate, endExclusive)
        if (totalDays <= 0 || contractAmount <= 0L) {
            return MonthlyContractAllocationResult(
                year = targetYear,
                month = targetMonth,
                daysInMonth = 0,
                totalContractDays = totalDays.coerceAtLeast(0),
                allocatedAmount = 0L,
                isLastMonthOfContract = false
            )
        }

        val monthStart = LocalDateSpec(targetYear, targetMonth, 1)
        val monthEndExclusive = monthStart.plusMonths(1)

        val overlapStart = if (startDate > monthStart) startDate else monthStart
        val overlapEnd = if (endExclusive < monthEndExclusive) endExclusive else monthEndExclusive
        val daysInMonth = DateUtils.daysBetween(overlapStart, overlapEnd).coerceAtLeast(0)

        if (daysInMonth == 0) {
            return MonthlyContractAllocationResult(
                year = targetYear,
                month = targetMonth,
                daysInMonth = 0,
                totalContractDays = totalDays,
                allocatedAmount = 0L,
                isLastMonthOfContract = false
            )
        }

        // Check if targetMonth is the final month containing active days of the contract
        val lastActiveDate = endExclusive.minusDays(1)
        val isLastMonth = (lastActiveDate.year == targetYear && lastActiveDate.month == targetMonth)
        val isSingleMonth = (startDate.year == targetYear && startDate.month == targetMonth && isLastMonth)

        val allocated = when {
            isSingleMonth -> contractAmount
            isLastMonth -> {
                val daysBeforeThisMonth = DateUtils.daysBetween(startDate, monthStart).coerceAtLeast(0)
                val previouslyAllocated = (contractAmount.toDouble() * daysBeforeThisMonth.toDouble() / totalDays.toDouble()).roundToLong()
                (contractAmount - previouslyAllocated).coerceAtLeast(0L)
            }
            else -> {
                (contractAmount.toDouble() * daysInMonth.toDouble() / totalDays.toDouble()).roundToLong()
            }
        }

        return MonthlyContractAllocationResult(
            year = targetYear,
            month = targetMonth,
            daysInMonth = daysInMonth,
            totalContractDays = totalDays,
            allocatedAmount = allocated,
            isLastMonthOfContract = isLastMonth
        )
    }

    /**
     * Generates the complete month-by-month allocation schedule for a contract [startDate, endExclusive)
     * guaranteeing that the sum of all monthly allocations equals contractAmount.
     */
    fun generateFullContractSchedule(
        startDate: LocalDateSpec,
        endExclusive: LocalDateSpec,
        contractAmount: Long
    ): List<MonthlyContractAllocationResult> {
        val totalDays = DateUtils.daysBetween(startDate, endExclusive)
        if (totalDays <= 0 || contractAmount <= 0L) return emptyList()

        val results = mutableListOf<MonthlyContractAllocationResult>()
        var cursor = LocalDateSpec(startDate.year, startDate.month, 1)
        val lastDay = endExclusive.minusDays(1)
        val endMonthCursor = LocalDateSpec(lastDay.year, lastDay.month, 1)

        while (cursor <= endMonthCursor) {
            val res = calculateMonthlyAllocatedRevenue(
                startDate = startDate,
                endExclusive = endExclusive,
                contractAmount = contractAmount,
                targetYear = cursor.year,
                targetMonth = cursor.month
            )
            if (res.daysInMonth > 0) {
                results.add(res)
            }
            cursor = cursor.plusMonths(1)
        }

        // Reconcile any multi-month intermediate rounding drift on the earliest month if needed
        // so that sum of all months in full schedule == contractAmount while preserving last month
        if (results.size > 2) {
            val currentSum = results.sumOf { it.allocatedAmount }
            val diff = contractAmount - currentSum
            if (diff != 0L) {
                val first = results.first()
                results[0] = first.copy(allocatedAmount = first.allocatedAmount + diff)
            }
        }
        return results
    }

    /**
     * Phần 9: Doanh thu phân bổ PT
     * Ví dụ: Gói PT 10 buổi, tổng tiền 1.400.000đ, Trung tâm 50%, PT 50%.
     * Trong tháng khách tập 3 buổi:
     * Doanh thu phân bổ trung tâm = 1.400.000 * 50% / 10 * 3 = 210.000đ.
     * Phần PT hưởng = 210.000đ.
     * Tổng phân bổ (Trung tâm + PT) = 420.000đ.
     */
    fun calculatePtMonthlyAllocation(
        contractTotalAmount: Long,
        totalSessions: Int,
        centerPercent: Int = 50,
        ptPercent: Int = 50,
        sessionsUsedInMonth: Int
    ): PtSessionAllocationResult {
        if (totalSessions <= 0 || sessionsUsedInMonth <= 0 || contractTotalAmount <= 0L) {
            return PtSessionAllocationResult(
                totalSessionsInContract = totalSessions.coerceAtLeast(0),
                contractTotalAmount = contractTotalAmount,
                centerPercent = centerPercent,
                ptPercent = ptPercent,
                sessionsUsedInMonth = 0,
                valuePerSession = if (totalSessions > 0) contractTotalAmount.toDouble() / totalSessions else 0.0,
                centerAllocatedRevenue = 0L,
                ptAllocatedShare = 0L,
                totalAllocatedInMonth = 0L
            )
        }
        val valuePerSession = contractTotalAmount.toDouble() / totalSessions.toDouble()
        val totalAllocated = (valuePerSession * sessionsUsedInMonth.toDouble()).roundToLong()
        val centerRevenue = (contractTotalAmount.toDouble() * (centerPercent / 100.0) * sessionsUsedInMonth.toDouble() / totalSessions.toDouble()).roundToLong()
        val ptShare = (contractTotalAmount.toDouble() * (ptPercent / 100.0) * sessionsUsedInMonth.toDouble() / totalSessions.toDouble()).roundToLong()

        return PtSessionAllocationResult(
            totalSessionsInContract = totalSessions,
            contractTotalAmount = contractTotalAmount,
            centerPercent = centerPercent,
            ptPercent = ptPercent,
            sessionsUsedInMonth = sessionsUsedInMonth,
            valuePerSession = valuePerSession,
            centerAllocatedRevenue = centerRevenue,
            ptAllocatedShare = ptShare,
            totalAllocatedInMonth = totalAllocated
        )
    }

    /**
     * Phần 11.1 & Nâng cấp Module Doanh thu (Tách riêng GYM và YOGA):
     * - Phân loại giao dịch dựa trên nguồn dịch vụ thực tế GYM hoặc YOGA.
     * - Tính doanh thu theo ngày thanh toán thực tế (ngayThanhToan), không dựa vào ngày đăng ký hợp đồng hay ngày bắt đầu tập.
     * - Không tính một giao dịch hai lần (khử trùng lặp theo id).
     * - Không đưa doanh thu GYM vào báo cáo YOGA và ngược lại.
     * - Các giao dịch cũ được phân loại chính xác theo dữ liệu hiện có (trường boMon của giao dịch, hợp đồng hoặc hội viên);
     *   không tự suy đoán loại dịch vụ khi dữ liệu không đủ căn cứ.
     * - Tổng thực thu toàn trung tâm = Thực thu GYM + Thực thu YOGA.
     */
    fun calculateMonthlyCashFlow(
        targetYear: Int,
        targetMonth: Int,
        payments: List<PaymentTransactionEntity>,
        walkInTickets: List<WalkInTicketEntity>,
        membersById: Map<String, MemberEntity> = emptyMap(),
        contractsById: Map<String, MemberContractEntity> = emptyMap(),
        ptContractsById: Map<String, PtContractEntity> = emptyMap(),
        deletedContractIds: Set<String> = emptySet(),
        deletedPtContractIds: Set<String> = emptySet()
    ): MonthlyCashFlowSummaryResult {
        val monthPrefix = String.format(Locale.US, "%04d-%02d", targetYear, targetMonth)

        fun isDateInTargetMonth(rawDate: String): Boolean {
            val parsed = LocalDateSpec.parseIso(rawDate)
            return if (parsed != null) {
                parsed.year == targetYear && parsed.month == targetMonth
            } else {
                rawDate.trim().startsWith(monthPrefix)
            }
        }

        var cashFlowMemberGym = 0L
        var cashFlowPtGym = 0L
        var cashFlowWalkInGym = 0L
        var cashFlowMemberYoga = 0L
        var cashFlowOtherYoga = 0L

        val gymTransactions = mutableListOf<CashFlowTransactionRecord>()
        val yogaTransactions = mutableListOf<CashFlowTransactionRecord>()
        val unclassifiedTransactions = mutableListOf<CashFlowTransactionRecord>()

        // 1. Duyệt các giao dịch trong bảng giao_dich_thanh_toan (khử trùng lặp theo ID)
        payments
            .distinctBy { it.id }
            .filter { p ->
                p.soTien != 0L &&
                    p.hopDongId !in deletedContractIds &&
                    p.hopDongId !in deletedPtContractIds &&
                    isDateInTargetMonth(p.ngayThanhToan)
            }
            .sortedByDescending { it.ngayThanhToan }
            .forEach { p ->
                val contract = contractsById[p.hopDongId]
                val member = membersById[p.hoiVienId] ?: contract?.let { membersById[it.hoiVienId] }
                val ptContract = ptContractsById[p.hopDongId]

                val rawBoMon = p.boMon.trim().uppercase(Locale.US)
                val contractBoMon = contract?.boMon?.trim()?.uppercase(Locale.US)
                val memberBoMon = member?.boMon?.trim()?.uppercase(Locale.US)

                val resolvedBoMon = when {
                    rawBoMon == BoMon.GYM || rawBoMon == BoMon.YOGA -> rawBoMon
                    p.loaiNguon == "HOP_DONG_PT" || ptContract != null -> BoMon.GYM
                    contractBoMon == BoMon.GYM || contractBoMon == BoMon.YOGA -> contractBoMon
                    memberBoMon == BoMon.GYM || memberBoMon == BoMon.YOGA -> memberBoMon
                    else -> "CHUA_XAC_DINH"
                }

                val displayDate = DateUtils.isoToDisplay(p.ngayThanhToan)

                when (resolvedBoMon) {
                    BoMon.GYM -> {
                        val isPt = p.loaiNguon == "HOP_DONG_PT" || ptContract != null
                        if (isPt) {
                            cashFlowPtGym += p.soTien
                            val custName = ptContract?.let { "${it.hoTen} (${it.maKhach})" }
                                ?: member?.hoTen
                                ?: p.hoiVienId.ifBlank { "Khách PT GYM" }
                            val srvName = ptContract?.let { "PT GYM - ${it.goiPt} (${it.tongSoBuoi} buổi)" }
                                ?: "Gói tập PT GYM"
                            val content = p.ghiChu.ifBlank { "Thanh toán hợp đồng PT GYM" }
                            gymTransactions.add(
                                CashFlowTransactionRecord(
                                    id = p.id,
                                    boMon = BoMon.GYM,
                                    customerName = custName,
                                    serviceName = srvName,
                                    paymentContent = content,
                                    ngayThanhToanIso = p.ngayThanhToan,
                                    ngayThanhToanDisplay = displayDate,
                                    amount = p.soTien,
                                    categoryLabel = "PT GYM",
                                    title = "Khách PT GYM: $custName",
                                    subtitle = "$srvName • $content"
                                )
                            )
                        } else {
                            cashFlowMemberGym += p.soTien
                            val custName = member?.let { "${it.hoTen} (STT ${it.stt})" }
                                ?: p.hoiVienId.ifBlank { "Hội viên GYM" }
                            val srvName = contract?.goiTap?.takeIf { it.isNotBlank() } ?: "Hội viên GYM"
                            val content = p.ghiChu.ifBlank { "Thanh toán hợp đồng Hội viên GYM" }
                            gymTransactions.add(
                                CashFlowTransactionRecord(
                                    id = p.id,
                                    boMon = BoMon.GYM,
                                    customerName = custName,
                                    serviceName = srvName,
                                    paymentContent = content,
                                    ngayThanhToanIso = p.ngayThanhToan,
                                    ngayThanhToanDisplay = displayDate,
                                    amount = p.soTien,
                                    categoryLabel = "Hội viên GYM",
                                    title = "Hội viên GYM: $custName",
                                    subtitle = "$srvName • $content"
                                )
                            )
                        }
                    }

                    BoMon.YOGA -> {
                        val isStandardMember = p.loaiNguon == "HOP_DONG_HOI_VIEN" || p.loaiNguon.isBlank()
                        val custName = member?.let { "${it.hoTen} (STT ${it.stt})" }
                            ?: p.hoiVienId.ifBlank { "Hội viên YOGA" }
                        val srvName = contract?.goiTap?.takeIf { it.isNotBlank() }
                            ?: if (isStandardMember) "Hội viên YOGA" else "Dịch vụ YOGA khác"
                        val content = p.ghiChu.ifBlank {
                            if (isStandardMember) "Thanh toán hợp đồng Hội viên YOGA" else "Khoản thu YOGA khác"
                        }
                        if (isStandardMember) {
                            cashFlowMemberYoga += p.soTien
                        } else {
                            cashFlowOtherYoga += p.soTien
                        }
                        yogaTransactions.add(
                            CashFlowTransactionRecord(
                                id = p.id,
                                boMon = BoMon.YOGA,
                                customerName = custName,
                                serviceName = srvName,
                                paymentContent = content,
                                ngayThanhToanIso = p.ngayThanhToan,
                                ngayThanhToanDisplay = displayDate,
                                amount = p.soTien,
                                categoryLabel = if (isStandardMember) "Hội viên YOGA" else "Thu khác YOGA",
                                title = if (isStandardMember) "Hội viên YOGA: $custName" else "Thu khác YOGA: $custName",
                                subtitle = "$srvName • $content"
                            )
                        )
                    }

                    else -> {
                        val custName = member?.hoTen ?: p.hoiVienId.ifBlank { "Chưa rõ khách hàng" }
                        val content = p.ghiChu.ifBlank { "Giao dịch chưa đủ căn cứ phân loại bộ môn" }
                        unclassifiedTransactions.add(
                            CashFlowTransactionRecord(
                                id = p.id,
                                boMon = "CHUA_XAC_DINH",
                                customerName = custName,
                                serviceName = "Chưa xác định bộ môn",
                                paymentContent = content,
                                ngayThanhToanIso = p.ngayThanhToan,
                                ngayThanhToanDisplay = displayDate,
                                amount = p.soTien,
                                categoryLabel = "Chưa xác định",
                                title = "Chưa xác định: $custName",
                                subtitle = content
                            )
                        )
                    }
                }
            }

        // 2. Duyệt các giao dịch vé khách tập lẻ GYM (khử trùng lặp theo ID, loại trừ vé đã xóa)
        walkInTickets
            .distinctBy { it.id }
            .filter { w ->
                !w.trangThaiXoa &&
                    w.soTien != 0L &&
                    isDateInTargetMonth(w.ngayThanhToan)
            }
            .sortedByDescending { it.ngayThanhToan }
            .forEach { w ->
                cashFlowWalkInGym += w.soTien
                val displayDate = DateUtils.isoToDisplay(w.ngayThanhToan)
                val srvName = "${w.tenLoaiVe} (SL: ${w.soLuong})"
                val content = w.ghiChu.ifBlank { "Thu trực tiếp tại quầy" }
                gymTransactions.add(
                    CashFlowTransactionRecord(
                        id = w.id,
                        boMon = BoMon.GYM,
                        customerName = "Khách tập lẻ GYM",
                        serviceName = srvName,
                        paymentContent = content,
                        ngayThanhToanIso = w.ngayThanhToan,
                        ngayThanhToanDisplay = displayDate,
                        amount = w.soTien,
                        categoryLabel = "Khách lẻ GYM",
                        title = "Khách lẻ GYM: $srvName",
                        subtitle = content
                    )
                )
            }

        val sortedGymTransactions = gymTransactions.sortedWith(
            compareByDescending<CashFlowTransactionRecord> { it.ngayThanhToanIso }.thenBy { it.id }
        )
        val sortedYogaTransactions = yogaTransactions.sortedWith(
            compareByDescending<CashFlowTransactionRecord> { it.ngayThanhToanIso }.thenBy { it.id }
        )

        val totalCashFlowGym = cashFlowMemberGym + cashFlowPtGym + cashFlowWalkInGym
        val totalCashFlowYoga = cashFlowMemberYoga + cashFlowOtherYoga
        val totalCashFlowCenter = totalCashFlowGym + totalCashFlowYoga

        return MonthlyCashFlowSummaryResult(
            year = targetYear,
            month = targetMonth,
            cashFlowMemberGym = cashFlowMemberGym,
            cashFlowPtGym = cashFlowPtGym,
            cashFlowWalkInGym = cashFlowWalkInGym,
            totalCashFlowGym = totalCashFlowGym,
            gymTransactionCount = sortedGymTransactions.size,
            gymTransactions = sortedGymTransactions,
            cashFlowMemberYoga = cashFlowMemberYoga,
            cashFlowOtherYoga = cashFlowOtherYoga,
            totalCashFlowYoga = totalCashFlowYoga,
            yogaTransactionCount = sortedYogaTransactions.size,
            yogaTransactions = sortedYogaTransactions,
            totalCashFlowCenter = totalCashFlowCenter,
            totalCenterTransactionCount = sortedGymTransactions.size + sortedYogaTransactions.size,
            unclassifiedTransactions = unclassifiedTransactions
        )
    }

    /**
     * Phần 18: Chạy tự động toàn bộ 7 Golden Test Cases độc lập với dữ liệu kinh doanh thật.
     */
    fun runAllGoldenTestCases(): List<GoldenTestCaseResult> {
        val list = mutableListOf<GoldenTestCaseResult>()

        // Test 1: Hợp đồng 365 ngày
        // Bắt đầu: 12/10/2025, Kết thúc độc quyền: 12/10/2026, Giá: 2.250.000đ, Tổng: 365 ngày.
        // Tháng 10/2026 có 11 ngày được tính -> Kết quả: 67.808đ.
        val t1 = calculateMonthlyAllocatedRevenue(
            startDate = LocalDateSpec(2025, 10, 12),
            endExclusive = LocalDateSpec(2026, 10, 12),
            contractAmount = 2_250_000L,
            targetYear = 2026,
            targetMonth = 10
        )
        list.add(
            GoldenTestCaseResult(
                id = 1,
                title = "Test 1: Hợp đồng 365 ngày (12/10/2025 – 12/10/2026)",
                description = "Giá 2.250.000đ, tổng 365 ngày. Tháng 10/2026 có 11 ngày được tính.",
                expectedDisplay = "365 ngày | Tháng 10/2026: 11 ngày -> 67.808đ",
                actualDisplay = "${t1.totalContractDays} ngày | Tháng 10/2026: ${t1.daysInMonth} ngày -> ${DateUtils.formatVnd(t1.allocatedAmount)}",
                passed = (t1.totalContractDays == 365 && t1.daysInMonth == 11 && t1.allocatedAmount == 67_808L)
            )
        )

        // Test 2: Đăng ký lại sau thời gian nghỉ
        // HĐ cũ: 12/07/2026 -> 12/10/2026, Giá 1.000.000đ, Tổng 92 ngày. Tháng 10: 11 ngày -> 119.565đ.
        // HĐ mới: 27/10/2026 -> 27/01/2027, Giá 1.000.000đ, Tổng 92 ngày. Tháng 10: 5 ngày -> 54.348đ.
        val t2Old = calculateMonthlyAllocatedRevenue(
            startDate = LocalDateSpec(2026, 7, 12),
            endExclusive = LocalDateSpec(2026, 10, 12),
            contractAmount = 1_000_000L,
            targetYear = 2026,
            targetMonth = 10
        )
        val t2New = calculateMonthlyAllocatedRevenue(
            startDate = LocalDateSpec(2026, 10, 27),
            endExclusive = LocalDateSpec(2027, 1, 27),
            contractAmount = 1_000_000L,
            targetYear = 2026,
            targetMonth = 10
        )
        list.add(
            GoldenTestCaseResult(
                id = 2,
                title = "Test 2: Đăng ký lại sau thời gian nghỉ",
                description = "HĐ cũ (12/07–12/10/2026, 92 ngày): T10 có 11 ngày. HĐ mới (27/10/2026–27/01/2027, 92 ngày): T10 có 5 ngày.",
                expectedDisplay = "HĐ cũ: 119.565đ (11 ngày) | HĐ mới: 54.348đ (5 ngày)",
                actualDisplay = "HĐ cũ: ${DateUtils.formatVnd(t2Old.allocatedAmount)} (${t2Old.daysInMonth} ngày) | HĐ mới: ${DateUtils.formatVnd(t2New.allocatedAmount)} (${t2New.daysInMonth} ngày)",
                passed = (t2Old.totalContractDays == 92 && t2Old.daysInMonth == 11 && t2Old.allocatedAmount == 119_565L &&
                    t2New.totalContractDays == 92 && t2New.daysInMonth == 5 && t2New.allocatedAmount == 54_348L)
            )
        )

        // Test 3: Khách mới một tháng
        // Bắt đầu: 06/10/2026, Kết thúc độc quyền: 06/11/2026, Giá: 250.000đ, Tổng 31 ngày.
        // Tháng 10: 26 ngày -> 209.677đ. Tháng 11: 5 ngày -> 40.323đ. Tổng 2 tháng: 250.000đ.
        val t3Oct = calculateMonthlyAllocatedRevenue(
            startDate = LocalDateSpec(2026, 10, 6),
            endExclusive = LocalDateSpec(2026, 11, 6),
            contractAmount = 250_000L,
            targetYear = 2026,
            targetMonth = 10
        )
        val t3Nov = calculateMonthlyAllocatedRevenue(
            startDate = LocalDateSpec(2026, 10, 6),
            endExclusive = LocalDateSpec(2026, 11, 6),
            contractAmount = 250_000L,
            targetYear = 2026,
            targetMonth = 11
        )
        val t3Sum = t3Oct.allocatedAmount + t3Nov.allocatedAmount
        list.add(
            GoldenTestCaseResult(
                id = 3,
                title = "Test 3: Khách mới 1 tháng (06/10/2026 – 06/11/2026)",
                description = "Giá 250.000đ, tổng 31 ngày. Tháng 10 (26 ngày) + Tháng 11 (5 ngày) = 250.000đ.",
                expectedDisplay = "T10: 209.677đ | T11: 40.323đ | Tổng: 250.000đ",
                actualDisplay = "T10: ${DateUtils.formatVnd(t3Oct.allocatedAmount)} | T11: ${DateUtils.formatVnd(t3Nov.allocatedAmount)} | Tổng: ${DateUtils.formatVnd(t3Sum)}",
                passed = (t3Oct.daysInMonth == 26 && t3Oct.allocatedAmount == 209_677L &&
                    t3Nov.daysInMonth == 5 && t3Nov.allocatedAmount == 40_323L &&
                    t3Sum == 250_000L)
            )
        )

        // Test 4: Gia hạn đúng ngày nối tiếp
        // HĐ cũ: 08/07/2026 đến hết 07/10/2026 (độc quyền 08/10/2026), Giá 1.500.000đ, Tổng 92 ngày. T10: 7 ngày -> 114.130đ.
        // HĐ mới: Bắt đầu 08/10/2026, độc quyền 08/01/2027, Giá 1.500.000đ, Tổng 92 ngày. T10: 24 ngày -> 391.304đ.
        val t4Old = calculateMonthlyAllocatedRevenue(
            startDate = LocalDateSpec(2026, 7, 8),
            endExclusive = LocalDateSpec(2026, 10, 8),
            contractAmount = 1_500_000L,
            targetYear = 2026,
            targetMonth = 10
        )
        val t4NewStart = calculateRenewalStartDate(
            previousEndExclusive = LocalDateSpec(2026, 10, 8),
            renewalDate = LocalDateSpec(2026, 10, 8)
        )
        val t4New = calculateMonthlyAllocatedRevenue(
            startDate = t4NewStart,
            endExclusive = LocalDateSpec(2027, 1, 8),
            contractAmount = 1_500_000L,
            targetYear = 2026,
            targetMonth = 10
        )
        list.add(
            GoldenTestCaseResult(
                id = 4,
                title = "Test 4: Gia hạn đúng ngày nối tiếp (08/10/2026)",
                description = "HĐ cũ (08/07–07/10, 92 ngày): 7 ngày T10. HĐ mới (08/10–08/01, 92 ngày): 24 ngày T10. Không trùng ngày 08/10.",
                expectedDisplay = "HĐ cũ: 114.130đ (7 ngày) | HĐ mới: 391.304đ (24 ngày)",
                actualDisplay = "HĐ cũ: ${DateUtils.formatVnd(t4Old.allocatedAmount)} (${t4Old.daysInMonth} ngày) | HĐ mới: ${DateUtils.formatVnd(t4New.allocatedAmount)} (${t4New.daysInMonth} ngày)",
                passed = (t4Old.daysInMonth == 7 && t4Old.allocatedAmount == 114_130L &&
                    t4New.daysInMonth == 24 && t4New.allocatedAmount == 391_304L &&
                    t4Old.daysInMonth + t4New.daysInMonth == 31)
            )
        )

        // Test 5: Ngày hết hạn được sửa thủ công
        // Bắt đầu: 01/09/2026, Kết thúc độc quyền: 18/11/2026, Giá: 1.500.000đ, Tổng 78 ngày.
        // Tháng 10 có 31 ngày -> Kết quả: 596.154đ.
        val t5 = calculateMonthlyAllocatedRevenue(
            startDate = LocalDateSpec(2026, 9, 1),
            endExclusive = LocalDateSpec(2026, 11, 18),
            contractAmount = 1_500_000L,
            targetYear = 2026,
            targetMonth = 10
        )
        list.add(
            GoldenTestCaseResult(
                id = 5,
                title = "Test 5: Ngày hết hạn sửa thủ công (01/09 – 18/11/2026)",
                description = "Giá 1.500.000đ, tổng 78 ngày. Tháng 10 có 31 ngày.",
                expectedDisplay = "Tổng 78 ngày | T10 (31 ngày): 596.154đ",
                actualDisplay = "Tổng ${t5.totalContractDays} ngày | T10 (${t5.daysInMonth} ngày): ${DateUtils.formatVnd(t5.allocatedAmount)}",
                passed = (t5.totalContractDays == 78 && t5.daysInMonth == 31 && t5.allocatedAmount == 596_154L)
            )
        )

        // Test 6: PT
        // Gói PT: 10 buổi, Giá: 1.400.000đ, Trung tâm hưởng 50%, Khách tập 3 buổi trong tháng.
        // Doanh thu phân bổ trung tâm: 210.000đ, Phần PT: 210.000đ, Tổng cộng: 420.000đ.
        val t6 = calculatePtMonthlyAllocation(
            contractTotalAmount = 1_400_000L,
            totalSessions = 10,
            centerPercent = 50,
            ptPercent = 50,
            sessionsUsedInMonth = 3
        )
        list.add(
            GoldenTestCaseResult(
                id = 6,
                title = "Test 6: Doanh thu phân bổ PT (10 buổi, 1.400.000đ, tập 3 buổi)",
                description = "Trung tâm hưởng 50%, PT hưởng 50%, khách tập 3 buổi trong tháng.",
                expectedDisplay = "Trung tâm: 210.000đ | PT: 210.000đ | Tổng: 420.000đ",
                actualDisplay = "Trung tâm: ${DateUtils.formatVnd(t6.centerAllocatedRevenue)} | PT: ${DateUtils.formatVnd(t6.ptAllocatedShare)} | Tổng: ${DateUtils.formatVnd(t6.totalAllocatedInMonth)}",
                passed = (t6.centerAllocatedRevenue == 210_000L && t6.ptAllocatedShare == 210_000L && t6.totalAllocatedInMonth == 420_000L)
            )
        )

        // Test 7: Gia hạn sau thời gian nghỉ (Golden Test Case Phần 12.3 & Phần 18)
        // Nguyễn Văn A: Đăng ký 15/07/2026, gói 1 tháng, giá 300.000đ, ngày cuối tập 14/08/2026 (độc quyền 15/08/2026).
        // Gia hạn lại 25/08/2026, giá 300.000đ, ngày cuối tập 24/09/2026 (độc quyền 25/09/2026).
        // Tháng 8: HĐ cũ 14 ngày + HĐ mới 7 ngày (nghỉ 10 ngày) -> Tổng doanh thu phân bổ: 203.226đ.
        val t7Old = calculateMonthlyAllocatedRevenue(
            startDate = LocalDateSpec(2026, 7, 15),
            endExclusive = LocalDateSpec(2026, 8, 15),
            contractAmount = 300_000L,
            targetYear = 2026,
            targetMonth = 8
        )
        val t7New = calculateMonthlyAllocatedRevenue(
            startDate = LocalDateSpec(2026, 8, 25),
            endExclusive = LocalDateSpec(2026, 9, 25),
            contractAmount = 300_000L,
            targetYear = 2026,
            targetMonth = 8
        )
        val t7Total = t7Old.allocatedAmount + t7New.allocatedAmount
        list.add(
            GoldenTestCaseResult(
                id = 7,
                title = "Test 7: Gia hạn sau thời gian nghỉ (Nguyễn Văn A – Tháng 8)",
                description = "HĐ cũ (15/07–14/08): 14 ngày T8. Nghỉ 15/08–24/08 (10 ngày). HĐ mới (25/08–24/09): 7 ngày T8.",
                expectedDisplay = "HĐ cũ (14 ngày): 135.484đ + HĐ mới (7 ngày): 67.742đ = 203.226đ",
                actualDisplay = "HĐ cũ (${t7Old.daysInMonth} ngày): ${DateUtils.formatVnd(t7Old.allocatedAmount)} + HĐ mới (${t7New.daysInMonth} ngày): ${DateUtils.formatVnd(t7New.allocatedAmount)} = ${DateUtils.formatVnd(t7Total)}",
                passed = (t7Old.daysInMonth == 14 && t7New.daysInMonth == 7 && t7Total == 203_226L)
            )
        )

        return list
    }
}
