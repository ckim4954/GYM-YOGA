package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.domain.DateUtils
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

enum class PdfReportType(val code: String, val titleVi: String) {
    CON_HAN("CON_HAN", "BÁO CÁO HỘI VIÊN CÒN HẠN & ĐĂNG KÝ MỚI"),
    GIA_HAN("GIA_HAN", "BÁO CÁO HỘI VIÊN GIA HẠN"),
    PT("PT", "BÁO CÁO KHÁCH TẬP PT (GYM)"),
    KHACH_LE("KHACH_LE", "BÁO CÁO KHÁCH TẬP BUỔI LẺ & TUẦN LẺ (GYM)"),
    TONG_HOP_GYM("TONG_HOP_GYM", "BÁO CÁO TỔNG HỢP DOANH THU GYM"),
    TONG_HOP_YOGA("TONG_HOP_YOGA", "BÁO CÁO TỔNG HỢP DOANH THU YOGA")
}

data class MemberReportRow(
    val stt: Int,
    val hoTen: String,
    val boMon: String,
    val goiTap: String,
    val ngayDangKyDisplay: String,
    val ngayBatDauDisplay: String,
    val ngayHetHanDisplay: String,
    val soTienHopDong: Long,
    val soNgayTrongThang: Int,
    val tongSoNgayHopDong: Int,
    val doanhThuPhanBo: Long
)

data class PtReportRow(
    val stt: Int,
    val hoTen: String,
    val goiPt: String,
    val tongSoBuoi: Int,
    val soBuoiDaTapTrongThang: Int,
    val soBuoiConLai: Int,
    val soTienHopDong: Long,
    val doanhThuTrungTam: Long,
    val doanhThuPt: Long
)

data class WalkInReportRow(
    val stt: Int,
    val maGiaoDich: String,
    val tenLoaiVe: String,
    val soLuong: Int,
    val ngayThuDisplay: String,
    val thoiGianSuDungDisplay: String,
    val soTienThanhToan: Long,
    val doanhThuPhanBoThang: Long
)

data class SummaryMetricRow(
    val hangMuc: String,
    val moTa: String,
    val soLuongBanGhi: Int,
    val soTien: Long
)

object ReportExporter {

    // A4 Portrait standard points (72 dpi): 595 x 842
    private const val A4_WIDTH = 595
    private const val A4_HEIGHT = 842
    private const val MARGIN_H = 24f
    private const val MARGIN_TOP = 32f
    private const val MARGIN_BOTTOM = 40f
    private const val TABLE_WIDTH = A4_WIDTH - 2 * MARGIN_H // 547f

    /**
     * Generates an A4 Portrait PDF report into the given OutputStream.
     */
    fun writePdfReport(
        outputStream: OutputStream,
        reportType: PdfReportType,
        boMonFilterLabel: String,
        month: Int,
        year: Int,
        memberRows: List<MemberReportRow> = emptyList(),
        ptRows: List<PtReportRow> = emptyList(),
        walkInRows: List<WalkInReportRow> = emptyList(),
        summaryCashFlowRows: List<SummaryMetricRow> = emptyList(),
        summaryAllocatedRows: List<SummaryMetricRow> = emptyList(),
        totalCashFlow: Long = 0L,
        totalAllocated: Long = 0L
    ) {
        val document = PdfDocument()

        when (reportType) {
            PdfReportType.CON_HAN, PdfReportType.GIA_HAN -> {
                renderMemberTablePages(
                    document = document,
                    reportTitle = reportType.titleVi,
                    boMonLabel = boMonFilterLabel,
                    month = month,
                    year = year,
                    rows = memberRows
                )
            }
            PdfReportType.PT -> {
                renderPtTablePages(
                    document = document,
                    reportTitle = reportType.titleVi,
                    month = month,
                    year = year,
                    rows = ptRows
                )
            }
            PdfReportType.KHACH_LE -> {
                renderWalkInTablePages(
                    document = document,
                    reportTitle = reportType.titleVi,
                    month = month,
                    year = year,
                    rows = walkInRows
                )
            }
            PdfReportType.TONG_HOP_GYM, PdfReportType.TONG_HOP_YOGA -> {
                renderSummaryPages(
                    document = document,
                    reportTitle = reportType.titleVi,
                    boMonLabel = if (reportType == PdfReportType.TONG_HOP_GYM) "GYM" else "YOGA",
                    month = month,
                    year = year,
                    cashFlowRows = summaryCashFlowRows,
                    allocatedRows = summaryAllocatedRows,
                    totalCashFlow = totalCashFlow,
                    totalAllocated = totalAllocated,
                    memberRows = memberRows
                )
            }
        }

        document.writeTo(outputStream)
        document.close()
    }

    /**
     * Cột báo cáo hội viên bắt buộc (Phần 15):
     * STT | Họ tên | Gói tập | Ngày đăng ký | Ngày hết hạn | Số tiền hợp đồng | Doanh thu phân bổ
     */
    private fun renderMemberTablePages(
        document: PdfDocument,
        reportTitle: String,
        boMonLabel: String,
        month: Int,
        year: Int,
        rows: List<MemberReportRow>
    ) {
        val colHeaders = listOf(
            "STT",
            "Họ tên",
            "Gói tập",
            "Ngày ĐK",
            "Ngày hết hạn",
            "Số tiền HĐ",
            "DT phân bổ"
        )
        // Sum of widths = 32 + 125 + 88 + 68 + 68 + 83 + 83 = 547f
        val colWidths = floatArrayOf(32f, 125f, 88f, 68f, 68f, 83f, 83f)
        val colAlignRight = booleanArrayOf(false, false, false, false, false, true, true)

        val tableData = rows.map { r ->
            listOf(
                r.stt.toString(),
                r.hoTen,
                r.goiTap,
                r.ngayBatDauDisplay,
                r.ngayHetHanDisplay,
                DateUtils.formatVnd(r.soTienHopDong, withUnit = false),
                DateUtils.formatVnd(r.doanhThuPhanBo, withUnit = false)
            )
        }

        val totalContractSum = rows.sumOf { it.soTienHopDong }
        val totalAllocatedSum = rows.sumOf { it.doanhThuPhanBo }
        val footerCells = listOf(
            "",
            "TỔNG CỘNG (${rows.size} HĐ)",
            "",
            "",
            "",
            DateUtils.formatVnd(totalContractSum),
            DateUtils.formatVnd(totalAllocatedSum)
        )

        renderGenericPaginatedTable(
            document = document,
            reportTitle = reportTitle,
            subTitle = "Bộ môn: $boMonLabel  |  Kỳ báo cáo: Tháng %02d/%04d  |  Đơn vị tính: VNĐ".format(month, year),
            accentColor = if (boMonLabel.contains("YOGA")) Color.parseColor("#7B1FA2") else Color.parseColor("#1565C0"),
            headers = colHeaders,
            colWidths = colWidths,
            colAlignRight = colAlignRight,
            rows = tableData,
            footerRow = footerCells
        )
    }

    private fun renderPtTablePages(
        document: PdfDocument,
        reportTitle: String,
        month: Int,
        year: Int,
        rows: List<PtReportRow>
    ) {
        val colHeaders = listOf(
            "STT",
            "Họ tên khách PT",
            "Gói PT",
            "Tổng buổi",
            "Tập T$month",
            "Còn lại",
            "Giá HĐ",
            "DT Trung tâm (50%)",
            "Phần PT (50%)"
        )
        // Sum = 28 + 105 + 72 + 42 + 42 + 42 + 72 + 72 + 72 = 547f
        val colWidths = floatArrayOf(28f, 105f, 72f, 42f, 42f, 42f, 72f, 72f, 72f)
        val colAlignRight = booleanArrayOf(false, false, false, true, true, true, true, true, true)

        val tableData = rows.map { r ->
            listOf(
                r.stt.toString(),
                r.hoTen,
                r.goiPt,
                r.tongSoBuoi.toString(),
                r.soBuoiDaTapTrongThang.toString(),
                r.soBuoiConLai.toString(),
                DateUtils.formatVnd(r.soTienHopDong, withUnit = false),
                DateUtils.formatVnd(r.doanhThuTrungTam, withUnit = false),
                DateUtils.formatVnd(r.doanhThuPt, withUnit = false)
            )
        }

        val totalSessionsInMonth = rows.sumOf { it.soBuoiDaTapTrongThang }
        val totalContractValue = rows.sumOf { it.soTienHopDong }
        val totalCenter = rows.sumOf { it.doanhThuTrungTam }
        val totalPt = rows.sumOf { it.doanhThuPt }

        val footerCells = listOf(
            "",
            "TỔNG CỘNG (${rows.size} khách)",
            "",
            "",
            "$totalSessionsInMonth b",
            "",
            DateUtils.formatVnd(totalContractValue, withUnit = false),
            DateUtils.formatVnd(totalCenter, withUnit = false),
            DateUtils.formatVnd(totalPt, withUnit = false)
        )

        renderGenericPaginatedTable(
            document = document,
            reportTitle = reportTitle,
            subTitle = "Bộ môn: GYM (PT)  |  Kỳ báo cáo: Tháng %02d/%04d  |  Đơn vị tính: VNĐ".format(month, year),
            accentColor = Color.parseColor("#1565C0"),
            headers = colHeaders,
            colWidths = colWidths,
            colAlignRight = colAlignRight,
            rows = tableData,
            footerRow = footerCells
        )
    }

    private fun renderWalkInTablePages(
        document: PdfDocument,
        reportTitle: String,
        month: Int,
        year: Int,
        rows: List<WalkInReportRow>
    ) {
        val colHeaders = listOf(
            "STT",
            "Mã GD",
            "Loại vé",
            "SL",
            "Ngày thu",
            "Thời gian sử dụng",
            "Tiền đã thu",
            "DT phân bổ T$month"
        )
        // Sum = 28 + 64 + 95 + 30 + 65 + 105 + 80 + 80 = 547f
        val colWidths = floatArrayOf(28f, 64f, 95f, 30f, 65f, 105f, 80f, 80f)
        val colAlignRight = booleanArrayOf(false, false, false, true, false, false, true, true)

        val tableData = rows.map { r ->
            listOf(
                r.stt.toString(),
                r.maGiaoDich,
                r.tenLoaiVe,
                r.soLuong.toString(),
                r.ngayThuDisplay,
                r.thoiGianSuDungDisplay,
                DateUtils.formatVnd(r.soTienThanhToan, withUnit = false),
                DateUtils.formatVnd(r.doanhThuPhanBoThang, withUnit = false)
            )
        }

        val totalCollected = rows.sumOf { it.soTienThanhToan }
        val totalAllocated = rows.sumOf { it.doanhThuPhanBoThang }
        val footerCells = listOf(
            "",
            "TỔNG CỘNG",
            "${rows.size} giao dịch",
            "",
            "",
            "",
            DateUtils.formatVnd(totalCollected),
            DateUtils.formatVnd(totalAllocated)
        )

        renderGenericPaginatedTable(
            document = document,
            reportTitle = reportTitle,
            subTitle = "Bộ môn: GYM (Khách lẻ)  |  Kỳ báo cáo: Tháng %02d/%04d  |  Đơn vị tính: VNĐ".format(month, year),
            accentColor = Color.parseColor("#1565C0"),
            headers = colHeaders,
            colWidths = colWidths,
            colAlignRight = colAlignRight,
            rows = tableData,
            footerRow = footerCells
        )
    }

    private fun renderSummaryPages(
        document: PdfDocument,
        reportTitle: String,
        boMonLabel: String,
        month: Int,
        year: Int,
        cashFlowRows: List<SummaryMetricRow>,
        allocatedRows: List<SummaryMetricRow>,
        totalCashFlow: Long,
        totalAllocated: Long,
        memberRows: List<MemberReportRow>
    ) {
        // First table: Summary of Cash Flow & Allocated Revenue + Member breakdown
        val colHeaders = listOf(
            "STT",
            "Họ tên / Hạng mục",
            "Gói tập / Nhóm",
            "Ngày ĐK",
            "Ngày hết hạn",
            "Số tiền HĐ",
            "DT phân bổ"
        )
        val colWidths = floatArrayOf(32f, 125f, 88f, 68f, 68f, 83f, 83f)
        val colAlignRight = booleanArrayOf(false, false, false, false, false, true, true)

        val combinedRows = mutableListOf<List<String>>()
        cashFlowRows.forEachIndexed { idx, item ->
            combinedRows.add(
                listOf(
                    "A${idx + 1}",
                    "[DÒNG TIỀN] ${item.hangMuc}",
                    item.moTa,
                    "-",
                    "-",
                    "${item.soLuongBanGhi} GD",
                    DateUtils.formatVnd(item.soTien, withUnit = false)
                )
            )
        }
        combinedRows.add(
            listOf(
                "A*",
                "TỔNG DOANH THU DÒNG TIỀN",
                "Thực thu T$month/$year",
                "-",
                "-",
                "-",
                DateUtils.formatVnd(totalCashFlow, withUnit = false)
            )
        )
        allocatedRows.forEachIndexed { idx, item ->
            combinedRows.add(
                listOf(
                    "B${idx + 1}",
                    "[PHÂN BỔ] ${item.hangMuc}",
                    item.moTa,
                    "-",
                    "-",
                    "${item.soLuongBanGhi} mục",
                    DateUtils.formatVnd(item.soTien, withUnit = false)
                )
            )
        }
        memberRows.forEach { r ->
            combinedRows.add(
                listOf(
                    r.stt.toString(),
                    r.hoTen,
                    r.goiTap,
                    r.ngayBatDauDisplay,
                    r.ngayHetHanDisplay,
                    DateUtils.formatVnd(r.soTienHopDong, withUnit = false),
                    DateUtils.formatVnd(r.doanhThuPhanBo, withUnit = false)
                )
            )
        }

        val footerCells = listOf(
            "",
            "TỔNG DOANH THU PHÂN BỔ $boMonLabel",
            "Tháng %02d/%04d".format(month, year),
            "",
            "",
            "Thực thu: ${DateUtils.formatVnd(totalCashFlow, withUnit = false)}",
            DateUtils.formatVnd(totalAllocated)
        )

        renderGenericPaginatedTable(
            document = document,
            reportTitle = reportTitle,
            subTitle = "Bộ môn: $boMonLabel  |  Kỳ báo cáo: Tháng %02d/%04d  |  Đơn vị tính: VNĐ".format(month, year),
            accentColor = if (boMonLabel == "YOGA") Color.parseColor("#7B1FA2") else Color.parseColor("#1565C0"),
            headers = colHeaders,
            colWidths = colWidths,
            colAlignRight = colAlignRight,
            rows = combinedRows,
            footerRow = footerCells
        )
    }

    private fun renderGenericPaginatedTable(
        document: PdfDocument,
        reportTitle: String,
        subTitle: String,
        accentColor: Int,
        headers: List<String>,
        colWidths: FloatArray,
        colAlignRight: BooleanArray,
        rows: List<List<String>>,
        footerRow: List<String>
    ) {
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            textSize = 13.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subTitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#334155")
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val headerBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            style = Paint.Style.FILL
        }
        val headerTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 8.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val cellTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = 8.2f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val footerBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#EFF6FF")
            style = Paint.Style.FILL
        }
        val footerTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            textSize = 8.6f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#CBD5E1")
            style = Paint.Style.STROKE
            strokeWidth = 0.6f
        }
        val zebraPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F8FAFC")
            style = Paint.Style.FILL
        }
        val pageNumPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#64748B")
            textSize = 8.5f
        }

        // Pre-measure row heights so we know total pages for "Trang X / Y"
        val lineSpacing = 11f
        val cellPaddingV = 5f
        val cellPaddingH = 4f
        val headerHeight = 24f

        data class MeasuredRow(val wrappedCols: List<List<String>>, val height: Float, val isFooter: Boolean = false)

        val measuredDataRows = rows.map { row ->
            val wrapped = row.mapIndexed { colIdx, text ->
                wrapTextToWidth(text, cellTextPaint, colWidths[colIdx] - 2 * cellPaddingH)
            }
            val maxLines = wrapped.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
            val h = maxLines * lineSpacing + 2 * cellPaddingV
            MeasuredRow(wrapped, h, isFooter = false)
        }

        val wrappedFooter = footerRow.mapIndexed { colIdx, text ->
            wrapTextToWidth(text, footerTextPaint, colWidths[colIdx] - 2 * cellPaddingH)
        }
        val footerMaxLines = wrappedFooter.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
        val measuredFooter = MeasuredRow(
            wrappedCols = wrappedFooter,
            height = footerMaxLines * lineSpacing + 2 * cellPaddingV + 2f,
            isFooter = true
        )

        val allRowsToPaginate = if (measuredDataRows.isEmpty()) {
            val emptyRow = List(headers.size) { if (it == 1) "Không có dữ liệu trong kỳ báo cáo" else "-" }
            val wrappedEmpty = emptyRow.mapIndexed { colIdx, text ->
                wrapTextToWidth(text, cellTextPaint, colWidths[colIdx] - 2 * cellPaddingH)
            }
            listOf(MeasuredRow(wrappedEmpty, 24f, false), measuredFooter)
        } else {
            measuredDataRows + measuredFooter
        }

        // Group rows into pages
        val pages = mutableListOf<List<MeasuredRow>>()
        var currentPageRows = mutableListOf<MeasuredRow>()
        val firstPageTopY = MARGIN_TOP + 46f + headerHeight
        val nextPageTopY = MARGIN_TOP + 22f + headerHeight
        val maxBottomY = A4_HEIGHT - MARGIN_BOTTOM

        var currentY = firstPageTopY
        for (mRow in allRowsToPaginate) {
            if (currentY + mRow.height > maxBottomY && currentPageRows.isNotEmpty()) {
                pages.add(currentPageRows)
                currentPageRows = mutableListOf()
                currentY = nextPageTopY
            }
            currentPageRows.add(mRow)
            currentY += mRow.height
        }
        if (currentPageRows.isNotEmpty()) {
            pages.add(currentPageRows)
        }
        val totalPages = pages.size.coerceAtLeast(1)

        // Draw each page
        pages.forEachIndexed { pageIdx, pageRows ->
            val pageNumber = pageIdx + 1
            val pageInfo = PdfDocument.PageInfo.Builder(A4_WIDTH, A4_HEIGHT, pageNumber).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            var y = MARGIN_TOP
            if (pageIdx == 0) {
                canvas.drawText("GYM & YOGA MANAGER", MARGIN_H, y + 10f, subTitlePaint)
                y += 24f
                canvas.drawText(reportTitle, MARGIN_H, y, titlePaint)
                y += 16f
                canvas.drawText(subTitle, MARGIN_H, y, subTitlePaint)
                y += 10f
            } else {
                canvas.drawText("$reportTitle (Tiếp theo)", MARGIN_H, y + 10f, subTitlePaint)
                y += 20f
            }

            // Draw table header (repeated on every page per Phần 15)
            drawTableHeader(
                canvas = canvas,
                startX = MARGIN_H,
                startY = y,
                height = headerHeight,
                headers = headers,
                colWidths = colWidths,
                colAlignRight = colAlignRight,
                bgPaint = headerBgPaint,
                textPaint = headerTextPaint,
                borderPaint = borderPaint,
                paddingH = cellPaddingH
            )
            y += headerHeight

            // Draw rows
            pageRows.forEachIndexed { rowIdx, mRow ->
                val rowRect = RectF(MARGIN_H, y, MARGIN_H + TABLE_WIDTH, y + mRow.height)
                if (mRow.isFooter) {
                    canvas.drawRect(rowRect, footerBgPaint)
                } else if (rowIdx % 2 == 1) {
                    canvas.drawRect(rowRect, zebraPaint)
                }

                var x = MARGIN_H
                for (colIdx in headers.indices) {
                    val w = colWidths[colIdx]
                    val cellRect = RectF(x, y, x + w, y + mRow.height)
                    canvas.drawRect(cellRect, borderPaint)

                    val lines = mRow.wrappedCols.getOrElse(colIdx) { emptyList() }
                    val paintToUse = if (mRow.isFooter) footerTextPaint else cellTextPaint
                    var lineY = y + cellPaddingV + 8.5f
                    for (line in lines) {
                        if (colAlignRight[colIdx]) {
                            val textW = paintToUse.measureText(line)
                            canvas.drawText(line, (x + w - cellPaddingH - textW).coerceAtLeast(x + 2f), lineY, paintToUse)
                        } else {
                            canvas.drawText(line, x + cellPaddingH, lineY, paintToUse)
                        }
                        lineY += lineSpacing
                    }
                    x += w
                }
                y += mRow.height
            }

            // Draw footer page number
            val pageText = "Trang $pageNumber / $totalPages"
            val pw = pageNumPaint.measureText(pageText)
            canvas.drawText(pageText, A4_WIDTH - MARGIN_H - pw, A4_HEIGHT - 16f, pageNumPaint)
            canvas.drawText(
                "Xuất từ ứng dụng GYM & YOGA MANAGER",
                MARGIN_H,
                A4_HEIGHT - 16f,
                pageNumPaint
            )

            document.finishPage(page)
        }
    }

    private fun drawTableHeader(
        canvas: Canvas,
        startX: Float,
        startY: Float,
        height: Float,
        headers: List<String>,
        colWidths: FloatArray,
        colAlignRight: BooleanArray,
        bgPaint: Paint,
        textPaint: Paint,
        borderPaint: Paint,
        paddingH: Float
    ) {
        val headerRect = RectF(startX, startY, startX + TABLE_WIDTH, startY + height)
        canvas.drawRect(headerRect, bgPaint)

        var x = startX
        for (i in headers.indices) {
            val w = colWidths[i]
            val cellRect = RectF(x, startY, x + w, startY + height)
            canvas.drawRect(cellRect, borderPaint)
            val title = headers[i]
            val textY = startY + height / 2f + 3f
            if (colAlignRight[i]) {
                val tw = textPaint.measureText(title)
                canvas.drawText(title, (x + w - paddingH - tw).coerceAtLeast(x + 2f), textY, textPaint)
            } else {
                canvas.drawText(title, x + paddingH, textY, textPaint)
            }
            x += w
        }
    }

    private fun wrapTextToWidth(text: String, paint: Paint, maxWidth: Float): List<String> {
        if (text.isBlank()) return listOf("")
        if (paint.measureText(text) <= maxWidth) return listOf(text)

        val words = text.split(" ")
        val lines = mutableListOf<String>()
        var currentLine = StringBuilder()

        for (word in words) {
            val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
            if (paint.measureText(testLine) <= maxWidth) {
                currentLine = StringBuilder(testLine)
            } else {
                if (currentLine.isNotEmpty()) {
                    lines.add(currentLine.toString())
                    currentLine = StringBuilder()
                }
                // If single word exceeds maxWidth, split by character
                if (paint.measureText(word) > maxWidth) {
                    var chunk = StringBuilder()
                    for (ch in word) {
                        if (paint.measureText("$chunk$ch") <= maxWidth) {
                            chunk.append(ch)
                        } else {
                            if (chunk.isNotEmpty()) lines.add(chunk.toString())
                            chunk = StringBuilder(ch.toString())
                        }
                    }
                    currentLine = chunk
                } else {
                    currentLine = StringBuilder(word)
                }
            }
        }
        if (currentLine.isNotEmpty()) {
            lines.add(currentLine.toString())
        }
        return lines
    }

    /**
     * Xuất nội dung CSV (tương thích Microsoft Excel với UTF-8 BOM \uFEFF).
     */
    fun buildExcelCsvContent(
        reportType: PdfReportType,
        month: Int,
        year: Int,
        memberRows: List<MemberReportRow> = emptyList(),
        ptRows: List<PtReportRow> = emptyList(),
        walkInRows: List<WalkInReportRow> = emptyList(),
        summaryCashFlowRows: List<SummaryMetricRow> = emptyList(),
        summaryAllocatedRows: List<SummaryMetricRow> = emptyList(),
        totalCashFlow: Long = 0L,
        totalAllocated: Long = 0L
    ): String {
        val sb = StringBuilder("\uFEFF") // UTF-8 BOM for Excel Vietnamese support
        sb.appendLine("\"${reportType.titleVi} - THÁNG $month/$year\"")

        when (reportType) {
            PdfReportType.CON_HAN, PdfReportType.GIA_HAN -> {
                sb.appendLine("STT,Bộ môn,Họ và tên,Gói tập,Ngày bắt đầu,Ngày hết hạn,Số ngày trong tháng,Tổng ngày HĐ,Số tiền hợp đồng,Doanh thu phân bổ")
                memberRows.forEach { r ->
                    sb.appendLine("${r.stt},\"${r.boMon}\",\"${escapeCsv(r.hoTen)}\",\"${escapeCsv(r.goiTap)}\",\"${r.ngayBatDauDisplay}\",\"${r.ngayHetHanDisplay}\",${r.soNgayTrongThang},${r.tongSoNgayHopDong},${r.soTienHopDong},${r.doanhThuPhanBo}")
                }
                sb.appendLine(",\"TỔNG CỘNG\",,,,,,,${memberRows.sumOf { it.soTienHopDong }},${memberRows.sumOf { it.doanhThuPhanBo }}")
            }
            PdfReportType.PT -> {
                sb.appendLine("STT,Họ và tên,Gói PT,Tổng số buổi,Số buổi tập trong tháng,Số buổi còn lại,Giá hợp đồng,Doanh thu Trung tâm (50%),Phần PT (50%)")
                ptRows.forEach { r ->
                    sb.appendLine("${r.stt},\"${escapeCsv(r.hoTen)}\",\"${escapeCsv(r.goiPt)}\",${r.tongSoBuoi},${r.soBuoiDaTapTrongThang},${r.soBuoiConLai},${r.soTienHopDong},${r.doanhThuTrungTam},${r.doanhThuPt}")
                }
                sb.appendLine(",\"TỔNG CỘNG\",,,${ptRows.sumOf { it.soBuoiDaTapTrongThang }},,${ptRows.sumOf { it.soTienHopDong }},${ptRows.sumOf { it.doanhThuTrungTam }},${ptRows.sumOf { it.doanhThuPt }}")
            }
            PdfReportType.KHACH_LE -> {
                sb.appendLine("STT,Mã giao dịch,Loại vé,Số lượng,Ngày thu,Thời gian sử dụng,Số tiền thanh toán,Doanh thu phân bổ tháng")
                walkInRows.forEach { r ->
                    sb.appendLine("${r.stt},\"${r.maGiaoDich}\",\"${escapeCsv(r.tenLoaiVe)}\",${r.soLuong},\"${r.ngayThuDisplay}\",\"${r.thoiGianSuDungDisplay}\",${r.soTienThanhToan},${r.doanhThuPhanBoThang}")
                }
                sb.appendLine(",\"TỔNG CỘNG\",,,,,${walkInRows.sumOf { it.soTienThanhToan }},${walkInRows.sumOf { it.doanhThuPhanBoThang }}")
            }
            PdfReportType.TONG_HOP_GYM, PdfReportType.TONG_HOP_YOGA -> {
                sb.appendLine("Nhóm,Hạng mục,Mô tả,Số lượng,Số tiền (VNĐ)")
                summaryCashFlowRows.forEach { r ->
                    sb.appendLine("\"Doanh thu dòng tiền\",\"${escapeCsv(r.hangMuc)}\",\"${escapeCsv(r.moTa)}\",${r.soLuongBanGhi},${r.soTien}")
                }
                sb.appendLine("\"Doanh thu dòng tiền\",\"TỔNG DÒNG TIỀN THỰC THU\",\"\",,$totalCashFlow")
                summaryAllocatedRows.forEach { r ->
                    sb.appendLine("\"Doanh thu phân bổ\",\"${escapeCsv(r.hangMuc)}\",\"${escapeCsv(r.moTa)}\",${r.soLuongBanGhi},${r.soTien}")
                }
                sb.appendLine("\"Doanh thu phân bổ\",\"TỔNG DOANH THU PHÂN BỔ\",\"\",,$totalAllocated")
            }
        }
        return sb.toString()
    }

    private fun escapeCsv(input: String): String = input.replace("\"", "\"\"")

    /**
     * Lưu báo cáo PDF vào thư mục cache/reports và mở hộp thoại chia sẻ / xem PDF trên Android.
     */
    fun sharePdfFile(
        context: Context,
        fileName: String,
        writer: (OutputStream) -> Unit
    ): Result<Uri> {
        return try {
            val reportsDir = File(context.cacheDir, "reports")
            if (!reportsDir.exists()) reportsDir.mkdirs()
            val file = File(reportsDir, fileName)
            FileOutputStream(file).use { out ->
                writer(out)
            }
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(shareIntent, "Chia sẻ / Lưu báo cáo PDF A4").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            Result.success(uri)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun shareCsvOrJsonFile(
        context: Context,
        fileName: String,
        mimeType: String,
        content: String
    ): Result<Uri> {
        return try {
            val reportsDir = File(context.cacheDir, "reports")
            if (!reportsDir.exists()) reportsDir.mkdirs()
            val file = File(reportsDir, fileName)
            file.writeText(content, Charsets.UTF_8)
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(shareIntent, "Chia sẻ / Lưu tệp").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            Result.success(uri)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
