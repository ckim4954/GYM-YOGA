package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.domain.DateUtils
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

/**
 * 8 báo cáo độc lập chuẩn hóa cho 89 FITNESS & YOGA:
 * - Nhóm GYM (1 -> 5):
 *   1. Báo cáo hội viên GYM còn hạn & đăng ký mới
 *   2. Báo cáo hội viên GYM gia hạn
 *   3. Báo cáo khách tập PT (GYM)
 *   4. Báo cáo khách tập buổi lẻ & tuần lẻ (GYM)
 *   5. Báo cáo tổng hợp doanh thu GYM
 * - Nhóm YOGA (6 -> 8):
 *   6. Báo cáo hội viên YOGA còn hạn & đăng ký mới
 *   7. Báo cáo hội viên YOGA gia hạn
 *   8. Báo cáo tổng hợp doanh thu YOGA
 */
enum class PdfReportType(
    val code: String,
    val orderIndex: Int,
    val titleVi: String,
    val cardTitleVi: String,
    val methodologyVi: String,
    val boMon: String
) {
    // NHÓM BÁO CÁO GYM (1 - 5)
    CON_HAN_GYM(
        code = "CON_HAN_GYM",
        orderIndex = 1,
        titleVi = "BÁO CÁO HỘI VIÊN GYM CÒN HẠN & ĐĂNG KÝ MỚI",
        cardTitleVi = "1. Báo cáo hội viên GYM còn hạn & đăng ký mới",
        methodologyVi = "Phân bổ theo số ngày hiệu lực của hợp đồng trong tháng",
        boMon = "GYM"
    ),
    GIA_HAN_GYM(
        code = "GIA_HAN_GYM",
        orderIndex = 2,
        titleVi = "BÁO CÁO HỘI VIÊN GYM GIA HẠN",
        cardTitleVi = "2. Báo cáo hội viên GYM gia hạn",
        methodologyVi = "Phân bổ theo số ngày hiệu lực của hợp đồng trong tháng",
        boMon = "GYM"
    ),
    PT(
        code = "PT_GYM",
        orderIndex = 3,
        titleVi = "BÁO CÁO KHÁCH TẬP PT (GYM)",
        cardTitleVi = "3. Báo cáo khách tập PT (GYM)",
        methodologyVi = "Phân bổ theo số buổi PT thực tế đã hoàn thành trong tháng",
        boMon = "GYM"
    ),
    KHACH_LE(
        code = "KHACH_LE_GYM",
        orderIndex = 4,
        titleVi = "BÁO CÁO KHÁCH TẬP BUỔI LẺ & TUẦN LẺ (GYM)",
        cardTitleVi = "4. Báo cáo khách tập buổi lẻ & tuần lẻ (GYM)",
        methodologyVi = "Vé ngày: Ghi nhận theo ngày sử dụng • Vé tuần: Phân bổ theo số ngày sử dụng thuộc tháng báo cáo",
        boMon = "GYM"
    ),
    TONG_HOP_GYM(
        code = "TONG_HOP_GYM",
        orderIndex = 5,
        titleVi = "BÁO CÁO TỔNG HỢP DOANH THU GYM",
        cardTitleVi = "5. Báo cáo tổng hợp doanh thu GYM",
        methodologyVi = "Tổng hợp A. Doanh thu thực thu & B. Doanh thu phân bổ bộ môn GYM",
        boMon = "GYM"
    ),

    // NHÓM BÁO CÁO YOGA (6 - 8)
    CON_HAN_YOGA(
        code = "CON_HAN_YOGA",
        orderIndex = 6,
        titleVi = "BÁO CÁO HỘI VIÊN YOGA CÒN HẠN & ĐĂNG KÝ MỚI",
        cardTitleVi = "6. Báo cáo hội viên YOGA còn hạn & đăng ký mới",
        methodologyVi = "Phân bổ theo số ngày hiệu lực của hợp đồng trong tháng",
        boMon = "YOGA"
    ),
    GIA_HAN_YOGA(
        code = "GIA_HAN_YOGA",
        orderIndex = 7,
        titleVi = "BÁO CÁO HỘI VIÊN YOGA GIA HẠN",
        cardTitleVi = "7. Báo cáo hội viên YOGA gia hạn",
        methodologyVi = "Phân bổ theo số ngày hiệu lực của hợp đồng trong tháng",
        boMon = "YOGA"
    ),
    TONG_HOP_YOGA(
        code = "TONG_HOP_YOGA",
        orderIndex = 8,
        titleVi = "BÁO CÁO TỔNG HỢP DOANH THU YOGA",
        cardTitleVi = "8. Báo cáo tổng hợp doanh thu YOGA",
        methodologyVi = "Tổng hợp A. Doanh thu thực thu & B. Doanh thu phân bổ bộ môn YOGA",
        boMon = "YOGA"
    );

    companion object {
        val gymReports: List<PdfReportType>
            get() = listOf(CON_HAN_GYM, GIA_HAN_GYM, PT, KHACH_LE, TONG_HOP_GYM)

        val yogaReports: List<PdfReportType>
            get() = listOf(CON_HAN_YOGA, GIA_HAN_YOGA, TONG_HOP_YOGA)
    }
}

data class MemberReportRow(
    val stt: Int,
    val hoTen: String,
    val boMon: String,
    val goiTap: String,
    val loaiBaoCaoLabel: String = "",
    val ngayDangKyDisplay: String,
    val ngayBatDauDisplay: String,
    val ngayHetHanDisplay: String,
    val soTienHopDong: Long,
    val soNgayTrongThang: Int,
    val tongSoNgayHopDong: Int,
    val doanhThuPhanBo: Long
)

data class PtReportRow(
    val stt: Int,
    val hoTen: String,
    val goiPt: String,
    val tongSoBuoi: Int,
    val soBuoiDaTapTrongThang: Int,
    val soBuoiConLai: Int,
    val soTienHopDong: Long,
    val doanhThuTrungTam: Long,
    val doanhThuPt: Long
)

data class WalkInReportRow(
    val stt: Int,
    val maGiaoDich: String,
    val tenLoaiVe: String,
    val soLuong: Int,
    val soNgaySuDung: Int = soLuong,
    val ngayThuDisplay: String,
    val thoiGianSuDungDisplay: String,
    val soTienThanhToan: Long,
    val doanhThuPhanBoThang: Long
)

data class SummaryMetricRow(
    val hangMuc: String,
    val moTa: String,
    val soLuongBanGhi: Int,
    val donViBanGhi: String = "bản ghi",
    val soTien: Long
)

object ReportExporter {

    // A4 Portrait standard points (72 dpi): 595 x 842
    private const val A4_WIDTH = 595
    private const val A4_HEIGHT = 842
    private const val MARGIN_H = 24f
    private const val MARGIN_TOP = 28f
    private const val MARGIN_BOTTOM = 38f
    private const val TABLE_WIDTH = A4_WIDTH - 2 * MARGIN_H // 547f

    const val EMPTY_REPORT_MESSAGE = "Không có dữ liệu trong kỳ báo cáo"
    const val GROUP_A_TITLE = "A. DOANH THU THỰC THU"
    const val GROUP_A_DESC = "Tổng số tiền thực tế đã nhận trong tháng, tính theo ngày thanh toán."
    const val GROUP_A_TOTAL_LABEL = "TỔNG TIỀN THỰC THU TRONG THÁNG"

    const val GROUP_B_TITLE = "B. DOANH THU PHÂN BỔ"
    const val GROUP_B_DESC = "Giá trị dịch vụ được phân bổ vào tháng báo cáo theo thời gian hiệu lực hợp đồng hoặc dịch vụ đã sử dụng."
    const val GROUP_B_TOTAL_LABEL = "TỔNG DOANH THU PHÂN BỔ"

    const val METHOD_MEMBER_ALLOCATION = "Phân bổ theo số ngày hiệu lực của hợp đồng trong tháng"
    const val METHOD_PT_ALLOCATION = "Phân bổ theo số buổi PT thực tế đã hoàn thành trong tháng"
    const val METHOD_DAILY_WALK_IN = "Ghi nhận theo ngày sử dụng"
    const val METHOD_WEEKLY_WALK_IN = "Phân bổ theo số ngày sử dụng thuộc tháng báo cáo"

    /**
     * Generates an A4 Portrait PDF report into the given OutputStream.
     */
    fun writePdfReport(
        outputStream: OutputStream,
        reportType: PdfReportType,
        boMonFilterLabel: String = reportType.boMon,
        month: Int,
        year: Int,
        memberRows: List<MemberReportRow> = emptyList(),
        ptRows: List<PtReportRow> = emptyList(),
        walkInRows: List<WalkInReportRow> = emptyList(),
        summaryCashFlowRows: List<SummaryMetricRow> = emptyList(),
        summaryAllocatedRows: List<SummaryMetricRow> = emptyList(),
        totalCashFlow: Long = 0L,
        totalAllocated: Long = 0L
    ) {
        val document = PdfDocument()

        when (reportType) {
            PdfReportType.CON_HAN_GYM,
            PdfReportType.GIA_HAN_GYM,
            PdfReportType.CON_HAN_YOGA,
            PdfReportType.GIA_HAN_YOGA -> {
                renderMemberTablePages(
                    document = document,
                    reportTitle = reportType.titleVi,
                    boMonLabel = reportType.boMon,
                    methodologyText = reportType.methodologyVi,
                    month = month,
                    year = year,
                    rows = memberRows
                )
            }
            PdfReportType.PT -> {
                renderPtTablePages(
                    document = document,
                    reportTitle = reportType.titleVi,
                    month = month,
                    year = year,
                    rows = ptRows
                )
            }
            PdfReportType.KHACH_LE -> {
                renderWalkInTablePages(
                    document = document,
                    reportTitle = reportType.titleVi,
                    month = month,
                    year = year,
                    rows = walkInRows
                )
            }
            PdfReportType.TONG_HOP_GYM, PdfReportType.TONG_HOP_YOGA -> {
                renderSummaryPages(
                    document = document,
                    reportTitle = reportType.titleVi,
                    boMonLabel = reportType.boMon,
                    month = month,
                    year = year,
                    cashFlowRows = summaryCashFlowRows,
                    allocatedRows = summaryAllocatedRows,
                    totalCashFlow = totalCashFlow,
                    totalAllocated = totalAllocated,
                    memberRows = memberRows
                )
            }
        }

        document.writeTo(outputStream)
        document.close()
    }

    /**
     * Bảng báo cáo hội viên chuẩn hóa (Mục 1, 2, 6, 7):
     * STT | Họ tên | Gói tập | Ngày bắt đầu HĐ | Ngày kết thúc HĐ | Giá trị hợp đồng | Doanh thu phân bổ trong tháng
     */
    private fun renderMemberTablePages(
        document: PdfDocument,
        reportTitle: String,
        boMonLabel: String,
        methodologyText: String,
        month: Int,
        year: Int,
        rows: List<MemberReportRow>
    ) {
        val colHeaders = listOf(
            "STT",
            "Họ tên",
            "Gói tập",
            "Ngày bắt đầu HĐ",
            "Ngày kết thúc HĐ",
            "Giá trị hợp đồng",
            "Doanh thu phân bổ trong tháng"
        )
        // Sum = 32 + 120 + 79 + 68 + 68 + 86 + 94 = 547f
        val colWidths = floatArrayOf(32f, 120f, 79f, 68f, 68f, 86f, 94f)
        val colAlignRight = booleanArrayOf(false, false, false, false, false, true, true)

        val filteredRows = rows.filter { it.boMon == boMonLabel }
        val tableData = filteredRows.map { r ->
            listOf(
                r.stt.toString(),
                r.hoTen,
                r.goiTap,
                r.ngayBatDauDisplay,
                r.ngayHetHanDisplay,
                DateUtils.formatVnd(r.soTienHopDong, withUnit = false),
                DateUtils.formatVnd(r.doanhThuPhanBo, withUnit = false)
            )
        }

        val totalContractSum = filteredRows.sumOf { it.soTienHopDong }
        val totalAllocatedSum = filteredRows.sumOf { it.doanhThuPhanBo }
        val footerCells = listOf(
            "",
            "TỔNG CỘNG (${filteredRows.size} HĐ)",
            "",
            "",
            "",
            DateUtils.formatVnd(totalContractSum),
            DateUtils.formatVnd(totalAllocatedSum)
        )

        renderGenericPaginatedTable(
            document = document,
            reportTitle = reportTitle,
            metaLine = "Bộ môn: $boMonLabel   |   Kỳ báo cáo: Tháng %02d/%04d   |   Đơn vị tiền tệ: VNĐ".format(month, year),
            methodologyLine = "Phương pháp ghi nhận: $methodologyText.",
            accentColor = if (boMonLabel == "YOGA") Color.parseColor("#6B2FB5") else Color.parseColor("#0F4C81"),
            headers = colHeaders,
            colWidths = colWidths,
            colAlignRight = colAlignRight,
            rows = tableData,
            footerRow = footerCells
        )
    }

    /**
     * Bảng báo cáo khách tập PT (Mục 3):
     * STT | Họ tên khách PT | Gói PT | Tổng số buổi | Số buổi đã tập trong T[MM]/[YYYY] | Số buổi còn lại | Giá trị hợp đồng PT | Phần doanh thu Trung tâm (50%) | Phần doanh thu Huấn luyện viên (50%)
     */
    private fun renderPtTablePages(
        document: PdfDocument,
        reportTitle: String,
        month: Int,
        year: Int,
        rows: List<PtReportRow>
    ) {
        val periodLabel = "T%02d/%04d".format(month, year)
        val colHeaders = listOf(
            "STT",
            "Họ tên khách PT",
            "Gói PT",
            "Tổng số buổi",
            "Số buổi đã tập trong $periodLabel",
            "Số buổi còn lại",
            "Giá trị hợp đồng PT",
            "Phần doanh thu Trung tâm (50%)",
            "Phần doanh thu Huấn luyện viên (50%)"
        )
        // Sum = 26 + 89 + 56 + 44 + 58 + 44 + 74 + 78 + 78 = 547f
        val colWidths = floatArrayOf(26f, 89f, 56f, 44f, 58f, 44f, 74f, 78f, 78f)
        val colAlignRight = booleanArrayOf(false, false, false, true, true, true, true, true, true)

        val tableData = rows.map { r ->
            listOf(
                r.stt.toString(),
                r.hoTen,
                r.goiPt,
                r.tongSoBuoi.toString(),
                r.soBuoiDaTapTrongThang.toString(),
                r.soBuoiConLai.toString(),
                DateUtils.formatVnd(r.soTienHopDong, withUnit = false),
                DateUtils.formatVnd(r.doanhThuTrungTam, withUnit = false),
                DateUtils.formatVnd(r.doanhThuPt, withUnit = false)
            )
        }

        val totalSessionsAll = rows.sumOf { it.tongSoBuoi }
        val totalSessionsInMonth = rows.sumOf { it.soBuoiDaTapTrongThang }
        val totalRemaining = rows.sumOf { it.soBuoiConLai }
        val totalContractValue = rows.sumOf { it.soTienHopDong }
        val totalCenter = rows.sumOf { it.doanhThuTrungTam }
        val totalPt = rows.sumOf { it.doanhThuPt }

        val footerCells = listOf(
            "",
            "TỔNG CỘNG (${rows.size} HĐ)",
            "",
            totalSessionsAll.toString(),
            totalSessionsInMonth.toString(),
            totalRemaining.toString(),
            DateUtils.formatVnd(totalContractValue),
            DateUtils.formatVnd(totalCenter),
            DateUtils.formatVnd(totalPt)
        )

        renderGenericPaginatedTable(
            document = document,
            reportTitle = reportTitle,
            metaLine = "Bộ môn: GYM   |   Kỳ báo cáo: Tháng %02d/%04d   |   Đơn vị tiền tệ: VNĐ".format(month, year),
            methodologyLine = "Phương pháp ghi nhận: $METHOD_PT_ALLOCATION (Chia tỷ lệ 50% Trung tâm / 50% Huấn luyện viên).",
            accentColor = Color.parseColor("#0F4C81"),
            headers = colHeaders,
            colWidths = colWidths,
            colAlignRight = colAlignRight,
            rows = tableData,
            footerRow = footerCells
        )
    }

    /**
     * Bảng báo cáo khách tập buổi lẻ & tuần lẻ (Mục 4):
     * STT | Mã GD | Loại vé | Số ngày sử dụng | Ngày thanh toán | Thời gian sử dụng | Số tiền thực thu | Doanh thu phân bổ trong tháng
     */
    private fun renderWalkInTablePages(
        document: PdfDocument,
        reportTitle: String,
        month: Int,
        year: Int,
        rows: List<WalkInReportRow>
    ) {
        val colHeaders = listOf(
            "STT",
            "Mã GD",
            "Loại vé",
            "Số ngày sử dụng",
            "Ngày thanh toán",
            "Thời gian sử dụng",
            "Số tiền thực thu",
            "Doanh thu phân bổ trong tháng"
        )
        // Sum = 28 + 58 + 76 + 50 + 66 + 97 + 82 + 90 = 547f
        val colWidths = floatArrayOf(28f, 58f, 76f, 50f, 66f, 97f, 82f, 90f)
        val colAlignRight = booleanArrayOf(false, false, false, true, false, false, true, true)

        val tableData = rows.map { r ->
            listOf(
                r.stt.toString(),
                r.maGiaoDich,
                r.tenLoaiVe,
                r.soNgaySuDung.toString(),
                r.ngayThuDisplay,
                r.thoiGianSuDungDisplay,
                DateUtils.formatVnd(r.soTienThanhToan, withUnit = false),
                DateUtils.formatVnd(r.doanhThuPhanBoThang, withUnit = false)
            )
        }

        val totalDaysUsed = rows.sumOf { it.soNgaySuDung }
        val totalCollected = rows.sumOf { it.soTienThanhToan }
        val totalAllocated = rows.sumOf { it.doanhThuPhanBoThang }
        val footerCells = listOf(
            "",
            "TỔNG CỘNG",
            "${rows.size} vé",
            totalDaysUsed.toString(),
            "",
            "",
            DateUtils.formatVnd(totalCollected),
            DateUtils.formatVnd(totalAllocated)
        )

        renderGenericPaginatedTable(
            document = document,
            reportTitle = reportTitle,
            metaLine = "Bộ môn: GYM   |   Kỳ báo cáo: Tháng %02d/%04d   |   Đơn vị tiền tệ: VNĐ".format(month, year),
            methodologyLine = "Phương pháp: Vé ngày ($METHOD_DAILY_WALK_IN) • Vé tuần ($METHOD_WEEKLY_WALK_IN).",
            accentColor = Color.parseColor("#0F4C81"),
            headers = colHeaders,
            colWidths = colWidths,
            colAlignRight = colAlignRight,
            rows = tableData,
            footerRow = footerCells
        )
    }

    /**
     * Báo cáo tổng hợp doanh thu GYM (Mục 5) & YOGA (Mục 8):
     * - Phần đầu: Tách Bảng A (A. DOANH THU THỰC THU) và Bảng B (B. DOANH THU PHÂN BỔ) rõ ràng kèm mô tả.
     * - Phần dưới: Bảng C (Chi tiết hợp đồng hội viên của bộ môn tương ứng trong kỳ).
     */
    private fun renderSummaryPages(
        document: PdfDocument,
        reportTitle: String,
        boMonLabel: String,
        month: Int,
        year: Int,
        cashFlowRows: List<SummaryMetricRow>,
        allocatedRows: List<SummaryMetricRow>,
        totalCashFlow: Long,
        totalAllocated: Long,
        memberRows: List<MemberReportRow>
    ) {
        val accentColor = if (boMonLabel == "YOGA") Color.parseColor("#6B2FB5") else Color.parseColor("#0F4C81")
        val filteredMemberRows = memberRows.filter { it.boMon == boMonLabel }

        val brandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#475569")
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            textSize = 14f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val metaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1E293B")
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val sectionTitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            textSize = 10.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val sectionDescPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#475569")
            textSize = 8.8f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val headerBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            style = Paint.Style.FILL
        }
        val headerTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 8.6f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val cellTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = 8.6f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val emptyTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#475569")
            textSize = 9.2f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
        }
        val footerBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (boMonLabel == "YOGA") Color.parseColor("#F3E8FF") else Color.parseColor("#E0F2FE")
            style = Paint.Style.FILL
        }
        val footerTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#CBD5E1")
            style = Paint.Style.STROKE
            strokeWidth = 0.7f
        }
        val zebraPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F8FAFC")
            style = Paint.Style.FILL
        }
        val pageNumPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#64748B")
            textSize = 8.5f
        }

        val lineSpacing = 11.5f
        val cellPaddingV = 5.5f
        val cellPaddingH = 5f

        // Summary tables A & B column layout (Sum = 34 + 185 + 168 + 62 + 98 = 547f)
        val sumWidths = floatArrayOf(34f, 185f, 168f, 62f, 98f)
        val sumAlignRight = booleanArrayOf(false, false, false, true, true)
        val headersA = listOf(
            "STT",
            "Khoản mục thu tiền",
            "Phương pháp ghi nhận",
            "Số giao dịch",
            "Số tiền thực thu (VNĐ)"
        )
        val headersB = listOf(
            "STT",
            "Hạng mục doanh thu phân bổ",
            "Phương pháp phân bổ doanh thu",
            "Số lượng",
            "Doanh thu phân bổ trong tháng"
        )

        // Detailed Member Table C column layout (Sum = 32 + 120 + 79 + 68 + 68 + 86 + 94 = 547f)
        val memHeaders = listOf(
            "STT",
            "Họ tên",
            "Gói tập",
            "Ngày bắt đầu HĐ",
            "Ngày kết thúc HĐ",
            "Giá trị hợp đồng",
            "Doanh thu phân bổ trong tháng"
        )
        val memWidths = floatArrayOf(32f, 120f, 79f, 68f, 68f, 86f, 94f)
        val memAlignRight = booleanArrayOf(false, false, false, false, false, true, true)

        val measuredMemberRows = filteredMemberRows.map { r ->
            val goiTapWithTag = if (r.loaiBaoCaoLabel.isNotBlank()) {
                "${r.goiTap} (${r.loaiBaoCaoLabel})"
            } else {
                r.goiTap
            }
            val rawCells = listOf(
                r.stt.toString(),
                r.hoTen,
                goiTapWithTag,
                r.ngayBatDauDisplay,
                r.ngayHetHanDisplay,
                DateUtils.formatVnd(r.soTienHopDong, withUnit = false),
                DateUtils.formatVnd(r.doanhThuPhanBo, withUnit = false)
            )
            val wrapped = rawCells.mapIndexed { idx, txt ->
                wrapTextToWidth(txt, cellTextPaint, memWidths[idx] - 2 * cellPaddingH)
            }
            val maxLines = wrapped.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
            MeasuredRow(
                wrappedCols = wrapped,
                height = maxLines * lineSpacing + 2 * cellPaddingV,
                isFooter = false,
                isEmptyNotice = false
            )
        }

        val totalContractSum = filteredMemberRows.sumOf { it.soTienHopDong }
        val totalMemberAllocatedSum = filteredMemberRows.sumOf { it.doanhThuPhanBo }
        val memFooterRaw = listOf(
            "",
            "TỔNG CỘNG HỘI VIÊN (${filteredMemberRows.size} HĐ)",
            "",
            "",
            "",
            DateUtils.formatVnd(totalContractSum),
            DateUtils.formatVnd(totalMemberAllocatedSum)
        )
        val wrappedMemFooter = memFooterRaw.mapIndexed { idx, txt ->
            wrapTextToWidth(txt, footerTextPaint, memWidths[idx] - 2 * cellPaddingH)
        }
        val memFooterMaxLines = wrappedMemFooter.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
        val measuredMemFooter = MeasuredRow(
            wrappedCols = wrappedMemFooter,
            height = memFooterMaxLines * lineSpacing + 2 * cellPaddingV + 2f,
            isFooter = true,
            isEmptyNotice = false
        )

        val memberRowsForPagination = if (measuredMemberRows.isEmpty()) {
            listOf(
                MeasuredRow(
                    wrappedCols = listOf(listOf(EMPTY_REPORT_MESSAGE)),
                    height = 28f,
                    isFooter = false,
                    isEmptyNotice = true
                ),
                measuredMemFooter
            )
        } else {
            measuredMemberRows + measuredMemFooter
        }

        val memHeaderWrapped = memHeaders.mapIndexed { idx, h ->
            wrapTextToWidth(h, headerTextPaint, memWidths[idx] - 2 * cellPaddingH)
        }
        val memHeaderHeight = (memHeaderWrapped.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1) * lineSpacing + 2 * cellPaddingV + 2f

        // Pre-measure Table A & Table B heights so we can paginate Table C accurately
        val tableAHeaderWrapped = headersA.mapIndexed { idx, h ->
            wrapTextToWidth(h, headerTextPaint, sumWidths[idx] - 2 * cellPaddingH)
        }
        val tableAHeaderH = (tableAHeaderWrapped.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1) * lineSpacing + 2 * cellPaddingV + 2f
        val measuredTableARows = cashFlowRows.mapIndexed { i, item ->
            val cells = listOf(
                "A.${i + 1}",
                item.hangMuc,
                item.moTa,
                "${item.soLuongBanGhi} ${item.donViBanGhi}",
                DateUtils.formatVnd(item.soTien, withUnit = false)
            )
            val w = cells.mapIndexed { colIdx, t -> wrapTextToWidth(t, cellTextPaint, sumWidths[colIdx] - 2 * cellPaddingH) }
            val lines = w.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
            MeasuredRow(w, lines * lineSpacing + 2 * cellPaddingV)
        }
        val tableAFooterCells = listOf(
            "",
            GROUP_A_TOTAL_LABEL,
            "Tháng %02d/%04d".format(month, year),
            "${cashFlowRows.sumOf { it.soLuongBanGhi }} GD",
            DateUtils.formatVnd(totalCashFlow)
        )
        val tableAFooterWrapped = tableAFooterCells.mapIndexed { colIdx, t ->
            wrapTextToWidth(t, footerTextPaint, sumWidths[colIdx] - 2 * cellPaddingH)
        }
        val tableAFooterRow = MeasuredRow(
            wrappedCols = tableAFooterWrapped,
            height = (tableAFooterWrapped.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1) * lineSpacing + 2 * cellPaddingV + 2f,
            isFooter = true
        )

        val tableBHeaderWrapped = headersB.mapIndexed { idx, h ->
            wrapTextToWidth(h, headerTextPaint, sumWidths[idx] - 2 * cellPaddingH)
        }
        val tableBHeaderH = (tableBHeaderWrapped.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1) * lineSpacing + 2 * cellPaddingV + 2f
        val measuredTableBRows = allocatedRows.mapIndexed { i, item ->
            val cells = listOf(
                "B.${i + 1}",
                item.hangMuc,
                item.moTa,
                "${item.soLuongBanGhi} ${item.donViBanGhi}",
                DateUtils.formatVnd(item.soTien, withUnit = false)
            )
            val w = cells.mapIndexed { colIdx, t -> wrapTextToWidth(t, cellTextPaint, sumWidths[colIdx] - 2 * cellPaddingH) }
            val lines = w.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
            MeasuredRow(w, lines * lineSpacing + 2 * cellPaddingV)
        }
        val tableBFooterCells = listOf(
            "",
            GROUP_B_TOTAL_LABEL,
            "Tháng %02d/%04d".format(month, year),
            "${allocatedRows.sumOf { it.soLuongBanGhi }} mục",
            DateUtils.formatVnd(totalAllocated)
        )
        val tableBFooterWrapped = tableBFooterCells.mapIndexed { colIdx, t ->
            wrapTextToWidth(t, footerTextPaint, sumWidths[colIdx] - 2 * cellPaddingH)
        }
        val tableBFooterRow = MeasuredRow(
            wrappedCols = tableBFooterWrapped,
            height = (tableBFooterWrapped.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1) * lineSpacing + 2 * cellPaddingV + 2f,
            isFooter = true
        )

        // Calculate starting Y for Section C on Page 1
        val topHeaderBlockH = 58f
        val sectionABlockH = 30f + tableAHeaderH + measuredTableARows.sumOf { it.height.toDouble() }.toFloat() + tableAFooterRow.height
        val sectionBBlockH = 32f + tableBHeaderH + measuredTableBRows.sumOf { it.height.toDouble() }.toFloat() + tableBFooterRow.height
        val sectionCHeadingH = 34f + memHeaderHeight
        val maxBottomY = A4_HEIGHT - MARGIN_BOTTOM

        val page1SectionCStartY = MARGIN_TOP + topHeaderBlockH + sectionABlockH + sectionBBlockH + sectionCHeadingH
        val nextPageStartY = MARGIN_TOP + 24f + memHeaderHeight

        val memberPages = mutableListOf<List<MeasuredRow>>()
        var currRows = mutableListOf<MeasuredRow>()
        var currY = page1SectionCStartY

        for (mRow in memberRowsForPagination) {
            if (currY + mRow.height > maxBottomY && currRows.isNotEmpty()) {
                memberPages.add(currRows)
                currRows = mutableListOf()
                currY = nextPageStartY
            }
            currRows.add(mRow)
            currY += mRow.height
        }
        if (currRows.isNotEmpty()) {
            memberPages.add(currRows)
        }
        val totalPages = memberPages.size.coerceAtLeast(1)

        memberPages.forEachIndexed { pageIdx, pageMemberRows ->
            val pageNumber = pageIdx + 1
            val pageInfo = PdfDocument.PageInfo.Builder(A4_WIDTH, A4_HEIGHT, pageNumber).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            var y = MARGIN_TOP
            if (pageIdx == 0) {
                // Brand & Report Header
                canvas.drawText("89 FITNESS & YOGA", MARGIN_H, y + 10f, brandPaint)
                y += 24f
                canvas.drawText(reportTitle, MARGIN_H, y, titlePaint)
                y += 16f
                canvas.drawText(
                    "Bộ môn: $boMonLabel   |   Kỳ báo cáo: Tháng %02d/%04d   |   Đơn vị tiền tệ: VNĐ".format(month, year),
                    MARGIN_H,
                    y,
                    metaPaint
                )
                y += 18f

                // --- KHỐI A: DOANH THU THỰC THU ---
                canvas.drawText(GROUP_A_TITLE, MARGIN_H, y, sectionTitlePaint)
                y += 13f
                canvas.drawText("Mô tả: $GROUP_A_DESC", MARGIN_H, y, sectionDescPaint)
                y += 7f
                drawWrappedTableHeader(
                    canvas = canvas,
                    startX = MARGIN_H,
                    startY = y,
                    height = tableAHeaderH,
                    wrappedHeaders = tableAHeaderWrapped,
                    colWidths = sumWidths,
                    colAlignRight = sumAlignRight,
                    bgPaint = headerBgPaint,
                    textPaint = headerTextPaint,
                    borderPaint = borderPaint,
                    paddingH = cellPaddingH,
                    paddingV = cellPaddingV,
                    lineSpacing = lineSpacing
                )
                y += tableAHeaderH
                (measuredTableARows + tableAFooterRow).forEachIndexed { rIdx, mRow ->
                    drawSingleTableRow(
                        canvas = canvas,
                        startX = MARGIN_H,
                        startY = y,
                        mRow = mRow,
                        rowIdx = rIdx,
                        colWidths = sumWidths,
                        colAlignRight = sumAlignRight,
                        cellTextPaint = cellTextPaint,
                        footerTextPaint = footerTextPaint,
                        emptyTextPaint = emptyTextPaint,
                        footerBgPaint = footerBgPaint,
                        zebraPaint = zebraPaint,
                        borderPaint = borderPaint,
                        paddingH = cellPaddingH,
                        paddingV = cellPaddingV,
                        lineSpacing = lineSpacing
                    )
                    y += mRow.height
                }

                y += 14f

                // --- KHỐI B: DOANH THU PHÂN BỔ ---
                canvas.drawText(GROUP_B_TITLE, MARGIN_H, y, sectionTitlePaint)
                y += 13f
                canvas.drawText("Mô tả: $GROUP_B_DESC", MARGIN_H, y, sectionDescPaint)
                y += 7f
                drawWrappedTableHeader(
                    canvas = canvas,
                    startX = MARGIN_H,
                    startY = y,
                    height = tableBHeaderH,
                    wrappedHeaders = tableBHeaderWrapped,
                    colWidths = sumWidths,
                    colAlignRight = sumAlignRight,
                    bgPaint = headerBgPaint,
                    textPaint = headerTextPaint,
                    borderPaint = borderPaint,
                    paddingH = cellPaddingH,
                    paddingV = cellPaddingV,
                    lineSpacing = lineSpacing
                )
                y += tableBHeaderH
                (measuredTableBRows + tableBFooterRow).forEachIndexed { rIdx, mRow ->
                    drawSingleTableRow(
                        canvas = canvas,
                        startX = MARGIN_H,
                        startY = y,
                        mRow = mRow,
                        rowIdx = rIdx,
                        colWidths = sumWidths,
                        colAlignRight = sumAlignRight,
                        cellTextPaint = cellTextPaint,
                        footerTextPaint = footerTextPaint,
                        emptyTextPaint = emptyTextPaint,
                        footerBgPaint = footerBgPaint,
                        zebraPaint = zebraPaint,
                        borderPaint = borderPaint,
                        paddingH = cellPaddingH,
                        paddingV = cellPaddingV,
                        lineSpacing = lineSpacing
                    )
                    y += mRow.height
                }

                y += 16f

                // --- KHỐI C: BẢNG CHI TIẾT HỢP ĐỒNG HỘI VIÊN ---
                canvas.drawText(
                    "C. DANH SÁCH CHI TIẾT HỢP ĐỒNG HỘI VIÊN $boMonLabel TRONG KỲ (${filteredMemberRows.size} HĐ)",
                    MARGIN_H,
                    y,
                    sectionTitlePaint
                )
                y += 13f
                canvas.drawText(
                    "Phương pháp ghi nhận: $METHOD_MEMBER_ALLOCATION.",
                    MARGIN_H,
                    y,
                    sectionDescPaint
                )
                y += 7f
            } else {
                canvas.drawText(
                    "$reportTitle — Bộ môn: $boMonLabel (Trang tiếp theo)",
                    MARGIN_H,
                    y + 10f,
                    metaPaint
                )
                y += 20f
            }

            // Draw Member Table Header (repeated on every page)
            drawWrappedTableHeader(
                canvas = canvas,
                startX = MARGIN_H,
                startY = y,
                height = memHeaderHeight,
                wrappedHeaders = memHeaderWrapped,
                colWidths = memWidths,
                colAlignRight = memAlignRight,
                bgPaint = headerBgPaint,
                textPaint = headerTextPaint,
                borderPaint = borderPaint,
                paddingH = cellPaddingH,
                paddingV = cellPaddingV,
                lineSpacing = lineSpacing
            )
            y += memHeaderHeight

            pageMemberRows.forEachIndexed { rIdx, mRow ->
                drawSingleTableRow(
                    canvas = canvas,
                    startX = MARGIN_H,
                    startY = y,
                    mRow = mRow,
                    rowIdx = rIdx,
                    colWidths = memWidths,
                    colAlignRight = memAlignRight,
                    cellTextPaint = cellTextPaint,
                    footerTextPaint = footerTextPaint,
                    emptyTextPaint = emptyTextPaint,
                    footerBgPaint = footerBgPaint,
                    zebraPaint = zebraPaint,
                    borderPaint = borderPaint,
                    paddingH = cellPaddingH,
                    paddingV = cellPaddingV,
                    lineSpacing = lineSpacing
                )
                y += mRow.height
            }

            drawPageFooter(canvas, pageNumber, totalPages, pageNumPaint)
            document.finishPage(page)
        }
    }

    private data class MeasuredRow(
        val wrappedCols: List<List<String>>,
        val height: Float,
        val isFooter: Boolean = false,
        val isEmptyNotice: Boolean = false
    )

    private fun renderGenericPaginatedTable(
        document: PdfDocument,
        reportTitle: String,
        metaLine: String,
        methodologyLine: String,
        accentColor: Int,
        headers: List<String>,
        colWidths: FloatArray,
        colAlignRight: BooleanArray,
        rows: List<List<String>>,
        footerRow: List<String>
    ) {
        val brandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#475569")
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            textSize = 14f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val metaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1E293B")
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val methodPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#475569")
            textSize = 8.8f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val headerBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            style = Paint.Style.FILL
        }
        val headerTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 8.6f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val cellTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = 8.8f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val emptyTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#475569")
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
        }
        val footerBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#EFF6FF")
            style = Paint.Style.FILL
        }
        val footerTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#CBD5E1")
            style = Paint.Style.STROKE
            strokeWidth = 0.7f
        }
        val zebraPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F8FAFC")
            style = Paint.Style.FILL
        }
        val pageNumPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#64748B")
            textSize = 8.5f
        }

        val lineSpacing = 12f
        val cellPaddingV = 6f
        val cellPaddingH = 5f

        // Wrap multi-line column headers so long Vietnamese headers never overflow or squeeze
        val wrappedHeaders = headers.mapIndexed { colIdx, title ->
            wrapTextToWidth(title, headerTextPaint, colWidths[colIdx] - 2 * cellPaddingH)
        }
        val headerMaxLines = wrappedHeaders.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
        val headerHeight = headerMaxLines * lineSpacing + 2 * cellPaddingV + 2f

        val measuredDataRows = rows.map { row ->
            val wrapped = row.mapIndexed { colIdx, text ->
                wrapTextToWidth(text, cellTextPaint, colWidths[colIdx] - 2 * cellPaddingH)
            }
            val maxLines = wrapped.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
            val h = maxLines * lineSpacing + 2 * cellPaddingV
            MeasuredRow(wrapped, h, isFooter = false, isEmptyNotice = false)
        }

        val wrappedFooter = footerRow.mapIndexed { colIdx, text ->
            wrapTextToWidth(text, footerTextPaint, colWidths[colIdx] - 2 * cellPaddingH)
        }
        val footerMaxLines = wrappedFooter.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
        val measuredFooter = MeasuredRow(
            wrappedCols = wrappedFooter,
            height = footerMaxLines * lineSpacing + 2 * cellPaddingV + 2f,
            isFooter = true,
            isEmptyNotice = false
        )

        val allRowsToPaginate = if (measuredDataRows.isEmpty()) {
            listOf(
                MeasuredRow(
                    wrappedCols = listOf(listOf(EMPTY_REPORT_MESSAGE)),
                    height = 32f,
                    isFooter = false,
                    isEmptyNotice = true
                ),
                measuredFooter
            )
        } else {
            measuredDataRows + measuredFooter
        }

        // Group rows into pages
        val pages = mutableListOf<List<MeasuredRow>>()
        var currentPageRows = mutableListOf<MeasuredRow>()
        val firstPageTopY = MARGIN_TOP + 64f + headerHeight
        val nextPageTopY = MARGIN_TOP + 24f + headerHeight
        val maxBottomY = A4_HEIGHT - MARGIN_BOTTOM

        var currentY = firstPageTopY
        for (mRow in allRowsToPaginate) {
            if (currentY + mRow.height > maxBottomY && currentPageRows.isNotEmpty()) {
                pages.add(currentPageRows)
                currentPageRows = mutableListOf()
                currentY = nextPageTopY
            }
            currentPageRows.add(mRow)
            currentY += mRow.height
        }
        if (currentPageRows.isNotEmpty()) {
            pages.add(currentPageRows)
        }
        val totalPages = pages.size.coerceAtLeast(1)

        // Draw each page
        pages.forEachIndexed { pageIdx, pageRows ->
            val pageNumber = pageIdx + 1
            val pageInfo = PdfDocument.PageInfo.Builder(A4_WIDTH, A4_HEIGHT, pageNumber).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            var y = MARGIN_TOP
            if (pageIdx == 0) {
                canvas.drawText("89 FITNESS & YOGA", MARGIN_H, y + 10f, brandPaint)
                y += 24f
                canvas.drawText(reportTitle, MARGIN_H, y, titlePaint)
                y += 16f
                canvas.drawText(metaLine, MARGIN_H, y, metaPaint)
                y += 14f
                canvas.drawText(methodologyLine, MARGIN_H, y, methodPaint)
                y += 10f
            } else {
                canvas.drawText("$reportTitle (Trang tiếp theo)", MARGIN_H, y + 10f, metaPaint)
                y += 20f
            }

            // Draw table header (repeated on every page)
            drawWrappedTableHeader(
                canvas = canvas,
                startX = MARGIN_H,
                startY = y,
                height = headerHeight,
                wrappedHeaders = wrappedHeaders,
                colWidths = colWidths,
                colAlignRight = colAlignRight,
                bgPaint = headerBgPaint,
                textPaint = headerTextPaint,
                borderPaint = borderPaint,
                paddingH = cellPaddingH,
                paddingV = cellPaddingV,
                lineSpacing = lineSpacing
            )
            y += headerHeight

            // Draw rows
            pageRows.forEachIndexed { rowIdx, mRow ->
                drawSingleTableRow(
                    canvas = canvas,
                    startX = MARGIN_H,
                    startY = y,
                    mRow = mRow,
                    rowIdx = rowIdx,
                    colWidths = colWidths,
                    colAlignRight = colAlignRight,
                    cellTextPaint = cellTextPaint,
                    footerTextPaint = footerTextPaint,
                    emptyTextPaint = emptyTextPaint,
                    footerBgPaint = footerBgPaint,
                    zebraPaint = zebraPaint,
                    borderPaint = borderPaint,
                    paddingH = cellPaddingH,
                    paddingV = cellPaddingV,
                    lineSpacing = lineSpacing
                )
                y += mRow.height
            }

            drawPageFooter(canvas, pageNumber, totalPages, pageNumPaint)
            document.finishPage(page)
        }
    }

    private fun drawWrappedTableHeader(
        canvas: Canvas,
        startX: Float,
        startY: Float,
        height: Float,
        wrappedHeaders: List<List<String>>,
        colWidths: FloatArray,
        colAlignRight: BooleanArray,
        bgPaint: Paint,
        textPaint: Paint,
        borderPaint: Paint,
        paddingH: Float,
        paddingV: Float,
        lineSpacing: Float
    ) {
        val headerRect = RectF(startX, startY, startX + TABLE_WIDTH, startY + height)
        canvas.drawRect(headerRect, bgPaint)

        var x = startX
        for (i in wrappedHeaders.indices) {
            val w = colWidths[i]
            val cellRect = RectF(x, startY, x + w, startY + height)
            canvas.drawRect(cellRect, borderPaint)

            val lines = wrappedHeaders[i]
            val totalTextH = lines.size * lineSpacing
            var lineY = startY + (height - totalTextH) / 2f + 9f
            for (line in lines) {
                if (colAlignRight[i]) {
                    val tw = textPaint.measureText(line)
                    canvas.drawText(line, (x + w - paddingH - tw).coerceAtLeast(x + 2f), lineY, textPaint)
                } else {
                    canvas.drawText(line, x + paddingH, lineY, textPaint)
                }
                lineY += lineSpacing
            }
            x += w
        }
    }

    private fun drawSingleTableRow(
        canvas: Canvas,
        startX: Float,
        startY: Float,
        mRow: MeasuredRow,
        rowIdx: Int,
        colWidths: FloatArray,
        colAlignRight: BooleanArray,
        cellTextPaint: Paint,
        footerTextPaint: Paint,
        emptyTextPaint: Paint,
        footerBgPaint: Paint,
        zebraPaint: Paint,
        borderPaint: Paint,
        paddingH: Float,
        paddingV: Float,
        lineSpacing: Float
    ) {
        val rowRect = RectF(startX, startY, startX + TABLE_WIDTH, startY + mRow.height)
        if (mRow.isFooter) {
            canvas.drawRect(rowRect, footerBgPaint)
        } else if (rowIdx % 2 == 1) {
            canvas.drawRect(rowRect, zebraPaint)
        }

        // Full-width centered row for empty state ("Không có dữ liệu trong kỳ báo cáo")
        if (mRow.isEmptyNotice) {
            canvas.drawRect(rowRect, borderPaint)
            val msg = mRow.wrappedCols.firstOrNull()?.firstOrNull() ?: EMPTY_REPORT_MESSAGE
            val textW = emptyTextPaint.measureText(msg)
            val centerX = startX + (TABLE_WIDTH - textW) / 2f
            val centerY = startY + mRow.height / 2f + 3.5f
            canvas.drawText(msg, centerX, centerY, emptyTextPaint)
            return
        }

        var x = startX
        for (colIdx in colWidths.indices) {
            val w = colWidths[colIdx]
            val cellRect = RectF(x, startY, x + w, startY + mRow.height)
            canvas.drawRect(cellRect, borderPaint)

            val lines = mRow.wrappedCols.getOrElse(colIdx) { emptyList() }
            val paintToUse = if (mRow.isFooter) footerTextPaint else cellTextPaint
            var lineY = startY + paddingV + 8.8f
            for (line in lines) {
                if (colAlignRight[colIdx]) {
                    val textW = paintToUse.measureText(line)
                    canvas.drawText(line, (x + w - paddingH - textW).coerceAtLeast(x + 2f), lineY, paintToUse)
                } else {
                    canvas.drawText(line, x + paddingH, lineY, paintToUse)
                }
                lineY += lineSpacing
            }
            x += w
        }
    }

    private fun drawPageFooter(
        canvas: Canvas,
        pageNumber: Int,
        totalPages: Int,
        pageNumPaint: Paint
    ) {
        val pageText = "Trang $pageNumber / $totalPages"
        val pw = pageNumPaint.measureText(pageText)
        canvas.drawText(pageText, A4_WIDTH - MARGIN_H - pw, A4_HEIGHT - 16f, pageNumPaint)
        canvas.drawText(
            "89 FITNESS & YOGA — Hệ thống Báo cáo Quản trị & Tài chính chuẩn A4",
            MARGIN_H,
            A4_HEIGHT - 16f,
            pageNumPaint
        )
    }

    private fun wrapTextToWidth(text: String, paint: Paint, maxWidth: Float): List<String> {
        if (text.isBlank()) return listOf("")
        if (paint.measureText(text) <= maxWidth) return listOf(text)

        val words = text.split(" ")
        val lines = mutableListOf<String>()
        var currentLine = StringBuilder()

        for (word in words) {
            val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
            if (paint.measureText(testLine) <= maxWidth) {
                currentLine = StringBuilder(testLine)
            } else {
                if (currentLine.isNotEmpty()) {
                    lines.add(currentLine.toString())
                    currentLine = StringBuilder()
                }
                if (paint.measureText(word) > maxWidth) {
                    var chunk = StringBuilder()
                    for (ch in word) {
                        if (paint.measureText("$chunk$ch") <= maxWidth) {
                            chunk.append(ch)
                        } else {
                            if (chunk.isNotEmpty()) lines.add(chunk.toString())
                            chunk = StringBuilder(ch.toString())
                        }
                    }
                    currentLine = chunk
                } else {
                    currentLine = StringBuilder(word)
                }
            }
        }
        if (currentLine.isNotEmpty()) {
            lines.add(currentLine.toString())
        }
        return lines
    }

    /**
     * Xuất nội dung Excel CSV (chuẩn UTF-8 BOM \uFEFF) đồng bộ 100% thuật ngữ và dữ liệu với PDF A4.
     * Giữ nguyên dữ liệu số để người dùng tính toán bằng công thức Excel, đồng thời có cột/dòng định dạng VNĐ.
     */
    fun buildExcelCsvContent(
        reportType: PdfReportType,
        month: Int,
        year: Int,
        memberRows: List<MemberReportRow> = emptyList(),
        ptRows: List<PtReportRow> = emptyList(),
        walkInRows: List<WalkInReportRow> = emptyList(),
        summaryCashFlowRows: List<SummaryMetricRow> = emptyList(),
        summaryAllocatedRows: List<SummaryMetricRow> = emptyList(),
        totalCashFlow: Long = 0L,
        totalAllocated: Long = 0L
    ): String {
        val periodStr = "Tháng %02d/%04d".format(month, year)
        val periodShort = "T%02d/%04d".format(month, year)
        val sb = StringBuilder("\uFEFF") // UTF-8 BOM for Excel Vietnamese support

        sb.appendLine("\"89 FITNESS & YOGA\"")
        sb.appendLine("\"${reportType.titleVi}\"")
        sb.appendLine("\"Bộ môn: ${reportType.boMon}\",\"Kỳ báo cáo: $periodStr\",\"Đơn vị tiền tệ: VNĐ\"")
        sb.appendLine("\"Phương pháp ghi nhận: ${reportType.methodologyVi}\"")
        sb.appendLine()

        when (reportType) {
            PdfReportType.CON_HAN_GYM,
            PdfReportType.GIA_HAN_GYM,
            PdfReportType.CON_HAN_YOGA,
            PdfReportType.GIA_HAN_YOGA -> {
                val filtered = memberRows.filter { it.boMon == reportType.boMon }
                sb.appendLine("STT,Bộ môn,Họ tên,Gói tập,Ngày bắt đầu HĐ,Ngày kết thúc HĐ,Số ngày hiệu lực trong tháng,Tổng số ngày HĐ,Giá trị hợp đồng (VNĐ),Doanh thu phân bổ trong tháng (VNĐ)")
                if (filtered.isEmpty()) {
                    sb.appendLine(",\"$EMPTY_REPORT_MESSAGE\",,,,,,,0,0")
                } else {
                    filtered.forEach { r ->
                        sb.appendLine("${r.stt},\"${r.boMon}\",\"${escapeCsv(r.hoTen)}\",\"${escapeCsv(r.goiTap)}\",\"${r.ngayBatDauDisplay}\",\"${r.ngayHetHanDisplay}\",${r.soNgayTrongThang},${r.tongSoNgayHopDong},${r.soTienHopDong},${r.doanhThuPhanBo}")
                    }
                }
                val sumContract = filtered.sumOf { it.soTienHopDong }
                val sumAlloc = filtered.sumOf { it.doanhThuPhanBo }
                sb.appendLine(",\"TỔNG CỘNG (${filtered.size} HĐ)\",,,,,,,$sumContract,$sumAlloc")
            }

            PdfReportType.PT -> {
                sb.appendLine("STT,Bộ môn,Họ tên khách PT,Gói PT,Tổng số buổi,Số buổi đã tập trong $periodShort,Số buổi còn lại,Giá trị hợp đồng PT (VNĐ),Phần doanh thu Trung tâm (50%) (VNĐ),Phần doanh thu Huấn luyện viên (50%) (VNĐ)")
                if (ptRows.isEmpty()) {
                    sb.appendLine(",\"$EMPTY_REPORT_MESSAGE\",,,0,0,0,0,0,0")
                } else {
                    ptRows.forEach { r ->
                        sb.appendLine("${r.stt},\"GYM\",\"${escapeCsv(r.hoTen)}\",\"${escapeCsv(r.goiPt)}\",${r.tongSoBuoi},${r.soBuoiDaTapTrongThang},${r.soBuoiConLai},${r.soTienHopDong},${r.doanhThuTrungTam},${r.doanhThuPt}")
                    }
                }
                sb.appendLine(",\"TỔNG CỘNG (${ptRows.size} HĐ)\",,,${ptRows.sumOf { it.tongSoBuoi }},${ptRows.sumOf { it.soBuoiDaTapTrongThang }},${ptRows.sumOf { it.soBuoiConLai }},${ptRows.sumOf { it.soTienHopDong }},${ptRows.sumOf { it.doanhThuTrungTam }},${ptRows.sumOf { it.doanhThuPt }}")
            }

            PdfReportType.KHACH_LE -> {
                sb.appendLine("STT,Bộ môn,Mã GD,Loại vé,Số ngày sử dụng,Ngày thanh toán,Thời gian sử dụng,Số tiền thực thu (VNĐ),Doanh thu phân bổ trong tháng (VNĐ)")
                if (walkInRows.isEmpty()) {
                    sb.appendLine(",\"$EMPTY_REPORT_MESSAGE\",,,0,,,0,0")
                } else {
                    walkInRows.forEach { r ->
                        sb.appendLine("${r.stt},\"GYM\",\"${r.maGiaoDich}\",\"${escapeCsv(r.tenLoaiVe)}\",${r.soNgaySuDung},\"${r.ngayThuDisplay}\",\"${r.thoiGianSuDungDisplay}\",${r.soTienThanhToan},${r.doanhThuPhanBoThang}")
                    }
                }
                sb.appendLine(",\"TỔNG CỘNG (${walkInRows.size} vé)\",,,${walkInRows.sumOf { it.soNgaySuDung }},,,${walkInRows.sumOf { it.soTienThanhToan }},${walkInRows.sumOf { it.doanhThuPhanBoThang }}")
            }

            PdfReportType.TONG_HOP_GYM, PdfReportType.TONG_HOP_YOGA -> {
                val filtered = memberRows.filter { it.boMon == reportType.boMon }

                sb.appendLine("\"$GROUP_A_TITLE\"")
                sb.appendLine("\"Mô tả: $GROUP_A_DESC\"")
                sb.appendLine("Nhóm,Hạng mục thu tiền,Phương pháp ghi nhận,Số lượng giao dịch,Số tiền thực thu (VNĐ)")
                summaryCashFlowRows.forEach { r ->
                    sb.appendLine("\"$GROUP_A_TITLE\",\"${escapeCsv(r.hangMuc)}\",\"${escapeCsv(r.moTa)}\",${r.soLuongBanGhi},${r.soTien}")
                }
                sb.appendLine("\"$GROUP_A_TITLE\",\"$GROUP_A_TOTAL_LABEL\",\"$periodStr\",${summaryCashFlowRows.sumOf { it.soLuongBanGhi }},$totalCashFlow")

                sb.appendLine()
                sb.appendLine("\"$GROUP_B_TITLE\"")
                sb.appendLine("\"Mô tả: $GROUP_B_DESC\"")
                sb.appendLine("Nhóm,Hạng mục doanh thu phân bổ,Phương pháp phân bổ doanh thu,Số lượng bản ghi,Doanh thu phân bổ trong tháng (VNĐ)")
                summaryAllocatedRows.forEach { r ->
                    sb.appendLine("\"$GROUP_B_TITLE\",\"${escapeCsv(r.hangMuc)}\",\"${escapeCsv(r.moTa)}\",${r.soLuongBanGhi},${r.soTien}")
                }
                sb.appendLine("\"$GROUP_B_TITLE\",\"$GROUP_B_TOTAL_LABEL\",\"$periodStr\",${summaryAllocatedRows.sumOf { it.soLuongBanGhi }},$totalAllocated")

                sb.appendLine()
                sb.appendLine("\"C. DANH SÁCH CHI TIẾT HỢP ĐỒNG HỘI VIÊN ${reportType.boMon} TRONG KỲ\"")
                sb.appendLine("STT,Bộ môn,Nhóm hợp đồng,Họ tên,Gói tập,Ngày bắt đầu HĐ,Ngày kết thúc HĐ,Số ngày hiệu lực trong tháng,Tổng số ngày HĐ,Giá trị hợp đồng (VNĐ),Doanh thu phân bổ trong tháng (VNĐ)")
                if (filtered.isEmpty()) {
                    sb.appendLine(",\"${reportType.boMon}\",\"$EMPTY_REPORT_MESSAGE\",,,,,,,0,0")
                } else {
                    filtered.forEach { r ->
                        sb.appendLine("${r.stt},\"${r.boMon}\",\"${escapeCsv(r.loaiBaoCaoLabel)}\",\"${escapeCsv(r.hoTen)}\",\"${escapeCsv(r.goiTap)}\",\"${r.ngayBatDauDisplay}\",\"${r.ngayHetHanDisplay}\",${r.soNgayTrongThang},${r.tongSoNgayHopDong},${r.soTienHopDong},${r.doanhThuPhanBo}")
                    }
                }
                sb.appendLine(",\"TỔNG CỘNG HỘI VIÊN (${filtered.size} HĐ)\",,,,,,,,${filtered.sumOf { it.soTienHopDong }},${filtered.sumOf { it.doanhThuPhanBo }}")
            }
        }
        return sb.toString()
    }

    private fun escapeCsv(input: String): String = input.replace("\"", "\"\"")

    /**
     * Lưu báo cáo PDF vào thư mục cache/reports và mở hộp thoại chia sẻ / xem PDF trên Android.
     */
    fun sharePdfFile(
        context: Context,
        fileName: String,
        writer: (OutputStream) -> Unit
    ): Result<Uri> {
        return try {
            val reportsDir = File(context.cacheDir, "reports")
            if (!reportsDir.exists()) reportsDir.mkdirs()
            val file = File(reportsDir, fileName)
            FileOutputStream(file).use { out ->
                writer(out)
            }
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(shareIntent, "Chia sẻ / Lưu báo cáo PDF A4").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            Result.success(uri)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun shareCsvOrJsonFile(
        context: Context,
        fileName: String,
        mimeType: String,
        content: String
    ): Result<Uri> {
        return try {
            val reportsDir = File(context.cacheDir, "reports")
            if (!reportsDir.exists()) reportsDir.mkdirs()
            val file = File(reportsDir, fileName)
            file.writeText(content, Charsets.UTF_8)
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(shareIntent, "Chia sẻ / Lưu tệp").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            Result.success(uri)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
