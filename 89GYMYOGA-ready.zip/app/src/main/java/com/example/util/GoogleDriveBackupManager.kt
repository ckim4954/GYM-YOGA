package com.example.util

import android.accounts.Account
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

data class DriveAccountProfile(
    val email: String,
    val displayName: String,
    val accessToken: String
)

typealias GoogleAccountProfile = DriveAccountProfile

data class DriveBackupFileItem(
    val id: String,
    val name: String,
    val createdTimeDisplay: String,
    val sizeBytes: Long
)

data class DriveAuthOutcome(
    val profile: DriveAccountProfile? = null,
    val pendingIntent: PendingIntent? = null,
    val selectedEmailHint: String? = null
)

object GoogleDriveBackupManager {

    const val DRIVE_FILE_SCOPE = "https://www.googleapis.com/auth/drive.file"
    private const val EMAIL_SCOPE = "email"
    private const val PROFILE_SCOPE = "profile"
    const val BACKUP_FOLDER_NAME = "89_Fitness_Yoga_Backups"

    private val httpClient = OkHttpClient()

    fun isNetworkAvailable(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /**
     * Trích xuất mã SHA-1 thực tế của chứng chỉ ký APK đang chạy trên thiết bị.
     * Giúp người quản trị kiểm tra và cấu hình chính xác OAuth Client ID trên Google Cloud Console.
     */
    @Suppress("DEPRECATION", "PackageManagerGetSignatures")
    fun getAppSigningSha1(context: Context): String {
        return try {
            val pm = context.packageManager
            val pkgName = context.packageName
            val signatureBytes: ByteArray? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val info = pm.getPackageInfo(pkgName, PackageManager.GET_SIGNING_CERTIFICATES)
                val signingInfo = info.signingInfo
                val sigs = if (signingInfo != null) {
                    if (signingInfo.hasMultipleSigners()) signingInfo.apkContentsSigners
                    else signingInfo.signingCertificateHistory
                } else null
                sigs?.firstOrNull()?.toByteArray()
            } else {
                val info = pm.getPackageInfo(pkgName, PackageManager.GET_SIGNATURES)
                info.signatures?.firstOrNull()?.toByteArray()
            }

            if (signatureBytes == null) {
                "Không đọc được chữ ký APK"
            } else {
                val md = MessageDigest.getInstance("SHA-1")
                val digest = md.digest(signatureBytes)
                digest.joinToString(":") { byte -> String.format("%02X", byte) }
            }
        } catch (e: Exception) {
            "Không xác định (${e.javaClass.simpleName})"
        }
    }

    /**
     * Tạo Intent mở hộp thoại chọn tài khoản Google (Account Picker) để mọi người dùng
     * trên mọi thiết bị đều có thể chọn đúng tài khoản Gmail muốn dùng.
     */
    suspend fun prepareAccountPickerSignInIntent(
        context: Context,
        forceAccountPicker: Boolean = true
    ): Intent = withContext(Dispatchers.IO) {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestProfile()
            .requestScopes(Scope(DRIVE_FILE_SCOPE))
            .build()
        val client = GoogleSignIn.getClient(context, gso)
        if (forceAccountPicker) {
            try {
                suspendCancellableCoroutine<Unit> { cont ->
                    client.signOut().addOnCompleteListener {
                        if (cont.isActive) cont.resume(Unit)
                    }
                }
            } catch (_: Exception) {
            }
        }
        client.signInIntent
    }

    /**
     * Xử lý kết quả sau khi người dùng chọn tài khoản Google từ Account Picker,
     * sau đó xin Access Token cho scope drive.file của đúng tài khoản vừa chọn.
     */
    suspend fun handleAccountPickerResultAndAuthorize(
        context: Context,
        data: Intent?
    ): Result<DriveAuthOutcome> {
        return try {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            val account: GoogleSignInAccount = task.getResult(ApiException::class.java)
            authorize(
                context = context,
                selectedAccount = account.account,
                fallbackEmail = account.email,
                fallbackDisplayName = account.displayName
            )
        } catch (e: ApiException) {
            // Nếu GoogleSignIn bị lỗi cấu hình SHA-1 (mã 10) hoặc bị hủy (mã 12501), thử fallback sang Identity AuthorizationClient
            if (e.statusCode == 12501) {
                Result.failure(IllegalStateException("Đã hủy chọn tài khoản Google."))
            } else {
                // Thử gọi trực tiếp Identity AuthorizationClient phòng trường hợp GIS hoạt động độc lập
                val fallbackRes = authorize(context, selectedAccount = null)
                if (fallbackRes.isSuccess) {
                    fallbackRes
                } else {
                    Result.failure(
                        IllegalStateException(buildOAuthDiagnosticMessage(context, e.statusCode, e.message))
                    )
                }
            }
        } catch (e: Exception) {
            authorize(context, selectedAccount = null)
        }
    }

    /**
     * Requests Google OAuth2 authorization for drive.file + email + profile using
     * Google Identity Services AuthorizationClient.
     */
    suspend fun authorize(
        context: Context,
        selectedAccount: Account? = null,
        fallbackEmail: String? = null,
        fallbackDisplayName: String? = null
    ): Result<DriveAuthOutcome> {
        if (!isNetworkAvailable(context)) {
            return Result.failure(IllegalStateException("Không có kết nối mạng. Vui lòng kiểm tra Wi-Fi/4G và thử lại."))
        }
        return try {
            val builder = AuthorizationRequest.builder()
                .setRequestedScopes(
                    listOf(
                        Scope(DRIVE_FILE_SCOPE),
                        Scope(EMAIL_SCOPE),
                        Scope(PROFILE_SCOPE)
                    )
                )
            if (selectedAccount != null) {
                builder.setAccount(selectedAccount)
            }
            val request = builder.build()

            val authClient = Identity.getAuthorizationClient(context)
            val result: AuthorizationResult = suspendCancellableCoroutine { cont ->
                authClient.authorize(request)
                    .addOnSuccessListener { res ->
                        if (cont.isActive) cont.resume(res)
                    }
                    .addOnFailureListener { err ->
                        if (cont.isActive) cont.resumeWithException(err)
                    }
            }

            if (result.hasResolution()) {
                val pendingIntent = result.pendingIntent
                if (pendingIntent != null) {
                    return Result.success(
                        DriveAuthOutcome(
                            pendingIntent = pendingIntent,
                            selectedEmailHint = fallbackEmail ?: selectedAccount?.name
                        )
                    )
                }
            }

            val token = result.accessToken
            if (token.isNullOrBlank()) {
                return Result.failure(IllegalStateException("Không nhận được Access Token từ Google. Vui lòng thử đăng nhập lại."))
            }

            val profile = fetchUserInfo(
                accessToken = token,
                fallbackEmail = fallbackEmail ?: selectedAccount?.name,
                fallbackName = fallbackDisplayName
            )
            Result.success(DriveAuthOutcome(profile = profile))
        } catch (e: ApiException) {
            Result.failure(
                IllegalStateException(buildOAuthDiagnosticMessage(context, e.statusCode, e.message))
            )
        } catch (e: Exception) {
            Result.failure(
                IllegalStateException("Không thể kết nối Google OAuth: ${e.localizedMessage ?: e.javaClass.simpleName}")
            )
        }
    }

    /**
     * Completes authorization after the user finishes the Google consent screen resolution.
     */
    suspend fun handleAuthorizationIntentResult(
        context: Context,
        data: Intent?,
        fallbackEmail: String? = null
    ): Result<DriveAccountProfile> {
        if (data == null) {
            return Result.failure(IllegalStateException("Đã hủy đăng nhập Google."))
        }
        return try {
            val authClient = Identity.getAuthorizationClient(context)
            val result = authClient.getAuthorizationResultFromIntent(data)
            val token = result.accessToken
            if (token.isNullOrBlank()) {
                return Result.failure(IllegalStateException("Google chưa cấp quyền truy cập Google Drive."))
            }
            val profile = fetchUserInfo(token, fallbackEmail = fallbackEmail)
            Result.success(profile)
        } catch (e: ApiException) {
            Result.failure(
                IllegalStateException(buildOAuthDiagnosticMessage(context, e.statusCode, e.message))
            )
        } catch (e: Exception) {
            Result.failure(
                IllegalStateException("Lỗi xử lý kết quả đăng nhập Google: ${e.localizedMessage ?: e.message}")
            )
        }
    }

    /**
     * Revokes the OAuth2 access token and signs out of both GoogleSignIn and Google Identity Services.
     */
    suspend fun revokeAccess(context: Context, accessToken: String) = withContext(Dispatchers.IO) {
        try {
            if (accessToken.isNotBlank()) {
                val req = Request.Builder()
                    .url("https://oauth2.googleapis.com/revoke?token=$accessToken")
                    .post("".toRequestBody("application/x-www-form-urlencoded".toMediaType()))
                    .build()
                httpClient.newCall(req).execute().close()
            }
        } catch (_: Exception) {
        }
        try {
            val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build()
            val client = GoogleSignIn.getClient(context, gso)
            suspendCancellableCoroutine<Unit> { cont ->
                client.revokeAccess().addOnCompleteListener {
                    if (cont.isActive) cont.resume(Unit)
                }
            }
            suspendCancellableCoroutine<Unit> { cont ->
                client.signOut().addOnCompleteListener {
                    if (cont.isActive) cont.resume(Unit)
                }
            }
        } catch (_: Exception) {
        }
        try {
            Identity.getSignInClient(context).signOut()
        } catch (_: Exception) {
        }
    }

    private suspend fun fetchUserInfo(
        accessToken: String,
        fallbackEmail: String? = null,
        fallbackName: String? = null
    ): DriveAccountProfile = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("https://www.googleapis.com/oauth2/v3/userinfo")
                .addHeader("Authorization", "Bearer $accessToken")
                .get()
                .build()
            httpClient.newCall(req).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyStr = response.body?.string().orEmpty()
                    val json = JSONObject(bodyStr)
                    val email = json.optString("email", fallbackEmail ?: "Đã kết nối tài khoản Google")
                    val name = json.optString("name", fallbackName ?: email)
                    return@withContext DriveAccountProfile(
                        email = email,
                        displayName = name,
                        accessToken = accessToken
                    )
                }
            }
        } catch (_: Exception) {
        }
        val resolvedEmail = fallbackEmail?.takeIf { it.isNotBlank() } ?: "Tài khoản Google đã cấp quyền Drive"
        val resolvedName = fallbackName?.takeIf { it.isNotBlank() } ?: resolvedEmail
        DriveAccountProfile(
            email = resolvedEmail,
            displayName = resolvedName,
            accessToken = accessToken
        )
    }

    /**
     * Finds or creates the dedicated "89_Fitness_Yoga_Backups" folder on Google Drive.
     */
    private suspend fun getOrCreateBackupFolderId(accessToken: String): String = withContext(Dispatchers.IO) {
        val query = "mimeType='application/vnd.google-apps.folder' and name='$BACKUP_FOLDER_NAME' and trashed=false"
        val encodedQuery = java.net.URLEncoder.encode(query, "UTF-8")
        val searchUrl = "https://www.googleapis.com/drive/v3/files?q=$encodedQuery&spaces=drive&fields=files(id,name)"

        val searchReq = Request.Builder()
            .url(searchUrl)
            .addHeader("Authorization", "Bearer $accessToken")
            .get()
            .build()

        httpClient.newCall(searchReq).execute().use { resp ->
            val respBody = resp.body?.string().orEmpty()
            if (resp.code == 401 || resp.code == 403) {
                throw IllegalStateException("Phiên đăng nhập Google Drive đã hết hạn hoặc thiếu quyền truy cập (HTTP ${resp.code}). Vui lòng bấm 'Đổi tài khoản / Kết nối lại' và thử lại.")
            }
            if (!resp.isSuccessful) {
                throw IllegalStateException("Google Drive từ chối truy vấn thư mục (HTTP ${resp.code}): $respBody")
            }
            val files = JSONObject(respBody).optJSONArray("files") ?: JSONArray()
            if (files.length() > 0) {
                return@withContext files.getJSONObject(0).getString("id")
            }
        }

        // Create folder if not found
        val metaJson = JSONObject().apply {
            put("name", BACKUP_FOLDER_NAME)
            put("mimeType", "application/vnd.google-apps.folder")
        }
        val createReq = Request.Builder()
            .url("https://www.googleapis.com/drive/v3/files?fields=id")
            .addHeader("Authorization", "Bearer $accessToken")
            .post(metaJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        httpClient.newCall(createReq).execute().use { resp ->
            val respBody = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                throw IllegalStateException("Không thể tạo thư mục sao lưu trên Google Drive (HTTP ${resp.code}): $respBody")
            }
            return@withContext JSONObject(respBody).getString("id")
        }
    }

    /**
     * Uploads a validated JSON backup to Google Drive inside 89_Fitness_Yoga_Backups,
     * then verifies the file actually exists on Google Drive before returning success.
     */
    suspend fun uploadBackupToDrive(
        accessToken: String,
        backupJson: String
    ): Result<DriveBackupFileItem> = withContext(Dispatchers.IO) {
        try {
            if (backupJson.isBlank()) {
                return@withContext Result.failure(
                    IllegalStateException("Dữ liệu sao lưu trống, không thể tải lên Google Drive.")
                )
            }
            val folderId = getOrCreateBackupFolderId(accessToken)
            val timestampStr = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
            val fileName = "89FitnessYoga_Backup_$timestampStr.json"

            val metadataJson = JSONObject().apply {
                put("name", fileName)
                put("mimeType", "application/json")
                put("parents", JSONArray().put(folderId))
                put("description", "Bản sao lưu dữ liệu đầy đủ 9 bảng ứng dụng 89 FITNESS & YOGA")
            }

            val multipartBody = MultipartBody.Builder()
                .setType("multipart/related".toMediaType())
                .addPart(metadataJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .addPart(backupJson.toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()

            val uploadReq = Request.Builder()
                .url("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,createdTime,size")
                .addHeader("Authorization", "Bearer $accessToken")
                .post(multipartBody)
                .build()

            val uploadedFileId: String
            val uploadedName: String
            val uploadedCreatedIso: String
            val uploadedSize: Long

            httpClient.newCall(uploadReq).execute().use { resp ->
                val respBody = resp.body?.string().orEmpty()
                if (resp.code == 401 || resp.code == 403) {
                    return@withContext Result.failure(
                        IllegalStateException("Phiên truy cập Google Drive đã hết hạn (HTTP ${resp.code}). Vui lòng bấm Kết nối lại tài khoản Google.")
                    )
                }
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException("Google Drive trả về lỗi khi tải lên (HTTP ${resp.code}): $respBody")
                    )
                }
                val json = JSONObject(respBody)
                uploadedFileId = json.optString("id", "")
                if (uploadedFileId.isBlank()) {
                    return@withContext Result.failure(
                        IllegalStateException("Google Drive không xác nhận ID tệp sao lưu.")
                    )
                }
                uploadedName = json.optString("name", fileName)
                uploadedCreatedIso = json.optString("createdTime", "")
                uploadedSize = json.optLong("size", backupJson.toByteArray().size.toLong())
            }

            // Bước xác thực bắt buộc (Section 9.2): Kiểm tra file thực sự tồn tại trên Google Drive
            val verifyReq = Request.Builder()
                .url("https://www.googleapis.com/drive/v3/files/$uploadedFileId?fields=id,name,createdTime,size,trashed")
                .addHeader("Authorization", "Bearer $accessToken")
                .get()
                .build()

            httpClient.newCall(verifyReq).execute().use { verifyResp ->
                val verifyBody = verifyResp.body?.string().orEmpty()
                if (!verifyResp.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException("Không thể xác minh tệp sao lưu trên Google Drive sau khi tải lên (HTTP ${verifyResp.code}).")
                    )
                }
                val vJson = JSONObject(verifyBody)
                val isTrashed = vJson.optBoolean("trashed", false)
                val verifiedId = vJson.optString("id", "")
                if (verifiedId.isBlank() || isTrashed) {
                    return@withContext Result.failure(
                        IllegalStateException("Tệp sao lưu chưa tồn tại hợp lệ trên Google Drive.")
                    )
                }
                val finalSize = vJson.optLong("size", uploadedSize)
                val finalCreated = vJson.optString("createdTime", uploadedCreatedIso)
                Result.success(
                    DriveBackupFileItem(
                        id = verifiedId,
                        name = vJson.optString("name", uploadedName),
                        createdTimeDisplay = formatDriveIsoTimestamp(finalCreated),
                        sizeBytes = finalSize
                    )
                )
            }
        } catch (e: java.io.IOException) {
            Result.failure(
                IllegalStateException("Mất kết nối mạng khi tải bản sao lưu lên Google Drive. Vui lòng kiểm tra kết nối và thử lại.")
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Lists all backup files created by the app on Google Drive, newest first.
     */
    suspend fun listBackupsFromDrive(
        accessToken: String
    ): Result<List<DriveBackupFileItem>> = withContext(Dispatchers.IO) {
        try {
            val query = "mimeType='application/json' and trashed=false and (name contains '89FitnessYoga_Backup_' or name contains 'GymYogaManager_Backup_')"
            val encodedQuery = java.net.URLEncoder.encode(query, "UTF-8")
            val url = "https://www.googleapis.com/drive/v3/files?q=$encodedQuery&spaces=drive&orderBy=createdTime%20desc&pageSize=30&fields=files(id,name,createdTime,size)"

            val req = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $accessToken")
                .get()
                .build()

            httpClient.newCall(req).execute().use { resp ->
                val respBody = resp.body?.string().orEmpty()
                if (resp.code == 401 || resp.code == 403) {
                    return@withContext Result.failure(
                        IllegalStateException("Phiên làm việc Google Drive đã hết hạn (HTTP ${resp.code}). Vui lòng kết nối lại tài khoản Google.")
                    )
                }
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException("Không thể lấy danh sách sao lưu từ Google Drive (HTTP ${resp.code}).")
                    )
                }
                val filesArr = JSONObject(respBody).optJSONArray("files") ?: JSONArray()
                val items = mutableListOf<DriveBackupFileItem>()
                for (i in 0 until filesArr.length()) {
                    val o = filesArr.getJSONObject(i)
                    items.add(
                        DriveBackupFileItem(
                            id = o.getString("id"),
                            name = o.getString("name"),
                            createdTimeDisplay = formatDriveIsoTimestamp(o.optString("createdTime", "")),
                            sizeBytes = o.optLong("size", 0L)
                        )
                    )
                }
                Result.success(items)
            }
        } catch (e: java.io.IOException) {
            Result.failure(
                IllegalStateException("Không có kết nối mạng để tải danh sách sao lưu từ Google Drive.")
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Downloads the raw JSON content of a selected backup file from Google Drive.
     */
    suspend fun downloadBackupFromDrive(
        accessToken: String,
        fileId: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("https://www.googleapis.com/drive/v3/files/$fileId?alt=media")
                .addHeader("Authorization", "Bearer $accessToken")
                .get()
                .build()

            httpClient.newCall(req).execute().use { resp ->
                val bodyStr = resp.body?.string().orEmpty()
                if (resp.code == 401 || resp.code == 403) {
                    return@withContext Result.failure(
                        IllegalStateException("Phiên làm việc Google Drive đã hết hạn (HTTP ${resp.code}). Vui lòng kết nối lại.")
                    )
                }
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException("Tải tệp sao lưu thất bại (HTTP ${resp.code}).")
                    )
                }
                if (bodyStr.isBlank()) {
                    return@withContext Result.failure(
                        IllegalStateException("Nội dung tệp sao lưu trên Google Drive bị trống.")
                    )
                }
                Result.success(bodyStr)
            }
        } catch (e: java.io.IOException) {
            Result.failure(
                IllegalStateException("Mất kết nối mạng khi tải bản sao lưu từ Google Drive.")
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Saves an automatic local safety backup before overwriting current database during restore.
     */
    suspend fun saveLocalSafetySnapshot(context: Context, currentBackupJson: String): File? = withContext(Dispatchers.IO) {
        try {
            val dir = File(context.filesDir, "reports")
            if (!dir.exists()) dir.mkdirs()
            val ts = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
            val file = File(dir, "SafetyBackup_BeforeRestore_$ts.json")
            file.writeText(currentBackupJson, Charsets.UTF_8)
            file
        } catch (_: Exception) {
            null
        }
    }

    private fun formatDriveIsoTimestamp(iso: String): String {
        if (iso.isBlank()) return "Không rõ thời gian"
        return try {
            val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            val parsed = parser.parse(iso)
            if (parsed != null) {
                SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(parsed)
            } else iso
        } catch (_: Exception) {
            iso.replace("T", " ").removeSuffix("Z")
        }
    }

    fun buildOAuthDiagnosticMessage(
        context: Context,
        statusCode: Int,
        rawMessage: String?
    ): String {
        val sha1 = getAppSigningSha1(context)
        return buildString {
            append("Không thể hoàn tất xác thực Google OAuth (Mã lỗi: $statusCode).\n")
            append("Nguyên nhân & cách khắc phục để mọi tài khoản Google đều đăng nhập được:\n")
            append("1. Trên Google Cloud Console > Credentials, cần có OAuth 2.0 Client ID (Android) khớp với:\n")
            append("   • Package Name: ${context.packageName}\n")
            append("   • SHA-1 của APK hiện tại: $sha1\n")
            append("2. Trên Google Cloud Console > OAuth consent screen:\n")
            append("   • Chuyển trạng thái Publishing status sang 'In production' (Đã xuất bản) để mọi tài khoản Gmail đều đăng nhập được (không bị giới hạn Test Users).\n")
            append("   • Bật Google Drive API và cấp quyền scope: $DRIVE_FILE_SCOPE")
            if (!rawMessage.isNullOrBlank()) {
                append("\nChi tiết kỹ thuật: $rawMessage")
            }
        }
    }
}
