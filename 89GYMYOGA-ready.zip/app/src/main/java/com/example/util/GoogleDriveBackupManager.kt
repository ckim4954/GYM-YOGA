package com.example.util

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

data class DriveAccountProfile(
    val email: String,
    val displayName: String,
    val accessToken: String
)

typealias GoogleAccountProfile = DriveAccountProfile

data class DriveBackupFileItem(
    val id: String,
    val name: String,
    val createdTimeDisplay: String,
    val sizeBytes: Long
)

data class DriveAuthOutcome(
    val profile: DriveAccountProfile? = null,
    val pendingIntent: PendingIntent? = null
)

object GoogleDriveBackupManager {

    const val DRIVE_FILE_SCOPE = "https://www.googleapis.com/auth/drive.file"
    private const val EMAIL_SCOPE = "email"
    private const val PROFILE_SCOPE = "profile"
    const val BACKUP_FOLDER_NAME = "89_Fitness_Yoga_Backups"

    private val httpClient = OkHttpClient()

    fun isNetworkAvailable(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /**
     * Requests Google OAuth2 authorization for drive.file + email + profile using
     * Google Identity Services AuthorizationClient.
     */
    suspend fun authorize(context: Context): Result<DriveAuthOutcome> {
        if (!isNetworkAvailable(context)) {
            return Result.failure(IllegalStateException("Không có kết nối mạng. Vui lòng kiểm tra Wi-Fi/4G và thử lại."))
        }
        return try {
            val request = AuthorizationRequest.builder()
                .setRequestedScopes(
                    listOf(
                        Scope(DRIVE_FILE_SCOPE),
                        Scope(EMAIL_SCOPE),
                        Scope(PROFILE_SCOPE)
                    )
                )
                .build()

            val authClient = Identity.getAuthorizationClient(context)
            val result: AuthorizationResult = suspendCancellableCoroutine { cont ->
                authClient.authorize(request)
                    .addOnSuccessListener { res ->
                        if (cont.isActive) cont.resume(res)
                    }
                    .addOnFailureListener { err ->
                        if (cont.isActive) cont.resumeWithException(err)
                    }
            }

            if (result.hasResolution()) {
                val pendingIntent = result.pendingIntent
                if (pendingIntent != null) {
                    return Result.success(DriveAuthOutcome(pendingIntent = pendingIntent))
                }
            }

            val token = result.accessToken
            if (token.isNullOrBlank()) {
                return Result.failure(IllegalStateException("Không nhận được Access Token từ Google. Vui lòng thử đăng nhập lại."))
            }

            val profile = fetchUserInfo(token)
            Result.success(DriveAuthOutcome(profile = profile))
        } catch (e: ApiException) {
            Result.failure(
                IllegalStateException(buildOAuthDiagnosticMessage(context, e.statusCode, e.message))
            )
        } catch (e: Exception) {
            Result.failure(
                IllegalStateException("Không thể kết nối Google OAuth: ${e.localizedMessage ?: e.javaClass.simpleName}")
            )
        }
    }

    /**
     * Completes authorization after the user finishes the Google consent screen resolution.
     */
    suspend fun handleAuthorizationIntentResult(
        context: Context,
        data: Intent?
    ): Result<DriveAccountProfile> {
        if (data == null) {
            return Result.failure(IllegalStateException("Đã hủy đăng nhập Google."))
        }
        return try {
            val authClient = Identity.getAuthorizationClient(context)
            val result = authClient.getAuthorizationResultFromIntent(data)
            val token = result.accessToken
            if (token.isNullOrBlank()) {
                return Result.failure(IllegalStateException("Google chưa cấp quyền truy cập Google Drive."))
            }
            val profile = fetchUserInfo(token)
            Result.success(profile)
        } catch (e: ApiException) {
            Result.failure(
                IllegalStateException(buildOAuthDiagnosticMessage(context, e.statusCode, e.message))
            )
        } catch (e: Exception) {
            Result.failure(
                IllegalStateException("Lỗi xử lý kết quả đăng nhập Google: ${e.localizedMessage ?: e.message}")
            )
        }
    }

    /**
     * Revokes the OAuth2 access token and signs out of Google Identity Services.
     */
    suspend fun revokeAccess(context: Context, accessToken: String) = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("https://oauth2.googleapis.com/revoke?token=$accessToken")
                .post("".toRequestBody("application/x-www-form-urlencoded".toMediaType()))
                .build()
            httpClient.newCall(req).execute().close()
        } catch (_: Exception) {
        }
        try {
            Identity.getSignInClient(context).signOut()
        } catch (_: Exception) {
        }
    }

    private suspend fun fetchUserInfo(accessToken: String): DriveAccountProfile = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("https://www.googleapis.com/oauth2/v3/userinfo")
                .addHeader("Authorization", "Bearer $accessToken")
                .get()
                .build()
            httpClient.newCall(req).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyStr = response.body?.string().orEmpty()
                    val json = JSONObject(bodyStr)
                    val email = json.optString("email", "Đã kết nối tài khoản Google")
                    val name = json.optString("name", email)
                    return@withContext DriveAccountProfile(
                        email = email,
                        displayName = name,
                        accessToken = accessToken
                    )
                }
            }
        } catch (_: Exception) {
        }
        DriveAccountProfile(
            email = "Tài khoản Google đã cấp quyền Drive",
            displayName = "Quản lý 89 Fitness & Yoga",
            accessToken = accessToken
        )
    }

    /**
     * Finds or creates the dedicated "89_Fitness_Yoga_Backups" folder on Google Drive.
     */
    private suspend fun getOrCreateBackupFolderId(accessToken: String): String = withContext(Dispatchers.IO) {
        val query = "mimeType='application/vnd.google-apps.folder' and name='$BACKUP_FOLDER_NAME' and trashed=false"
        val encodedQuery = java.net.URLEncoder.encode(query, "UTF-8")
        val searchUrl = "https://www.googleapis.com/drive/v3/files?q=$encodedQuery&spaces=drive&fields=files(id,name)"

        val searchReq = Request.Builder()
            .url(searchUrl)
            .addHeader("Authorization", "Bearer $accessToken")
            .get()
            .build()

        httpClient.newCall(searchReq).execute().use { resp ->
            val respBody = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                throw IllegalStateException("Google Drive từ chối truy vấn thư mục (HTTP ${resp.code}): $respBody")
            }
            val files = JSONObject(respBody).optJSONArray("files") ?: JSONArray()
            if (files.length() > 0) {
                return@withContext files.getJSONObject(0).getString("id")
            }
        }

        // Create folder if not found
        val metaJson = JSONObject().apply {
            put("name", BACKUP_FOLDER_NAME)
            put("mimeType", "application/vnd.google-apps.folder")
        }
        val createReq = Request.Builder()
            .url("https://www.googleapis.com/drive/v3/files?fields=id")
            .addHeader("Authorization", "Bearer $accessToken")
            .post(metaJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        httpClient.newCall(createReq).execute().use { resp ->
            val respBody = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                throw IllegalStateException("Không thể tạo thư mục sao lưu trên Google Drive (HTTP ${resp.code}): $respBody")
            }
            return@withContext JSONObject(respBody).getString("id")
        }
    }

    /**
     * Uploads a validated JSON backup to Google Drive inside 89_Fitness_Yoga_Backups.
     * Only returns success when Google Drive confirms upload completion with file ID.
     */
    suspend fun uploadBackupToDrive(
        accessToken: String,
        backupJson: String
    ): Result<DriveBackupFileItem> = withContext(Dispatchers.IO) {
        try {
            val folderId = getOrCreateBackupFolderId(accessToken)
            val timestampStr = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
            val fileName = "89FitnessYoga_Backup_$timestampStr.json"

            val metadataJson = JSONObject().apply {
                put("name", fileName)
                put("mimeType", "application/json")
                put("parents", JSONArray().put(folderId))
                put("description", "Bản sao lưu dữ liệu ứng dụng 89 FITNESS & YOGA")
            }

            val multipartBody = MultipartBody.Builder()
                .setType("multipart/related".toMediaType())
                .addPart(metadataJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .addPart(backupJson.toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()

            val uploadReq = Request.Builder()
                .url("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,createdTime,size")
                .addHeader("Authorization", "Bearer $accessToken")
                .post(multipartBody)
                .build()

            httpClient.newCall(uploadReq).execute().use { resp ->
                val respBody = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException("Google Drive trả về lỗi khi tải lên (HTTP ${resp.code}): $respBody")
                    )
                }
                val json = JSONObject(respBody)
                val fileId = json.optString("id", "")
                if (fileId.isBlank()) {
                    return@withContext Result.failure(
                        IllegalStateException("Google Drive không xác nhận ID tệp sao lưu.")
                    )
                }
                val createdIso = json.optString("createdTime", "")
                val sizeBytes = json.optLong("size", backupJson.toByteArray().size.toLong())
                Result.success(
                    DriveBackupFileItem(
                        id = fileId,
                        name = json.optString("name", fileName),
                        createdTimeDisplay = formatDriveIsoTimestamp(createdIso),
                        sizeBytes = sizeBytes
                    )
                )
            }
        } catch (e: java.io.IOException) {
            Result.failure(
                IllegalStateException("Mất kết nối mạng khi tải bản sao lưu lên Google Drive. Vui lòng kiểm tra kết nối và thử lại.")
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Lists all backup files created by the app on Google Drive, newest first.
     */
    suspend fun listBackupsFromDrive(
        accessToken: String
    ): Result<List<DriveBackupFileItem>> = withContext(Dispatchers.IO) {
        try {
            val query = "mimeType='application/json' and trashed=false and (name contains '89FitnessYoga_Backup_' or name contains 'GymYogaManager_Backup_')"
            val encodedQuery = java.net.URLEncoder.encode(query, "UTF-8")
            val url = "https://www.googleapis.com/drive/v3/files?q=$encodedQuery&spaces=drive&orderBy=createdTime%20desc&pageSize=30&fields=files(id,name,createdTime,size)"

            val req = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $accessToken")
                .get()
                .build()

            httpClient.newCall(req).execute().use { resp ->
                val respBody = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException("Không thể lấy danh sách sao lưu từ Google Drive (HTTP ${resp.code}).")
                    )
                }
                val filesArr = JSONObject(respBody).optJSONArray("files") ?: JSONArray()
                val items = mutableListOf<DriveBackupFileItem>()
                for (i in 0 until filesArr.length()) {
                    val o = filesArr.getJSONObject(i)
                    items.add(
                        DriveBackupFileItem(
                            id = o.getString("id"),
                            name = o.getString("name"),
                            createdTimeDisplay = formatDriveIsoTimestamp(o.optString("createdTime", "")),
                            sizeBytes = o.optLong("size", 0L)
                        )
                    )
                }
                Result.success(items)
            }
        } catch (e: java.io.IOException) {
            Result.failure(
                IllegalStateException("Không có kết nối mạng để tải danh sách sao lưu từ Google Drive.")
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Downloads the raw JSON content of a selected backup file from Google Drive.
     */
    suspend fun downloadBackupFromDrive(
        accessToken: String,
        fileId: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("https://www.googleapis.com/drive/v3/files/$fileId?alt=media")
                .addHeader("Authorization", "Bearer $accessToken")
                .get()
                .build()

            httpClient.newCall(req).execute().use { resp ->
                val bodyStr = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException("Tải tệp sao lưu thất bại (HTTP ${resp.code}).")
                    )
                }
                if (bodyStr.isBlank()) {
                    return@withContext Result.failure(
                        IllegalStateException("Nội dung tệp sao lưu trên Google Drive bị trống.")
                    )
                }
                Result.success(bodyStr)
            }
        } catch (e: java.io.IOException) {
            Result.failure(
                IllegalStateException("Mất kết nối mạng khi tải bản sao lưu từ Google Drive.")
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Saves an automatic local safety backup before overwriting current database during restore.
     */
    suspend fun saveLocalSafetySnapshot(context: Context, currentBackupJson: String): File? = withContext(Dispatchers.IO) {
        try {
            val dir = File(context.filesDir, "reports")
            if (!dir.exists()) dir.mkdirs()
            val ts = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
            val file = File(dir, "SafetyBackup_BeforeRestore_$ts.json")
            file.writeText(currentBackupJson, Charsets.UTF_8)
            file
        } catch (_: Exception) {
            null
        }
    }

    private fun formatDriveIsoTimestamp(iso: String): String {
        if (iso.isBlank()) return "Không rõ thời gian"
        return try {
            val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            val parsed = parser.parse(iso)
            if (parsed != null) {
                SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(parsed)
            } else iso
        } catch (_: Exception) {
            iso.replace("T", " ").removeSuffix("Z")
        }
    }

    private fun buildOAuthDiagnosticMessage(
        context: Context,
        statusCode: Int,
        rawMessage: String?
    ): String {
        return buildString {
            append("Không thể hoàn tất xác thực Google OAuth (Mã lỗi: $statusCode). ")
            append("Để sử dụng Google Sign-In & Google Drive API trên thiết bị thực tế, hãy đảm bảo dự án Google Cloud đã đăng ký Android OAuth Client cho:\n")
            append("• Package Name: ${context.packageName}\n")
            append("• Scope: https://www.googleapis.com/auth/drive.file\n")
            append("• SHA-1 Fingerprint của chứng chỉ ký APK hiện tại.")
            if (!rawMessage.isNullOrBlank()) {
                append("\nChi tiết: $rawMessage")
            }
        }
    }
}
