package com.example

import com.example.domain.FinancialEngine
import com.example.ui.theme.ThemeModePreference
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleRobolectricTest {

    @Test
    fun `verify default theme mode preference is LIGHT and supports 3 options`() {
        assertEquals(ThemeModePreference.LIGHT, ThemeModePreference.fromConfigString(null))
        assertEquals(ThemeModePreference.LIGHT, ThemeModePreference.fromConfigString("LIGHT"))
        assertEquals(ThemeModePreference.DARK, ThemeModePreference.fromConfigString("DARK"))
        assertEquals(ThemeModePreference.SYSTEM, ThemeModePreference.fromConfigString("SYSTEM"))
    }

    @Test
    fun `verify all 7 golden test cases pass with 100 percent accuracy`() {
        val results = FinancialEngine.runAllGoldenTestCases()
        assertEquals(7, results.size)
        assertTrue(results.all { it.passed })
    }
}
