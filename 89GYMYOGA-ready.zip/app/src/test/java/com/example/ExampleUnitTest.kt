package com.example

import com.example.domain.DateUtils
import com.example.domain.FinancialEngine
import com.example.domain.LocalDateSpec
import com.example.domain.MemberTrackingStatus
import com.example.util.MemberReportRow
import com.example.util.PdfReportType
import com.example.util.PtReportRow
import com.example.util.ReportExporter
import com.example.util.SummaryMetricRow
import com.example.util.WalkInReportRow
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `verify all 7 mandatory Golden Test Cases pass`() {
        val results = FinancialEngine.runAllGoldenTestCases()
        assertEquals(7, results.size)
        results.forEach { result ->
            assertTrue(
                "Golden Test ${result.id} (${result.title}) failed: expected [${result.expectedDisplay}] but got [${result.actualDisplay}]",
                result.passed
            )
        }
    }

    @Test
    fun `verify renewal rules Case 1, Case 2, and Case 3`() {
        // Old contract: 15/07/2026 to last training day 14/08/2026 -> exclusive end = 15/08/2026
        val oldEndExclusive = LocalDateSpec(2026, 8, 15)

        // Case 1: Early renewal on 10/08/2026 -> new start date must be 15/08/2026
        val case1Start = FinancialEngine.calculateRenewalStartDate(
            previousEndExclusive = oldEndExclusive,
            renewalDate = LocalDateSpec(2026, 8, 10)
        )
        assertEquals(LocalDateSpec(2026, 8, 15), case1Start)

        // Case 2: Exact next-cycle renewal on 15/08/2026 -> new start date must be 15/08/2026
        val case2Start = FinancialEngine.calculateRenewalStartDate(
            previousEndExclusive = oldEndExclusive,
            renewalDate = LocalDateSpec(2026, 8, 15)
        )
        assertEquals(LocalDateSpec(2026, 8, 15), case2Start)

        // Case 3: Renew after gap on 25/08/2026 -> new start date must be 25/08/2026
        val case3Start = FinancialEngine.calculateRenewalStartDate(
            previousEndExclusive = oldEndExclusive,
            renewalDate = LocalDateSpec(2026, 8, 25)
        )
        assertEquals(LocalDateSpec(2026, 8, 25), case3Start)
    }

    @Test
    fun `verify full contract schedule sum equals contract amount`() {
        val start = LocalDateSpec(2026, 10, 6)
        val endEx = LocalDateSpec(2026, 11, 6)
        val schedule = FinancialEngine.generateFullContractSchedule(start, endEx, 250_000L)
        assertEquals(2, schedule.size)
        assertEquals(209_677L, schedule[0].allocatedAmount)
        assertEquals(40_323L, schedule[1].allocatedAmount)
        assertEquals(250_000L, schedule.sumOf { it.allocatedAmount })
    }

    @Test
    fun `verify tracking status 5 tiers`() {
        val today = LocalDateSpec(2026, 8, 10)

        // Expired yesterday (last training day 09/08 -> endExclusive 10/08)
        val (statusExpired, remExpired) = FinancialEngine.evaluateTrackingStatus(today, LocalDateSpec(2026, 8, 10))
        assertEquals(MemberTrackingStatus.EXPIRED, statusExpired)
        assertEquals(-1, remExpired)

        // Expiring today (last training day 10/08 -> endExclusive 11/08)
        val (statusToday, remToday) = FinancialEngine.evaluateTrackingStatus(today, LocalDateSpec(2026, 8, 11))
        assertEquals(MemberTrackingStatus.EXPIRING_TODAY, statusToday)
        assertEquals(0, remToday)

        // Expiring in 5 days (1..7)
        val (status7, rem7) = FinancialEngine.evaluateTrackingStatus(today, DateUtils.toExclusiveEndDate(today.plusDays(5)))
        assertEquals(MemberTrackingStatus.EXPIRING_1_TO_7, status7)
        assertEquals(5, rem7)

        // Expiring in 10 days (8..15)
        val (status15, rem15) = FinancialEngine.evaluateTrackingStatus(today, DateUtils.toExclusiveEndDate(today.plusDays(10)))
        assertEquals(MemberTrackingStatus.EXPIRING_8_TO_15, status15)
        assertEquals(10, rem15)

        // Active > 15 days (20 days)
        val (statusActive, remActive) = FinancialEngine.evaluateTrackingStatus(today, DateUtils.toExclusiveEndDate(today.plusDays(20)))
        assertEquals(MemberTrackingStatus.ACTIVE_OVER_15, statusActive)
        assertEquals(20, remActive)
    }

    @Test
    fun `verify Yoga 1 2 3 month package automatic contract end date calculation`() {
        val regDate = LocalDateSpec(2026, 11, 7)

        val endExclusive1M = regDate.plusMonths(1)
        assertEquals(LocalDateSpec(2026, 12, 7), endExclusive1M)
        assertEquals(LocalDateSpec(2026, 12, 6), DateUtils.toDisplayedLastTrainingDate(endExclusive1M))

        val endExclusive2M = regDate.plusMonths(2)
        assertEquals(LocalDateSpec(2027, 1, 7), endExclusive2M)
        assertEquals(LocalDateSpec(2027, 1, 6), DateUtils.toDisplayedLastTrainingDate(endExclusive2M))

        val endExclusive3M = regDate.plusMonths(3)
        assertEquals(LocalDateSpec(2027, 2, 7), endExclusive3M)
        assertEquals(LocalDateSpec(2027, 2, 6), DateUtils.toDisplayedLastTrainingDate(endExclusive3M))
    }

    @Test
    fun `verify 8 independent reports structure, department isolation, terminology, and reconciliation`() {
        // 1. Verify 8 independent report types (5 GYM + 3 YOGA)
        assertEquals(8, PdfReportType.entries.size)
        assertEquals(5, PdfReportType.gymReports.size)
        assertEquals(3, PdfReportType.yogaReports.size)
        PdfReportType.gymReports.forEach { assertEquals("GYM", it.boMon) }
        PdfReportType.yogaReports.forEach { assertEquals("YOGA", it.boMon) }

        val gymConHanRow = MemberReportRow(
            stt = 1,
            hoTen = "Nguyễn Văn An",
            boMon = "GYM",
            goiTap = "1 tháng",
            loaiBaoCaoLabel = "Còn hạn & Đăng ký mới",
            ngayDangKyDisplay = "01/11/2026",
            ngayBatDauDisplay = "01/11/2026",
            ngayHetHanDisplay = "30/11/2026",
            soTienHopDong = 250_000L,
            soNgayTrongThang = 30,
            tongSoNgayHopDong = 30,
            doanhThuPhanBo = 250_000L
        )
        val gymGiaHanRow = MemberReportRow(
            stt = 2,
            hoTen = "Trần Minh Bình",
            boMon = "GYM",
            goiTap = "3 tháng",
            loaiBaoCaoLabel = "Gia hạn",
            ngayDangKyDisplay = "01/11/2026",
            ngayBatDauDisplay = "01/11/2026",
            ngayHetHanDisplay = "31/01/2027",
            soTienHopDong = 650_000L,
            soNgayTrongThang = 30,
            tongSoNgayHopDong = 92,
            doanhThuPhanBo = 211_957L
        )
        val yogaConHanRow = MemberReportRow(
            stt = 1,
            hoTen = "Lê Thu Hà",
            boMon = "YOGA",
            goiTap = "Yoga 2 tháng",
            loaiBaoCaoLabel = "Còn hạn & Đăng ký mới",
            ngayDangKyDisplay = "07/11/2026",
            ngayBatDauDisplay = "07/11/2026",
            ngayHetHanDisplay = "06/01/2027",
            soTienHopDong = 1_000_000L,
            soNgayTrongThang = 24,
            tongSoNgayHopDong = 61,
            doanhThuPhanBo = 393_443L
        )
        val yogaGiaHanRow = MemberReportRow(
            stt = 2,
            hoTen = "Phạm Ngọc Mai",
            boMon = "YOGA",
            goiTap = "Yoga 1 tháng",
            loaiBaoCaoLabel = "Gia hạn",
            ngayDangKyDisplay = "01/11/2026",
            ngayBatDauDisplay = "01/11/2026",
            ngayHetHanDisplay = "30/11/2026",
            soTienHopDong = 500_000L,
            soNgayTrongThang = 30,
            tongSoNgayHopDong = 30,
            doanhThuPhanBo = 500_000L
        )

        val ptRow = PtReportRow(
            stt = 1,
            hoTen = "Hoàng Quốc Bảo",
            goiPt = "Gói PT 12 buổi",
            tongSoBuoi = 12,
            soBuoiDaTapTrongThang = 6,
            soBuoiConLai = 6,
            soTienHopDong = 3_600_000L,
            doanhThuTrungTam = 900_000L,
            doanhThuPt = 900_000L
        )

        val walkInRow = WalkInReportRow(
            stt = 1,
            maGiaoDich = "KL-001",
            tenLoaiVe = "1 ngày lẻ",
            soLuong = 1,
            soNgaySuDung = 1,
            ngayThuDisplay = "07/11/2026",
            thoiGianSuDungDisplay = "07/11/2026",
            soTienThanhToan = 30_000L,
            doanhThuPhanBoThang = 30_000L
        )

        // Test Report 1 (CON_HAN_GYM) with mixed input to ensure YOGA is strictly excluded
        val csv1 = ReportExporter.buildExcelCsvContent(
            reportType = PdfReportType.CON_HAN_GYM,
            month = 11,
            year = 2026,
            memberRows = listOf(gymConHanRow, yogaConHanRow)
        )
        assertTrue(csv1.contains("Bộ môn: GYM"))
        assertFalse(csv1.contains("GYM & YOGA"))
        assertTrue(csv1.contains("Nguyễn Văn An"))
        assertFalse("CON_HAN_GYM must not contain YOGA member", csv1.contains("Lê Thu Hà"))
        assertTrue(csv1.contains("Ngày bắt đầu HĐ"))
        assertTrue(csv1.contains("Ngày kết thúc HĐ"))
        assertTrue(csv1.contains("Giá trị hợp đồng (VNĐ)"))
        assertTrue(csv1.contains("Doanh thu phân bổ trong tháng (VNĐ)"))
        assertTrue(csv1.contains(ReportExporter.METHOD_MEMBER_ALLOCATION))
        assertFalse(csv1.contains("Phân bổ theo ngày tập thực tế"))

        // Test Report 2 (GIA_HAN_GYM)
        val csv2 = ReportExporter.buildExcelCsvContent(
            reportType = PdfReportType.GIA_HAN_GYM,
            month = 11,
            year = 2026,
            memberRows = listOf(gymGiaHanRow, yogaGiaHanRow)
        )
        assertTrue(csv2.contains("Bộ môn: GYM"))
        assertTrue(csv2.contains("Trần Minh Bình"))
        assertFalse("GIA_HAN_GYM must not contain YOGA member", csv2.contains("Phạm Ngọc Mai"))
        assertTrue(csv2.contains("650000,211957"))

        // Test Report 3 (PT_GYM)
        val csv3 = ReportExporter.buildExcelCsvContent(
            reportType = PdfReportType.PT,
            month = 11,
            year = 2026,
            ptRows = listOf(ptRow)
        )
        assertTrue(csv3.contains("Bộ môn: GYM"))
        assertTrue(csv3.contains("Tổng số buổi"))
        assertTrue(csv3.contains("Số buổi đã tập trong T11/2026"))
        assertTrue(csv3.contains("Số buổi còn lại"))
        assertTrue(csv3.contains("Giá trị hợp đồng PT (VNĐ)"))
        assertTrue(csv3.contains("Phần doanh thu Trung tâm (50%) (VNĐ)"))
        assertTrue(csv3.contains("Phần doanh thu Huấn luyện viên (50%) (VNĐ)"))
        assertTrue(csv3.contains(ReportExporter.METHOD_PT_ALLOCATION))
        assertTrue(csv3.contains("900000,900000"))

        // Test Report 4 (KHACH_LE_GYM)
        val csv4 = ReportExporter.buildExcelCsvContent(
            reportType = PdfReportType.KHACH_LE,
            month = 11,
            year = 2026,
            walkInRows = listOf(walkInRow)
        )
        assertTrue(csv4.contains("Bộ môn: GYM"))
        assertTrue(csv4.contains("Số ngày sử dụng"))
        assertTrue(csv4.contains("Ngày thanh toán"))
        assertTrue(csv4.contains("Thời gian sử dụng"))
        assertTrue(csv4.contains("Số tiền thực thu (VNĐ)"))
        assertTrue(csv4.contains("Doanh thu phân bổ trong tháng (VNĐ)"))
        assertTrue(csv4.contains("30000,30000"))

        // Test Report 5 (TONG_HOP_GYM)
        val gymTotalCash = 250_000L + 650_000L + 3_600_000L + 30_000L // 4,530,000
        val gymTotalAlloc = 250_000L + 211_957L + 900_000L + 30_000L // 1,391,957
        val csv5 = ReportExporter.buildExcelCsvContent(
            reportType = PdfReportType.TONG_HOP_GYM,
            month = 11,
            year = 2026,
            memberRows = listOf(gymConHanRow, gymGiaHanRow, yogaConHanRow),
            summaryCashFlowRows = listOf(
                SummaryMetricRow("Tiền hội viên GYM & PT đã thanh toán", "Tính theo ngày thanh toán thực tế trong tháng", 3, "GD", 4_500_000L),
                SummaryMetricRow("Tiền khách tập buổi lẻ & tuần lẻ (GYM)", "Tính theo ngày thanh toán thực tế trong tháng", 1, "GD", 30_000L)
            ),
            summaryAllocatedRows = listOf(
                SummaryMetricRow("1. Hội viên GYM còn hạn & đăng ký mới", ReportExporter.METHOD_MEMBER_ALLOCATION, 1, "HĐ", 250_000L),
                SummaryMetricRow("2. Hội viên GYM gia hạn", ReportExporter.METHOD_MEMBER_ALLOCATION, 1, "HĐ", 211_957L),
                SummaryMetricRow("3. Khách tập PT (Phần doanh thu Trung tâm 50%)", ReportExporter.METHOD_PT_ALLOCATION, 1, "HĐ", 900_000L),
                SummaryMetricRow("4. Khách tập buổi lẻ / ngày lẻ (GYM)", ReportExporter.METHOD_DAILY_WALK_IN, 1, "vé", 30_000L),
                SummaryMetricRow("5. Khách tập tuần lẻ (GYM)", ReportExporter.METHOD_WEEKLY_WALK_IN, 0, "vé", 0L)
            ),
            totalCashFlow = gymTotalCash,
            totalAllocated = gymTotalAlloc
        )
        assertTrue(csv5.contains("Bộ môn: GYM"))
        assertTrue(csv5.contains("A. DOANH THU THỰC THU"))
        assertTrue(csv5.contains("Tổng số tiền thực tế đã nhận trong tháng, tính theo ngày thanh toán."))
        assertTrue(csv5.contains("TỔNG TIỀN THỰC THU TRONG THÁNG"))
        assertTrue(csv5.contains("B. DOANH THU PHÂN BỔ"))
        assertTrue(csv5.contains("Giá trị dịch vụ được phân bổ vào tháng báo cáo theo thời gian hiệu lực hợp đồng hoặc dịch vụ đã sử dụng."))
        assertTrue(csv5.contains("TỔNG DOANH THU PHÂN BỔ"))
        assertTrue(csv5.contains(gymTotalCash.toString()))
        assertTrue(csv5.contains(gymTotalAlloc.toString()))
        assertFalse("TONG_HOP_GYM must not contain YOGA member", csv5.contains("Lê Thu Hà"))

        // Test Report 6 (CON_HAN_YOGA)
        val csv6 = ReportExporter.buildExcelCsvContent(
            reportType = PdfReportType.CON_HAN_YOGA,
            month = 11,
            year = 2026,
            memberRows = listOf(gymConHanRow, yogaConHanRow)
        )
        assertTrue(csv6.contains("Bộ môn: YOGA"))
        assertTrue(csv6.contains("Lê Thu Hà"))
        assertFalse("CON_HAN_YOGA must not contain GYM member", csv6.contains("Nguyễn Văn An"))
        assertTrue(csv6.contains("1000000,393443"))

        // Test Report 7 (GIA_HAN_YOGA)
        val csv7 = ReportExporter.buildExcelCsvContent(
            reportType = PdfReportType.GIA_HAN_YOGA,
            month = 11,
            year = 2026,
            memberRows = listOf(gymGiaHanRow, yogaGiaHanRow)
        )
        assertTrue(csv7.contains("Bộ môn: YOGA"))
        assertTrue(csv7.contains("Phạm Ngọc Mai"))
        assertFalse("GIA_HAN_YOGA must not contain GYM member", csv7.contains("Trần Minh Bình"))
        assertTrue(csv7.contains("500000,500000"))

        // Test Report 8 (TONG_HOP_YOGA)
        val yogaTotalCash = 1_500_000L
        val yogaTotalAlloc = 393_443L + 500_000L // 893,443
        val csv8 = ReportExporter.buildExcelCsvContent(
            reportType = PdfReportType.TONG_HOP_YOGA,
            month = 11,
            year = 2026,
            memberRows = listOf(gymConHanRow, yogaConHanRow, yogaGiaHanRow),
            summaryCashFlowRows = listOf(
                SummaryMetricRow("Tiền hội viên YOGA đã thanh toán", "Tính theo ngày thanh toán thực tế trong tháng", 2, "GD", yogaTotalCash)
            ),
            summaryAllocatedRows = listOf(
                SummaryMetricRow("1. Hội viên YOGA còn hạn & đăng ký mới", ReportExporter.METHOD_MEMBER_ALLOCATION, 1, "HĐ", 393_443L),
                SummaryMetricRow("2. Hội viên YOGA gia hạn", ReportExporter.METHOD_MEMBER_ALLOCATION, 1, "HĐ", 500_000L)
            ),
            totalCashFlow = yogaTotalCash,
            totalAllocated = yogaTotalAlloc
        )
        assertTrue(csv8.contains("Bộ môn: YOGA"))
        assertTrue(csv8.contains("A. DOANH THU THỰC THU"))
        assertTrue(csv8.contains("TỔNG TIỀN THỰC THU TRONG THÁNG"))
        assertTrue(csv8.contains("B. DOANH THU PHÂN BỔ"))
        assertTrue(csv8.contains("TỔNG DOANH THU PHÂN BỔ"))
        assertTrue(csv8.contains(yogaTotalCash.toString()))
        assertTrue(csv8.contains(yogaTotalAlloc.toString()))
        assertFalse("TONG_HOP_YOGA must not contain GYM member", csv8.contains("Nguyễn Văn An"))
    }

    @Test
    fun `verify all 8 reports handle empty data state with centered message and zero totals`() {
        PdfReportType.entries.forEach { reportType ->
            val emptyCsv = ReportExporter.buildExcelCsvContent(
                reportType = reportType,
                month = 11,
                year = 2026,
                memberRows = emptyList(),
                ptRows = emptyList(),
                walkInRows = emptyList(),
                summaryCashFlowRows = emptyList(),
                summaryAllocatedRows = emptyList(),
                totalCashFlow = 0L,
                totalAllocated = 0L
            )
            assertTrue(
                "Report ${reportType.code} must display '${ReportExporter.EMPTY_REPORT_MESSAGE}' when empty",
                emptyCsv.contains(ReportExporter.EMPTY_REPORT_MESSAGE)
            )
            assertTrue(
                "Report ${reportType.code} must still include a total row with 0 when empty",
                emptyCsv.contains("TỔNG") && emptyCsv.contains(",0")
            )
        }
    }
}
