package com.example

import com.example.data.local.BoMon
import com.example.data.local.DoiTuong
import com.example.data.local.LoaiBaoCao
import com.example.data.local.LoaiHopDong
import com.example.data.local.LoaiVeKhachLe
import com.example.data.local.MemberContractEntity
import com.example.data.local.MemberEntity
import com.example.data.local.TrangThaiThanhToan
import com.example.domain.DateUtils
import com.example.domain.FinancialEngine
import com.example.domain.LocalDateSpec
import com.example.domain.MemberTrackingStatus
import com.example.ui.components.findMembersBySttForJump
import com.example.ui.components.paginateItems
import com.example.ui.screens.SettingsCategory
import com.example.ui.screens.calculateWalkInStepperSpec
import com.example.ui.screens.filterActionableTrackingMembers
import com.example.ui.screens.searchSettingsEntries
import com.example.ui.viewmodel.MemberWithContractsUi
import com.example.util.MemberReportRow
import com.example.util.PdfReportType
import com.example.util.PtReportRow
import com.example.util.ReportExporter
import com.example.util.SummaryMetricRow
import com.example.util.WalkInReportRow
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `verify all 7 mandatory Golden Test Cases pass`() {
        val results = FinancialEngine.runAllGoldenTestCases()
        assertEquals(7, results.size)
        results.forEach { result ->
            assertTrue(
                "Golden Test ${result.id} (${result.title}) failed: expected [${result.expectedDisplay}] but got [${result.actualDisplay}]",
                result.passed
            )
        }
    }

    @Test
    fun `verify renewal rules Case 1, Case 2, and Case 3`() {
        // Old contract: 15/07/2026 to last training day 14/08/2026 -> exclusive end = 15/08/2026
        val oldEndExclusive = LocalDateSpec(2026, 8, 15)

        // Case 1: Early renewal on 10/08/2026 -> new start date must be 15/08/2026
        val case1Start = FinancialEngine.calculateRenewalStartDate(
            previousEndExclusive = oldEndExclusive,
            renewalDate = LocalDateSpec(2026, 8, 10)
        )
        assertEquals(LocalDateSpec(2026, 8, 15), case1Start)

        // Case 2: Exact next-cycle renewal on 15/08/2026 -> new start date must be 15/08/2026
        val case2Start = FinancialEngine.calculateRenewalStartDate(
            previousEndExclusive = oldEndExclusive,
            renewalDate = LocalDateSpec(2026, 8, 15)
        )
        assertEquals(LocalDateSpec(2026, 8, 15), case2Start)

        // Case 3: Renew after gap on 25/08/2026 -> new start date must be 25/08/2026
        val case3Start = FinancialEngine.calculateRenewalStartDate(
            previousEndExclusive = oldEndExclusive,
            renewalDate = LocalDateSpec(2026, 8, 25)
        )
        assertEquals(LocalDateSpec(2026, 8, 25), case3Start)
    }

    @Test
    fun `verify full contract schedule sum equals contract amount`() {
        val start = LocalDateSpec(2026, 10, 6)
        val endEx = LocalDateSpec(2026, 11, 6)
        val schedule = FinancialEngine.generateFullContractSchedule(start, endEx, 250_000L)
        assertEquals(2, schedule.size)
        assertEquals(209_677L, schedule[0].allocatedAmount)
        assertEquals(40_323L, schedule[1].allocatedAmount)
        assertEquals(250_000L, schedule.sumOf { it.allocatedAmount })
    }

    @Test
    fun `verify tracking status 5 tiers`() {
        val today = LocalDateSpec(2026, 8, 10)

        // Expired yesterday (last training day 09/08 -> endExclusive 10/08)
        val (statusExpired, remExpired) = FinancialEngine.evaluateTrackingStatus(today, LocalDateSpec(2026, 8, 10))
        assertEquals(MemberTrackingStatus.EXPIRED, statusExpired)
        assertEquals(-1, remExpired)

        // Expiring today (last training day 10/08 -> endExclusive 11/08)
        val (statusToday, remToday) = FinancialEngine.evaluateTrackingStatus(today, LocalDateSpec(2026, 8, 11))
        assertEquals(MemberTrackingStatus.EXPIRING_TODAY, statusToday)
        assertEquals(0, remToday)

        // Expiring in 5 days (1..7)
        val (status7, rem7) = FinancialEngine.evaluateTrackingStatus(today, DateUtils.toExclusiveEndDate(today.plusDays(5)))
        assertEquals(MemberTrackingStatus.EXPIRING_1_TO_7, status7)
        assertEquals(5, rem7)

        // Expiring in 10 days (8..15)
        val (status15, rem15) = FinancialEngine.evaluateTrackingStatus(today, DateUtils.toExclusiveEndDate(today.plusDays(10)))
        assertEquals(MemberTrackingStatus.EXPIRING_8_TO_15, status15)
        assertEquals(10, rem15)

        // Active > 15 days (20 days)
        val (statusActive, remActive) = FinancialEngine.evaluateTrackingStatus(today, DateUtils.toExclusiveEndDate(today.plusDays(20)))
        assertEquals(MemberTrackingStatus.ACTIVE_OVER_15, statusActive)
        assertEquals(20, remActive)
    }

    @Test
    fun `verify Yoga 1 2 3 month package automatic contract end date calculation`() {
        val regDate = LocalDateSpec(2026, 11, 7)

        val endExclusive1M = regDate.plusMonths(1)
        assertEquals(LocalDateSpec(2026, 12, 7), endExclusive1M)
        assertEquals(LocalDateSpec(2026, 12, 6), DateUtils.toDisplayedLastTrainingDate(endExclusive1M))

        val endExclusive2M = regDate.plusMonths(2)
        assertEquals(LocalDateSpec(2027, 1, 7), endExclusive2M)
        assertEquals(LocalDateSpec(2027, 1, 6), DateUtils.toDisplayedLastTrainingDate(endExclusive2M))

        val endExclusive3M = regDate.plusMonths(3)
        assertEquals(LocalDateSpec(2027, 2, 7), endExclusive3M)
        assertEquals(LocalDateSpec(2027, 2, 6), DateUtils.toDisplayedLastTrainingDate(endExclusive3M))
    }

    @Test
    fun `verify 8 independent reports structure, department isolation, terminology, and reconciliation`() {
        // 1. Verify 8 independent report types (5 GYM + 3 YOGA)
        assertEquals(8, PdfReportType.entries.size)
        assertEquals(5, PdfReportType.gymReports.size)
        assertEquals(3, PdfReportType.yogaReports.size)
        PdfReportType.gymReports.forEach { assertEquals("GYM", it.boMon) }
        PdfReportType.yogaReports.forEach { assertEquals("YOGA", it.boMon) }

        val gymConHanRow = MemberReportRow(
            stt = 1,
            hoTen = "Nguyễn Văn An",
            boMon = "GYM",
            goiTap = "1 tháng",
            loaiBaoCaoLabel = "Còn hạn & Đăng ký mới",
            ngayDangKyDisplay = "01/11/2026",
            ngayBatDauDisplay = "01/11/2026",
            ngayHetHanDisplay = "30/11/2026",
            soTienHopDong = 250_000L,
            soNgayTrongThang = 30,
            tongSoNgayHopDong = 30,
            doanhThuPhanBo = 250_000L
        )
        val gymGiaHanRow = MemberReportRow(
            stt = 2,
            hoTen = "Trần Minh Bình",
            boMon = "GYM",
            goiTap = "3 tháng",
            loaiBaoCaoLabel = "Gia hạn",
            ngayDangKyDisplay = "01/11/2026",
            ngayBatDauDisplay = "01/11/2026",
            ngayHetHanDisplay = "31/01/2027",
            soTienHopDong = 650_000L,
            soNgayTrongThang = 30,
            tongSoNgayHopDong = 92,
            doanhThuPhanBo = 211_957L
        )
        val yogaConHanRow = MemberReportRow(
            stt = 1,
            hoTen = "Lê Thu Hà",
            boMon = "YOGA",
            goiTap = "Yoga 2 tháng",
            loaiBaoCaoLabel = "Còn hạn & Đăng ký mới",
            ngayDangKyDisplay = "07/11/2026",
            ngayBatDauDisplay = "07/11/2026",
            ngayHetHanDisplay = "06/01/2027",
            soTienHopDong = 1_000_000L,
            soNgayTrongThang = 24,
            tongSoNgayHopDong = 61,
            doanhThuPhanBo = 393_443L
        )
        val yogaGiaHanRow = MemberReportRow(
            stt = 2,
            hoTen = "Phạm Ngọc Mai",
            boMon = "YOGA",
            goiTap = "Yoga 1 tháng",
            loaiBaoCaoLabel = "Gia hạn",
            ngayDangKyDisplay = "01/11/2026",
            ngayBatDauDisplay = "01/11/2026",
            ngayHetHanDisplay = "30/11/2026",
            soTienHopDong = 500_000L,
            soNgayTrongThang = 30,
            tongSoNgayHopDong = 30,
            doanhThuPhanBo = 500_000L
        )

        val ptRow = PtReportRow(
            stt = 1,
            hoTen = "Hoàng Quốc Bảo",
            goiPt = "Gói PT 12 buổi",
            tongSoBuoi = 12,
            soBuoiDaTapTrongThang = 6,
            soBuoiConLai = 6,
            soTienHopDong = 3_600_000L,
            doanhThuTrungTam = 900_000L,
            doanhThuPt = 900_000L
        )

        val walkInRow = WalkInReportRow(
            stt = 1,
            maGiaoDich = "KL-001",
            tenLoaiVe = "1 ngày lẻ",
            soLuong = 1,
            soNgaySuDung = 1,
            ngayThuDisplay = "07/11/2026",
            thoiGianSuDungDisplay = "07/11/2026",
            soTienThanhToan = 30_000L,
            doanhThuPhanBoThang = 30_000L
        )

        // Test Report 1 (CON_HAN_GYM) with mixed input to ensure YOGA is strictly excluded
        val csv1 = ReportExporter.buildExcelCsvContent(
            reportType = PdfReportType.CON_HAN_GYM,
            month = 11,
            year = 2026,
            memberRows = listOf(gymConHanRow, yogaConHanRow)
        )
        assertTrue(csv1.contains("Bộ môn: GYM"))
        assertFalse(csv1.contains("GYM & YOGA"))
        assertTrue(csv1.contains("Nguyễn Văn An"))
        assertFalse("CON_HAN_GYM must not contain YOGA member", csv1.contains("Lê Thu Hà"))
        assertTrue(csv1.contains("Ngày bắt đầu HĐ"))
        assertTrue(csv1.contains("Ngày kết thúc HĐ"))
        assertTrue(csv1.contains("Giá trị hợp đồng (VNĐ)"))
        assertTrue(csv1.contains("Doanh thu phân bổ trong tháng (VNĐ)"))
        assertTrue(csv1.contains(ReportExporter.METHOD_MEMBER_ALLOCATION))
        assertFalse(csv1.contains("Phân bổ theo ngày tập thực tế"))

        // Test Report 2 (GIA_HAN_GYM)
        val csv2 = ReportExporter.buildExcelCsvContent(
            reportType = PdfReportType.GIA_HAN_GYM,
            month = 11,
            year = 2026,
            memberRows = listOf(gymGiaHanRow, yogaGiaHanRow)
        )
        assertTrue(csv2.contains("Bộ môn: GYM"))
        assertTrue(csv2.contains("Trần Minh Bình"))
        assertFalse("GIA_HAN_GYM must not contain YOGA member", csv2.contains("Phạm Ngọc Mai"))
        assertTrue(csv2.contains("650000,211957"))

        // Test Report 3 (PT_GYM)
        val csv3 = ReportExporter.buildExcelCsvContent(
            reportType = PdfReportType.PT,
            month = 11,
            year = 2026,
            ptRows = listOf(ptRow)
        )
        assertTrue(csv3.contains("Bộ môn: GYM"))
        assertTrue(csv3.contains("Tổng số buổi"))
        assertTrue(csv3.contains("Số buổi đã tập trong T11/2026"))
        assertTrue(csv3.contains("Số buổi còn lại"))
        assertTrue(csv3.contains("Giá trị hợp đồng PT (VNĐ)"))
        assertTrue(csv3.contains("Phần doanh thu Trung tâm (50%) (VNĐ)"))
        assertTrue(csv3.contains("Phần doanh thu Huấn luyện viên (50%) (VNĐ)"))
        assertTrue(csv3.contains(ReportExporter.METHOD_PT_ALLOCATION))
        assertTrue(csv3.contains("900000,900000"))

        // Test Report 4 (KHACH_LE_GYM)
        val csv4 = ReportExporter.buildExcelCsvContent(
            reportType = PdfReportType.KHACH_LE,
            month = 11,
            year = 2026,
            walkInRows = listOf(walkInRow)
        )
        assertTrue(csv4.contains("Bộ môn: GYM"))
        assertTrue(csv4.contains("Số ngày sử dụng"))
        assertTrue(csv4.contains("Ngày thanh toán"))
        assertTrue(csv4.contains("Thời gian sử dụng"))
        assertTrue(csv4.contains("Số tiền thực thu (VNĐ)"))
        assertTrue(csv4.contains("Doanh thu phân bổ trong tháng (VNĐ)"))
        assertTrue(csv4.contains("30000,30000"))

        // Test Report 5 (TONG_HOP_GYM)
        val gymTotalCash = 250_000L + 650_000L + 3_600_000L + 30_000L // 4,530,000
        val gymTotalAlloc = 250_000L + 211_957L + 900_000L + 30_000L // 1,391,957
        val csv5 = ReportExporter.buildExcelCsvContent(
            reportType = PdfReportType.TONG_HOP_GYM,
            month = 11,
            year = 2026,
            memberRows = listOf(gymConHanRow, gymGiaHanRow, yogaConHanRow),
            summaryCashFlowRows = listOf(
                SummaryMetricRow("Tiền hội viên GYM & PT đã thanh toán", "Tính theo ngày thanh toán thực tế trong tháng", 3, "GD", 4_500_000L),
                SummaryMetricRow("Tiền khách tập buổi lẻ & tuần lẻ (GYM)", "Tính theo ngày thanh toán thực tế trong tháng", 1, "GD", 30_000L)
            ),
            summaryAllocatedRows = listOf(
                SummaryMetricRow("1. Hội viên GYM còn hạn & đăng ký mới", ReportExporter.METHOD_MEMBER_ALLOCATION, 1, "HĐ", 250_000L),
                SummaryMetricRow("2. Hội viên GYM gia hạn", ReportExporter.METHOD_MEMBER_ALLOCATION, 1, "HĐ", 211_957L),
                SummaryMetricRow("3. Khách tập PT (Phần doanh thu Trung tâm 50%)", ReportExporter.METHOD_PT_ALLOCATION, 1, "HĐ", 900_000L),
                SummaryMetricRow("4. Khách tập buổi lẻ / ngày lẻ (GYM)", ReportExporter.METHOD_DAILY_WALK_IN, 1, "vé", 30_000L),
                SummaryMetricRow("5. Khách tập tuần lẻ (GYM)", ReportExporter.METHOD_WEEKLY_WALK_IN, 0, "vé", 0L)
            ),
            totalCashFlow = gymTotalCash,
            totalAllocated = gymTotalAlloc
        )
        assertTrue(csv5.contains("Bộ môn: GYM"))
        assertTrue(csv5.contains("A. DOANH THU THỰC THU"))
        assertTrue(csv5.contains("Tổng số tiền thực tế đã nhận trong tháng, tính theo ngày thanh toán."))
        assertTrue(csv5.contains("TỔNG TIỀN THỰC THU TRONG THÁNG"))
        assertTrue(csv5.contains("B. DOANH THU PHÂN BỔ"))
        assertTrue(csv5.contains("Giá trị dịch vụ được phân bổ vào tháng báo cáo theo thời gian hiệu lực hợp đồng hoặc dịch vụ đã sử dụng."))
        assertTrue(csv5.contains("TỔNG DOANH THU PHÂN BỔ"))
        assertTrue(csv5.contains(gymTotalCash.toString()))
        assertTrue(csv5.contains(gymTotalAlloc.toString()))
        assertFalse("TONG_HOP_GYM must not contain YOGA member", csv5.contains("Lê Thu Hà"))

        // Test Report 6 (CON_HAN_YOGA)
        val csv6 = ReportExporter.buildExcelCsvContent(
            reportType = PdfReportType.CON_HAN_YOGA,
            month = 11,
            year = 2026,
            memberRows = listOf(gymConHanRow, yogaConHanRow)
        )
        assertTrue(csv6.contains("Bộ môn: YOGA"))
        assertTrue(csv6.contains("Lê Thu Hà"))
        assertFalse("CON_HAN_YOGA must not contain GYM member", csv6.contains("Nguyễn Văn An"))
        assertTrue(csv6.contains("1000000,393443"))

        // Test Report 7 (GIA_HAN_YOGA)
        val csv7 = ReportExporter.buildExcelCsvContent(
            reportType = PdfReportType.GIA_HAN_YOGA,
            month = 11,
            year = 2026,
            memberRows = listOf(gymGiaHanRow, yogaGiaHanRow)
        )
        assertTrue(csv7.contains("Bộ môn: YOGA"))
        assertTrue(csv7.contains("Phạm Ngọc Mai"))
        assertFalse("GIA_HAN_YOGA must not contain GYM member", csv7.contains("Trần Minh Bình"))
        assertTrue(csv7.contains("500000,500000"))

        // Test Report 8 (TONG_HOP_YOGA)
        val yogaTotalCash = 1_500_000L
        val yogaTotalAlloc = 393_443L + 500_000L // 893,443
        val csv8 = ReportExporter.buildExcelCsvContent(
            reportType = PdfReportType.TONG_HOP_YOGA,
            month = 11,
            year = 2026,
            memberRows = listOf(gymConHanRow, yogaConHanRow, yogaGiaHanRow),
            summaryCashFlowRows = listOf(
                SummaryMetricRow("Tiền hội viên YOGA đã thanh toán", "Tính theo ngày thanh toán thực tế trong tháng", 2, "GD", yogaTotalCash)
            ),
            summaryAllocatedRows = listOf(
                SummaryMetricRow("1. Hội viên YOGA còn hạn & đăng ký mới", ReportExporter.METHOD_MEMBER_ALLOCATION, 1, "HĐ", 393_443L),
                SummaryMetricRow("2. Hội viên YOGA gia hạn", ReportExporter.METHOD_MEMBER_ALLOCATION, 1, "HĐ", 500_000L)
            ),
            totalCashFlow = yogaTotalCash,
            totalAllocated = yogaTotalAlloc
        )
        assertTrue(csv8.contains("Bộ môn: YOGA"))
        assertTrue(csv8.contains("A. DOANH THU THỰC THU"))
        assertTrue(csv8.contains("TỔNG TIỀN THỰC THU TRONG THÁNG"))
        assertTrue(csv8.contains("B. DOANH THU PHÂN BỔ"))
        assertTrue(csv8.contains("TỔNG DOANH THU PHÂN BỔ"))
        assertTrue(csv8.contains(yogaTotalCash.toString()))
        assertTrue(csv8.contains(yogaTotalAlloc.toString()))
        assertFalse("TONG_HOP_YOGA must not contain GYM member", csv8.contains("Nguyễn Văn An"))
    }

    @Test
    fun `verify all 8 reports handle empty data state with centered message and zero totals`() {
        PdfReportType.entries.forEach { reportType ->
            val emptyCsv = ReportExporter.buildExcelCsvContent(
                reportType = reportType,
                month = 11,
                year = 2026,
                memberRows = emptyList(),
                ptRows = emptyList(),
                walkInRows = emptyList(),
                summaryCashFlowRows = emptyList(),
                summaryAllocatedRows = emptyList(),
                totalCashFlow = 0L,
                totalAllocated = 0L
            )
            assertTrue(
                "Report ${reportType.code} must display '${ReportExporter.EMPTY_REPORT_MESSAGE}' when empty",
                emptyCsv.contains(ReportExporter.EMPTY_REPORT_MESSAGE)
            )
            assertTrue(
                "Report ${reportType.code} must still include a total row with 0 when empty",
                emptyCsv.contains("TỔNG") && emptyCsv.contains(",0")
            )
        }
    }

    @Test
    fun `verify pagination 25 50 100 and Jump to STT with non-contiguous and duplicate STTs`() {
        val sampleMembers = (1..120).map { i ->
            val stt = when (i) {
                5 -> 999 // duplicate STT #999
                65 -> 999 // second member with duplicate STT #999 on page 2 (when pageSize = 50)
                else -> i * 2 // non-contiguous STTs
            }
            createDummyMemberWithTracking(id = "M-$i", stt = stt, hoTen = "Hội viên số $i", remainingDays = 10)
        }

        // Default 50 per page -> 3 pages (1..50, 51..100, 101..120)
        val page1 = paginateItems(sampleMembers, pageSize = 50, requestedPage = 1)
        assertEquals(3, page1.totalPages)
        assertEquals(50, page1.pageItems.size)
        assertEquals(1, page1.startIndexOneBased)
        assertEquals(50, page1.endIndexOneBased)

        val page3 = paginateItems(sampleMembers, pageSize = 50, requestedPage = 3)
        assertEquals(20, page3.pageItems.size)
        assertEquals(101, page3.startIndexOneBased)
        assertEquals(120, page3.endIndexOneBased)

        // 25 per page -> 5 pages
        val slice25 = paginateItems(sampleMembers, pageSize = 25, requestedPage = 2)
        assertEquals(5, slice25.totalPages)
        assertEquals(26, slice25.startIndexOneBased)
        assertEquals(50, slice25.endIndexOneBased)

        // 100 per page -> 2 pages
        val slice100 = paginateItems(sampleMembers, pageSize = 100, requestedPage = 2)
        assertEquals(2, slice100.totalPages)
        assertEquals(20, slice100.pageItems.size)

        // Jump to duplicate STT 999 with pageSize = 50
        val matches999 = findMembersBySttForJump(sampleMembers, targetStt = 999, pageSize = 50)
        assertEquals(2, matches999.size)
        assertEquals(1, matches999[0].targetPage)
        assertEquals(4, matches999[0].indexWithinPage) // 5th item -> index 4 on page 1
        assertEquals(2, matches999[1].targetPage)
        assertEquals(14, matches999[1].indexWithinPage) // 65th item -> index 14 on page 2

        // Jump to non-existent STT
        val missingMatches = findMembersBySttForJump(sampleMembers, targetStt = 7777, pageSize = 50)
        assertTrue(missingMatches.isEmpty())
    }

    @Test
    fun `verify Tracking screen completely excludes members with remainingDays over 15`() {
        val mExpired = createDummyMemberWithTracking("M-1", 1, "HV Hết Hạn", remainingDays = -3, status = MemberTrackingStatus.EXPIRED)
        val mToday = createDummyMemberWithTracking("M-2", 2, "HV Hôm Nay", remainingDays = 0, status = MemberTrackingStatus.EXPIRING_TODAY)
        val mSoon7 = createDummyMemberWithTracking("M-3", 3, "HV 1-7 Ngày", remainingDays = 5, status = MemberTrackingStatus.EXPIRING_1_TO_7)
        val mSoon15 = createDummyMemberWithTracking("M-4", 4, "HV 8-15 Ngày", remainingDays = 15, status = MemberTrackingStatus.EXPIRING_8_TO_15)
        val mOver15 = createDummyMemberWithTracking("M-5", 5, "HV Còn 16 Ngày", remainingDays = 16, status = MemberTrackingStatus.ACTIVE_OVER_15)
        val mOver60 = createDummyMemberWithTracking("M-6", 6, "HV Còn 60 Ngày", remainingDays = 60, status = MemberTrackingStatus.ACTIVE_OVER_15)

        val actionable = filterActionableTrackingMembers(listOf(mExpired, mToday, mSoon7, mSoon15, mOver15, mOver60))
        assertEquals(4, actionable.size)
        assertFalse(actionable.any { it.trackingStatus == MemberTrackingStatus.ACTIVE_OVER_15 })
        assertFalse(actionable.any { it.remainingDays > 15 })
        assertTrue(actionable.any { it.member.hoTen == "HV Hết Hạn" })
        assertTrue(actionable.any { it.member.hoTen == "HV Hôm Nay" })
        assertTrue(actionable.any { it.member.hoTen == "HV 1-7 Ngày" })
        assertTrue(actionable.any { it.member.hoTen == "HV 8-15 Ngày" })
    }

    @Test
    fun `verify Walk-in ticket stepper calculates days and prices for daily and weekly tickets`() {
        val startDate = LocalDateSpec(2026, 11, 7)

        val dailySpec = calculateWalkInStepperSpec(
            loaiVe = LoaiVeKhachLe.NGAY_LE,
            unitCount = 3,
            startDate = startDate
        )
        assertEquals(3, dailySpec.totalDays)
        assertEquals(90_000L, dailySpec.suggestedPrice)
        assertEquals("3 ngày lẻ", dailySpec.suggestedLabel)
        assertEquals(LocalDateSpec(2026, 11, 9), dailySpec.displayedLastTrainingDate)

        val weeklySpec1 = calculateWalkInStepperSpec(
            loaiVe = LoaiVeKhachLe.TUAN_LE,
            unitCount = 1,
            startDate = startDate
        )
        assertEquals(7, weeklySpec1.totalDays)
        assertEquals(150_000L, weeklySpec1.suggestedPrice)
        assertEquals("1 tuần lẻ", weeklySpec1.suggestedLabel)
        assertEquals(LocalDateSpec(2026, 11, 13), weeklySpec1.displayedLastTrainingDate)

        val weeklySpec2 = calculateWalkInStepperSpec(
            loaiVe = LoaiVeKhachLe.TUAN_LE,
            unitCount = 2,
            startDate = startDate
        )
        assertEquals(14, weeklySpec2.totalDays)
        assertEquals(300_000L, weeklySpec2.suggestedPrice)
        assertEquals("2 tuần lẻ", weeklySpec2.suggestedLabel)
        assertEquals(LocalDateSpec(2026, 11, 20), weeklySpec2.displayedLastTrainingDate)
    }

    @Test
    fun `verify Settings categories exclude Tat ca muc and support Vietnamese search`() {
        assertEquals(5, SettingsCategory.entries.size)
        assertFalse(SettingsCategory.entries.any { it.title.contains("Tất cả mục", ignoreCase = true) })

        val driveMatches = searchSettingsEntries("Google Drive")
        assertTrue(driveMatches.any { it.category == SettingsCategory.BACKUP })

        val shaMatches = searchSettingsEntries("SHA-1")
        assertTrue(shaMatches.any { it.category == SettingsCategory.BACKUP })

        val trashMatches = searchSettingsEntries("Thùng rác")
        assertTrue(trashMatches.any { it.category == SettingsCategory.TRASH })
    }

    @Test
    fun `verify Revenue overview has exactly 3 independent categories with standardized terminology`() {
        val categories = com.example.ui.screens.RevenueCategory.entries
        assertEquals(3, categories.size)
        assertEquals("Doanh thu GYM", categories[0].title)
        assertEquals("Xem doanh thu thực thu, doanh thu phân bổ và chi tiết GYM.", categories[0].subtitle)
        assertEquals("Doanh thu YOGA", categories[1].title)
        assertEquals("Xem doanh thu thực thu, doanh thu phân bổ và chi tiết YOGA.", categories[1].subtitle)
        assertEquals("Xuất tài liệu báo cáo", categories[2].title)
        assertEquals("Quản lý và xuất 8 báo cáo PDF A4 và Excel của GYM và YOGA.", categories[2].subtitle)
    }

    private fun createDummyMemberWithTracking(
        id: String,
        stt: Int,
        hoTen: String,
        remainingDays: Int,
        status: MemberTrackingStatus = MemberTrackingStatus.EXPIRING_8_TO_15
    ): MemberWithContractsUi {
        val member = MemberEntity(
            id = id,
            boMon = BoMon.GYM,
            stt = stt,
            hoTen = hoTen,
            soDienThoai = "0901234567",
            loaiKhach = DoiTuong.NAM,
            ngayTao = "2026-11-01"
        )
        val contract = MemberContractEntity(
            id = "C-$id",
            hoiVienId = id,
            boMon = BoMon.GYM,
            loaiBaoCao = LoaiBaoCao.CON_HAN,
            loaiHopDong = LoaiHopDong.DANG_KY_MOI,
            goiTap = "1 tháng",
            ngayDangKy = "2026-11-01",
            ngayBatDau = "2026-11-01",
            ngayKetThucDocQuyen = "2026-12-01",
            soTienHopDong = 250_000L,
            soTienDaThu = 250_000L,
            ngayThanhToan = "2026-11-01",
            trangThaiThanhToan = TrangThaiThanhToan.DA_THANH_TOAN
        )
        return MemberWithContractsUi(
            member = member,
            contracts = listOf(contract),
            payments = emptyList(),
            latestContract = contract,
            startDateDisplay = "01/11/2026",
            registrationDateDisplay = "01/11/2026",
            lastTrainingDateDisplay = "30/11/2026",
            trackingStatus = status,
            remainingDays = remainingDays,
            totalDebt = 0L
        )
    }
}
